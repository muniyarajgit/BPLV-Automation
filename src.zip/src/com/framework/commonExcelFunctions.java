package com.framework;

import static org.junit.Assert.*;

import java.awt.Frame;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;


//import com.application.provision_17;
import com.application.provision_24;

public class commonExcelFunctions extends frameworkParameters {
	//	public static String FilePath = "C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\Copy of 09 - Retail_Generic_Copay_DSC Fields added_v2.xlsx";
	public static String FilePath = frameworkParameters.FilePath;
	public static String strNumberOfTierValue 	= null;
	public static String strsubProcessValue 	= null;
	public static String srtTierType			= null;
	public static String strDollarAmountValue 	= null;
	public static String strNonFormularyAmountValueOrder = null;
	public static String strsteppedCopay 		= null;
	static Cell cell;
	public static XSSFSheet xssfSheet = null;
	static boolean retailtire		  = false;
	public static boolean ExpectedFlag;
	static DataFormatter formatter=new DataFormatter();
	public static String drugListValueID		= null;
	public static String strsubsection2	= null;
	public static String strProvisionLineValue_id	= null;
	public static String druglistName				= null;	
	public static String drugGrouplistName		 = null;
	public static String drugGroupListValueID 	 = null;
	public static boolean drugGrouplist			 = false;
	public static boolean druglist				 = false;
	public static boolean lineValue_Temp = false;
	//	DC Fields
	public static String strDC_Retail_IncExcl_DC 		= null;
	public static String strDC_Retail_IncExcl_1 		= null;
	public static String strDC_ApplyLimit_1 		= null;
	public static String strDC_Retail_DrugListorDrugGroup_1 		= null;
	public static String strDC_Retail_StartAge_1 		= null;
	public static String strDC_Retail_EndAge_1 		= null;
	public static String strDC_Gender_1 		= null;
	public static String strDC_MinDays_1 		= null;
	public static String strDC_DailyDose_1 		= null;
	public static String strDC_StartAgeType_1 		= null;
	public static String strDC_EndAgeType_1 		= null;
	public static String strDC_MaxDays_1 		= null;
	public static String strDC_MaxDaysperfill_1 		= null;
	public static String strDC_DOTTP_1 		= null;
	public static String strDC_DOTDays_1 		= null;
	public static String strDC_DOTTV_1 		= null;
	public static String strDC_QOTQty_1 		= null;
	public static String strDC_QOTTP_1 		= null;
	public static String strDC_QOTTV_1 		= null;
	public static String strDC_MaxFills_1 		= null;
	public static String strDC_MinQty_1 		= null;


	//Accums DSC
	public static String strAccum_DrugSpecific_MAB                      = null;
	public static String strAccum_DrugSpecific_M                        = null;
	public static String strAccum_DrugSpecific_N                        = null;
	public static String strAccum_DrugSpecific_O                        = null;
	public static String strAccum_DrugSpecific_Y                        = null;
	public static String strAccum_DrugSpecific_DL                       = null;
	public static String strAccum_DrugSpecific_DG                       = null;
	public static String strAccum_DrugSpecific_MABAmount                = null;
	public static String strAccum_DrugSpecific_MABPeriod                = null;
	public static String strAccum_DrugSpecific_MABMet                   = null;

	public static boolean DLColorFlag= true;
	public static boolean IncExclDCColorFlag= true;
	public static boolean IncExclColorFlag= true;
	public static boolean DLALFlag= true;

	// Drug Specific Copay
	public static String strDrugSpecificCopay	= null;
	public static String strFormularyGroup 		= null;
	public static String ParentMappingValue	 	= null;
	public static String strM_Value 			= null;
	public static String strN_Value				= null;
	public static String strO_Value				= null;
	public static String strY_Value				= null;
	public static String strDollarAmount_Value	= null;
	public static String strPercent_Value	= null;
	public static String strMinimumDollar_Value	= null;
	public static String strMaximumDollar_Value	= null;
	public static String CRDCopayLogic			= null;
	public static String strReverse			= null;
	
	public static boolean steppedColorFlag= true;
	public static boolean MColorFlag= true;
	public static boolean NColorFlag= true;
	public static boolean OColorFlag= true;
	public static boolean YColorFlag= true;
	public static boolean DollarAmountColorFlag= true;
	public static boolean ReverseColorFlag= true;
	public static boolean MaxdollarColorFlag= true;
	public static boolean PercentColorFlag= true;
	public static boolean MindollarColorFlag= true;
	public static boolean CopaycalcColorFlag= true;
	
	
	
	@SuppressWarnings("resource")
	@Test
	public static String getInputData(String sheetName,String ColName, int RowNum)

	{
		String CellValue="";
		FileInputStream file = null;
		XSSFWorkbook workbook = null;
		try {
			file = new FileInputStream(FilePath);             
			workbook = new XSSFWorkbook(file);
			xssfSheet = workbook.getSheet(sheetName);                
			int ColNum =getColumnContains(xssfSheet,0,ColName);
			CellValue=formatter.formatCellValue(xssfSheet.getRow(RowNum).getCell(ColNum));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return CellValue.trim();

	}
	public static String getReportData(String sheetName,String ColName, int RowNum)


	{
		String CellValue="";
		FileInputStream file = null;
		XSSFWorkbook workbook = null;
		try {
			file = new FileInputStream(provisionSheetPath);             
			workbook = new XSSFWorkbook(file);
			xssfSheet = workbook.getSheet(sheetName);                
			int ColNum =getColumnContains(xssfSheet,0,ColName);
			CellValue=formatter.formatCellValue(xssfSheet.getRow(RowNum).getCell(ColNum));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return CellValue.trim();
	}
	public static int getColumnContains(XSSFSheet xssfsheetname2, int Rownum, String value) throws Exception {

		int a;
		try {

			int columncount=getColumnUsed(xssfsheetname2);
			for ( a=0 ; a<columncount; a++){
				if  (getCellData(xssfsheetname2,Rownum,a).equalsIgnoreCase(value)){
					break;
				}
			}
			return a;
		}catch (Exception e){
			throw(e);
		}
	}
	public static String getCellData(XSSFSheet xssfsheetname2, int RowNum, int ColNum) throws Exception

	{	
		try{
			cell = xssfsheetname2.getRow(RowNum).getCell(ColNum);
			String CellData = formatter.formatCellValue(cell);//cell.getStringCellValue();
			return CellData;

		}
		catch (Exception e)
		{

			return"";

		}

	}
	public static int getColumnUsed(XSSFSheet xssfsheetname2) throws Exception 
	{
		int ColumnCount= xssfsheetname2.getRow(0).getLastCellNum();
		return ColumnCount;
	}
	public static String getCommonData(String sheetName,String ColName, int RowNum)
	{
		String CellValue="";
		FileInputStream file;
		try {
			file = new FileInputStream(InputFilepath);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet xssfSheet = workbook.getSheet(sheetName);
			int ColNum =getColumnContains(xssfSheet,0,ColName);

			FormulaEvaluator formulaEvaluator = workbook.getCreationHelper()
					.createFormulaEvaluator();
			XSSFRow row = xssfSheet.getRow(RowNum);
			XSSFCell cell = row.getCell(ColNum);
			CellValue = getCellValueAsString(cell, formulaEvaluator).trim();
		} catch (Exception e) {
			e.printStackTrace();
		}	           

		return CellValue;
	}
	private static String getCellValueAsString(XSSFCell cell,FormulaEvaluator formulaEvaluator) {
		if (cell == null || cell.getCellType() == XSSFCell.CELL_TYPE_BLANK) {
			return null;
		} else {
			if (formulaEvaluator.evaluate(cell).getCellType() == XSSFCell.CELL_TYPE_ERROR) {
				System.out.println(
						"Error in formula within this cell! " + "Error code: "
								+ cell.getErrorCellValue());
			}
			DataFormatter dataFormatter = new DataFormatter();
			return dataFormatter.formatCellValue(formulaEvaluator
					.evaluateInCell(cell));
		}
	}
	public static void validateLineTextValue()	{
		File strLineTextValue= new File(lineTextValue);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> strProvisionNumber  = new ArrayList<String>();
		ArrayList<String> strLinevalue = new ArrayList<String>();
		ArrayList<String> strLinevaluetext = new ArrayList<String>();
		int row=0;
		try {

			br = new BufferedReader(new FileReader(lineTextValue));
			while ((line = br.readLine()) != null) {
				row++;
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				strProvisionNumber.add(strPosition[2]);
				strLinevalue.add(strPosition[3]);
				strLinevaluetext.add(strPosition[4]);
			}
			for(int PVNmber=0;PVNmber<row;PVNmber++){
				if(strProvisionNumber.get(PVNmber).equalsIgnoreCase(BPLV_Functions.provisionNumber))	{
					if(strLinevalue.get(PVNmber).equalsIgnoreCase(provision_24.pvLineValue))	{
						System.out.println("strLinevaluetext.get(PVNmber) : " + strLinevaluetext.get(PVNmber));
						if(strLinevaluetext.get(PVNmber).trim().contains(BPLV_Functions.Provision_LineText.trim()))		{
							System.out.println("Provision Line value matched");
							strProvisionLineValue_id = BPLV_Functions.Provision_LineText.trim();
							lineValue_Temp=true;
							break;

						}
					}
				}
			}
		}	catch(Exception e){
			e.printStackTrace();
		}

	}

	static ArrayList<String> firstColumnValue  = new ArrayList<String>();
	static ArrayList<String> secondColumnValue = new ArrayList<String>();
	static ArrayList<String> ThirdColumnValue  = new ArrayList<String>();
	static ArrayList<String> fourthColumnValue = new ArrayList<String>();
	static ArrayList<String> fifthColumnValue  = new ArrayList<String>();
	static ArrayList<String> sixthColumnValue  = new ArrayList<String>();
	static ArrayList<String> seventhColumnValue= new ArrayList<String>();
	static ArrayList<String> eighthColumnValue = new ArrayList<String>();
	static ArrayList<String> ninthColumnValue  = new ArrayList<String>();
	static ArrayList<String> tenthColumnValue  = new ArrayList<String>();
	static ArrayList<String> eleventhColumnValue  = new ArrayList<String>();

	static int mappingName=0,mappingValuesName=1,lineValueID=2,provisionValue=4,lineValue=4,objectAPI=5,fieldLabel=6,fieldValue=8,row=0,parentMapping=9,parentMapNotes=10,NotesColumn=11,rowIterator;

	public static void readReportValue()	{
		File csvFile= new File(provisionSheetPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				row++;
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				firstColumnValue.add(strPosition[mappingName]);
				secondColumnValue.add(strPosition[mappingValuesName]);
				ThirdColumnValue.add(strPosition[lineValueID]);
				fourthColumnValue.add(strPosition[provisionValue]);
				fifthColumnValue.add(strPosition[lineValue]);
				sixthColumnValue.add(strPosition[objectAPI]);
				seventhColumnValue.add(strPosition[fieldLabel]);
				/*if(strPosition[fieldValue].contains(""))	{
				System.out.println(strPosition[0]);
			}*/
				eighthColumnValue.add(strPosition[fieldValue]);
				ninthColumnValue.add(strPosition[parentMapping]);
				tenthColumnValue.add(strPosition[parentMapNotes]);
				eleventhColumnValue.add(strPosition[NotesColumn]);
			}	
		}catch 	(Exception e)	{
			e.printStackTrace();
		}
	}


	// To get Parent Mapping Value
	static int formularyIteraor;

	static String parntMappingValueFinal="";
	public static void getparentmapping()	{
		int mIterator = 0;
		//		int formularyIteraor;
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
				if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(drugListValueID))	{
							parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
				}
			}
		}
	}
	public static void getInExDCField_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion Exclusion Drug Class"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_DC  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getInExField_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion/Exclusion"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getApplylimit_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Apply Limitations"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_ApplyLimit_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getStartAge_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_StartAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndAge_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_EndAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getGender_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Gender"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Gender_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMindays_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMinQty_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDailyDose_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Daily Dose"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DailyDose_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getstartagetype_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_StartAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndagetype_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_EndAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDays_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxFills_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Fills"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxFills_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDaysperfill_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Max Days per Fill"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDaysperfill_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTP_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTDays_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: # of Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTV_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTQty_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTP_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTV_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || BPLV_Functions.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getAccumulationsDrugSpecific(){

		 
		for(rowIterator=0;rowIterator<row;rowIterator++){
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue)){
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Accumulations__c")){
					if(tenthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Creates Accumulation - Individual All")){

						if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Are there any drug specific MAB?")){
							if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_MAB)){
								strAccum_DrugSpecific_MAB = eighthColumnValue.get(rowIterator).toString();
							}
						}      
					}
				}      

				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("AccumulationSpecificDrug__c")){

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("M")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_M)){
							strAccum_DrugSpecific_M = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("N")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_N)){
							strAccum_DrugSpecific_N = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("O")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_O)){
							strAccum_DrugSpecific_O = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Y")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_Y)){
							strAccum_DrugSpecific_Y = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Amount")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_MABAmount)){
							strAccum_DrugSpecific_MABAmount = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Period")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_MABPeriod)){
							strAccum_DrugSpecific_MABPeriod = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("What happens when MAB is met?")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.Accum_DrugSpecific_MABMet)){
							strAccum_DrugSpecific_MABMet = eighthColumnValue.get(rowIterator).toString();
						}
					}


					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Drug List")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(drugListValueID.substring(0,15))){

							strAccum_DrugSpecific_DL = eighthColumnValue.get(rowIterator).toString();
						}
					}
				}
			}
		}

	}
	static ArrayList<String> strFormularyIDMappingValue = new ArrayList<String>();
	public static void Validate_DSC()	{
		for(rowIterator=0;rowIterator<row;rowIterator++)	{
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRD__c"))	{
					if(tenthColumnValue.get(rowIterator).toString().contains("Creates CRD"))	{
						if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail")){
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Retail copays?"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC_RetailFieldValue))	{
									strsubsection2 = BPLV_Functions.DSC_RetailFieldValue;
								}
							}
						}
						if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Mail copays?"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC_RetailFieldValue))	{
									strsubsection2 = BPLV_Functions.DSC_RetailFieldValue;
								}
							}
						}
						if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Paper"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper copays?"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC_RetailFieldValue))	{
									strsubsection2 = BPLV_Functions.DSC_RetailFieldValue;
								}
							}
						} 

						if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty copays?"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC_FieldValue))	{
									strsubsection2 = BPLV_Functions.DSC_RetailFieldValue;
								}
							}
						}	
						if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialityOutOfNetwrok"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty OON copays"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC_FieldValue))	{
									strsubsection2 = BPLV_Functions.DSC_RetailFieldValue;
								}
							}
						}
						if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper copays?"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC_FieldValue))	{
									strsubsection2 = BPLV_Functions.DSC_RetailFieldValue;
								}
							}
						}
						if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper Out of Network copays?"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC_FieldValue))	{
									strsubsection2 = BPLV_Functions.DSC_RetailFieldValue;
								}
							}
						}							
					}
				}	
			}
		}
	}

	public static void getFormularyId()	{
							strFormularyIDMappingValue.clear();
		int mIterator = 0;
		//		int formularyIteraor;
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
				if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(BPLV_Functions.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
							strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
							strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
						}
					}
				}
			}
		}
	}
	static int drugIterator;
	static int parentIterator=0;
	//static String parntMappingValueFinal="";
	public static void getParentMappingValue()	{
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
				if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(drugListValueID) ||(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(drugGroupListValueID))){
							parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
							for(int i=0;i<strFormularyIDMappingValue.size();i++)	{
								if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(strFormularyIDMappingValue.get(i)))	{
									parntMappingValueFinal = strFormularyIDMappingValue.get(i);
									break;
								}
							}
						}
					}
				}
			}
		}
	}
	public static void getStepped_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Stepped Copay"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strsteppedCopay  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getM_Value()	{

		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("M"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strM_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getN_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("N"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strN_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getO_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("O"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strO_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;	
							}
						}
					}
				}
			}
	}
	public static void getY_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strY_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDollarAmount_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDollarAmount_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getPercent_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strPercent_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMindollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strMinimumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxdollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strMaximumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getCopaycalc_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								CRDCopayLogic  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getReverse_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+BPLV_Functions.provisionNumber+"L"+provision_24.pvLineValue))	{
					if(BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")))|| BPLV_Functions.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON")))) {
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Reverse"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strReverse = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
		//---------
	public static void findDrugGroupName()	{

		int rowIterator = 0;
		File drugFile= new File(drugListPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> drugGroupID  = new ArrayList<String>();
		ArrayList<String> drugGroupnameValue = new ArrayList<String>();
		ArrayList<String> drugGroupName = new ArrayList<String>();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				drugGroupID.add(strPosition[0]);
				drugGroupnameValue.add(strPosition[1]);
				drugGroupName.add(strPosition[2]);
			}
			for(rowIterator = 0;rowIterator<drugGroupID.size();rowIterator++)	{
				if(drugGroupnameValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC__DrugList.trim()))	{
					drugGrouplistName = drugGroupName.get(rowIterator).toString();
					drugGroupListValueID = drugGroupID.get(rowIterator).toString();
					System.out.println("drugGroupListValueID length : " + drugGroupListValueID.length());
					if(drugGroupListValueID.length()>15){
						drugGroupListValueID = drugGroupListValueID.substring(0,15);
					}
					break;
				}
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}


	public static void findDrugList()	{
		int rowIterator = 0;
		File drugFile= new File(drugListPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> idValue  = new ArrayList<String>();
		ArrayList<String> nameValue = new ArrayList<String>();
		ArrayList<String> drugName = new ArrayList<String>();


		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				idValue.add(strPosition[0]);
				nameValue.add(strPosition[1]);
				drugName.add(strPosition[2]);
			}
			//			System.out.println("BPLV_Functions.DSC__DrugList.trim() : " + BPLV_Functions.DSC__DrugList.trim());
			for(rowIterator = 0;rowIterator<idValue.size();rowIterator++)	{
				if(nameValue.get(rowIterator).toString().equalsIgnoreCase(BPLV_Functions.DSC__DrugList.trim()))	{
					druglistName = drugName.get(rowIterator).toString();
					drugListValueID = idValue.get(rowIterator).toString();
					//drugListValueID = drugListValueID.substring(0,15);
					break;
					//					System.out.println("Drug List value is matched");
				}
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}

	public static boolean CellValue_Comparator(String filename_updated, String sheetname,int row,String col1, String Value2) throws Exception


	{
		{
			FileInputStream file = new FileInputStream(filename_updated);
			@SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet SheetName = workbook.getSheet(sheetname);
			XSSFRow rowhead = SheetName.getRow(row);

			int Col = getColumnContains(SheetName,0,col1);
			Cell cell = SheetName.getRow(row).getCell(Col);

			//String col2= cell.toString();
			if (cell == null)
			{
				cell = rowhead.createCell(Col);
			}
			String value1=null;
			//			col1 = cell.toString();
			if(col1.contains("NumberOfTier") || col1.contains("NumberOfTiers"))		{
				if(cell.toString().contains("Use Copay Logic") || cell.toString().equalsIgnoreCase("Use Copay Logic"))	{
					value1 = commonExcelFunctions.getCommonData("TestData", "NumberOfTier", 1);
				}
			}	else if(col1.contains("TierType") )	{
				if(cell.toString().contains("Use Copay Logic") || cell.toString().equalsIgnoreCase("Use Copay Logic"))	{
					value1 = commonExcelFunctions.getCommonData("TestData", "TierType", 1);
				}
			}	else if(col1.contains("_NonFormularyDollarAmount")||col1.contains("_NonFormularyPercent_")||col1.contains("_NonFormularyAmount_")||col1.contains("_NonFormularyCopayCalculation_")||col1.contains("_NonFormularyMinimumDollar_")||col1.contains("_NonFormularyMaximumDollar_"))	{

				value1 = BPLV_Functions.strcopayNonFormularyValue;

			}
			else if(col1.contains("_DrugList_"))	{

				value1 = commonExcelFunctions.drugListValueID;

			}
			else if(col1.contains("_DrugClass_"))	{
				value1 = BPLV_Functions.DC_Retail_DrugClass_1;
			}	

			else if(col1.contains("_IncExcl_"))	{
				value1 = BPLV_Functions.DC_Retail_IncExcl_1;
			}	

			else if(col1.contains("_ApplyLimit_"))	{
				value1 = BPLV_Functions.DC_ApplyLimit_1;
			}

			else if(col1.contains("_StartAge_"))	{
				value1 = BPLV_Functions.DC_Retail_StartAge_1;
			}	

			else if(col1.contains("_EndAge_"))	{
				value1 = BPLV_Functions.DC_Retail_EndAge_1;
			}	


			else if(col1.contains("_Gender_"))	{
				value1 = BPLV_Functions.DC_Gender_1;
			}	

			else if(col1.contains("_Mindays_"))	{
				value1 = BPLV_Functions.DC_Mindays_1;
			}	

			else if(col1.contains("_Minquantity_"))	{
				value1 = BPLV_Functions.DC_Minquantity_1 ;
			}	

			else if(col1.contains("_DailyDose_"))	{
				value1 = BPLV_Functions.DC_DailyDose_1;
			}	

			else if(col1.contains("_StartAgeType_"))	{
				value1 = BPLV_Functions.DC_Retail_StrtAgeType_1;
			}	

			else if(col1.contains("_EndAgeType_"))	{
				value1 = BPLV_Functions.DC_Retail_EnAgeType_1;
			}	

			else if(col1.contains("_MaxDaysperFill_"))	{
				value1 = BPLV_Functions.DC_Retail_MaxDaysperFill_1;
			}

			else if(col1.contains("_MaxDays_"))	{
				value1 = BPLV_Functions.DC_Retail_MaxDays_1;
			}

			else if(col1.contains("_MaxFills_"))	{
				value1 = BPLV_Functions.DC_Retail_MaxFills_1;
			}

			else if(col1.contains("_DOT_TP_"))	{
				value1 = BPLV_Functions.DC_Retail_DOT1_TP_1;
			}

			else if(col1.contains("_DOT_Days_"))	{
				value1 = BPLV_Functions.DC_Retail_DOT_Days_1;
			}

			else if(col1.contains("_DOT_TV_"))	{
				value1 = BPLV_Functions.DC_Retail_DOT_TV_1;
			}

			else if(col1.contains("_QOT_Qty_"))	{
				value1 = BPLV_Functions.DC_Retail_QOT_Qty_1;
			}

			else if(col1.contains("_QOT_TP_"))	{
				value1 = BPLV_Functions.DC_Retail_QOT_TP_1;
			}

			else if(col1.contains("_QOT_TV_"))	{
				value1 = BPLV_Functions.DC_Retail_QOT_TV_1;
			}
			
			//Accums DSC
		       else if(col1.contains("Accum_DrugSpecific_DL")) {

                   value1 = drugListValueID.substring(0,15);

             }

//DSC
		       else if(col1.contains("_FormularyGroup_"))	{

					value1 = BPLV_Functions.DSC_Retail_FormularyGroup;

				}	else if(col1.contains("_DrugList_"))	{

					value1 = commonExcelFunctions.drugListValueID;

				}	else if(col1.contains("Provision_LineText"))	{

					value1 = BPLV_Functions.Provision_LineText;

				}	else if(col1.contains("_Stepped_"))	{

					value1 = BPLV_Functions.DSC_Retail_Stepped;

				}	else if(col1.contains("_M_"))	{

					value1 = BPLV_Functions.DSC_Retail_M;

				}
				else if(col1.contains("_N_"))	{

					value1 = BPLV_Functions.DSC_Retail_N;

				}
				else if(col1.contains("_O_"))	{

					value1 = BPLV_Functions.DSC_Retail_O;

				}
				else if(col1.contains("_Y_"))	{

					value1 = BPLV_Functions.DSC_Retail_Y;

				}
				else if(col1.contains("_DollarAmount_"))	{

					value1 = BPLV_Functions.DSC_Retail_DollarAmount;

				}
				else if(col1.contains("_Percent_"))	{

					value1 = BPLV_Functions.DSC_Retail_Percent;

				}
				else if(col1.contains("_MinimumDollar_"))	{

					value1 = BPLV_Functions.DSC_Retail_MinimumDollar;

				}
				else if(col1.contains("_MaximumDollar_"))	{

					value1 = BPLV_Functions.DSC_Retail_MaximumDollar;

				}
				else if(col1.contains("_Reverse_"))	{

					value1 = BPLV_Functions.DSC_Retail_Reverse;

				}
				else if(col1.contains("_CopayCalculation_"))	{

					value1 = BPLV_Functions.DSC_Retail_CopayCalculation;

				}
				else if(col1.contains("_SubSectionProcess_2"))	{

					value1 = BPLV_Functions.DSC_RetailFieldValue;

				}
					
			else	{
				value1 = cell.toString();
			}

			if(col1.contains("l_DrugListorDrugGroup_"))	{
				if(druglist== true){
					value1 = commonExcelFunctions.drugListValueID;
					System.out.println("drug list value assigned successfully");
				}
			}

			if (Value2==null)
			{
				Value2 = "";
			}
			
			ArrayList copayNonFormularyValue = new ArrayList();
			cell.setCellType(Cell.CELL_TYPE_STRING);
			if(Value2.equalsIgnoreCase(value1))	{
				final XSSFCellStyle description = (XSSFCellStyle) workbook.createCellStyle();
				description.setFillPattern( XSSFCellStyle.SOLID_FOREGROUND );
				description.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
				description.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				description.setBorderTop(XSSFCellStyle.BORDER_THIN);
				description.setBorderRight(XSSFCellStyle.BORDER_THIN);
				description.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				description.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				cell.setCellStyle(description);
				if(col1.contains("_Stepped_"))	{
					steppedColorFlag = true;
				}
				if(col1.contains("_M_"))	{
					MColorFlag = true;
				}
				if(col1.contains("_N_"))	{
					NColorFlag = true;
				}
				if(col1.contains("_O_"))	{
					OColorFlag = true;
				}
				if(col1.contains("_Y_"))	{
					YColorFlag = true;
				}
				if(col1.contains("_DollarAmount_"))	{
					DollarAmountColorFlag = true;
				}
				if(col1.contains("_Percent_"))	{
					PercentColorFlag = true;
				}
				if(col1.contains("_MinimumDollar_"))	{
					MindollarColorFlag = true;
				}
				if(col1.contains("_MaximumDollar_"))	{
					MaxdollarColorFlag = true;
				}
				if(col1.contains("_CopayCalculation_"))	{
					CopaycalcColorFlag = true;
				}
				if(col1.contains("_Reverse_"))	{
					ReverseColorFlag = true;
				}
			}	else	{
				final XSSFCellStyle description = (XSSFCellStyle) workbook.createCellStyle();
				description.setFillPattern( XSSFCellStyle.SOLID_FOREGROUND );
				description.setFillForegroundColor(IndexedColors.RED.getIndex());
				description.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				description.setBorderTop(XSSFCellStyle.BORDER_THIN);
				description.setBorderRight(XSSFCellStyle.BORDER_THIN);
				description.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				description.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				cell.setCellStyle(description);
				if(col1.contains("_Stepped_"))	{
					steppedColorFlag = false;
				}
				if(col1.contains("_M_"))	{
					MColorFlag = false;
				}
				if(col1.contains("_N_"))	{
					NColorFlag = false;
				}
				if(col1.contains("_O_"))	{
					OColorFlag = false;
				}
				if(col1.contains("_Y_"))	{
					YColorFlag = false;
				}
				if(col1.contains("_DollarAmount_"))	{
					DollarAmountColorFlag = false;
				}
				if(col1.contains("_Percent_"))	{
					PercentColorFlag = false;
				}
				if(col1.contains("_MinimumDollar_"))	{
					MindollarColorFlag = false;
				}
				if(col1.contains("_MaximumDollar_"))	{
					MaxdollarColorFlag = false;
				}
				if(col1.contains("_CopayCalculation_"))	{
					CopaycalcColorFlag = false;
				}
				if(col1.contains("_Reverse_"))	{
					ReverseColorFlag = false;
				}
			}

			file.close();
			FileOutputStream fileOut = new FileOutputStream(filename_updated);
			workbook.write(fileOut);
			//workbook.close();
			fileOut.close();
		}
		return ExpectedFlag;
	}
}
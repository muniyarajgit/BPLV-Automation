package com.framework;

import static org.junit.Assert.*;

import org.junit.Test;

public class frameworkParameters {

	@Test
	public void test() {
		//		System.out.println("Framework Parameter");
	}

	public static String FilePath 				= "C:\\Automation_BPLV\\BPLV_Validation\\DataSheets\\146_Drug Specific Copay_MPR47 - Copy.xlsx";
//	public static String FilePath 				= "C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\009-Retail_Generic_Copay_MPR47_123.xlsx";
	
	public static String InputFilepath 			= "C:\\Automation_BPLV\\BPLV_Validation\\DataSheets\\CommonInputData.xlsx";
	public static String provisionSheetPath		= "C:\\Automation_BPLV\\BPLV_Validation\\DataSheets\\P146.csv";
	public static String provisionSheetPath1	= "C:\\Automation_BPLV\\BPLV_Validation\\DataSheets\\report1519889441912.csv";
	public static String drugListPath			= "C:\\Automation_BPLV\\BPLV_Validation\\DataSheets\\Druglist.csv";
	public static String lineTextValue			= "C:\\Automation_BPLV\\BPLV_Validation\\DataSheets\\ProvisionLineValueText.csv";
	public static String strDrugGroup			= "C:\\Automation_BPLV\\BPLV_Validation\\DataSheets\\DrugGroup.csv";
	
	public static String strProvision_Number	= commonExcelFunctions.getCommonData("TestData", "Provision_Number", 1);
	public static String strProvisionLineValue  = commonExcelFunctions.getCommonData("TestData", "ProvisionLineValue", 1);
	

}

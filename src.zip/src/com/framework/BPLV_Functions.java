package com.framework;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

public class BPLV_Functions extends frameworkParameters {
	private static final String[][] String 				= null;
	public static String provisionNumber 				= null;
	public static String provisionLineValue				= null;
	public static String Provision_LineText 			= null;
	public static String subSection 					= null;
	public static String FieldName						= null;
	public static String strFieldName 					= null;
	//Drug Specific Copay - Speciality Tiers 
	public static String DSC_SpecialtyTiers_1      		= null;	
	public static String DSC_RetailTier;
	public static String DSC_RetailFieldValue 			= null;
	public static String strcopayNonFormularyValue		= null;
	//Expected Provision Report Details
	public static commonExcelFunctions objExcelFunc = new commonExcelFunctions();
	// common Variable
	public static int row;
	public static int Subsection;
	//ExpectedReport Variable declarations
	public static String Rep_provisionNumber 				= null;
	public static String Rep_provisionLineValue				= null;
	public static String Rep_Provision_LineText 			= null;
	public static String Rep_subSection 					= null;
	public static String Rep_FieldName						= null;
	public static String Rep_planTypeRetailFieldValue_1		= null;
	public static String Rep_NumberOfTiers_1				= null;
	public static String Rep_CopayToPaper_1					= null;
	public static String Rep_TierType_1 					= null;
	public static String Rep_CRDCopayLogic_1				= null;
	public static String Rep_DollarAmount_1					= null;
	public static String Rep_Percent_1 						= null;
	public static String Rep_CoPayCalculation_1				= null;
	public static String Rep_MinimunDollar_1				= null;
	public static String Rep_MaximumDollar_1				= null;
	public static String Rep_NonFormularyDollarAmount_1		= null;
	public static String Rep_NonFormularyPercent_1			= null;
	public static String Rep_NonFormularyCopayCalculation_1 = null;
	public static String Rep_NonFormularyMinimumDollar_1	= null;
	public static String Rep_NonFormularyMaximumDollar_1	= null;
	//
	public static XSSFSheet xssfSheet = null;
	//
	public static String strNumberOfTierValue 			 = null;
	public static String strsubProcessValue 	 		 = null;
	public static String srtTierType			 		 = null;
	public static String strDollarAmountValue 			 = null;
	public static String strNonFormularyAmountValueOrder = null;

	public static String subsectionProcessType_Value	 = null;
	public static String DSC_FieldValue					 = null;
	public static String strCRDCopayLogic 				 = null;
	public static String DSC__DrugList					 = null;
	//public static String DC__DrugList					 = null;
	public static String planTypePaperFieldValue    	 = null;
	public static String dsc_Subsection					 = null;
	public static String strProvisionLineValue_id		 = null;
	public static int rowCount;
	public static String DSC__DrugListSelection			 = null;
	public static ArrayList arr_ProvisionLineValue =  new ArrayList();
	public static ArrayList arrRowValue = new ArrayList();
	//Jayashree
	public static String DC_Retail_DrugListorDrugGroup_1 		= null; 
	public static String DC__DrugListDrugGroupSelection_1		= null; 

	public static String DC_Retail_DrugClass_1 		= null;
	public static String DC_Retail_IncExcl_1 		= null;
	public static String DC_ApplyLimit_1 			= null;
	public static String DC_Retail_StartAge_1 		= null;
	public static String DC_Retail_EndAge_1 		= null;
	public static String DC_Gender_1 				= null;
	public static String DC_Mindays_1 				= null;
	public static String DC_Minquantity_1 			= null;
	public static String DC_DailyDose_1 			= null;
	public static String DC_Retail_StrtAgeType_1 	= null;
	public static String DC_Retail_EnAgeType_1 		= null;
	public static String DC_Retail_Day_QuantityRule_1= null;
	public static String DC_Retail_MaxDaysperFill_1 = null;
	public static String DC_Retail_MaxDays_1 		= null;
	public static String DC_Retail_MaxFills_1 		= null;
	public static String DC_Retail_DOT1_TP_1 		= null;
	public static String DC_Retail_DOT_Days_1		= null;
	public static String DC_Retail_DOT_TV_1			= null;
	public static String DC_Retail_MaxQtyperFill_1 	= null;
	public static String DC_Retail_QOT_Qty_1 		= null;
	public static String DC_Retail_QOT_TP_1 		= null;
	public static String DC_Retail_QOT_TV_1 		= null;
	public static String DC_Retail_BypassMOOP_1 	= null;
	
	//Accums specific DSC
	public static String Accum_DrugSpecific_MAB    	  = null;
	public static String Accum_DrugSpecific_M      	  = null;
	public static String Accum_DrugSpecific_N      	  = null;
	public static String Accum_DrugSpecific_O      	  = null;
	public static String Accum_DrugSpecific_Y         = null;
	public static String Accum_DrugSpecific_DL        = null;
	public static String Accum_DrugSpecific_DG  	  = null;
	public static String Accum_DrugSpecific_MABAmount = null;
	public static String Accum_DrugSpecific_MABPeriod = null;
	public static String Accum_DrugSpecific_MABMet    = null;
//

	public static String tempsubsec = "";
	public static String tempDLid = "";
	public static String tempIncExcl = "";
	public static String tempIncExclDC = "";
	public static String tempApplylimit = "";
	public static String tempStartAge = "";
	public static String tempEndAge = "";
	public static String tempGender = "";
	public static String tempMindays = "";
	public static String tempMinquantity = "";
	public static String tempDailyDose = "";
	public static String tempStartAgeType = "";
	public static String tempEndAgeType = "";
	public static String tempDay_QuantityRule = "";
	public static String tempMaxDaysperFill = "";
	public static String tempMaxDays = "";
	public static String tempMaxFills = "";
	public static String tempDOT_TP = "";
	public static String tempDOT_Days = "";
	public static String tempDOT_TV = "";
	public static String tempMaxQtyperFill = "";
	public static String tempQOT_Qty = "";
	public static String tempQOT_TP = "";
	public static String tempQOT_TV = "";
	public static String tempBypassMOOP = "";
	
	//DSC
	public static String tempStepped = "";
	public static String tempM = "";
	public static String tempN = "";
	public static String tempO = "";
	public static String tempY = "";
	public static String tempDollarAmount = "";
	public static String tempPercentAmount = "";
	public static String tempMindollar = "";
	public static String tempMaxdollar = "";
	public static String tempCopayCalc = "";
	public static String tempReverse = "";
	
	// Drug Specific CoPay - Retail Tiers 
	public static String DSC_Retail_FormularyGroup = null;
	public static String DSC_Retail_DrugList 	   = null;
	public static String DSC_Retail_Stepped 	   = null;
	public static String DSC_Retail_M 	   		   = null;
	public static String DSC_Retail_N 	  		   = null;
	public static String DSC_Retail_O 	   		   = null;
	public static String DSC_Retail_Y 	   		   = null;
	public static String DSC_Retail_DollarAmount   = null;
	public static String DSC_Retail_Percent 	   = null;
	public static String DSC_Retail_CopayCalculation= null;
	public static String DSC_Retail_MinimumDollar  = null;
	public static String DSC_Retail_MaximumDollar  = null;
	public static String DSC_Retail_Reverse 	   = null;
		


	@Test
	public static void getProvisionNumber()		{
		provisionNumber = commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", 1);
		System.out.println("provisionNumber"+provisionNumber);
	}
	public static void getProvisionLineValue() throws Exception	{
		commonExcelFunctions objExcelFunc = new commonExcelFunctions();
		Loop:
			for(row =2;row<objExcelFunc.xssfSheet.getLastRowNum();row++)	{
				if(commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", row).equalsIgnoreCase("Expected Line Value"))	{

					for(row= row+1;rowCount<objExcelFunc.xssfSheet.getLastRowNum();row++)	{
						if(commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", row).equalsIgnoreCase("")||commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", row).equalsIgnoreCase(null))	{
							break Loop;
						}	else	{
							arr_ProvisionLineValue.add(commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", row));
							arrRowValue.add(row);
							continue;
							/*if(strProvisionLineValue.equalsIgnoreCase(provisionLineValue))	{
							strProvisionLineValue = provisionLineValue;
							continue;
						}*/
						}
					}
				}
			}
	}
	public static void getProvisionLineText(int row) throws Exception	{

		Provision_LineText = commonExcelFunctions.getInputData("Sheet 1", "Provision_LineText", row);
		System.out.println("Provision_LineText : " + Provision_LineText);
		commonExcelFunctions.validateLineTextValue();
		if(commonExcelFunctions.lineValue_Temp == true){
			Thread.sleep(2000);
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row,"Provision_LineText",commonExcelFunctions.strProvisionLineValue_id);
			System.out.println("Comparision completed");
		}
	}
	public static void getTabName()	{
		commonExcelFunctions objExcelFunc = new commonExcelFunctions();
		for(Subsection= 0;Subsection<objExcelFunc.xssfSheet.getLastRowNum();Subsection++)	{
			subSection = commonExcelFunctions.getInputData("Sheet 1", "Tab_Name", Subsection);
			if(subSection.trim().equalsIgnoreCase("Subsection"))	{
				break;
			}
		}
	}
	public static void getSubSectionAndFieldName(String processType, int row)	{

		if(processType.equalsIgnoreCase("1"))	{
			subSection = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection);
			FieldName = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection+1);
		}	else if(processType.equalsIgnoreCase("2"))	{
			subSection = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection);
			strFieldName = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection+1);
		}
		DSC_RetailTier = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, row);
		System.out.println("DSC_RetailTier : " + DSC_RetailTier);
		System.out.println("subSection : " + subSection);
		System.out.println("FieldName : " + FieldName);
	}

public static String DC_Retail_DrugList_1 = "";	
	public static void getDrugCoverageDetails(String subsectionProcessType, String process, String value, int row) throws Exception	{
		// Read Values from Template
		subsectionProcessType_Value = process;
//		dsc_Subsection 		   				 = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_1", row);
		DC_Retail_DrugListorDrugGroup_1 	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugListorDrugGroup_"+value, row);
		DC_Retail_DrugList_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugList_"+value, row);
		DC_Retail_DrugClass_1			 	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugClass_"+value, row);
		DC_Retail_IncExcl_1 	 			 = commonExcelFunctions.getInputData("Sheet 1", process+"_IncExcl_"+value, row);
		DC_ApplyLimit_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_ApplyLimit_"+value, row);
		DC_Retail_StartAge_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_StartAge_"+value, row);
		DC_Retail_EndAge_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_EndAge_"+value, row);
		DC_Gender_1 						 = commonExcelFunctions.getInputData("Sheet 1", process+"_Gender_"+value, row);
		DC_Mindays_1 						 = commonExcelFunctions.getInputData("Sheet 1", process+"_Mindays_"+value, row);
		DC_Minquantity_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_Minquantity_"+value, row);
		DC_DailyDose_1 						 = commonExcelFunctions.getInputData("Sheet 1", process+"_DailyDose_"+value, row);
		DC_Retail_StrtAgeType_1				 = commonExcelFunctions.getInputData("Sheet 1", process+"_StartAgeType_"+value, row);
		DC_Retail_EnAgeType_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_EndAgeType_"+value, row);
		DC_Retail_Day_QuantityRule_1 		 = commonExcelFunctions.getInputData("Sheet 1", process+"_Day_QuantityRule_"+value, row);
		DC_Retail_MaxDaysperFill_1 			 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxDaysperFill_"+value, row);
		DC_Retail_MaxDays_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxDays_"+value, row);
		DC_Retail_MaxFills_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxFills_"+value, row);
		DC_Retail_DOT1_TP_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DOT_TP_"+value, row);
		DC_Retail_DOT_Days_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DOT_Days_"+value, row);
		DC_Retail_DOT_TV_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_DOT_TV_"+value, row);
		DC_Retail_MaxQtyperFill_1 			 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxQtyperFill_"+value, row);
		DC_Retail_QOT_Qty_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_QOT_Qty_"+value, row);
		DC_Retail_QOT_TP_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_QOT_TP_"+value, row);
		DC_Retail_QOT_TV_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_QOT_TV_"+value, row);
		DC_Retail_BypassMOOP_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_BypassMOOP_"+value, row);


		//Split and store values in array
		tempsubsec = DC_Retail_DrugListorDrugGroup_1;
		tempDLid = DC_Retail_DrugList_1;
		tempIncExclDC = DC_Retail_DrugClass_1;
		tempIncExcl = DC_Retail_IncExcl_1;
		tempApplylimit= DC_ApplyLimit_1;
		tempStartAge= DC_Retail_StartAge_1;
		tempEndAge = DC_Retail_EndAge_1; 
		tempGender= DC_Gender_1; 
		tempMindays = DC_Mindays_1;
		tempMinquantity= DC_Minquantity_1 ;
		tempDailyDose =  DC_DailyDose_1 ;
		tempStartAgeType = DC_Retail_StrtAgeType_1 ;
		tempEndAgeType = DC_Retail_EnAgeType_1 ;
		tempDay_QuantityRule =  DC_Retail_Day_QuantityRule_1 ;
		tempMaxDaysperFill = DC_Retail_MaxDaysperFill_1 ;
		tempMaxDays = DC_Retail_MaxDays_1;		
		tempMaxFills = DC_Retail_MaxFills_1;
		tempDOT_TP = DC_Retail_DOT1_TP_1;
		tempDOT_Days = DC_Retail_DOT_Days_1;
		tempDOT_TV = DC_Retail_DOT_TV_1;
		tempMaxQtyperFill = DC_Retail_MaxQtyperFill_1;
		tempQOT_Qty = DC_Retail_QOT_Qty_1;
		tempQOT_TP = DC_Retail_QOT_TP_1;
		tempQOT_TV = DC_Retail_QOT_TV_1;
		tempBypassMOOP = DC_Retail_BypassMOOP_1;		 


		if(!DC_Retail_DrugListorDrugGroup_1.equalsIgnoreCase(""))	{
			String[] DrugListSel = DC_Retail_DrugListorDrugGroup_1.split("\n");
			String[] DrugListID = DC_Retail_DrugList_1.split("\n");
			commonExcelFunctions.readReportValue();
			for(int i=0;i<DrugListSel.length;i++) {
				if(DrugListSel[i].equalsIgnoreCase("Drug List")) {
					DSC__DrugList = DrugListID[i];
					commonExcelFunctions.findDrugList();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugList_"+value, commonExcelFunctions.drugListValueID);
					System.out.println("<<< Drug List value is matched>>>>");
					commonExcelFunctions.getparentmapping();
					/*if(DC__DrugListDrugGroupSelection_1.equalsIgnoreCase("Drug Group"))	{
						commonExcelFunctions.findDrugGroupName();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug Group");
					}*/
					if(!DC_Retail_DrugClass_1.equalsIgnoreCase(""))	
					{
						String[] IncExcl_DC = tempIncExclDC.split("\n");
						DC_Retail_DrugClass_1 = IncExcl_DC[i];
						commonExcelFunctions.getInExDCField_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugClass_"+value, commonExcelFunctions.strDC_Retail_IncExcl_DC);
						System.out.println("<<< Inclusion Exclusion Drug Class value is matched>>>>");
					}
					if(!DC_Retail_IncExcl_1.equalsIgnoreCase(""))	
					{
						String[] IncExcl = tempIncExcl.split("\n");
						DC_Retail_IncExcl_1 = IncExcl[i];
						commonExcelFunctions.getInExField_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_IncExcl_"+value, commonExcelFunctions.strDC_Retail_IncExcl_1);
						System.out.println("<<< Inclusion Exclusion value is matched>>>>");
					}
					if(!DC_ApplyLimit_1.equalsIgnoreCase(""))	
					{
						String[] ApplyLimit = tempApplylimit.split("\n");
						DC_ApplyLimit_1 = ApplyLimit[i];
						commonExcelFunctions.getApplylimit_Value();
						Thread.sleep(3000);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_ApplyLimit_"+value, commonExcelFunctions.strDC_ApplyLimit_1);
						System.out.println("<<<  Apply Limitations value is matched>>>>");


					}
					if(!DC_Retail_StartAge_1.equalsIgnoreCase(""))	
					{
						String[] StartAge = tempStartAge.split("\n");
						DC_Retail_StartAge_1 = StartAge[i];
						commonExcelFunctions.getStartAge_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_StartAge_"+value, commonExcelFunctions.strDC_Retail_StartAge_1);
						System.out.println("<<<  Start Age value is matched>>>>");


					}
					if(!DC_Retail_EndAge_1.equalsIgnoreCase(""))	
					{
						String[] EndAge = tempEndAge.split("\n");
						DC_Retail_EndAge_1  = EndAge[i];
						commonExcelFunctions.getEndAge_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_EndAge_"+value, commonExcelFunctions.strDC_Retail_EndAge_1);
						System.out.println("<<<  End Age value is matched>>>>");
					}
					if(!DC_Gender_1.equalsIgnoreCase(""))	
					{
						String[] Gender = tempGender.split("\n");
						DC_Gender_1   = Gender[i];
						commonExcelFunctions.getGender_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Gender_"+value, commonExcelFunctions.strDC_Gender_1);
						System.out.println("<<<  Gender value is matched>>>>");
					}
					if(!DC_Mindays_1.equalsIgnoreCase(""))	
					{
						String[] Mindays = tempMindays.split("\n");
						DC_Mindays_1   = Mindays[i];
						commonExcelFunctions.getMindays_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Mindays_"+value, commonExcelFunctions.strDC_MinDays_1);
						System.out.println("<<<  Gender value is matched>>>>");
					}
					if(!DC_Minquantity_1.equalsIgnoreCase(""))	
					{
						String[] Minquantity = tempMinquantity.split("\n");
						DC_Minquantity_1    = Minquantity[i];
						commonExcelFunctions.getMindays_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Minquantity_"+value, commonExcelFunctions.strDC_MinQty_1);
						System.out.println("<<<  Minimum quantity value is matched>>>>");
					}
					if(!DC_DailyDose_1.equalsIgnoreCase(""))	
					{
						String[] DailyDose = tempDailyDose.split("\n");
						DC_DailyDose_1     = DailyDose[i];
						commonExcelFunctions.getDailyDose_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DailyDose_"+value, commonExcelFunctions.strDC_DailyDose_1);
						System.out.println("<<<  Daily Dose value is matched>>>>");
					}
					if(!DC_Retail_StrtAgeType_1.equalsIgnoreCase(""))	
					{
						String[] StartAgeType = tempStartAgeType.split("\n");
						DC_Retail_StrtAgeType_1      = StartAgeType[i];
						commonExcelFunctions.getstartagetype_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_StartAgeType_"+value, commonExcelFunctions.strDC_StartAgeType_1);
						System.out.println("<<< StartAgeType value is matched>>>>");
					}
					if(!DC_Retail_EnAgeType_1.equalsIgnoreCase(""))	
					{
						String[] EndAgeType =  tempEndAgeType.split("\n");
						DC_Retail_EnAgeType_1       = EndAgeType[i];
						commonExcelFunctions.getEndagetype_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_EndAgeType_"+value, commonExcelFunctions.strDC_StartAgeType_1);
						System.out.println("<<< EndAgeType value is matched>>>>");
					}
					if(!DC_Retail_MaxDays_1.equalsIgnoreCase(""))	
					{
						String[] MaxDays =   tempMaxDays.split("\n");
						DC_Retail_MaxDays_1       = MaxDays[i];
						commonExcelFunctions.getMaxDays_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaxDays_"+value, commonExcelFunctions.strDC_MaxDays_1);
						System.out.println("<<< Maximum Days value is matched>>>>");
					}
					if(!DC_Retail_MaxFills_1.equalsIgnoreCase(""))	
					{
						String[] MaxFills =    tempMaxFills.split("\n");
						DC_Retail_MaxFills_1       = MaxFills[i];
						commonExcelFunctions.getMaxFills_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaxFills_"+value, commonExcelFunctions.strDC_MaxFills_1);
						System.out.println("<<< Maximum Fills value is matched>>>>");
					}
					if(!DC_Retail_MaxDaysperFill_1.equalsIgnoreCase(""))	
					{
						String[] MaxDaysperFill =    tempMaxDaysperFill.split("\n");
						DC_Retail_MaxDaysperFill_1       = MaxDaysperFill[i];
						commonExcelFunctions.getMaxDaysperfill_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaxDaysperFill_"+value, commonExcelFunctions.strDC_MaxDaysperfill_1);
						System.out.println("<<< Maximum Days per Fill value is matched>>>>");
					}
					if(!DC_Retail_DOT1_TP_1.equalsIgnoreCase(""))	
					{
						String[] DOT_TP =    tempMaxDaysperFill.split("\n");
						DC_Retail_DOT1_TP_1       = DOT_TP[i];
						commonExcelFunctions.getDOTTP_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DOT_TP_"+value, commonExcelFunctions.strDC_DOTTP_1);
						System.out.println("<<< DOT Time period value is matched>>>>");
					}
					if(!DC_Retail_DOT_Days_1.equalsIgnoreCase(""))	
					{
						String[] DOT_Days =    tempDOT_Days.split("\n");
						DC_Retail_DOT_Days_1       = DOT_Days[i];
						commonExcelFunctions.getDOTTP_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DOT_Days_"+value, commonExcelFunctions.strDC_DOTDays_1);
						System.out.println("<<< DOT Days value is matched>>>>");
					}
					if(!DC_Retail_DOT_TV_1.equalsIgnoreCase(""))	
					{
						String[] DOT_TV =    tempDOT_TV.split("\n");
						DC_Retail_DOT_TV_1       = DOT_TV[i];
						commonExcelFunctions.getDOTTV_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DOT_TV_"+value, commonExcelFunctions.strDC_DOTTV_1);
						System.out.println("<<< DOT Timevalue value is matched>>>>");
					}
					if(!DC_Retail_QOT_Qty_1.equalsIgnoreCase(""))	
					{
						String[] QOT_Qty =    tempQOT_Qty.split("\n");
						DC_Retail_QOT_Qty_1       = QOT_Qty[i];
						commonExcelFunctions.getQOTQty_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_QOT_Qty_"+value, commonExcelFunctions.strDC_QOTQty_1);
						System.out.println("<<< QOT Quantity value is matched>>>>");
					}
					if(!DC_Retail_QOT_TP_1.equalsIgnoreCase(""))	
					{
						String[] QOT_TP =     tempQOT_TP.split("\n");
						DC_Retail_QOT_TP_1       = QOT_TP[i];
						commonExcelFunctions.getQOTTP_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_QOT_TP_"+value, commonExcelFunctions.strDC_QOTTP_1);
						System.out.println("<<< QOT Time period value is matched>>>>");
					}
					if(!DC_Retail_QOT_TV_1.equalsIgnoreCase(""))	
					{
						String[] QOT_TV =     tempQOT_TV.split("\n");
						DC_Retail_QOT_TV_1       = QOT_TV[i];
						commonExcelFunctions.getQOTTV_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_QOT_TV_"+value, commonExcelFunctions.strDC_QOTTV_1);
						System.out.println("<<< QOT Time value is matched>>>>");
					}
				}
				
       


				}
			}

		}
	
	

public static void getAccumulationsDrugSpecific(String Accum, int row) throws Exception  {
           
           Accum_DrugSpecific_MAB                                 = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_MAB", row);
           Accum_DrugSpecific_M                                   = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_M", row);
           Accum_DrugSpecific_N                                   = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_N", row);
           Accum_DrugSpecific_O                                   = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_O", row);
           Accum_DrugSpecific_Y                                   = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_Y", row);
           Accum_DrugSpecific_DL                                  = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_DL", row);
           Accum_DrugSpecific_DG                                  = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_DG", row);
           Accum_DrugSpecific_MABAmount                           = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_MABAmount", row);
           Accum_DrugSpecific_MABPeriod                           = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_MABPeriod", row);
           Accum_DrugSpecific_MABMet                              = commonExcelFunctions.getInputData("Sheet 1", "Accum_DrugSpecific_MABMet", row);
                                             
           DSC__DrugList = Accum_DrugSpecific_DL;
           
           commonExcelFunctions.findDrugList();
           commonExcelFunctions.getAccumulationsDrugSpecific();
                                          
           
           Thread.sleep(1000);
           if(!Accum_DrugSpecific_MAB.equalsIgnoreCase("")){
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_MAB", commonExcelFunctions.strAccum_DrugSpecific_MAB);
                  System.out.println("Are there any drug specific MAB?  is matched");
           }
           
           Thread.sleep(1000);
           if(!Accum_DrugSpecific_M.equalsIgnoreCase("")){
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_M", commonExcelFunctions.strAccum_DrugSpecific_M);
                  System.out.println("Accum Drug Specific- M  is matched");
           }
           
           Thread.sleep(1000);
           if(!Accum_DrugSpecific_N.equalsIgnoreCase("")){
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_N", commonExcelFunctions.strAccum_DrugSpecific_N);
                  System.out.println("Accum Drug Specific- N  is matched");
           }
           
           Thread.sleep(1000);
           if(!Accum_DrugSpecific_O.equalsIgnoreCase("")){
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_O", commonExcelFunctions.strAccum_DrugSpecific_O);
                  System.out.println("Accum Drug Specific- O  is matched");
           }
           
           Thread.sleep(1000);
           if(!Accum_DrugSpecific_Y.equalsIgnoreCase("")){
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_Y", commonExcelFunctions.strAccum_DrugSpecific_Y);
                  System.out.println("Accum Drug Specific- Y  is matched");
           }
           
       
           if(!Accum_DrugSpecific_MABAmount.equalsIgnoreCase("")){
        	   Thread.sleep(3000);
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_MABAmount", commonExcelFunctions.strAccum_DrugSpecific_MABAmount);
                  System.out.println("MAB Amount  is matched");
           }
           
          
           if(!Accum_DrugSpecific_MABPeriod.equalsIgnoreCase("")){
        	   Thread.sleep(3000);
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_MABPeriod", commonExcelFunctions.strAccum_DrugSpecific_MABPeriod);
                  System.out.println("MAB Period  is matched");
           }
          
           if(!Accum_DrugSpecific_MABMet.equalsIgnoreCase("")){
        	   Thread.sleep(3000);
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_MABMet", commonExcelFunctions.strAccum_DrugSpecific_MABMet);
                  System.out.println("What happens when MAB is met? is matched");
           }
           
            if(!Accum_DrugSpecific_DL.equalsIgnoreCase("")){
        	   Thread.sleep(3000);                  
                  commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "Accum_DrugSpecific_DL", commonExcelFunctions.strAccum_DrugSpecific_DL);
                  System.out.println("Accum Drug Specific- Drug List is matched");
           }
           
}          

            //Drug specific copay
public static void getDrugSpecificCopayDetails( String subsectionProcessType, String process, String value, int row) throws Exception	{
	subsectionProcessType_Value = process;
	//if (subSection.equalsIgnoreCase("Drug Specific Copay"))	{
	if((subsectionProcessType.equalsIgnoreCase("Retail Tiers")) || (subsectionProcessType.equalsIgnoreCase("Specialty Tiers")) || (subsectionProcessType.equalsIgnoreCase("Specialty Out of Network"))||(subsectionProcessType.equalsIgnoreCase("Paper Tiers"))||(subsectionProcessType.equalsIgnoreCase("Paper Out of Network")) || (subsectionProcessType.equalsIgnoreCase("Mail Tiers"))) 	{
		if(subsectionProcessType.equalsIgnoreCase("Retail Tiers") || subsectionProcessType.equalsIgnoreCase("Paper Tiers") || subsectionProcessType.equalsIgnoreCase("Mail Tiers"))	{
			DSC_Retail_FormularyGroup 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_FormularyGroup_"+value, row);
		}
		if(subsectionProcessType.equalsIgnoreCase("Specialty Tiers") || (subsectionProcessType.equalsIgnoreCase("Specialty Out of Network")))	{
			DSC__DrugList  		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugList_"+value, row);
			DSC_Retail_FormularyGroup 	   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_FormularyGroup_"+value, row);
			DSC_Retail_DrugList		 		 = commonExcelFunctions.getInputData("Sheet 1", process+"_SpecialtyTiers_"+value, row);
		}
		dsc_Subsection 		   				 = commonExcelFunctions.getInputData("Sheet 1", process+"SubSectionProcess_"+value, row);
		DSC__DrugList  		   				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugList_"+value, row);
		DSC__DrugListSelection	   			 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugListSelection_"+value, row);
		DSC_FieldValue	 		 		  	 = commonExcelFunctions.getInputData("Sheet 1", process+"_"+value, row);
		DSC_RetailFieldValue	 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_SubSectionProcess_2", row);
		DSC_Retail_Stepped		 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_Stepped_"+value, row);
		DSC_Retail_M		 		  	 	 = commonExcelFunctions.getInputData("Sheet 1", process+"_M_"+value, row);
		DSC_Retail_N		 		   		 = commonExcelFunctions.getInputData("Sheet 1", process+"_N_"+value, row);
		DSC_Retail_O		 		   		 = commonExcelFunctions.getInputData("Sheet 1", process+"_O_"+value, row);
		DSC_Retail_Y		 		   		 = commonExcelFunctions.getInputData("Sheet 1", process+"_Y_"+value, row);
		DSC_Retail_DollarAmount		 	   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DollarAmount_"+value, row);
		DSC_Retail_Percent		 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_Percent_"+value, row);
		DSC_Retail_CopayCalculation		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_CopayCalculation_"+value, row);
		DSC_Retail_MinimumDollar		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_MinimumDollar_"+value, row);
		DSC_Retail_MaximumDollar		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaximumDollar_"+value, row);
		DSC_Retail_Reverse		 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_Reverse_"+value, row);
		String value2 = "";
		commonExcelFunctions.readReportValue();
		commonExcelFunctions.Validate_DSC();
		if(!DSC_RetailFieldValue.equalsIgnoreCase("")){
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_SubSectionProcess_2",commonExcelFunctions.strsubsection2);
		}
		tempStepped = DSC_Retail_Stepped;
		tempM = DSC_Retail_M;
		tempN = DSC_Retail_N;
		tempO = DSC_Retail_O;
		tempY = DSC_Retail_Y;
		tempDollarAmount = DSC_Retail_DollarAmount;
		tempPercentAmount = DSC_Retail_Percent;
		tempMindollar = DSC_Retail_MinimumDollar;
		tempMaxdollar = DSC_Retail_MaximumDollar;
		tempCopayCalc = DSC_Retail_CopayCalculation;
		tempReverse = DSC_Retail_Reverse;
		
		String[] data = DSC_Retail_FormularyGroup.split("\n");
		for(int i=0;i<data.length;i++)	{
			value2 = value2.trim().replaceAll("\\s", "")+data[i].trim().replaceAll("\\s", "")+";";
		}
		DSC_Retail_FormularyGroup = value2;
		if(DSC_Retail_FormularyGroup.endsWith(";"))	{
			DSC_Retail_FormularyGroup = DSC_Retail_FormularyGroup.substring(0,DSC_Retail_FormularyGroup.length()-1).trim();
		}
	}

	commonExcelFunctions.getFormularyId();
	if(!DSC__DrugListSelection.equalsIgnoreCase(""))	
	{
		String[] DrugListSel = DSC__DrugListSelection.split("\n");
		String[] DrugListID = DSC__DrugList.split("\n");
		for(int i=0;i<DrugListSel.length;i++) {
			if(DrugListSel[i].equalsIgnoreCase("Drug List")) {
				DSC__DrugList = DrugListID[i];
				commonExcelFunctions.findDrugList();
				commonExcelFunctions.getParentMappingValue();
			}
			else if(DrugListSel[i].equalsIgnoreCase("Drug Group")) {
				DSC__DrugList = DrugListID[i];
				commonExcelFunctions.findDrugGroupName();
				commonExcelFunctions.getParentMappingValue();
			}
				//No change

				if(!DSC__DrugList.equalsIgnoreCase(""))	{
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugList_"+value,commonExcelFunctions.drugListValueID);
					Thread.sleep(100);
				}
				if(!DSC_Retail_FormularyGroup.equalsIgnoreCase("")){
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_FormularyGroup_"+value,commonExcelFunctions.strDrugSpecificCopay);
					Thread.sleep(200);
				}
				if(!tempStepped.equalsIgnoreCase(""))	
				{
					String[] DSC_Stepped = tempStepped.split("\n");
					DSC_Retail_Stepped = DSC_Stepped[i];
					commonExcelFunctions.getStepped_Value();
					if(commonExcelFunctions.steppedColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Stepped_"+value,commonExcelFunctions.strsteppedCopay);
						Thread.sleep(100);
					}
				}
				if(!tempM.equalsIgnoreCase(""))	
				{
					String[] DSC_M = tempM.split("\n");
					DSC_Retail_M = DSC_M[i];
					commonExcelFunctions.getM_Value();
					if(commonExcelFunctions.MColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_M_"+value,commonExcelFunctions.strM_Value);
						Thread.sleep(100);
					}
				}
				Thread.sleep(100);
				if(!tempN.equalsIgnoreCase(""))	
				{
					String[] DSC_N = tempN.split("\n");
					DSC_Retail_N = DSC_N[i];
					commonExcelFunctions.getN_Value();
					if(commonExcelFunctions.NColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_N_"+value,commonExcelFunctions.strN_Value);
					}
					Thread.sleep(100);
				}

				if(!tempO.equalsIgnoreCase(""))	
				{
					String[] DSC_O = tempO.split("\n");
					DSC_Retail_O = DSC_O[i];
					commonExcelFunctions.getO_Value();
					if(commonExcelFunctions.OColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_O_"+value,commonExcelFunctions.strO_Value);
						Thread.sleep(100);
					}
				}
				if(!tempY.equalsIgnoreCase(""))	
				{
					String[] DSC_Y = tempY.split("\n");
					DSC_Retail_Y = DSC_Y[i];
					commonExcelFunctions.getY_Value();
					if(commonExcelFunctions.YColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Y_"+value,commonExcelFunctions.strY_Value);
						Thread.sleep(100);
					}
				}
				if(!tempDollarAmount.equalsIgnoreCase(""))  
				{
					String[] DSC_Dollar = tempDollarAmount.split("\n");
					DSC_Retail_DollarAmount = DSC_Dollar[i];
					commonExcelFunctions.getDollarAmount_Value();
					if(commonExcelFunctions.DollarAmountColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DollarAmount_"+value,commonExcelFunctions.strDollarAmount_Value);
						Thread.sleep(100);
					}
				}
				if(!tempPercentAmount.equalsIgnoreCase(""))  
				{
					String[] DSC_Percent = tempPercentAmount.split("\n");
					DSC_Retail_Percent = DSC_Percent[i];
					commonExcelFunctions.getPercent_Value();
					if(commonExcelFunctions.PercentColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Percent_"+value,commonExcelFunctions.strPercent_Value);
						Thread.sleep(100);
					}
				}
				if(!tempMindollar.equalsIgnoreCase(""))  
				{
					String[] DSC_Mindollar = tempMindollar.split("\n");
					DSC_Retail_MinimumDollar = DSC_Mindollar[i];
					commonExcelFunctions.getMindollar_Value();
					if(commonExcelFunctions.MindollarColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MinimumDollar_"+value,commonExcelFunctions.strMinimumDollar_Value);
						Thread.sleep(100);
					}
				}
				if(!tempMaxdollar.equalsIgnoreCase(""))  
				{
					String[] DSC_Maxdollar = tempMaxdollar.split("\n");
					DSC_Retail_MaximumDollar = DSC_Maxdollar[i];
					commonExcelFunctions.getMaxdollar_Value();
					if(commonExcelFunctions.MaxdollarColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaximumDollar_"+value,commonExcelFunctions.strMaximumDollar_Value);
						Thread.sleep(100);
					}
				}
				if(!tempCopayCalc.equalsIgnoreCase(""))  
				{
					String[] DSC_Copaycalc = tempCopayCalc.split("\n");
					DSC_Retail_CopayCalculation = DSC_Copaycalc[i];
					commonExcelFunctions.getCopaycalc_Value();
					if(commonExcelFunctions.CopaycalcColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_CopayCalculation_"+value,commonExcelFunctions.CRDCopayLogic);
						Thread.sleep(100);
					}
				}
				if(!tempReverse.equalsIgnoreCase(""))  
				{
					String[] DSC_Reverse = tempCopayCalc.split("\n");
					DSC_Retail_Reverse = DSC_Reverse[i];
					commonExcelFunctions.getReverse_Value();
					if(commonExcelFunctions.ReverseColorFlag==true)	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Reverse_"+value,commonExcelFunctions.strReverse);
						Thread.sleep(100);
					}
				}

		}

	}
}
}
	


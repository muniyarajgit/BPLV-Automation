/*package com.application;

import java.io.BufferedInputStream;

import xni.parser.CSVParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.yaml.snakeyaml.reader.StreamReader;

import com.framework.commonExcelFunctions;
import com.framework.frameworkParameters;



public class Test1 {
	//	public static String FilePath = "C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\report1519889369517.xlsx";
	public static void main(String[] args) throws IOException {
		
		
		/*CSVReader reader = new CSVReader(new FileReader("yourfile.csv")); 
		String [] nextLine; 
		while ((nextLine = reader.readNext()) != null) { 
			// nextLine[] is an array of values from the line System.out.println(nextLine[0] + nextLine[1] + "etc..."); }
			
		}*/
		
		/*csv csvReader;
		InputStream file;
		file = new FileInputStream(frameworkParameters.provisionSheetPath1);
		csvReader = csv.reader( file,  delimiter=",", quotechar='"')*/
		/*TextFieldParser parser = new TextFieldParser(@"c:\file.csv");
		parser.TextFieldType = FieldType.Delimited;
		parser.SetDelimiters(",");
		while (!parser.EndOfData) 
		{
		    //Processing row
		    string[] fields = parser.ReadFields();
		    foreach (string field in fields) 
		    {
		        //TODO: Do whatever you need
		    }
		}
		parser.Close();*/
/*
//		File csvFile= new File(frameworkParameters.provisionSheetPath1);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		
		br = new BufferedReader(new FileReader("C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\report1519889441912.csv"));
		while ((line = br.readLine()) != null) {
			strPosition = line.split(cvsSplitBy);
			strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
			
			if(strPosition[0].contains(""))	{
				System.out.println(strPosition[0]);
				System.out.println(strPosition[1]);
				System.out.println(strPosition[2]);
				System.out.println(strPosition[3]);
				System.out.println(strPosition[4]);
				
			}
			System.out.println(strPosition[0]);
		} */
		
	/*	InputStream csvStream = getAssets().open(yourCSVFile);
        InputStreamReader csvStreamReader = new InputStreamReader(csvStream);
        CSV csvReader = new CSVReader(csvStreamReader);
        String[] line;

        while ((line = csvReader.readNext()) != null) {
                     String example = line[0]; // first item of your csv row
                  }*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
/*
		String CellValue="";
		FileInputStream file = null;
		XSSFWorkbook workbook = null;
		try{
			file = new FileInputStream(frameworkParameters.provisionSheetPath);             
			workbook = new XSSFWorkbook(file);
			XSSFSheet xssfSheet = workbook.getSheet("sheet1");  
			int rowItrator;
			String a = commonExcelFunctions.getReportData("Sheet1", "Line ValueID",0);
			System.out.println("a : " + a);
			String object_API 	    = commonExcelFunctions.getReportData("Sheet1", "Object API",  0);
			System.out.println(object_API);
			for(int i=0;i<xssfSheet.getLastRowNum();i++)	{
				String a = commonExcelFunctions.getReportData("Sheet1", "Line ValueID",i);
				System.out.println("a : " + a);
				String object_API 	    = commonExcelFunctions.getReportData("Sheet1", "Object API",  i);
				System.out.println(object_API);
			}
*/
			/*for(rowItrator=0;rowItrator<=xssfSheet.getLastRowNum();rowItrator++)	{
				Rep_provisionNumber 	= commonExcelFunctions.getReportData("Sheet1", "Line ValueID",rowItrator);
				String object_API 	    = commonExcelFunctions.getReportData("Sheet1", "Object API",  rowItrator);
				String fieldLabel 		= commonExcelFunctions.getReportData("Sheet1", "Field Label", rowItrator);
				String fieldValue  		= commonExcelFunctions.getReportData("Sheet1", "FieldValue",  rowItrator);
				if(Rep_provisionNumber.equalsIgnoreCase("P"+provisionNumber+"L"+strProvisionLineValue))	{
					if(object_API.equalsIgnoreCase("CRD__c"))	{
						if(fieldLabel.equalsIgnoreCase("Plan Type: Retail"))	{
							if(fieldValue.equalsIgnoreCase(planTypeRetailFieldValue_1)){
								System.out.println("Plan Type Retail Field Value is matched");
								strsubProcessValue = planTypeRetailFieldValue_1;
							}
						}	else if(fieldLabel.equalsIgnoreCase("Plan Type: Paper"))	{
							if(fieldValue.equalsIgnoreCase(CopayToPaper_1)){
								System.out.println("Plan Type Retail Field Value is matched");
								strsubProcessValue = planTypeRetailFieldValue_1;
							}
						}
					}
				}

			}*/

	/*	}	catch(Exception e)	{
			e.printStackTrace();
		}*/
		
		
		
	
		
		/*String csvFile = "C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\report1519889441912.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] country = null;
		//		 ArrayList<Card> ArrayList = new ArrayList<Card>( ); 
		try {
			br = new BufferedReader(new FileReader(csvFile));
			int i=0;
			while ((line = br.readLine()) != null) {
				country =line.split(cvsSplitBy);
				System.out.println("Country value is : " + country[8]);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}*/
			
		




































		/*FileInputStream file = new FileInputStream("C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\report1519889369517.xls");
		HSSFWorkbook wb = new HSSFWorkbook(file);
		HSSFSheet sheet = wb.getSheetAt(0);
		System.out.println("sheet : " + sheet.getLastRowNum());*/

		/*InputStream is = new FileInputStream(new File("/path/to/workbook.xlsx"));
		StreamReader reader = StreamReader.builder()
		        .rowCacheSize(100)    // number of rows to keep in memory (defaults to 10)
		        .bufferSize(4096)     // buffer size to use when reading InputStream to file (defaults to 1024)
		        .sheetIndex(0)        // index of sheet to use (defaults to 0)
		        .read(is);            // InputStream or File for XLSX file (required)

		for (Row r : reader) {
		  for (Cell c : r) {
		    System.out.println(c.getStringCellValue());
		  }
		}   */


		/* OPCPackage pkg = OPCPackage.open(FilePath, PackageAccess.READ);
		    XSSFReader r = new XSSFReader(pkg);
		    SharedStringsTable sst = r.getSharedStringsTable();

		    SheetHandler handler = new SheetHandler(sst);
		    XMLReader parser = fetchSheetParser(handler);
		    Iterator<InputStream> sheetIterator = r.getSheetsData();

		    if (!sheetIterator.hasNext()) {
		        return Collections.emptyList();
		    }

		    InputStream sheetInputStream = sheetIterator.next();
		    BufferedInputStream bisSheet = new BufferedInputStream(sheetInputStream);
		    InputSource sheetSource = new InputSource(bisSheet);
		    parser.parse(sheetSource);
		    List<String []> res = handler.getRowCache();
		    bisSheet.close();
		    return res;

	}

	private SharedStringsTable sst;

	private  void SheetHandler(SharedStringsTable sst) {
        this.sst = sst;
    }
	public List<String[]> getRowCache() {
        return getRowCache();
    }

		public XMLReader fetchSheetParser(SheetHandler handler) throws SAXException {
			XMLReader parser =
				XMLReaderFactory.createXMLReader(
						"org.apache.xerces.parsers.SAXParser"
				);
			SheetHandler handler1 = new SheetHandler(sst);
			parser.setContentHandler((ContentHandler) handler1);
			return parser;
		}
		 */
	

/* if(DSC__DrugListSelection.equalsIgnoreCase("Drug List"))	{
commonExcelFunctions.findDrugList();
commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug List");
} */
/*if(!DSC__DrugListSelection.equalsIgnoreCase(""))	
{
String[] DrugListSel = DSC__DrugListSelection.split("\n");
String[] DrugListID = DSC__DrugList.split("\n");
for(int i=0;i<DrugListSel.length;i++) {
	if(DrugListSel[i].equalsIgnoreCase("Drug List")) {
		DSC__DrugList = DrugListID[i];
		commonExcelFunctions.findDrugList();
		if(!DSC__DrugList.equalsIgnoreCase(""))	{
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugList_"+value,commonExcelFunctions.drugListValueID);
		}
		//commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug List");
	}
}	
}
if(DSC__DrugListSelection.equalsIgnoreCase("Drug Group"))	{
commonExcelFunctions.findDrugGroupName();
commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug Group");
}
// commonExcelFunctions.validateExpectedProvisionLineValue();

if(process.equalsIgnoreCase("DSC_SpecialtyTiers"))	{
if(!DSC_FieldValue.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strSpecialty);
}
}
if(process.equalsIgnoreCase("DSC_SpecialityOutOfNetwrok"))	{
if(!DSC_FieldValue.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strSpecialty_OON);
}
}
if(process.equalsIgnoreCase("DSC_PaperTiers"))	{
if(!DSC_FieldValue.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strpaper_DSC);
}
}
if(process.equalsIgnoreCase("DSC_PaperOutOfNetwork"))	{
if(!DSC_FieldValue.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strpaperOON_DSC);
}
}
Thread.sleep(200);
if(!dsc_Subsection.equalsIgnoreCase("")){
commonExcelFunctions.validateExpectedProvisionLineValue();
commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "SubSectionProcess_2", commonExcelFunctions.strsubsection2);

if(!DSC_Retail_FormularyGroup.equalsIgnoreCase("")){
	commonExcelFunctions.validateExpectedProvisionLineValue();
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_FormularyGroup_"+value,commonExcelFunctions.strDrugSpecificCopay);
	Thread.sleep(200);
}
if(!DSC_Retail_Stepped.equalsIgnoreCase(""))	
{
	String[] DSC_Stepped = DSC_Retail_Stepped.split("\n");
	for(int i=0;i<DSC_Stepped.length;i++) {
		DSC_Retail_Stepped = DSC_Stepped[i];
		commonExcelFunctions.validateExpectedProvisionLineValue();
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Stepped_"+value,commonExcelFunctions.strsteppedCopay);
		Thread.sleep(200);
	}
	Thread.sleep(200);
}
Thread.sleep(200);
if(!DSC_Retail_M.equalsIgnoreCase(""))	
{
	String[] DSC_M = DSC_Retail_M.split("\n");
	for(int i=0;i<DSC_M.length;i++) {
		DSC_Retail_M = DSC_M[i];
		commonExcelFunctions.validateExpectedProvisionLineValue();
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_M_"+value,commonExcelFunctions.strM_Value);
		Thread.sleep(500);
		//commonExcelFunctions.validateExpectedProvisionLineValue();
	}
	Thread.sleep(200);
}	
if(!DSC_Retail_N.equalsIgnoreCase(""))	
{
	String[] DSC_N = DSC_Retail_N.split("\n");
	for(int i=0;i<DSC_N.length;i++) {
		DSC_Retail_N = DSC_N[i];
		commonExcelFunctions.validateExpectedProvisionLineValue();
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_N_"+value,commonExcelFunctions.strN_Value);
		Thread.sleep(200);
	}
	Thread.sleep(200);
}
if(!DSC_Retail_O.equalsIgnoreCase(""))	
{
	String[] DSC_O = DSC_Retail_O.split("\n");
	for(int i=0;i<DSC_O.length;i++) {
		DSC_Retail_O = DSC_O[i];
		commonExcelFunctions.validateExpectedProvisionLineValue();
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_O_"+value,commonExcelFunctions.strO_Value);
		Thread.sleep(200);
		//commonExcelFunctions.validateExpectedProvisionLineValue();
	}
	Thread.sleep(200);
}
if(!DSC_Retail_Y.equalsIgnoreCase(""))	
{
	String[] DSC_Y = DSC_Retail_Y.split("\n");
	for(int i=0;i<DSC_Y.length;i++) {
		DSC_Retail_Y = DSC_Y[i];
		commonExcelFunctions.validateExpectedProvisionLineValue();
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Y_"+value,commonExcelFunctions.strY_Value);
		Thread.sleep(200);
		//commonExcelFunctions.validateExpectedProvisionLineValue();
	}
	Thread.sleep(200);
}
if(!DSC_Retail_DollarAmount.equalsIgnoreCase(""))	
{
	String[] DSC_Dollar = DSC_Retail_DollarAmount.split("\n");
	for(int i=0;i<DSC_Dollar.length;i++) {
		DSC_Retail_DollarAmount = DSC_Dollar[i];
		commonExcelFunctions.validateExpectedProvisionLineValue();
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DollarAmount_"+value,commonExcelFunctions.strDollarAmount_Value);
		Thread.sleep(200);
		//commonExcelFunctions.validateExpectedProvisionLineValue();
	}
	Thread.sleep(200);
}*/
/*if(!DSC__DrugList.equalsIgnoreCase(""))	{
commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugList_"+value,commonExcelFunctions.drugListValueID);
}
if(!DSC_Retail_Stepped.equalsIgnoreCase("")){
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Stepped_"+value,commonExcelFunctions.strsteppedCopay);
}
if(!DSC_Retail_M.equalsIgnoreCase("")){
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_M_"+value,commonExcelFunctions.strM_Value);
}
if(!DSC_Retail_N.equalsIgnoreCase("")){
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_N_"+value,commonExcelFunctions.strN_Value);
}
if(!DSC_Retail_O.equalsIgnoreCase("")){
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_O_"+value,commonExcelFunctions.strO_Value);
}
if(!DSC_Retail_Y.equalsIgnoreCase("")){
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Y_"+value,commonExcelFunctions.strY_Value);
}
Thread.sleep(1500);
if(!DSC_Retail_DollarAmount.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DollarAmount_"+value,commonExcelFunctions.strDollarAmount_Value);
}
if(!DSC_Retail_Percent.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Percent_"+value,commonExcelFunctions.strPercent_Value);
}
if(!DSC_Retail_MinimumDollar.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MinimumDollar_"+value,commonExcelFunctions.strMinimumDollar_Value);
}
if(!DSC_Retail_MaximumDollar.equalsIgnoreCase(""))	{
	commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaximumDollar_"+value,commonExcelFunctions.strMaximumDollar_Value);
}*/



/*
package com.framework;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
/*
public class BPLV_Functions extends frameworkParameters {
	public static String provisionNumber 				= null;
	public static String provisionLineValue				= null;
	public static String Provision_LineText 			= null;
	public static String subSection 					= null;
	public static String FieldName						= null;
	public static String planTypeRetailFieldValue_1		= null;
	public static String NumberOfTiers_1				= null;
	public static String CopayToPaper_1					= null;
	public static String TierType_1 					= null;
	public static String CRDCopayLogic_1				= null;
	public static String DollarAmount_1					= null;
	public static String Percent_1 						= null;
	public static String CoPayCalculation_1				= null;
	public static String MinimumDollar_1				= null;
	public static String MaximumDollar_1				= null;
	public static String NonFormularyDollarAmount_1		= null;
	public static String NonFormularyPercent_1			= null;
	public static String NonFormularyCopayCalculation_1 = null;
	public static String NonFormularyMinimumDollar_1	= null;
	public static String NonFormularyMaximumDollar_1	= null;
	public static String NonFormularyAmount_1 			= null;
	public static String strFieldName 						= null;
	//variable declaration for SubSection Process - paper
	public static String paper_planTypeFieldValue_1  	= null;
	public static String paper_NumberOfTiers_1 			= null;
	public static String paper_CopayToPaper_1  			= null;
	public static String paper_TierType_1  				= null;
	public static String paper_DollarAmount_1  			= null;
	public static String paper_Percent_1  				= null;
	public static String paper_CoPayCalculation_1  		= null;
	public static String paper_MinimunDollar_1  		= null;
	public static String paper_MaximumDollar_1  		= null;
	public static String paper_NonFormularyDollarAmount_1 	 	= null;
	public static String paper_NonFormularyPercent_1  	  	 	= null;
	public static String paper_NonFormularyCopayCalculation_1  	= null;
	public static String paper_NonFormularyMinimumDollar_1 		= null;
	public static String paper_NonFormularyMaximumDollar_1  	= null;
	//variable declaration for SubSection Process - Paper Out of network
	public static String PaperOutOfNetwork_planTypeFieldValue_1 	= null;
	public static String PaperOutOfNetwork_NumberOfTiers_1			= null;
	public static String PaperOutOfNetwork_CopayToPaper_1 			= null;
	public static String PaperOutOfNetwork_TierType_1 				= null;
	public static String PaperOutOfNetwork_DollarAmount_1 			= null;
	public static String PaperOutOfNetwork_Percent_1 				= null;
	public static String PaperOutOfNetwork_CoPayCalculation_1 		= null;
	public static String PaperOutOfNetwork_MinimunDollar_1 			= null;
	public static String PaperOutOfNetwork_MaximumDollar_1 			= null;
	public static String PaperOutOfNetwork_NonFormularyDollarAmount_1= null;
	public static String PaperOutOfNetwork_NonFormularyPercent_1 	= null;
	public static String PaperOutOfNetwork_NonFormularyCopayCalculation_1 = null;
	public static String PaperOutOfNetwork_NonFormularyMinimumDollar_1 	  = null;
	public static String PaperOutOfNetwork_NonFormularyMaximumDollar_1 	  = null;
	// Drug Specific CoPay - Retail Tiers 
	public static String DSC_Retail_FormularyGroup = null;
	public static String DSC_Retail_DrugList 	   = null;
	public static String DSC_Retail_Stepped 	   = null;
	public static String DSC_Retail_M 	   		   = null;
	public static String DSC_Retail_N 	  		   = null;
	public static String DSC_Retail_O 	   		   = null;
	public static String DSC_Retail_Y 	   		   = null;
	public static String DSC_Retail_DollarAmount   = null;
	public static String DSC_Retail_Percent 	   = null;
	public static String DSC_Retail_CopayCalculation= null;
	public static String DSC_Retail_MinimumDollar  = null;
	public static String DSC_Retail_MaximumDollar  = null;
	public static String DSC_Retail_Reverse 	   = null;
	//Drug Specific Copay - Speciality Tiers 
	public static String DSC_SpecialtyTiers_1      = null;	
	public static String DSC_RetailTier;
	public static String DSC_RetailFieldValue = null;
	public static String strcopayNonFormularyValue	= null;
	//Expected Provision Report Details
	public static commonExcelFunctions objExcelFunc = new commonExcelFunctions();
	// common Variable
	public static int row;
	public static int Subsection;
	//ExpectedReport Variable declarations
	public static String Rep_provisionNumber 				= null;
	public static String Rep_provisionLineValue				= null;
	public static String Rep_Provision_LineText 			= null;
	public static String Rep_subSection 					= null;
	public static String Rep_FieldName						= null;
	public static String Rep_planTypeRetailFieldValue_1		= null;
	public static String Rep_NumberOfTiers_1				= null;
	public static String Rep_CopayToPaper_1					= null;
	public static String Rep_TierType_1 					= null;
	public static String Rep_CRDCopayLogic_1				= null;
	public static String Rep_DollarAmount_1					= null;
	public static String Rep_Percent_1 						= null;
	public static String Rep_CoPayCalculation_1				= null;
	public static String Rep_MinimunDollar_1				= null;
	public static String Rep_MaximumDollar_1				= null;
	public static String Rep_NonFormularyDollarAmount_1		= null;
	public static String Rep_NonFormularyPercent_1			= null;
	public static String Rep_NonFormularyCopayCalculation_1 = null;
	public static String Rep_NonFormularyMinimumDollar_1	= null;
	public static String Rep_NonFormularyMaximumDollar_1	= null;
	//
	public static XSSFSheet xssfSheet = null;
	//

	public static String strNumberOfTierValue 			 = null;
	public static String strsubProcessValue 	 		 = null;
	public static String srtTierType			 		 = null;
	public static String strDollarAmountValue 			 = null;
	public static String strNonFormularyAmountValueOrder = null;

	public static String subsectionProcessType_Value	 = null;
	public static String DSC_FieldValue					 = null;
	public static String strCRDCopayLogic 				 = null;
	public static String DSC__DrugList					 = null;
	public static String planTypePaperFieldValue    	 = null;
	public static String dsc_Subsection					 = null;


	public static String DSC_SpecialityValue	= null;
	public static String DSC_SpecialityOONValue = null;
	public static String DSC_Paper				= null;
	public static String DSC_PaperOON			= null;
	public static String strProvisionLineValue_id= null;
	public static int rowCount;
	public static String DSC__DrugListSelection			= null;

	public static ArrayList arr_ProvisionLineValue =  new ArrayList();
	public static ArrayList arrRowValue = new ArrayList();




	@Test
	public static void getProvisionNumber()		{


		provisionNumber = commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", 1);
	}
	public static void getProvisionLineValue() throws Exception	{


		commonExcelFunctions objExcelFunc = new commonExcelFunctions();
		Loop:
			for(row =2;row<objExcelFunc.xssfSheet.getLastRowNum();row++)	{
				if(commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", row).equalsIgnoreCase("Expected Line Value"))	{

					for(row= row+1;rowCount<objExcelFunc.xssfSheet.getLastRowNum();row++)	{
						if(commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", row).equalsIgnoreCase(""))	{
							break Loop;
						}	else	{
							arr_ProvisionLineValue.add(commonExcelFunctions.getInputData("Sheet 1", "Provision_Number", row));
							arrRowValue.add(row);

							continue;
							/*if(strProvisionLineValue.equalsIgnoreCase(provisionLineValue))	{
							strProvisionLineValue = provisionLineValue;
							continue;
						}*/
	/*public static void getProvisionLineText(int row) throws Exception{

		Provision_LineText = commonExcelFunctions.getInputData("Sheet 1", "Provision_LineText", row).trim();
		System.out.println("Provision_LineText : " + Provision_LineText);
		commonExcelFunctions.validateLineTextValue();
		if(commonExcelFunctions.lineValue_Temp == true){
			Thread.sleep(1000);
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row,"Provision_LineText",commonExcelFunctions.strProvisionLineValue_id);
			System.out.println("Comparision completed");
		}
	}
	public static void getTabName()	{


		commonExcelFunctions objExcelFunc = new commonExcelFunctions();
		for(Subsection= 0;Subsection<objExcelFunc.xssfSheet.getLastRowNum();Subsection++)	{
			subSection = commonExcelFunctions.getInputData("Sheet 1", "Tab_Name", Subsection);
			if(subSection.trim().equalsIgnoreCase("Subsection"))	{
				break;
			}
		}
	}
	public static void getSubSectionAndFieldName(String processType, int row)	{


		if(processType.equalsIgnoreCase("1"))	{
			subSection = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection);
			FieldName = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection+1);
		}	else if(processType.equalsIgnoreCase("2"))	{
			subSection = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection);
			strFieldName = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, Subsection+1);
		}
		DSC_RetailTier = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+processType, row);
		System.out.println("DSC_RetailTier : " + DSC_RetailTier);
		System.out.println("subSection : " + subSection);
		// System.out.println("FieldName : " + FieldName);
	}

	//Provision 9 Base - Copay Section
	public static void getCopaySubSectionProcess(String subsectionProcessType,String process,int value,int row) throws Exception	{
		subsectionProcessType_Value = process;
		if(subSection.equalsIgnoreCase("Copay"))	{
			if(subsectionProcessType.equalsIgnoreCase("Plan type Retail") || subsectionProcessType.equalsIgnoreCase("Plan Type Paper") || subsectionProcessType.equalsIgnoreCase("Plan Type Paper Out of Network") || subsectionProcessType.contains("Plan Type Mail"))	{
				planTypeRetailFieldValue_1			 = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_"+value, row);
				strCRDCopayLogic					 = commonExcelFunctions.getInputData("Sheet 1", process+"_CRDCopayLogic_"+value, row);
				planTypePaperFieldValue				 = commonExcelFunctions.getInputData("Sheet 1", process+"_FieldName_"+value, row);
				NumberOfTiers_1 		  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_NumberOfTiers_"+value, row);
				CopayToPaper_1			  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_CopayToPaper_"+value, row);
				TierType_1				  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_TierType_"+value, row);
				DollarAmount_1			  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_DollarAmount_"+value, row);
				Percent_1				  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_Percent_"+value, row);
				CoPayCalculation_1		  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_CoPayCalculation_"+value, row);
				MinimumDollar_1			  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_MinimumDollar_"+value, row);
				MaximumDollar_1			  			 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaximumDollar_"+value, row);
				NonFormularyDollarAmount_1			 = commonExcelFunctions.getInputData("Sheet 1", process+"_NonFormularyDollarAmount_"+value, row);
				NonFormularyPercent_1	   			 = commonExcelFunctions.getInputData("Sheet 1", process+"_NonFormularyPercent_"+value, row);
				NonFormularyAmount_1	   			 = commonExcelFunctions.getInputData("Sheet 1", process+"_NonFormularyAmount_"+value, row);
				NonFormularyCopayCalculation_1	 	 = commonExcelFunctions.getInputData("Sheet 1", process+"_NonFormularyCopayCalculation_"+value, row);
				NonFormularyMinimumDollar_1		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_NonFormularyMinimumDollar_"+value, row);
				NonFormularyMaximumDollar_1		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_NonFormularyMaximumDollar_"+value, row);
				strFieldName   						 = commonExcelFunctions.getInputData("Sheet 1", process+"_FieldName_"+value, row);
				//				System.out.println("NonFormularyMaximumDollar_1 : " + planTypeRetailFieldValue_1);

				if(subsectionProcessType.equalsIgnoreCase("Plan type Retail") || subsectionProcessType.contains("Plan Type Mail"))	{
					if(!NonFormularyDollarAmount_1.equalsIgnoreCase(""))	{
						NonFormularyDollarAmount_1 =NonFormularyDollarAmount_1+".00";
					}
					if(!NonFormularyPercent_1.equalsIgnoreCase(""))	{
						NonFormularyPercent_1 =NonFormularyPercent_1+".00";
					}
					if(!NonFormularyCopayCalculation_1.equalsIgnoreCase(""))	{
						NonFormularyCopayCalculation_1 =NonFormularyCopayCalculation_1+".00";
					}
					if(!NonFormularyMinimumDollar_1.equalsIgnoreCase(""))	{
						NonFormularyMinimumDollar_1 =NonFormularyMinimumDollar_1+".00";
					}
					if(!NonFormularyMaximumDollar_1.equalsIgnoreCase(""))	{
						NonFormularyMaximumDollar_1 =NonFormularyMaximumDollar_1+".00";
					}

					strcopayNonFormularyValue = NonFormularyDollarAmount_1+","+NonFormularyPercent_1+","+NonFormularyMinimumDollar_1+","+NonFormularyMaximumDollar_1+","+NonFormularyCopayCalculation_1;
				}	else if(subsectionProcessType.equalsIgnoreCase("Plan type Paper") || subsectionProcessType.equalsIgnoreCase("Plan Type Paper Out of Network")){
					if(!NonFormularyDollarAmount_1.equalsIgnoreCase(""))	{
						NonFormularyDollarAmount_1 =NonFormularyDollarAmount_1+".00";
					}
					if(!NonFormularyAmount_1.equalsIgnoreCase(""))	{
						NonFormularyAmount_1 =NonFormularyAmount_1+".00";
					}
					if(!NonFormularyCopayCalculation_1.equalsIgnoreCase(""))	{
						NonFormularyCopayCalculation_1 =NonFormularyCopayCalculation_1+".00";
					}
					if(!NonFormularyMinimumDollar_1.equalsIgnoreCase(""))	{
						NonFormularyMinimumDollar_1 =NonFormularyMinimumDollar_1+".00";
					}
					if(!NonFormularyMaximumDollar_1.equalsIgnoreCase(""))	{
						NonFormularyMaximumDollar_1 =NonFormularyMaximumDollar_1+".00";
					}
					strcopayNonFormularyValue = NonFormularyDollarAmount_1+","+NonFormularyAmount_1+","+NonFormularyMinimumDollar_1+","+NonFormularyMaximumDollar_1+","+NonFormularyCopayCalculation_1;
				}
				if(!subsectionProcessType.equalsIgnoreCase(""))	{
					commonExcelFunctions.validateExpectedProvisionLineValue();
				}
				if(!subsectionProcessType.equalsIgnoreCase(""))	{
					if(process.equalsIgnoreCase("Retail")||process.equalsIgnoreCase("PaperOutOfNetwork") || process.equalsIgnoreCase("Mail")) {
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "SubSectionProcess_1",commonExcelFunctions.strsubProcessValue);
						if(!strCRDCopayLogic.equalsIgnoreCase(""))	{
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_CRDCopayLogic_"+value,commonExcelFunctions.CRDCopayLogic);
							Thread.sleep(1000);
						}
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NumberOfTiers_"+value,commonExcelFunctions.strNumberOfTierValue);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_TierType_"+value,commonExcelFunctions.srtTierType);
						if(!DollarAmount_1.equalsIgnoreCase(""))	{
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DollarAmount_"+value,commonExcelFunctions.strDollarAmountValue);
						}
						if(!Percent_1.equalsIgnoreCase(""))	{
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Percent_"+value,commonExcelFunctions.strPercentValue);

						}
						if(!MinimumDollar_1.equalsIgnoreCase(""))	{
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MinimumDollar_"+value,commonExcelFunctions.strMinimumdollarValue);
						}
						if(!MaximumDollar_1.equalsIgnoreCase(""))	{
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaximumDollar_"+value,commonExcelFunctions.strMaximumdollarValue);
						}
						if(!CoPayCalculation_1.equalsIgnoreCase(""))	{
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_CoPayCalculation_"+value,commonExcelFunctions.strCopayCalculationValue);
						}
						if(!strcopayNonFormularyValue.equalsIgnoreCase(",,,,")&&(!commonExcelFunctions.strNonFormularyAmountValueOrder.equalsIgnoreCase("")))	{
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyDollarAmount_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyPercent_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
							Thread.sleep(1000);
							//					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyAmount_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyCopayCalculation_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyMinimumDollar_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
							Thread.sleep(1000);
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyMaximumDollar_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
						}
						Thread.sleep(200);
					}
					if(process.equalsIgnoreCase("Paper"))	{
						if(!planTypePaperFieldValue.equalsIgnoreCase(""))		{
							commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_FieldName_"+value,commonExcelFunctions.strPlanTypePaperFieldalue);
						}
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "SubSectionProcess_1",objExcelFunc.strsubProcessValue);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_CRDCopayLogic_"+value,commonExcelFunctions.CRDCopayLogic);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NumberOfTiers_"+value,commonExcelFunctions.strNumberOfTierValue);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_TierType_"+value,commonExcelFunctions.srtTierType);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DollarAmount_"+value,commonExcelFunctions.strDollarAmountValue);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyDollarAmount_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
						//						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyPercent_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyAmount_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyCopayCalculation_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyMinimumDollar_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_NonFormularyMaximumDollar_"+value,commonExcelFunctions.strNonFormularyAmountValueOrder);
					}
				}
			}	
		}
	}
	//Provision 9 Base - Drug specific Copay Section
	public static void getDrugSpecificCopayDetails( String subsectionProcessType, String process, String value, int row) throws Exception	{

		subsectionProcessType_Value = process;
		if (subSection.equalsIgnoreCase("Drug Specific Copay"))	{
			if((subsectionProcessType.equalsIgnoreCase("Retail Tiers")) || (subsectionProcessType.equalsIgnoreCase("Specialty Tiers")) || (subsectionProcessType.equalsIgnoreCase("Specialty Out of Network"))||(subsectionProcessType.equalsIgnoreCase("Paper Tiers"))||(subsectionProcessType.equalsIgnoreCase("Paper Out of Network")) || (subsectionProcessType.equalsIgnoreCase("Mail Tiers"))) 	{
				if(subsectionProcessType.equalsIgnoreCase("Retail Tiers") || subsectionProcessType.equalsIgnoreCase("Paper Tiers") || subsectionProcessType.equalsIgnoreCase("Mail Tiers"))	{
					//					DSC_RetailTier 		   				 = commonExcelFunctions.getInputData("Sheet 1", process+"_RetailTiers_"+value, row);
					//					System.out.println("DSC_RetailTier : " + DSC_RetailTier);
					DSC_Retail_FormularyGroup 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_FormularyGroup_"+value, row);
				}
				if(subsectionProcessType.equalsIgnoreCase("Specialty Tiers") || (subsectionProcessType.equalsIgnoreCase("Specialty Out of Network")))	{
					DSC__DrugList  		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugList_"+value, row);
					System.out.println("DSC_SpecialtyTiers_1 : " + DSC_SpecialtyTiers_1);
					DSC_Retail_FormularyGroup 	   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_FormularyGroup_"+value, row);
					DSC_Retail_DrugList		 		 = commonExcelFunctions.getInputData("Sheet 1", process+"_SpecialtyTiers_"+value, row);
				}
				dsc_Subsection 		   				 = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_2", row);
				DSC__DrugList  		   				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugList_"+value, row);
				DSC__DrugListSelection	   			 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugListSelection_"+value, row);
				DSC_FieldValue	 		 		  	 = commonExcelFunctions.getInputData("Sheet 1", process+"_"+value, row);
				DSC_RetailFieldValue	 		   	 = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_2", row);
				DSC_Retail_Stepped		 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_Stepped_"+value, row);
				DSC_Retail_M		 		  	 	 = commonExcelFunctions.getInputData("Sheet 1", process+"_M_"+value, row);
				DSC_Retail_N		 		   		 = commonExcelFunctions.getInputData("Sheet 1", process+"_N_"+value, row);
				DSC_Retail_O		 		   		 = commonExcelFunctions.getInputData("Sheet 1", process+"_O_"+value, row);
				DSC_Retail_Y		 		   		 = commonExcelFunctions.getInputData("Sheet 1", process+"_Y_"+value, row);
				DSC_Retail_DollarAmount		 	   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DollarAmount_"+value, row);
				DSC_Retail_Percent		 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_Percent_"+value, row);
				DSC_Retail_CopayCalculation		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_CopayCalculation_"+value, row);
				DSC_Retail_MinimumDollar		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_MinimumDollar_"+value, row);
				DSC_Retail_MaximumDollar		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaximumDollar_"+value, row);
				DSC_Retail_Reverse		 		   	 = commonExcelFunctions.getInputData("Sheet 1", process+"_Reverse_"+value, row);
				String value2 = "";
				commonExcelFunctions.readReportValue();
				String[] data = DSC_Retail_FormularyGroup.split("\n");
				for(int i=0;i<data.length;i++)	{
					value2 = value2.trim().replaceAll("\\s", "")+data[i].trim().replaceAll("\\s", "")+";";
				}
				DSC_Retail_FormularyGroup = value2;
				if(DSC_Retail_FormularyGroup.endsWith(";"))	{
					DSC_Retail_FormularyGroup = DSC_Retail_FormularyGroup.substring(0,DSC_Retail_FormularyGroup.length()-1).trim();
				}
			}
			commonExcelFunctions.getFormularyId();
			if(!DSC__DrugListSelection.equalsIgnoreCase(""))	
			{
			String[] DrugListSel = DSC__DrugListSelection.split("\n");
			String[] DrugListID = DSC__DrugList.split("\n");
			for(int i=0;i<DrugListSel.length;i++) {
				if(DrugListSel[i].equalsIgnoreCase("Drug List")) {
					DSC__DrugList = DrugListID[i];
					commonExcelFunctions.findDrugList();
					if(!DSC__DrugList.equalsIgnoreCase(""))	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugList_"+value,commonExcelFunctions.drugListValueID);
						}
					}
				}	
			}
			if(!dsc_Subsection.equalsIgnoreCase("")){
				commonExcelFunctions.validateExpectedProvisionLineValue();
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "SubSectionProcess_2", commonExcelFunctions.strsubsection2);
			}
			if(!DSC_Retail_FormularyGroup.equalsIgnoreCase("")){
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_FormularyGroup_"+value,commonExcelFunctions.strDrugSpecificCopay);
				Thread.sleep(200);
			}
			if(!DSC_Retail_Stepped.equalsIgnoreCase(""))	
			{
				String[] DSC_Stepped = DSC_Retail_Stepped.split("\n");
				for(int i=0;i<DSC_Stepped.length;i++) {
					DSC_Retail_Stepped = DSC_Stepped[i];
					commonExcelFunctions.getStepped_Value();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Stepped_"+value,commonExcelFunctions.strsteppedCopay);
					Thread.sleep(200);
				}
				Thread.sleep(200);
			}
			if(!DSC_Retail_M.equalsIgnoreCase(""))	
			{
				String[] DSC_M = DSC_Retail_M.split("\n");
				for(int i=0;i<DSC_M.length;i++) {
					DSC_Retail_M = DSC_M[i];
					commonExcelFunctions.getM_Value();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_M_"+value,commonExcelFunctions.strM_Value);
					Thread.sleep(200);
				}
				Thread.sleep(200);
			}	
			if(!DSC_Retail_N.equalsIgnoreCase(""))	
			{
				String[] DSC_N = DSC_Retail_N.split("\n");
				for(int i=0;i<DSC_N.length;i++) {
					DSC_Retail_N = DSC_N[i];
					commonExcelFunctions.getN_Value();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_N_"+value,commonExcelFunctions.strN_Value);
					Thread.sleep(200);
				}
				Thread.sleep(200);
			}

			if(!DSC_Retail_O.equalsIgnoreCase(""))	
			{
				String[] DSC_O = DSC_Retail_O.split("\n");
				for(int i=0;i<DSC_O.length;i++) {
					DSC_Retail_O = DSC_O[i];
					commonExcelFunctions.getO_Value();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_O_"+value,commonExcelFunctions.strO_Value);
					Thread.sleep(200);
					//commonExcelFunctions.validateExpectedProvisionLineValue();
				}
				Thread.sleep(200);
			}
			if(!DSC_Retail_Y.equalsIgnoreCase(""))	
			{
				String[] DSC_Y = DSC_Retail_Y.split("\n");
				for(int i=0;i<DSC_Y.length;i++) {
					DSC_Retail_Y = DSC_Y[i];
					commonExcelFunctions.getY_Value();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Y_"+value,commonExcelFunctions.strY_Value);
					Thread.sleep(200);
					//commonExcelFunctions.validateExpectedProvisionLineValue();
				}
				Thread.sleep(200);
			}
		}
	}
}*/





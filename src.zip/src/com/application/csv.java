package com.application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class csv {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		String fileName= "C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\report1519889441912.csv";
		File file= new File(fileName);

		// this gives you a 2-dimensional array of strings
		List<List<String>> lines = new ArrayList<>();
		Scanner inputStream;


		String csvFile = "C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\report1519889441912.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] country = null;
		@SuppressWarnings("rawtypes")
		ArrayList<String> val1 = new ArrayList<String>();
		@SuppressWarnings("rawtypes")
		ArrayList<String> val2 = new ArrayList<String>();
		ArrayList<String> val3 = new ArrayList<String>();
		ArrayList<String> val4 = new ArrayList<String>();
		ArrayList<String> val5 = new ArrayList<String>();
		ArrayList<String> val6 = new ArrayList<String>();
		ArrayList<String> val7 = new ArrayList<String>();
		ArrayList<String> val8 = new ArrayList<String>();
		ArrayList<String> val9 = new ArrayList<String>();

		int i=0,j=1, k=2,l=3,m=4,n=5,fieldLabel=6,fieldValue=8,row=0;

		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null) {
			row++;
			country = line.split(cvsSplitBy);
			val1.add(country[i]);
			val2.add(country[j]);
			val3.add(country[k]);
			val4.add(country[l]);
			val5.add(country[m]);
			val6.add(country[n]);
			val7.add(country[fieldLabel]);
			val8.add(country[fieldValue]);
		}
		/*for(int d=0;d<row;d++)	{
	if(val7.get(d).toString().equalsIgnoreCase("Tier type"))	{
	System.out.println(val7.get(d).toString());}
}*/

		for(i=0;i<row;i++)	{
			if(val3.get(i).toString().equalsIgnoreCase("P9L933"))	{
				if(val6.get(i).toString().equalsIgnoreCase("CRD__c"))	{
					if(val7.get(i).toString().equalsIgnoreCase("Plan Type: Retail"))	{
						System.out.println("P9L933 Provision value is found");
						System.out.println("Field Type : plan Type Retail is found");
						if(val8.get(i).toString().equalsIgnoreCase("TRUE"))	{
							System.out.println("Field Value : Plan Type Retail value is matched with expected");
							System.out.println("val7.get(i).toString() : " + val7.get(i).toString());
						}
					}
				}
				if(val6.get(i).toString().equalsIgnoreCase("Copay_Tier__c"))	{
					if(val7.get(i).toString().equalsIgnoreCase("Tier"))	{
						System.out.println("Tier__c is found");
						if(val8.get(i).toString().equalsIgnoreCase("1"))	{
							System.out.println("Field Value for Tier__c  is 1 found");

						}
					}
					if(val7.get(i).toString().equalsIgnoreCase("Tier type"))	{
						System.out.println("Tier_Type is found");
						if(val8.get(i).toString().equalsIgnoreCase("Generic (SSG & MSG)"))	{
							System.out.println("Field Value for TierType  is Generic (SSG & MSG) found");
						}
					}	
				}

			}
		}

	}






}


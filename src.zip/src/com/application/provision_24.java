package com.application;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.framework.BPLV_Functions;
import com.framework.commonExcelFunctions;
import com.framework.frameworkParameters;

public class provision_24 extends frameworkParameters {

	commonExcelFunctions objExcelFunc = new commonExcelFunctions();
	public static String pvLineValue = null;

	@Test
	public void provision_24_Validation() {
		try{
			BPLV_Functions.getProvisionNumber();
			BPLV_Functions.getProvisionLineValue();
			commonExcelFunctions.readReportValue();
			for(int rowIterator=0;rowIterator<BPLV_Functions.arr_ProvisionLineValue.size();rowIterator++)	{
				System.out.println("<<<<<< Line Value >>>>>" + BPLV_Functions.arr_ProvisionLineValue.get(rowIterator));
				pvLineValue = BPLV_Functions.arr_ProvisionLineValue.get(rowIterator).toString();
				int row = BPLV_Functions.arrRowValue.get(rowIterator).hashCode();
				BPLV_Functions.getProvisionLineText(row);
				BPLV_Functions.getSubSectionAndFieldName("1",row);
				//BPLV_Functions.getDrugCoverageDetails("Plan Type Retail","DC_Retail","1",row);
				/*BPLV_Functions.getDrugCoverageDetails("Plan Type Retail","DC_Retail","2",row);
				BPLV_Functions.getDrugCoverageDetails("Plan Type Retail","DC_Retail","3",row);
				BPLV_Functions.getDrugCoverageDetails("Plan Type Mail","DC_Mail","1",row);
				BPLV_Functions.getDrugCoverageDetails("Plan Type Mail","DC_Mail","2",row);
				BPLV_Functions.getDrugCoverageDetails("Plan Type Mail","DC_Mail","3",row);*/
				//BPLV_Functions.getAccumulationsDrugSpecific("Accumulations", row);
				BPLV_Functions.getDrugSpecificCopayDetails("Retail Tiers", "DSC_Retail","1",row);
			//	BPLV_Functions.getDrugSpecificCopayDetails("Retail Tiers", "DSC_Retail","2",row);
			//	BPLV_Functions.getDrugSpecificCopayDetails("Retail Tiers", "DSC_Retail","3",row);
				commonExcelFunctions.steppedColorFlag= true;
				commonExcelFunctions.MColorFlag= true;
				commonExcelFunctions.NColorFlag= true;
				commonExcelFunctions.OColorFlag= true;
				commonExcelFunctions.YColorFlag= true;
				commonExcelFunctions.DollarAmountColorFlag= true;
				commonExcelFunctions.PercentColorFlag= true;
				commonExcelFunctions.MindollarColorFlag= true;
				commonExcelFunctions.MaxdollarColorFlag= true;
				commonExcelFunctions.CopaycalcColorFlag= true;
				commonExcelFunctions.ReverseColorFlag= true;
				BPLV_Functions.getDrugSpecificCopayDetails("Mail Tiers", "DSC_Mail","1",row);
			//	BPLV_Functions.getDrugSpecificCopayDetails("Mail Tiers", "DSC_Mail","2",row);
			//	BPLV_Functions.getDrugSpecificCopayDetails("Mail Tiers", "DSC_Mail","3",row);
				BPLV_Functions.getDrugSpecificCopayDetails("Specialty Tiers", "DSC_SpecialtyTiers","1",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Specialty Tiers", "DSC_SpecialtyTiers","2",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Specialty Tiers", "DSC_SpecialtyTiers","3",row);
				BPLV_Functions.getDrugSpecificCopayDetails("Specialty Out of Network", "DSC_SpecialtyOutOfNetwork","1",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Specialty Out of Network", "DSC_SpecialtyOutOfNetwork","2",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Specialty Out of Network", "DSC_SpecialtyOutOfNetwork","3",row);
				BPLV_Functions.getDrugSpecificCopayDetails("Paper Tiers", "DSC_PaperTiers","1",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Paper Tiers", "DSC_PaperTiers","2",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Paper Tiers", "DSC_PaperTiers","3",row);
				BPLV_Functions.getDrugSpecificCopayDetails("Paper Out of Network", "DSC_PaperOutOfNetwork","1",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Paper Out of Network", "DSC_PaperOutOfNetwork","2",row);
				//BPLV_Functions.getDrugSpecificCopayDetails("Paper Out of Network", "DSC_PaperOutOfNetwork","3",row);*/
				
				
				
							}
		}	catch(Exception e)	{
			e.printStackTrace();
		}



	}

}

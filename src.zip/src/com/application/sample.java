package com.application;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.jar.Attributes;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class sample {
	public static String FilePath = "C:\\SFDC_Automation\\workSpace\\SFDC_Framework\\dataSheets\\P9.xlsx";
	@SuppressWarnings("resource")
	@Test
	public void test() throws IOException, SAXException, OpenXML4JException {
		
		
		/*if(!DSC__DrugListSelection.equalsIgnoreCase(""))	
		{
			String[] DrugListSel = DSC__DrugListSelection.split("\n");
			String[] DrugListID = DSC__DrugList.split("\n");
			for(int i=0;i<DrugListSel.length;i++) {
				if(DrugListSel[i].equalsIgnoreCase("Drug List")) {
					DSC__DrugList = DrugListID[i];
					commonExcelFunctions.findDrugList();
					if(!DSC__DrugList.equalsIgnoreCase(""))	{
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugList_"+value,commonExcelFunctions.drugListValueID);
					}
					//commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug List");
				}
			}	
		}
		if(DSC__DrugListSelection.equalsIgnoreCase("Drug Group"))	{
			commonExcelFunctions.findDrugGroupName();
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug Group");
		}
		// commonExcelFunctions.validateExpectedProvisionLineValue();

		if(process.equalsIgnoreCase("DSC_SpecialtyTiers"))	{
			if(!DSC_FieldValue.equalsIgnoreCase(""))	{
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strSpecialty);
			}
		}
		if(process.equalsIgnoreCase("DSC_SpecialityOutOfNetwrok"))	{
			if(!DSC_FieldValue.equalsIgnoreCase(""))	{
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strSpecialty_OON);
			}
		}
		if(process.equalsIgnoreCase("DSC_PaperTiers"))	{
			if(!DSC_FieldValue.equalsIgnoreCase(""))	{
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strpaper_DSC);
			}
		}
		if(process.equalsIgnoreCase("DSC_PaperOutOfNetwork"))	{
			if(!DSC_FieldValue.equalsIgnoreCase(""))	{
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_"+value, commonExcelFunctions.strpaperOON_DSC);
			}
		}
		Thread.sleep(200);
		if(!dsc_Subsection.equalsIgnoreCase("")){
			commonExcelFunctions.validateExpectedProvisionLineValue();
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "SubSectionProcess_2", commonExcelFunctions.strsubsection2);

			if(!DSC_Retail_FormularyGroup.equalsIgnoreCase("")){
				commonExcelFunctions.validateExpectedProvisionLineValue();
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_FormularyGroup_"+value,commonExcelFunctions.strDrugSpecificCopay);
				Thread.sleep(200);
			}
			if(!DSC_Retail_Stepped.equalsIgnoreCase(""))	
			{
				String[] DSC_Stepped = DSC_Retail_Stepped.split("\n");
				for(int i=0;i<DSC_Stepped.length;i++) {
					DSC_Retail_Stepped = DSC_Stepped[i];
					commonExcelFunctions.validateExpectedProvisionLineValue();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Stepped_"+value,commonExcelFunctions.strsteppedCopay);
					Thread.sleep(200);
				}
				Thread.sleep(200);
			}
			Thread.sleep(200);
			if(!DSC_Retail_M.equalsIgnoreCase(""))	
			{
				String[] DSC_M = DSC_Retail_M.split("\n");
				for(int i=0;i<DSC_M.length;i++) {
					DSC_Retail_M = DSC_M[i];
					commonExcelFunctions.validateExpectedProvisionLineValue();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_M_"+value,commonExcelFunctions.strM_Value);
					Thread.sleep(500);
					//commonExcelFunctions.validateExpectedProvisionLineValue();
				}
				Thread.sleep(200);
			}	
			if(!DSC_Retail_N.equalsIgnoreCase(""))	
			{
				String[] DSC_N = DSC_Retail_N.split("\n");
				for(int i=0;i<DSC_N.length;i++) {
					DSC_Retail_N = DSC_N[i];
					commonExcelFunctions.validateExpectedProvisionLineValue();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_N_"+value,commonExcelFunctions.strN_Value);
					Thread.sleep(200);
				}
				Thread.sleep(200);
			}
			if(!DSC_Retail_O.equalsIgnoreCase(""))	
			{
				String[] DSC_O = DSC_Retail_O.split("\n");
				for(int i=0;i<DSC_O.length;i++) {
					DSC_Retail_O = DSC_O[i];
					commonExcelFunctions.validateExpectedProvisionLineValue();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_O_"+value,commonExcelFunctions.strO_Value);
					Thread.sleep(200);
					//commonExcelFunctions.validateExpectedProvisionLineValue();
				}
				Thread.sleep(200);
			}
			if(!DSC_Retail_Y.equalsIgnoreCase(""))	
			{
				String[] DSC_Y = DSC_Retail_Y.split("\n");
				for(int i=0;i<DSC_Y.length;i++) {
					DSC_Retail_Y = DSC_Y[i];
					commonExcelFunctions.validateExpectedProvisionLineValue();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Y_"+value,commonExcelFunctions.strY_Value);
					Thread.sleep(200);
					//commonExcelFunctions.validateExpectedProvisionLineValue();
				}
				Thread.sleep(200);
			}
			if(!DSC_Retail_DollarAmount.equalsIgnoreCase(""))	
			{
				String[] DSC_Dollar = DSC_Retail_DollarAmount.split("\n");
				for(int i=0;i<DSC_Dollar.length;i++) {
					DSC_Retail_DollarAmount = DSC_Dollar[i];
					commonExcelFunctions.validateExpectedProvisionLineValue();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DollarAmount_"+value,commonExcelFunctions.strDollarAmount_Value);
					Thread.sleep(200);
					//commonExcelFunctions.validateExpectedProvisionLineValue();
				}
				Thread.sleep(200);
			}*/
		
		
		/*if(!DSC_Retail_Stepped.equalsIgnoreCase(""))	
		{
			String[] DSC_Stepped = DSC_Retail_Stepped.split("\n");
			for(int i=0;i<DSC_Stepped.length;i++) {
				DSC_Retail_Stepped = DSC_Stepped[i];
				commonExcelFunctions.getStepped_Value();
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Stepped_"+value,commonExcelFunctions.strsteppedCopay);
				Thread.sleep(200);
			}
			Thread.sleep(200);
		}
		if(!DSC_Retail_M.equalsIgnoreCase(""))	
		{
			String[] DSC_M = DSC_Retail_M.split("\n");
			for(int i=0;i<DSC_M.length;i++) {
				DSC_Retail_M = DSC_M[i];
				commonExcelFunctions.getM_Value();
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_M_"+value,commonExcelFunctions.strM_Value);
				Thread.sleep(200);
			}
			Thread.sleep(200);
		}	
		if(!DSC_Retail_N.equalsIgnoreCase(""))	
		{
			String[] DSC_N = DSC_Retail_N.split("\n");
			for(int i=0;i<DSC_N.length;i++) {
				DSC_Retail_N = DSC_N[i];
				commonExcelFunctions.getN_Value();
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_N_"+value,commonExcelFunctions.strN_Value);
				Thread.sleep(200);
			}
			Thread.sleep(200);
		}

		if(!DSC_Retail_O.equalsIgnoreCase(""))	
		{
			String[] DSC_O = DSC_Retail_O.split("\n");
			for(int i=0;i<DSC_O.length;i++) {
				DSC_Retail_O = DSC_O[i];
				commonExcelFunctions.getO_Value();
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_O_"+value,commonExcelFunctions.strO_Value);
				Thread.sleep(200);
				//commonExcelFunctions.validateExpectedProvisionLineValue();
			}
			Thread.sleep(200);
		}
		if(!DSC_Retail_Y.equalsIgnoreCase(""))	
		{
			String[] DSC_Y = DSC_Retail_Y.split("\n");
			for(int i=0;i<DSC_Y.length;i++) {
				DSC_Retail_Y = DSC_Y[i];
				commonExcelFunctions.getY_Value();
				commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Y_"+value,commonExcelFunctions.strY_Value);
				Thread.sleep(200);
				//commonExcelFunctions.validateExpectedProvisionLineValue();
			}
			Thread.sleep(200);
		}
	}
}
}*/

		
		
		
		
		/*String[] DSC_M = DSC_Retail_M.split("\n");
		if(!dsc_Subsection.equalsIgnoreCase("")){
			commonExcelFunctions.validateExpectedProvisionLineValue();
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, "SubSectionProcess_2", commonExcelFunctions.strsubsection2);
		}*/
		
		
		
		/*if(!DSC_Retail_FormularyGroup.equalsIgnoreCase("")){
		commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_FormularyGroup_"+value,commonExcelFunctions.strDrugSpecificCopay);
		Thread.sleep(200);
	}*/
	/*if(!DSC_Retail_M.equalsIgnoreCase(""))	
	{
			DSC_Retail_M = DSC_M[i];
			commonExcelFunctions.getM_Value();
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_M_"+value,commonExcelFunctions.strM_Value);
			Thread.sleep(200);
		}
		Thread.sleep(200);*/
		
		
/* if(DSC__DrugListSelection.equalsIgnoreCase("Drug List"))	{
			commonExcelFunctions.findDrugList();
			commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug List");
		} */

		
		
		/*String CellValue="";
		FileInputStream file = null;
		SXSSFWorkbook workbook = null;
		SXSSFSheet xssfSheet = null;
		
		file = new FileInputStream(FilePath);             
		workbook = new SXSSFWorkbook(9000);
		xssfSheet = workbook.getSheet("Sheet 1");
		Row row = xssfSheet.getRow(1);
		Cell cell = row.getCell(1);
		System.out.println("cell"  + cell.toString());*/
		
		
		
		
		OPCPackage pkg = OPCPackage.open(FilePath);
		XSSFReader r = new XSSFReader( pkg );
		SharedStringsTable sst = r.getSharedStringsTable();

		XMLReader parser = fetchSheetParser(sst);

		// To look up the Sheet Name / Sheet Order / rID,
		//  you need to process the core Workbook stream.
		// Normally it's of the form rId# or rSheet#
		InputStream sheet2 = r.getSheet("report1519803326223");
		InputSource sheetSource = new InputSource(sheet2);
		parser.parse(sheetSource);
		sheet2.close();
		
		
		
		
	}
	public XMLReader fetchSheetParser(SharedStringsTable sst) throws SAXException {
		XMLReader parser =
			XMLReaderFactory.createXMLReader(
					"org.apache.xerces.parsers.SAXParser"
			);
		SheetHandler handler = new SheetHandler(sst);
		parser.setContentHandler((ContentHandler) handler);
		return parser;
	}
	private static class SheetHandler extends DefaultHandler {
		private SharedStringsTable sst;
		private String lastContents;
		private boolean nextIsString;
		
		private SheetHandler(SharedStringsTable sst) {
			this.sst = sst;
		}
		
		public void startElement(String uri, String localName, String name,
				Attributes attributes) throws SAXException {
			// c => cell
			if(name.equals("c")) {
				// Print the cell reference
				System.out.print(attributes.getValue("r") + " - ");
				// Figure out if the value is an index in the SST
				String cellType = attributes.getValue("t");
				if(cellType != null && cellType.equals("s")) {
					nextIsString = true;
				} else {
					nextIsString = false;
				}
			}
			// Clear contents cache
			lastContents = "";
		}
	}
}

package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.CopyOfgetTemplateValues_146;
public class TestSuite_146 {

	public static int temp = 100;
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";

	@BeforeTest
	public static void createTestResult()    {
		try	{
			testResultFunctions.createExcelWorkbook("Report");
			ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 146 Consolidated_MU62.xlsx","LineValue");
			TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
			System.out.println("Pass");
		}      catch(Exception e)   {
			e.printStackTrace();
		}
	}
	@Test
	public void f() {
		System.out.println("Report Success TEST TEST");
		System.out.println("Report Success");
		GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P146.csv");
	}

	@Test(dataProvider="Provision 146",invocationCount = 1)//118
	public <testObjArray> void test146(Object[][] test) throws Exception	{
		CopyOfgetTemplateValues_146.getProvision146TemplateVlaues(test);
		CopyOfgetTemplateValues_146.validateDSC();
	}

	@DataProvider(name="Provision 146")
	public Object[][] getDataFromProvision146() throws Exception    {
		System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" +temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		temp++;
		int iTestCaseRow = ExcelUtils.getRowContains("P146_LV_6",0,iteration);//"P146_LV_"+temp
		testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 146 Consolidated_MU62.xlsx","LineValue",iTestCaseRow);
		iteration++;
		return new Object[][] {testObjArray};

	}

}

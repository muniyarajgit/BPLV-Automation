package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.CopyOfgetTemplateValues_107;
public class CopyOfTestSuite_107 {
	
	public static int temp = 23107;//35
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";
	
	@BeforeTest
	//Creating Result Report and Business Template Path to fetch the Values
    public static void createTestResult()    {
           try{
                  testResultFunctions.createExcelWorkbook("Report");
				  //Path for Provision 107 Template
                  ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision_107_Master Template.xlsx","LineValue");
                  TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
                  System.out.println("Pass");
           }      catch(Exception e)   {
                  e.printStackTrace();
           }
    }
	
	 @Test
	  public void f() {
		 System.out.println("Report Success");
		 //Fetching values from Provision 107 SFDc Extract Report
		  GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P107.csv");
	  }
	


	 @Test(dataProvider="Provision 107",invocationCount = 1)
	    public <testObjArray> void test107(Object[][] test) throws Exception{
			 //Fetching values from Provision 107 Template
	    	CopyOfgetTemplateValues_107.getProvision107TemplateValues(test);
			//Validating DCDL Section
//	    	getTemplateValues_107.validateDC();
			//Validating DSC Section
	    	CopyOfgetTemplateValues_107.validateDSC();
			//Validating Accum Section	    	
//	    	getTemplateValues_107.validateAccum();	    	
	    	
	    }
	
	
	
	    @DataProvider(name="Provision 107")
	    public Object[][] getDataFromProvision107() throws Exception    {
	           
	           temp++;
	           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+temp +">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	           int iTestCaseRow = ExcelUtils.getRowContains("P107_LV_"+temp,0,iteration);//+temp
	           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision_107_Master Template.xlsx","LineValue",iTestCaseRow);
	          // iteration++;
	           return new Object[][] {testObjArray};
	
	    }

}

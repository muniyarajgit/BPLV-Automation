package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.getTemplateValues_20;
public class TestSuite_20 {

	public static int temp = 49;//35
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";

	@BeforeTest
	public static void createTestResult()    {
		try	{
			testResultFunctions.createExcelWorkbook("Report");
			TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
			ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\020-Fertility_Consolidated_Master.xlsx","LineValue");
			System.out.println("Pass");
		}      catch(Exception e)   {
			e.printStackTrace();
		}
	}

	@Test
	public void f() {
		System.out.println("Report Success");
		GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P20.csv");
	}

	@Test(dataProvider="Provision 20",invocationCount = 1)
	public <testObjArray> void test4(Object[][] test) throws Exception	{
		getTemplateValues_20.getProvision20TemplateValues(test);
		//	    	getTemplateValues_20.validateDC();
		// getTemplateValues_20.validateDSC();	    	
		//	    	getTemplateValues_20.validateAccum();	    	

	}



	@DataProvider(name="Provision 20")
	public Object[][] getDataFromProvision20() throws Exception    {
		temp++;
		System.out.println("Line Value : " + temp);
		System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+temp +">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		int iTestCaseRow = ExcelUtils.getRowContains("P20_LV_"+temp,0,iteration);//+temp
		testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\020-Fertility_Consolidated_Master.xlsx","LineValue",iTestCaseRow);
		// iteration++;
		return new Object[][] {testObjArray};

	}

}

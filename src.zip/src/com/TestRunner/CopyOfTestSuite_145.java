package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.getTemplateValues_147;
public class CopyOfTestSuite_145 {
	
	public static int temp = 0;
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";
	
	@BeforeTest
    public static void createTestResult()    {
           try{
                  testResultFunctions.createExcelWorkbook("Report");
                  ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 147 Consolidated_MU62.xlsx","LineValue");
                  TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
                  System.out.println("Pass");
           }      catch(Exception e)   {
                  e.printStackTrace();
           }
    }
	 @Test
	  public void f() {
		 System.out.println("Report Success");
		  GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P147_v1.csv");
	  }


	@Test(dataProvider="Provision 147",invocationCount = 515)//394
    public <testObjArray> void test147(Object[][] test) throws Exception	{
    	getTemplateValues_147.getProvision147TemplateVlaues(test);
//    	getTemplateValues_147.validateCopay();
    	getTemplateValues_147.validateDSC();
    	
    }



    @DataProvider(name="Provision 147")
    public Object[][] getDataFromProvision147() throws Exception    {
           
           temp++;
           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< "+temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           int iTestCaseRow = ExcelUtils.getRowContains("P147_LV_"+temp,0,iteration);//+temp
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 147 Consolidated_MU62.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }
   
}

package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.CopyOfgetTemplateValues_13;

public class CopyOfTestSuite_13 {
	
	public static int temp = 290;//35
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";
	
	@BeforeTest
    public static void createTestResult()    {
           try{
                  testResultFunctions.createExcelWorkbook("Report");
                  ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 13 Consolidated_v1.xlsx","LineValue");
                  TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
                  System.out.println("Pass");
           }      catch(Exception e)   {
                  e.printStackTrace();
           }
    }
	
	 @Test
	  public void f() {
		 System.out.println("Report Success");
		  GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P4.csv");
	  }
	


	 @Test(dataProvider="Provision 13",invocationCount = 1)
	    public <testObjArray> void test13(Object[][] test) throws Exception{
	    	CopyOfgetTemplateValues_13.getProvision13TemplateVlaues(test);
//	    	getTemplateValues_13.validateDC();
	    	CopyOfgetTemplateValues_13.validateDSC();	    	
//	    	getTemplateValues_13.validateAccum();	    	
	    	
	    }
	
	
	
	    @DataProvider(name="Provision 13")
	    public Object[][] getDataFromProvision4() throws Exception    {
	           
	           temp++;
	           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+temp +">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	           int iTestCaseRow = ExcelUtils.getRowContains("P13_LV_"+temp,0,iteration);//+temp
	           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 13 Consolidated_MU64.xlsx","LineValue",iTestCaseRow);
	          // iteration++;
	           return new Object[][] {testObjArray};
	
	    }

}


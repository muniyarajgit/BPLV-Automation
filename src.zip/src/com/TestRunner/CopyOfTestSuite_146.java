package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.CopyOfgetTemplateValues_146;
public class CopyOfTestSuite_146 {

	public static int temp = 0;
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";

	@BeforeTest
	public static void createTestResult()    {
		try	{
			testResultFunctions.createExcelWorkbook("Report");
			ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 146 Consolidated_MU64_v1.xlsx","LineValue");
			TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
			System.out.println("Pass");
		}      catch(Exception e)   {
			e.printStackTrace();
		}
	}
	@Test
	public <testObjArray> void test146(Object[][] test) throws Exception	{
		System.out.println("Report Success TEST TEST");
		System.out.println("Report Success");
		CopyOfgetTemplateValues_146.getProvision146TemplateVlaues(test);
	//	getTemplateValues_146.validateDSC();
	}

	@DataProvider(name="Provision 146")
	public Object[][] getDataFromProvision146() throws Exception    {
		System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" +temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		temp++;
		int iTestCaseRow = ExcelUtils.getRowContains("P146_LV_"+temp,0,iteration);//"P146_LV_"+temp
		testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 146 Consolidated_MU64_v1.xlsx","LineValue",iTestCaseRow);
		iteration++;
		return new Object[][] {testObjArray};

	}

}

package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.getTemplateValues_8;
public class TestSuite_8 {
	
	public static int temp = 3;
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";
	
	@BeforeTest
    public static void createTestResult()    {
           try{
                  testResultFunctions.createExcelWorkbook("Report");
                  ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 8 Consolidated_MU62.xlsx","LineValue");
                  TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
                  System.out.println("Pass");
           }      catch(Exception e)   {
                  e.printStackTrace();
           }
    }
	 @Test
	  public void f() {
		 System.out.println("Report Success");
		  GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P8.csv");
	  }
	

	@Test(dataProvider="Provision 8",invocationCount = 1)
    public <testObjArray> void test8(Object[][] test) throws Exception{
    	getTemplateValues_8.getProvision8TemplateVlaues(test);
    	getTemplateValues_8.validateDSC();
//    	getTemplateValues_8.validateDC();
//    	getTemplateValues_8.validateAccum();
    }



    @DataProvider(name="Provision 8")
    public Object[][] getDataFromProvision8() throws Exception    {
           
           temp++;
           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< "+temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           int iTestCaseRow = ExcelUtils.getRowContains("P8_LV_"+temp,0,iteration);
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 8 Consolidated_MU62.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }

}

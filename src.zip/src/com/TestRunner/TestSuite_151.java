package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.getTemplateValues_151;
public class TestSuite_151 {
	
	public static int temp = 0;
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";
	
	@BeforeTest
    public static void createTestResult()    {
           try{
                  testResultFunctions.createExcelWorkbook("Report");
                  TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
                  System.out.println("Pass");
           }      catch(Exception e)   {
                  e.printStackTrace();
           }
    }
	 @Test
	  public void f() {
		 System.out.println("Report Success");
		  GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P151_New.csv");

	  }
	

	

	@Test(dataProvider="Provision 151",invocationCount = 74)
    public <testObjArray> void test151(Object[][] test) throws Exception{
    	getTemplateValues_151.getProvision151TemplateVlaues(test);
    	getTemplateValues_151.validateCopay();
    	getTemplateValues_151.validateDSC();
    }
//
//
//
    @DataProvider(name="Provision 151")
    public Object[][] getDataFromProvision151() throws Exception    {
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 151 Consolidated_final.xlsx","LineValue");
           temp++;
           int iTestCaseRow = ExcelUtils.getRowContains("P151_LV_"+temp,0,iteration);
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision_151_Consolidated_v1.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }

}

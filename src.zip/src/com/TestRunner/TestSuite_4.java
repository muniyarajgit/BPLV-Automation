package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.getTemplateValues_4;
public class TestSuite_4 {

	public static int temp = 49;//35
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";

	@BeforeTest
	public static void createTestResult()    {
		try	{
			testResultFunctions.createExcelWorkbook("Report");
			TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
			ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 4 Consolidated_MU62.xlsx","LineValue");
			System.out.println("Pass");
		}      catch(Exception e)   {
			e.printStackTrace();
		}
	}

	@Test
	public void f() {
		System.out.println("Report Success");
		GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P4.csv");
	}

	@Test(dataProvider="Provision 4",invocationCount = 1)
	public <testObjArray> void test4(Object[][] test) throws Exception	{
		getTemplateValues_4.getProvision4TemplateValues(test);
		//	    	getTemplateValues_4.validateDC();
		getTemplateValues_4.validateDSC();	    	
		//	    	getTemplateValues_4.validateAccum();	    	

	}



	@DataProvider(name="Provision 4")
	public Object[][] getDataFromProvision4() throws Exception    {
		temp++;
		System.out.println("Line Value : " + temp);
		System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+temp +">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		int iTestCaseRow = ExcelUtils.getRowContains("P4_LV_"+temp,0,iteration);//+temp
		testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 4 Consolidated_MU62.xlsx","LineValue",iTestCaseRow);
		// iteration++;
		return new Object[][] {testObjArray};

	}

}

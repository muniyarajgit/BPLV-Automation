package com.TestRunner;

import org.testng.annotations.Test;

public class test234 {
	
	
	@Test
	public static void test()	{
		System.out.println("pass");
	}

}

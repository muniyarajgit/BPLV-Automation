package com.TestRunner;

import org.testng.annotations.Test;

import com.FrameworkFunctions.GetReportValues;

public class TestReport {
  @Test
  public void f() {
	  GetReportValues.readReportValue("");
  }
}

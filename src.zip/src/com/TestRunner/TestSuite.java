package com.TestRunner;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.GetReportValues_test;
import com.FrameworkFunctions.testResultFunctions;
import com.keywords.getTemplateValues_13;
import com.keywords.getTemplateValues_146;
import com.keywords.getTemplateValues_147;
import com.keywords.getTemplateValues_151;
import com.keywords.getTemplateValues_4;
import com.keywords.getTemplateValues_60;
import com.keywords.getTemplateValues_8;
import com.keywords.getTemplateValues_9; //getTemplateValues_28
import com.keywords.getTemplateValues_28;
public class TestSuite {
	
	public static int temp = 50;//35
	public static int iteration = 0;
	public static Object[][] testObjArray = null;
	public static String TC_startTime="";
	public static String TC_EndTime="";
	public static String TestCase = "";
	
	@BeforeTest
    public static void createTestResult()    {
           try{
                  testResultFunctions.createExcelWorkbook("Report");
                  TC_startTime=new SimpleDateFormat("dd/MMM/yyyy_hh-mm-ssa").format(new Date());
                  System.out.println("Pass");
           }      catch(Exception e)   {
                  e.printStackTrace();
           }
    }
	 @Test
	  public void f() {
		 System.out.println("Report Success");
		  GetReportValues.readReportValue("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P9_New.csv");
	  }
	

	/*
	@Test(dataProvider="Provision 60",invocationCount = 44)
    public <testObjArray> void test60(Object[][] test) throws Exception{    	
    	getTemplateValues_60.getProvision60TemplateVlaues(test);
    	getTemplateValues_60.validateDSC();
    }
    

    
    @DataProvider(name="Provision 60")
    public Object[][] getDataFromProvision13() throws Exception    {
    	
    	//temp++;
    		System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+ temp +">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 60 Consolidated.xlsx","LineValue");
           temp++;        
           int iTestCaseRow = ExcelUtils.getRowContains("P60_LV_"+temp,0,iteration);
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 60 Consolidated.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};
    }*/
//
 /*
	@Test(dataProvider="Provision 146",invocationCount = 118)
    public <testObjArray> void test146(Object[][] test) throws Exception{
    	
    	getTemplateValues_146.getProvision146TemplateVlaues(test);
    	getTemplateValues_146.validateDSC();
    }
//
//
//
    @DataProvider(name="Provision 146")
    public Object[][] getDataFromProvision146() throws Exception    {
    	System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" +temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 146 Consolidated.xlsx","LineValue");
           temp++;
           int iTestCaseRow = ExcelUtils.getRowContains("P146_LV_"+temp,0,iteration);//"P146_LV_"+temp
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 146 Consolidated.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }

*/
	/*
	@Test(dataProvider="Provision 147",invocationCount = 94)
    public <testObjArray> void test147(Object[][] test) throws Exception{
    	getTemplateValues_147.getProvision147TemplateVlaues(test);
    	getTemplateValues_147.validateCopay();
    	getTemplateValues_147.validateDSC();
    	
    }



    @DataProvider(name="Provision 147")
    public Object[][] getDataFromProvision147() throws Exception    {
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 147 Consolidated_v2.xlsx","LineValue");
           temp++;
           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< "+temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           int iTestCaseRow = ExcelUtils.getRowContains("P147_LV_"+temp,0,iteration);
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 147 Consolidated_v2.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }
    */
	 /*
	@Test(dataProvider="Provision 151",invocationCount = 73)
    public <testObjArray> void test151(Object[][] test) throws Exception{
    	getTemplateValues_151.getProvision151TemplateVlaues(test);
    	getTemplateValues_151.validateCopay();
    	getTemplateValues_151.validateDSC();
    }
//
//
//
    @DataProvider(name="Provision 151")
    public Object[][] getDataFromProvision151() throws Exception    {
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision_151_Consolidated_v1.xlsx","LineValue");
           temp++;
           int iTestCaseRow = ExcelUtils.getRowContains("P151_LV_"+temp,0,iteration);
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision_151_Consolidated_v1.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }
*/
	/*
	 @Test(dataProvider="Provision 4",invocationCount = 100)
	    public <testObjArray> void test4(Object[][] test) throws Exception{
	    	getTemplateValues_4.getProvision4TemplateValues(test);
	    	getTemplateValues_4.validateDC();
	    	getTemplateValues_4.validateDSC();	    	
	    	getTemplateValues_4.validateAccum();	    	
	    	
	    }
	
	
	
	    @DataProvider(name="Provision 4")
	    public Object[][] getDataFromProvision4() throws Exception    {
	           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 4 Consolidated.xlsx","LineValue");
	           temp++;
	           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+temp +">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	           int iTestCaseRow = ExcelUtils.getRowContains("P4_LV_"+temp,0,iteration);//+temp
	           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 4 Consolidated.xlsx","LineValue",iTestCaseRow);
	          // iteration++;
	           return new Object[][] {testObjArray};
	
	    }
*/
	
	@Test(dataProvider="Provision 9",invocationCount = 50)
    public <testObjArray> void test9(Object[][] test) throws Exception{
    	
    	getTemplateValues_9.getProvision9TemplateVlaues(test);
    	getTemplateValues_9.validateCopay();
    	getTemplateValues_9.validateDSC();
    }



    @DataProvider(name="Provision 9")
    public Object[][] getDataFromProvision9() throws Exception    {
    	
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 9 Consolidated_v1.xlsx","LineValue");
           temp++;
           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           int iTestCaseRow = ExcelUtils.getRowContains("P9_LV_"+temp,0,iteration);//+temp
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 9 Consolidated_v1.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }

	/*
	@Test(dataProvider="Provision 8",invocationCount = 40)
    public <testObjArray> void test8(Object[][] test) throws Exception{
    	getTemplateValues_8.getProvision8TemplateVlaues(test);
    	getTemplateValues_8.validateDSC();
    	getTemplateValues_8.validateDC();
    	getTemplateValues_8.validateAccum();
    }



    @DataProvider(name="Provision 8")
    public Object[][] getDataFromProvision8() throws Exception    {
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 8 Consolidated_v2.xlsx","LineValue");
           temp++;
           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< "+temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           int iTestCaseRow = ExcelUtils.getRowContains("P8_LV_"+temp,0,iteration);
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 8 Consolidated_v2.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    }
*/
/*
@Test(dataProvider="Provision 13",invocationCount = 830)
    public <testObjArray> void test13(Object[][] test) throws Exception{
    	getTemplateValues_13.getProvision13TemplateVlaues(test);
    	getTemplateValues_13.validateDSC();
    	getTemplateValues_13.validateCopay();
   }



    @DataProvider(name="Provision 13")
    public Object[][] getDataFromProvision13() throws Exception    {
           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 13 Consolidated_v4.xlsx","LineValue");
           temp++;
           System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< "+temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           int iTestCaseRow = ExcelUtils.getRowContains("P13_LV_"+temp,0,iteration);//+temp
           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Provision 13 Consolidated_v4.xlsx","LineValue",iTestCaseRow);
           iteration++;
           return new Object[][] {testObjArray};

    } */
	 /*
	 @Test(dataProvider="Provision 28",invocationCount = 100)
	    public <testObjArray> void test146(Object[][] test) throws Exception{
	    	
	    	getTemplateValues_28.getProvision28TemplateVlaues(test);
	    	getTemplateValues_28.validate_WOD();
	    }
	//
	//
	//
	    @DataProvider(name="Provision 28")
	    public Object[][] getDataFromProvision28() throws Exception    {
	    	System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" +temp+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	           ExcelUtils.setExcelFile("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Copy of 226096- P028-Waiver of Deductible ST3894.xlsx","LineValue");
	           temp++;
	           int iTestCaseRow = ExcelUtils.getRowContains("P28_LV_"+temp,0,iteration);//"P146_LV_"+temp
	           testObjArray = ExcelUtils.getTableArray("C:\\Automation_BPLV\\BPLV_Validation\\Provision_Templates\\Copy of 226096- P028-Waiver of Deductible ST3894.xlsx","LineValue",iTestCaseRow);
	           iteration++;
	           return new Object[][] {testObjArray};

	    } */
}

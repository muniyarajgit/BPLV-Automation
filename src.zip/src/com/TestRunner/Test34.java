package com.TestRunner;



import org.testng.annotations.Test;

import com.FrameworkFunctions.ExcelUtils;
import com.FrameworkFunctions.testResultFunctions;

public class Test34 { 


@Test
	public static void test12() throws Exception    {
	
	System.out.println("pass");
}

}

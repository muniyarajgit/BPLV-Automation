package com.FrameworkFunctions;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


import com.perfectomobile.httpclient.utils.FileUtils;

public class testResultFunctions {


	static String strLocation;
	String strSheetName;
	//	String tcStarttime=new SimpleDateFormat("dd-MMM-yyyy_hh-mm-ssa").format(new Date());
	//	String resultFormat = "C:\\BDD_Framework\\DevOps_Framework\\dataSheet\\Result_"+tcStarttime+".xls";
	static String scrshotlink=null;
	static String resultFormat; 
	static String tcStarttime;
	public static String screenShotPath=null;
	static String date=new SimpleDateFormat("dd-MMM-yyyy").format(new Date());
	static String filename=new SimpleDateFormat("dd-MMM-yyyy_hh-mm-ssa").format(new Date());


	public static boolean createExcelWorkbook(String strSheetName) throws IOException, InterruptedException

	{
		tcStarttime=new SimpleDateFormat("dd-MMM-yyyy_hh-mm-ssa").format(new Date());
//		strLocation = "C:\\BDD_Framework\\DevOps_Framework\\test_Results\\Result_"+tcStarttime+".xls";
		strLocation = "C:\\Automation_BPLV\\BPLV_Validation\\testResults";
		//screenShotPath = strLocation+"\\"+"E2E_FormularyAutomation"+date+"\\"+"TestResults"+"_"+filename+"\\"+"E2E_FormularyAutomation"+"_"+tcStarttime;
		
		File dir=new File(strLocation+"\\"+"E2E_FormularyAutomation_"+date+"\\"+"TestResults"+"_"+filename);
		if(!dir.exists())
		{
			dir.mkdirs();
		}
		strLocation = strLocation+"\\"+"E2E_FormularyAutomation_"+date+"\\"+"TestResults"+"_"+filename+"\\Result_"+tcStarttime+".xls";
		boolean result = true;
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sh = wb.createSheet(strSheetName);
		FileOutputStream fileOut;
		try {
			fileOut = new FileOutputStream(strLocation);
			wb.write(fileOut);
			fileOut.close();
			Thread.sleep(2000);
			copyResultFormat(strLocation);
			return result;

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			return false;
		}
	}
	public static void copyResultFormat(String strLocation)

	{
		try
		{
			String resultFormat = "C:\\Automation_BPLV\\BPLV_Validation\\BPLV_Result_Format.xls";
			InputStream inp = new FileInputStream(resultFormat);
			HSSFWorkbook workbook = new HSSFWorkbook(inp);
			HSSFSheet sheet = workbook.getSheet("Report");
			copyRow(workbook, sheet, 1, 1);
			FileOutputStream out = new FileOutputStream(strLocation);
			workbook.write(out);
			out.close();
		}
		catch(Exception e)
		{

		}

	}

	private static  void copyRow(HSSFWorkbook workbook, HSSFSheet worksheet, int sourceRowNum, int destinationRowNum) {

		HSSFRow newRow = worksheet.getRow(destinationRowNum);
		HSSFRow sourceRow = worksheet.getRow(sourceRowNum);

		// If the row exist in destination, push down all rows by 1 else create a new row
		if (newRow != null) {
			worksheet.shiftRows(destinationRowNum, worksheet.getLastRowNum(), 1);
		} else {
			newRow = worksheet.createRow(destinationRowNum);
		}
		// Loop through source columns to add to new row
		for (int i = 0; i < sourceRow.getLastCellNum(); i++) {
			// Grab a copy of the old/new cell
			HSSFCell oldCell = sourceRow.getCell(i);
			HSSFCell newCell = newRow.createCell(i);

			// If the old cell is null jump to next cell
			if (oldCell == null) {
				newCell = null;
				continue;
			}

			// Copy style from old cell and apply to new cell
			HSSFCellStyle newCellStyle = workbook.createCellStyle();
			newCellStyle.cloneStyleFrom(oldCell.getCellStyle());
			;
			newCell.setCellStyle(newCellStyle);

			// If there is a cell comment, copy
			if (oldCell.getCellComment() != null) {
				newCell.setCellComment(oldCell.getCellComment());
			}

			// If there is a cell hyperlink, copy
			if (oldCell.getHyperlink() != null) {
				newCell.setHyperlink(oldCell.getHyperlink());
			}

			// Set the cell data type
			newCell.setCellType(oldCell.getCellType());

			// Set the cell data value
			switch (oldCell.getCellType()) {
			case HSSFCell.CELL_TYPE_BLANK:
				newCell.setCellValue(oldCell.getStringCellValue());
				break;
			case HSSFCell.CELL_TYPE_BOOLEAN:
				newCell.setCellValue(oldCell.getBooleanCellValue());
				break;
			case HSSFCell.CELL_TYPE_ERROR:
				newCell.setCellErrorValue(oldCell.getErrorCellValue());
				break;
			case HSSFCell.CELL_TYPE_FORMULA:
				newCell.setCellFormula(oldCell.getCellFormula());
				break;
			case HSSFCell.CELL_TYPE_NUMERIC:
				newCell.setCellValue(oldCell.getNumericCellValue());
				break;
			case HSSFCell.CELL_TYPE_STRING:
				newCell.setCellValue(oldCell.getRichStringCellValue());
				break;
			}
		}
	}
/*
	public static void writeKeyword_in_Report(String strwriteValue)



	{
		try
		{
			InputStream inp = new FileInputStream(strLocation);
			org.apache.poi.ss.usermodel.Workbook tempWB = WorkbookFactory.create(inp);

			org.apache.poi.ss.usermodel.Sheet dataSheet = tempWB.getSheet("Report");
			// int ColIndex=Driver.findCol(dataSheet,columnname);
			int rwNumb = dataSheet.getLastRowNum()+1;
			try
			{
				Cell cVal = dataSheet.getRow(rwNumb).createCell(1);
				cVal.setCellType(Cell.CELL_TYPE_STRING);
				cVal.setCellValue(strwriteValue);
			}
			catch(Exception e)
			{

				Cell cVal = dataSheet.createRow(rwNumb).createCell(1);
				cVal.setCellType(Cell.CELL_TYPE_STRING);
				cVal.setCellValue(strwriteValue);
			}

			FileOutputStream resultIns = new FileOutputStream(strLocation);
			tempWB.write(resultIns); 
			resultIns.flush();
		}
		catch(Exception e)
		{

		}
	}
/*
	public static void write_params_for_Keyword_in_Report(String strStartTime,String strEndTime, String keyword)
	{
		try
		{
			InputStream inp = new FileInputStream(strLocation);
			org.apache.poi.ss.usermodel.Workbook tempWB = WorkbookFactory.create(inp);
			org.apache.poi.ss.usermodel.Sheet dataSheet = tempWB.getSheet("Report");
			int rwNumb = dataSheet.getLastRowNum();
			String strchkVal = "",strchkStatus="",strOverallStatus = "PASS";
			for(int i=11;i<=rwNumb;i++)
			{
				try
				{
					String strKeyName = dataSheet.getRow(i).getCell(1).getStringCellValue();
					if(strKeyName.equalsIgnoreCase(keyword))
					{
						for(int k=i+1;k<=rwNumb;k++)
						{
							try
							{
								strchkVal = dataSheet.getRow(k).getCell(1).getStringCellValue();
								if(!strchkVal.equalsIgnoreCase(""))
								{
									break;
								}
							}
							catch(Exception e)
							{
								strchkStatus = dataSheet.getRow(k).getCell(7).getStringCellValue();
								if(strchkStatus.equalsIgnoreCase("FAIL"))
								{
									strOverallStatus = "FAIL";
									break;
								}
							}
						}
						Cell cStart = dataSheet.getRow(i).createCell(3);
						cStart.setCellType(Cell.CELL_TYPE_STRING);
						cStart.setCellValue(strStartTime);
						Cell cEnd = dataSheet.getRow(i).createCell(4);
						cEnd.setCellType(Cell.CELL_TYPE_STRING);
						cEnd.setCellValue(strEndTime);
						Cell cStatus = dataSheet.getRow(i).createCell(7);
						cStatus.setCellType(Cell.CELL_TYPE_STRING);
						cStatus.setCellValue(strOverallStatus);
						break;
					}
					else
					{
						continue;
					}
				}
				catch(Exception e)
				{
					continue;
				}
			}
			FileOutputStream resultIns = new FileOutputStream(strLocation);
			tempWB.write(resultIns); 
			resultIns.flush();
			//			TAKE_ScreenShot();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}*/
/*	public static void set_custom_message_in_Report(String strDesc, String strParam, String strStatus)


	{
		try
		{
			InputStream inp = new FileInputStream(strLocation);
			org.apache.poi.ss.usermodel.Workbook tempWB = WorkbookFactory.create(inp);

			org.apache.poi.ss.usermodel.Sheet dataSheet = tempWB.getSheet("Report");
			int rwNumb = dataSheet.getLastRowNum()+1;
			try
			{
				Cell cDesc = dataSheet.createRow(rwNumb).createCell(2);
				cDesc.setCellType(Cell.CELL_TYPE_STRING);
				cDesc.setCellValue(strDesc);
				Cell cParam = dataSheet.getRow(rwNumb).createCell(5);
				cParam.setCellType(Cell.CELL_TYPE_STRING);
				cParam.setCellValue(strParam);
				Cell cStat = dataSheet.getRow(rwNumb).createCell(7);
				cStat.setCellType(Cell.CELL_TYPE_STRING);
				cStat.setCellValue(strStatus);

				if(strStatus.equalsIgnoreCase("PASS"))
				{
					System.out.println(strDesc);
				}
				else
				{
					System.out.println(strDesc);

					/*CellStyle style = tempWB.createCellStyle();
					Font f =  tempWB.createFont();
					f.setUnderline(Font.U_SINGLE);
					f.setColor(IndexedColors.DARK_RED.getIndex());
					style.setFont(f);
					Cell cScreen = dataSheet.getRow(rwNumb).createCell(8);
					cScreen.setCellType(Cell.CELL_TYPE_STRING);
					
					CreationHelper createHelper = tempWB.getCreationHelper();
					HSSFHyperlink hype = (HSSFHyperlink) createHelper.createHyperlink(Hyperlink.LINK_URL);
					
					cScreen.setHyperlink(hype);
					cScreen.setCellStyle(style);*/

/*
				}
			}
			catch(Exception e)
			{
				System.out.println("Exception thrown in reporting function set_custom_message_in_Report");
			}

			FileOutputStream resultIns = new FileOutputStream(strLocation);
			tempWB.write(resultIns); 
			resultIns.flush();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	*/
	/*public static void set_custom_message_in_Report_Test(String TestCase, String Provision, String LineValue, String Sub_Section, String Field_API, String BT_FieldValue, String Report_Value, String Mapping_Value, String Status)


	{
		try
		{
			InputStream inp = new FileInputStream(strLocation);
			org.apache.poi.ss.usermodel.Workbook tempWB = WorkbookFactory.create(inp);

			org.apache.poi.ss.usermodel.Sheet dataSheet = tempWB.getSheet("Report");
			int rwNumb = dataSheet.getLastRowNum()+1;
			try
			{
				Cell cTestCase = dataSheet.createRow(rwNumb).createCell(3);
				cTestCase.setCellType(Cell.CELL_TYPE_STRING);
				cTestCase.setCellValue(TestCase);
				//System.out.println(TestCase);
				Cell cP = dataSheet.getRow(rwNumb).createCell(4);
				cP.setCellType(Cell.CELL_TYPE_STRING);
				cP.setCellValue(Provision);
				Cell cL = dataSheet.getRow(rwNumb).createCell(5);
				cL.setCellType(Cell.CELL_TYPE_STRING);
				cL.setCellValue(LineValue);
				Cell cS = dataSheet.createRow(rwNumb).createCell(6);
				cS.setCellType(Cell.CELL_TYPE_STRING);
				cS.setCellValue(Sub_Section);
				Cell cA = dataSheet.getRow(rwNumb).createCell(7);
				cA.setCellType(Cell.CELL_TYPE_STRING);
				cA.setCellValue(Field_API);
				Cell cB = dataSheet.getRow(rwNumb).createCell(8);
				cB.setCellType(Cell.CELL_TYPE_STRING);
				cB.setCellValue(BT_FieldValue);
				//System.out.println(BT_FieldValue);
				Cell cR = dataSheet.createRow(rwNumb).createCell(9);
				cR.setCellType(Cell.CELL_TYPE_STRING);
				cR.setCellValue(Report_Value);
				Cell cM = dataSheet.getRow(rwNumb).createCell(10);
				cM.setCellType(Cell.CELL_TYPE_STRING);
				cM.setCellValue(Mapping_Value);
				Cell cStat = dataSheet.getRow(rwNumb).createCell(11);
				cStat.setCellType(Cell.CELL_TYPE_STRING);
				cStat.setCellValue(Status);

			}
			catch(Exception e)
			{
				System.out.println("Exception thrown in reporting function set_custom_message_in_Report");
			}

			FileOutputStream resultIns = new FileOutputStream(strLocation);
			tempWB.write(resultIns); 
			resultIns.flush();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	*/
	
	//testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Fail");
	public static void set_custom_message_in_Report_Test(String TestCase, String Provision, String LineValue,String Subsection,String FieldName,String BTValues,String SFDCValues,String mappingValue,String Status )
	//public static void set_custom_message_in_Report_Test(String TestCase, String Provision, String LineValue,String Subsection,String FieldName,String BTValues,String SFDCValues,String mappingValue,String Status )

	{
		try
		{
			InputStream inp = new FileInputStream(strLocation);
			org.apache.poi.ss.usermodel.Workbook tempWB = WorkbookFactory.create(inp);

			org.apache.poi.ss.usermodel.Sheet dataSheet = tempWB.getSheet("Report");
			int rwNumb = dataSheet.getLastRowNum()+1;
			try
			{
				Cell cTestCase = dataSheet.createRow(rwNumb).createCell(3);
				cTestCase.setCellType(Cell.CELL_TYPE_STRING);
				cTestCase.setCellValue(TestCase);
				//System.out.println(TestCase);
				Cell cP = dataSheet.getRow(rwNumb).createCell(4);
				cP.setCellType(Cell.CELL_TYPE_STRING);
				cP.setCellValue(Provision);
				Cell cL = dataSheet.getRow(rwNumb).createCell(5);
				cL.setCellType(Cell.CELL_TYPE_STRING);
				cL.setCellValue(LineValue);
				Cell cS = dataSheet.getRow(rwNumb).createCell(6);
				cS.setCellType(Cell.CELL_TYPE_STRING);
				cS.setCellValue(Subsection);
				Cell cA = dataSheet.getRow(rwNumb).createCell(7);
				cA.setCellType(Cell.CELL_TYPE_STRING);
				cA.setCellValue(FieldName);
				Cell cB = dataSheet.getRow(rwNumb).createCell(8);
				cB.setCellType(Cell.CELL_TYPE_STRING);
				cB.setCellValue(BTValues);
				//System.out.println(BT_FieldValue);
				Cell cR = dataSheet.getRow(rwNumb).createCell(9);
				cR.setCellType(Cell.CELL_TYPE_STRING);
				cR.setCellValue(SFDCValues);
				Cell cM = dataSheet.getRow(rwNumb).createCell(10);
				cM.setCellType(Cell.CELL_TYPE_STRING);
				cM.setCellValue(mappingValue);
				Cell cStat = dataSheet.getRow(rwNumb).createCell(11);
				cStat.setCellType(Cell.CELL_TYPE_STRING);
				cStat.setCellValue(Status);
				
			}
			catch(Exception e)
			{
				System.out.println("Exception thrown in reporting function set_custom_message_in_Report");
			}

			FileOutputStream resultIns = new FileOutputStream(strLocation);
			tempWB.write(resultIns); 
			resultIns.flush();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
				
	
/*
public static void Write_TC_values_in_Report(int intTotalKeyCnt, String strTCStartime, String strTCEndime,String strTCTotalTime)
	{
		try
		{
			InputStream inp = new FileInputStream(strLocation);
			org.apache.poi.ss.usermodel.Workbook tempWB = WorkbookFactory.create(inp);
			org.apache.poi.ss.usermodel.Sheet dataSheet = tempWB.getSheet("Report");
			int rwNumb = dataSheet.getLastRowNum();
			//strchkVal = "",
			String strchkStatus="",strOverstat="";
			int intPasscnt=0,intFailcnt=0;
			for(int i=11;i<=rwNumb;i++)
			{
				try
				{
					String strKeyName = dataSheet.getRow(i).getCell(1).getStringCellValue();
					if(!strKeyName.equalsIgnoreCase(""))
					{
						try
						{
							strchkStatus = dataSheet.getRow(i).getCell(7).getStringCellValue();
							if(strchkStatus.equalsIgnoreCase("PASS"))
							{
								intPasscnt = intPasscnt+1;
							}
							else
							{
								intFailcnt = intFailcnt+1;
							}
						}
						catch(Exception e)
						{
							continue;
						}
					}
					else
					{
						continue;
					}
				}
				catch(Exception e)
				{
					continue;
				}
			}

			if(intFailcnt==0)
			{
				strOverstat = "PASS";
			}
			else
			{
				strOverstat = "FAIL";
			}
			try
			{
				Cell cTotKey = dataSheet.getRow(6).getCell(3);
				cTotKey.setCellType(Cell.CELL_TYPE_STRING);
				cTotKey.setCellValue(String.valueOf(intTotalKeyCnt));
				Cell cPassKey = dataSheet.getRow(7).getCell(3);
				cPassKey.setCellType(Cell.CELL_TYPE_STRING);
				cPassKey.setCellValue(String.valueOf(intPasscnt));
				Cell cFailKey = dataSheet.getRow(8).getCell(3);
				cFailKey.setCellType(Cell.CELL_TYPE_STRING);
				cFailKey.setCellValue(String.valueOf(intFailcnt));
				Cell cTotKeyNotExe = dataSheet.getRow(9).getCell(3);
				cTotKeyNotExe.setCellType(Cell.CELL_TYPE_STRING);
				cTotKeyNotExe.setCellValue(String.valueOf(intTotalKeyCnt-(intPasscnt+intFailcnt)));
				Cell cStat = dataSheet.getRow(4).getCell(2);
				cStat.setCellType(Cell.CELL_TYPE_STRING);
				cStat.setCellValue(String.valueOf(strTCStartime));
				Cell cEnd = dataSheet.getRow(4).getCell(4);
				cEnd.setCellType(Cell.CELL_TYPE_STRING);
				cEnd.setCellValue(String.valueOf(strTCEndime));
				Cell cTot = dataSheet.getRow(4).getCell(7);
				cTot.setCellType(Cell.CELL_TYPE_STRING);
				cTot.setCellValue(String.valueOf(strTCTotalTime));
				Cell cOverallStat = dataSheet.getRow(4).getCell(10);
				cOverallStat.setCellType(Cell.CELL_TYPE_STRING);
				cOverallStat.setCellValue(String.valueOf(strOverstat));

				Cell cTCName = dataSheet.getRow(2).getCell(1);
				String strTCVal = cTCName.getStringCellValue();
				cTCName.setCellType(Cell.CELL_TYPE_STRING);
				cTCName.setCellValue(String.valueOf(strTCVal)+String.valueOf("Pharmacy- Formulary Automation"));

			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

			FileOutputStream resultIns = new FileOutputStream(strLocation);
			tempWB.write(resultIns); 
			resultIns.flush();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

*/


}

package com.FrameworkFunctions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.framework.frameworkParameters;
import com.keywords.ValidateProvisionTemplate;
import com.keywords.ValidateProvisionTemplate_Test;
import com.keywords.getTemplateValues_9;



public class GetReportValues {
	public static boolean Flag	= false;
	public static int MapCountVal = 0;
	//Copay DrugclassVal
	public static String DrugclassVal	= null;
	public static String strPlanTypePaperFieldalue	= null;

	public static String strSpecialty				= null;
	public static String strSpecialty_OON			= null;
	//		public static String strpaper_DSC				= null;
	public static String strpaperOON_DSC			= null;
	public static String strPercentRepo	 			= null;
	public static  String strmindollarreport 		= null;
	public static  String strmaxdollarreport 		= null;
	public static  String strCopayCalculationreport = null;

	public static String FilePath = frameworkParameters.FilePath;
	public static String strNumberOfTierValue 	= null;
	public static String strsubProcessValue 	= null;
	public static String srtTierType			= null;
	public static String strDollarAmountValue 	= "";
	public static String strNonFormularyAmountValueOrder = "";
	public static String strsteppedCopay 		= null;
	static Cell cell;
	public static XSSFSheet xssfSheet = null;
	static boolean retailtire		  = false;
	public static boolean ExpectedFlag;
	public static String strsubsection2	= null;
	public static String strProvisionLineValue_id	= null;
	public static boolean drugGrouplist			 = false;
	public static boolean druglist				 = false;
	public static boolean lineValue_Temp = false;
	//	DC Fields
	public static String strDC_Retail_IncExcl_DC 		= null;
	public static String strDC_Retail_IncExcl_1 		= null;
	public static String strDC_ApplyLimit_1 		= null;
	public static String strDC_Retail_DrugListorDrugGroup_1 		= null;
	public static String strDC_Retail_StartAge_1 		= null;
	public static String strDC_Retail_EndAge_1 		= null;
	public static String strDC_Gender_1 		= null;
	public static String strDC_MinDays_1 		= null;
	public static String strDC_DailyDose_1 		= null;
	public static String strDC_StartAgeType_1 		= null;
	public static String strDC_EndAgeType_1 		= null;
	public static String strDC_MaxDays_1 		= null;
	public static String strDC_MaxDaysperfill_1 		= null;
	public static String strDC_DOTTP_1 		= null;
	public static String strDC_DOTDays_1 		= null;
	public static String strDC_DOTTV_1 		= null;
	public static String strDC_QOTQty_1 		= null;
	public static String strDC_QOTTP_1 		= null;
	public static String strDC_QOTTV_1 		= null;
	public static String strDC_MaxFills_1 		= null;
	public static String strDC_MinQty_1 		= null;

	public static String ParentMapVal = null;
	//Accums DSC
	public static String strAccum_DrugSpecific_MAB                      = null;
	public static String strAccum_DrugSpecific_M                        = null;
	public static String strAccum_DrugSpecific_N                        = null;
	public static String strAccum_DrugSpecific_O                        = null;
	public static String strAccum_DrugSpecific_Y                        = null;
	public static String strAccum_DrugSpecific_DL                       = null;
	public static String strAccum_DrugSpecific_DG                       = null;
	public static String strAccum_DrugSpecific_MABAmount                = null;
	public static String strAccum_DrugSpecific_MABPeriod                = null;
	public static String strAccum_DrugSpecific_MABMet                   = null;

	public static boolean DLColorFlag= true;
	public static boolean IncExclDCColorFlag= true;
	public static boolean IncExclColorFlag= true;
	public static boolean DLALFlag= true;



	static DataFormatter formatter=new DataFormatter();
	public static String drugListValueID		= "";


	public static String druglistName				= null;	
	public static String drugGrouplistName		 = null;
	public static String drugGroupListValueID 	 = "";

	public static ArrayList<String> strFormularyIDMappingValue = new ArrayList<String>();

	public static String strDrugSpecificCopay	= null;
	public static String strFormularyGroup 		= null;
	public static String ParentMappingValue	 	= null;
	public static String strM_Value 			= null;
	public static String strN_Value				= null;
	public static String strO_Value				= null;
	public static String strY_Value				= null;
	public static String strPreferredGeneric    =null;
	public static String strNon_PreferredGeneric=null;
	public static String strPreferredBrand         =null;
	public static String strNon_PreferredBrand =null;
	public static String strDollarAmount_Value	= null;
	public static String strPercent_Value	= null;
	public static String strMinimumDollar_Value	= null;
	public static String strMaximumDollar_Value	= null;
	public static String CRDCopayLogic			= "";
	public static String strReverse			= null;

	public static boolean steppedColorFlag= true;
	public static boolean MColorFlag= true;
	public static boolean NColorFlag= true;
	public static boolean OColorFlag= true;
	public static boolean YColorFlag= true;
	public static boolean DollarAmountColorFlag= true;
	public static boolean ReverseColorFlag= true;
	public static boolean MaxdollarColorFlag= true;
	public static boolean PercentColorFlag= true;
	public static boolean MindollarColorFlag= true;
	public static boolean CopaycalcColorFlag= true;
	public static String T_PaperOutOfNetwork = "";
	public static String T_IsTherePaperOoN = "";
	public static String T_DifferentCopays = "";
	public static String T_ApplyPenalty = "";
	public static String T_PenaltyType = "";
	public static String T_PenaltyAmount = "";
	public static String T_PercentageApplied = "";
	public static String T_NoOfTiers = "";
	public static String F_PaperOutOfNetwork = "";
	public static String F_IsTherePaperOoN = "";
	public static String F_DifferentCopays = "";
	public static String F_ApplyPenalty = "";
	public static String F_PenaltyType = "";
	public static String F_PenaltyAmount = "";
	public static String F_PercentageApplied = "";
	public static String F_NoOfTiers = "";

	public static ArrayList<String> firstColumnValue  = new ArrayList<String>();
	static ArrayList<String> secondColumnValue = new ArrayList<String>();
	public static ArrayList<String> ThirdColumnValue  = new ArrayList<String>();
	static ArrayList<String> fourthColumnValue = new ArrayList<String>();
	static ArrayList<String> fifthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> sixthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> seventhColumnValue= new ArrayList<String>();
	public static ArrayList<String> eighthColumnValue = new ArrayList<String>();
	public static ArrayList<String> ninthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> tenthColumnValue  = new ArrayList<String>();
	static ArrayList<String> eleventhColumnValue  = new ArrayList<String>();
	
	public static ArrayList<String> twelthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> thirteenColumnValue  = new ArrayList<String>();
	static ArrayList<String> fourteenthColumnValue  = new ArrayList<String>();

	static int mappingName=0,mappingValuesName=1,lineValueID=2,provisionValue=3,lineValue=4,objectAPI=5,fieldLabel=6,fieldValue=8;
	public static int row=0;
	static int parentMapping=9;
	static int parentMapNotes=10;
//	static int NotesColumn=11;
	
	/*
	 * 
	 */
	
	static int create=11;
	static int deleteRecord=12;
	static int RecordTypeId=13;
	
	static int rowIterator;


	public static void readReportValue(String path)	{
		File csvFile= new File(path);

		//File csvFile= new File("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P9_New.csv");
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				row++;
				//strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				firstColumnValue.add(strPosition[mappingName]);
				secondColumnValue.add(strPosition[mappingValuesName]);
				ThirdColumnValue.add(strPosition[lineValueID]);
				fourthColumnValue.add(strPosition[provisionValue]);
				fifthColumnValue.add(strPosition[lineValue]);
				sixthColumnValue.add(strPosition[objectAPI]);
				seventhColumnValue.add(strPosition[fieldLabel]);
				eighthColumnValue.add(strPosition[fieldValue]);
				ninthColumnValue.add(strPosition[parentMapping]);
				tenthColumnValue.add(strPosition[parentMapNotes]);
				//eleventhColumnValue.add(strPosition[NotesColumn]);
				twelthColumnValue.add(strPosition[create]);
				thirteenColumnValue.add(strPosition[deleteRecord]);
				fourteenthColumnValue.add(strPosition[RecordTypeId]);
			}	

		}catch 	(Exception e)	{
			e.printStackTrace();
		}



	}
	public static void LineValueCheck(String P, String L){
		int PvLn = 0;
		for(rowIterator=0;rowIterator<row;rowIterator++)	{
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+P+"L"+L))	{
				PvLn++;
			}
		}
		if(PvLn==0){
			testResultFunctions.set_custom_message_in_Report_Test("", ValidateProvisionTemplate_Test.provisionNumber, ValidateProvisionTemplate_Test.provisionLineValue, "", "", "", "", "", "Failed - Mapping LineValue not available in the Salesforce report");		
		}
	}
	// To get Parent Mapping Value
		static int formularyIteraor;
		public static ArrayList arr_DC_MAPID = new ArrayList();
		public static ArrayList arr_DC_MAPID_1 = new ArrayList();
		public static void MapValDC(String P, String L, String Sub_Sec){
			arr_DC_MAPID_1.clear();
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+P+"L"+L))	{
					if(Sub_Sec.contains("DC_Retail") && (ninthColumnValue.get(formularyIteraor).toString().equals("MV-0000224")) && (twelthColumnValue.get(formularyIteraor).toString().equals("1"))){
						//(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Related Drug Coverage"))	{
							arr_DC_MAPID.add(secondColumnValue.get(formularyIteraor).toString());
							arr_DC_MAPID_1.add(secondColumnValue.get(formularyIteraor).toString());
							System.out.println("TEST>>>>"+arr_DC_MAPID);
						//}
					}				
					else if(Sub_Sec.contains("DC_Mail") && (ninthColumnValue.get(formularyIteraor).toString().equals("MV-0000223"))&& (twelthColumnValue.get(formularyIteraor).toString().equals("1"))){
						//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Related Drug Coverage"))	{
							arr_DC_MAPID.add(secondColumnValue.get(formularyIteraor).toString());
							arr_DC_MAPID_1.add(secondColumnValue.get(formularyIteraor).toString());
						//}
					}
				}

			}
			System.out.println(arr_DC_MAPID);	
		}
	public static void FailedReportValues_DC(String Sub_Sec){
		//System.out.println(arrMAPID);
		for(int i=0;i<arr_DC_MAPID.size();i++){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
				if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase((String) arr_DC_MAPID.get(i))){
					if(seventhColumnValue.get(formularyIteraor).toString().equals("Related Drug Coverage") ){}
					else{
						testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Failed");
					}
				}
			}
		}
		arr_DC_MAPID.clear();
	}
	public static String parntMappingValueFinal="";
	public static void WOD()	{
		DrugclassVal = "";
		parntMappingValueFinal = "";
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	
		{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Class"))	{
					DrugclassVal = eighthColumnValue.get(formularyIteraor).toString(); 
					parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
					break;

				}
			}
		}
	}

	

	public static void compareCRDDetails(String pNo,String Line_Text,String Plan_Type,String PaperOutOfNetwork,String IsTherePaperOoN,String DifferentCopays,String ApplyPenalty,String PenaltyType,String PenaltyAmount,String PercentageApplied,String NoOfTiers){
		
		 T_PaperOutOfNetwork = "";
		 T_IsTherePaperOoN = "";
		 T_DifferentCopays = "";
		 T_ApplyPenalty = "";
		 T_PenaltyType = "";
		 T_PenaltyAmount = "";
		 T_PercentageApplied = "";
		 T_NoOfTiers = "";
		 F_PaperOutOfNetwork = "";
		 F_IsTherePaperOoN = "";
		 F_DifferentCopays = "";
		 F_ApplyPenalty = "";
		 F_PenaltyType = "";
		 F_PenaltyAmount = "";
		 F_PercentageApplied = "";
		 F_NoOfTiers = "";
		
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+pNo+"L"+Line_Text))	{
				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Plan Types:Paper Out of Network"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(PaperOutOfNetwork))	{
						T_PaperOutOfNetwork = PaperOutOfNetwork;
					}
					else
					{
						F_PaperOutOfNetwork =eighthColumnValue.get(formularyIteraor).toString();
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Is there Paper Out of Network?"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(IsTherePaperOoN))	{
						T_IsTherePaperOoN = IsTherePaperOoN;
					}
					else
					{
						F_IsTherePaperOoN =eighthColumnValue.get(formularyIteraor).toString();
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Different Copays from Paper In Network?"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(DifferentCopays))	{
						T_DifferentCopays = DifferentCopays;
					}
					else
					{
						F_DifferentCopays =eighthColumnValue.get(formularyIteraor).toString();
					}
				} 
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Apply Penalty?"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(ApplyPenalty))	{
						T_ApplyPenalty = ApplyPenalty;
					}
					else
					{
						F_ApplyPenalty =eighthColumnValue.get(formularyIteraor).toString();
					}
				} 
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Penalty Type"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(PenaltyType))	{
						T_PenaltyType = PenaltyType;
					}
					else
					{
						F_PenaltyType =eighthColumnValue.get(formularyIteraor).toString();
					}
				} 
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Penalty Amount"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(PenaltyAmount))	{
						T_PenaltyAmount = PenaltyAmount;
					}
					else
					{
						F_PenaltyAmount =eighthColumnValue.get(formularyIteraor).toString();
					}
				} 
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percentage Applied"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(PercentageApplied))	{
						T_PercentageApplied = PercentageApplied;
					}
					else
					{
						F_PercentageApplied =eighthColumnValue.get(formularyIteraor).toString();
					}
				}  
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Paper Out of Network - Number of Tiers"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().trim().equals(NoOfTiers))	{
						T_NoOfTiers = NoOfTiers;
					}
					else
					{
						F_NoOfTiers =eighthColumnValue.get(formularyIteraor).toString();
					}
				}  
			}
		}
	}
	
	//Delete
		public static ArrayList DeleteDrug = new ArrayList();
	    public static String Delete = "";
	    public static String DeleteMap = "";
	    //public static String DeleteDrug ="";
	    public static void DeleteCheck(String Pr,String Lv,String Plan,String DL)      {
	    	DeleteDrug.clear();
	           String[] DList = DL.split("\n");
	           System.out.println(DList.length);
	           for(int i=0;i<DList.length;i++)
	           {
	                  if(DList[i].contains("Remove")||DList[i].contains("remove"))
	                  {
	                	  if(DList[i].contains("DCA")){
	                        DeleteDrug.add(DList[i].substring(0, 11));
	                        System.out.println(DeleteDrug);
	                	  }
	                	  else
	                	  {
	                		  DeleteDrug.add(DList[i].substring(0, 10));
	                          System.out.println(DeleteDrug);
	                	  }
	                  }
	           }
	           for(int i=0;i<DeleteDrug.size();i++)
	           {
	                  Delete="";
	                  if(DeleteDrug.get(i).toString().contains("DCA"))
	                  {
	                        findDrugGroupName_1(DeleteDrug.get(i).toString());
	                        for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
	                               if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv)) {
	                               if(Plan.equalsIgnoreCase("Retail")&&ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("MV-0000224")){
	                                      if(thirteenColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("1")) {
	                                          if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(drugGroupListValueID))
	                                             {
	                                                    Delete = drugGroupListValueID;
	                                                    DeleteMap = "MV-0000224";
	                                             }
	                                      }
	                               }
	                              else if(Plan.equalsIgnoreCase("Mail")&&ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("MV-0000223")){
	                                   if(thirteenColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("1")) {
	                                       if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(drugGroupListValueID))
	                                          {
	                                                 Delete = drugGroupListValueID;
	                                                 DeleteMap = "MV-0000223";
	                                          }
	                                   }
	                            }
	                             
	                               }
	                        }
	                        if(!Delete.equals(""))
	                        {
	                               testResultFunctions.set_custom_message_in_Report_Test("", Pr, Lv, Plan, "Delete", drugGroupListValueID, drugGroupListValueID,DeleteMap, "Pass");
	                        }
	                        else
	                        {
	                               testResultFunctions.set_custom_message_in_Report_Test("", Pr, Lv, Plan, "Delete", drugGroupListValueID, "", "", "Fail");

	                        }
	                        
	                  }
	                  else
	                  {
	                	  findDrugList_1(DeleteDrug.get(i).toString());
	                      for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
	                             if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv)) {
	                             if(Plan.equalsIgnoreCase("Retail")&&ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("MV-0000224")){
	                                    if(thirteenColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("1")) {
	                                       // if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(drugListValueID))
	                                    	if(drugListValueID.contains(eighthColumnValue.get(formularyIteraor).toString()))
	                                           {
	                                                  Delete = drugListValueID;
	                                           }
	                                    }
	                             }
	                            else if(Plan.equalsIgnoreCase("Mail")&&ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("MV-0000223")){
	                                 if(thirteenColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("1")) {
	                                     //if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(drugListValueID))
	                                	 if(drugListValueID.contains(eighthColumnValue.get(formularyIteraor).toString()))
	                                        {
	                                               Delete = drugListValueID;
	                                        }
	                                 }
	                          }
	                           
	                             }
	                      }   
	                      if(!Delete.equals(""))
	                      {
	                             testResultFunctions.set_custom_message_in_Report_Test("", Pr, Lv, Plan, "Delete", drugListValueID, drugListValueID, "MV-0000224", "Pass");
	                      }
	                      else
	                      {
	                             testResultFunctions.set_custom_message_in_Report_Test("", Pr, Lv, Plan, "Delete", drugListValueID, "", "", "Fail");

	                      }
	                  }
	                  
	                  
	           }
	           
	    }
	    public static void findDrugGroupName_1(String DG)	{
			drugGroupListValueID = "null";
			drugListValueID = "null";
			int rowIterator = 0;
			File drugFile= new File(frameworkParameters.strDrugGroup);
			BufferedReader br = null;
			String line = "";
			String cvsSplitBy = ",";
			String[] strPosition = null;
			ArrayList<String> drugGroupID  = new ArrayList<String>();
			ArrayList<String> drugGroupnameValue = new ArrayList<String>();
			ArrayList<String> drugGroupName = new ArrayList<String>();
			drugGroupID.clear();
			drugGroupnameValue.clear();
			drugGroupName.clear();
			try {
				br = new BufferedReader(new FileReader(drugFile));
				while ((line = br.readLine()) != null) {
					strPosition = line.split(cvsSplitBy);
					strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
					drugGroupID.add(strPosition[1]);
					drugGroupnameValue.add(strPosition[2]);
					drugGroupName.add(strPosition[0]);
				}
				for(rowIterator = 0;rowIterator<drugGroupID.size();rowIterator++)	{
					//System.out.println(ValidateProvisionTemplate.DSC__DrugList);
					if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equals(DG))
					{
						System.out.println(drugGroupnameValue.get(rowIterator).toString());
					} //equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()) //drugGroupnameValue.get(rowIterator).toString()
					//drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1)
					if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equalsIgnoreCase(DG))	{					
						drugGrouplistName = drugGroupName.get(rowIterator).toString();
						drugGroupListValueID = drugGroupID.get(rowIterator).toString().substring(1,drugGroupID.get(rowIterator).toString().length()-1);
						System.out.println(drugGroupListValueID);
						System.out.println("drugGroupListValueID length : " + drugGroupListValueID.length());
						if(drugGroupListValueID.length()>15){
							drugGroupListValueID = drugGroupListValueID.substring(0,15);
							//	System.out.println(drugGroupListValueID);
						}
						break;
					}
					else
					{
						drugGroupListValueID = "";
					}

				}
			}	catch	(Exception e)	{
				e.printStackTrace();
			}
		}
	    //
		public static void findDrugList_1(String DL)	{
			drugGroupListValueID = "null";
			drugListValueID = "null";
			int rowIterator = 0;
			File drugFile= new File(frameworkParameters.drugListPath);
			BufferedReader br = null;
			String line = "";
			String cvsSplitBy = ",";
			String[] strPosition = null;
			ArrayList<String> idValue  = new ArrayList<String>();
			ArrayList<String> nameValue = new ArrayList<String>();
			ArrayList<String> drugName = new ArrayList<String>();
			idValue.clear();
			nameValue.clear();
			drugName.clear();
			try {
				br = new BufferedReader(new FileReader(drugFile));
				while ((line = br.readLine()) != null) {
					strPosition = line.split(cvsSplitBy);
					strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
					idValue.add(strPosition[0]);
					nameValue.add(strPosition[1]);
//					drugName.add(strPosition[2]);
				}
				//			System.out.println("ValidateProvisionTemplate.DSC__DrugList.trim() : " + ValidateProvisionTemplate.DSC__DrugList.trim());
	 			for(rowIterator = 0;rowIterator<idValue.size();rowIterator++)	{
					if(nameValue.get(rowIterator).toString().equalsIgnoreCase(DL))	{
						druglistName = nameValue.get(rowIterator).toString();
						drugListValueID = idValue.get(rowIterator).toString();
						System.out.println(druglistName+" "+drugListValueID);
						//drugListValueID = drugListValueID.substring(0,15);
						break;
						//					System.out.println("Drug List value is matched");
					}
					else
					{
						drugListValueID = "";
					}
				}
			}	catch	(Exception e)	{
				e.printStackTrace();
			}
		}
		
		//

	    
	    public static void getparentmapping()	{
			int mIterator = 0;
			//		int formularyIteraor;
			parntMappingValueFinal="";
			for(int i=0;i<arr_DC_MAPID_1.size();i++){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail")){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))	{
							//System.out.println("TEST1>>>>>>>>>");
							//if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugListValueID))	{
							if(drugListValueID.contains(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "")))	{
								System.out.println("TEST>>>>>>>>>");
								if(ninthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equals(arr_DC_MAPID_1.get(i)))	{
								System.out.println("Test Retail DL");
								parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
								break;
								}
								
							}
						}else{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
								//if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugGroupListValueID))	{
								if(drugGroupListValueID.contains(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "")))	{
									
									if(ninthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equals(arr_DC_MAPID_1.get(i)))	{
									System.out.println(tenthColumnValue.get(formularyIteraor).toString());
									System.out.println("Test Retail DG");
									parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
									break;
									}
									
								}
							}
						}
					}
					else if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") ){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))	{
							//if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugListValueID))	{
							if(drugListValueID.contains(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "")))	{
								
								if(ninthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equals(arr_DC_MAPID_1.get(i)))	{
								System.out.println(tenthColumnValue.get(formularyIteraor).toString());
								System.out.println("Test Mail DL");
								parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
								break;
							}
								
							}
						}else{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
								//if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugGroupListValueID))	{
								
									if(drugGroupListValueID.contains(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "")))	{
										if(ninthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equals(arr_DC_MAPID_1.get(i)))	{
											System.out.println(tenthColumnValue.get(formularyIteraor).toString());
									parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
									break;
								}
								
							}
						}
					}

				}
				}
			}
		}
		}
	public static void getInExDCField_Value()	{
		strDC_Retail_IncExcl_DC = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion Exclusion Drug Class"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_DC  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getInExField_Value()	{
		strDC_Retail_IncExcl_1 = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion/Exclusion"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getApplylimit_Value()	{
		strDC_ApplyLimit_1 = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Apply Limitations"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_ApplyLimit_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getStartAge_Value()	{
		strDC_Retail_StartAge_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_StartAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndAge_Value()	{
		strDC_Retail_EndAge_1  ="";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_EndAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getGender_Value()	{
		strDC_Gender_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Gender"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Gender_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMindays_Value()	{
		strDC_MinDays_1  ="";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMinQty_Value()	{
		strDC_MinQty_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDailyDose_Value()	{
		strDC_DailyDose_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Daily Dose"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DailyDose_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getstartagetype_Value()	{
		strDC_StartAgeType_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_StartAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndagetype_Value()	{
		strDC_EndAgeType_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_EndAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDays_Value()	{
		strDC_MaxDays_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxFills_Value()	{
		strDC_MaxFills_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Fills"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxFills_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDaysperfill_Value()	{
		strDC_MaxDaysperfill_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Max Days per Fill"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDaysperfill_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTP_Value()	{
		strDC_DOTTP_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTDays_Value()	{
		strDC_DOTDays_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: # of Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTV_Value()	{
		strDC_DOTTV_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTQty_Value()	{
		strDC_QOTQty_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTP_Value()	{
		strDC_QOTTP_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTV_Value()	{
		strDC_QOTTV_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getAccumulationsDrugSpecific(){


		for(rowIterator=0;rowIterator<row;rowIterator++){
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue)){
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Accumulations__c")){
					if(tenthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Creates Accumulation - Individual All")){

						if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Are there any drug specific MAB?")){
							if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MAB)){
								strAccum_DrugSpecific_MAB = eighthColumnValue.get(rowIterator).toString();
							}
						}      
					}
				}      

				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("AccumulationSpecificDrug__c")){

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("M")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_M)){
							strAccum_DrugSpecific_M = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("N")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_N)){
							strAccum_DrugSpecific_N = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("O")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_O)){
							strAccum_DrugSpecific_O = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Y")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_Y)){
							strAccum_DrugSpecific_Y = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Amount")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABAmount)){
							strAccum_DrugSpecific_MABAmount = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Period")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABPeriod)){
							strAccum_DrugSpecific_MABPeriod = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("What happens when MAB is met?")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABMet)){
							strAccum_DrugSpecific_MABMet = eighthColumnValue.get(rowIterator).toString();
						}
					}


					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Drug List")){
						if(eighthColumnValue.get(rowIterator).toString().contains(drugListValueID)){

							strAccum_DrugSpecific_DL = eighthColumnValue.get(rowIterator).toString();
						}
					}
				}
			}
		}

	}
	public static ArrayList arrFRMID = new ArrayList();
	public static ArrayList arrMAPID = new ArrayList();
	public static boolean x=false;
	public static String mappingvalue;
	public static boolean values=true;
	 public static boolean bol=true;
	//boolean values= true;
	//method to get multiple field values
	public static void getValues(String PNo,String LValue,String Sub_Sec,String T_DSC_RetailFieldValue,String T_DSC_Retail_FormularyGroup,String DrugListSel,String DrugListID,String Stepped,String M, String N, String O, String Y,String PreferredGeneric,String Non_PreferredGeneric,String PreferredBrand,String Non_PreferredBrand,String DollarAmount, String Percent, String Copaycal, String MinimumDollar, String MaximumDollar, String Reverse ) {
	//	if(Sub_Sec.equalsIgnoreCase("DSC_Retail")) 
		{
			String FGReport="";
			String Stepped_DSC="";
			String M_DSC="";
			String N_DSC="";
			String O_DSC="";
			String Y_DSC="";
			String PreferredGeneric_DSC="";
			String Non_PreferredGeneric_DSC="";
			String PreferredBrand_DSC="";
			String Non_PreferredBrand_DSC="";
			String DollarAmount_DSC="";
			String Percent_DSC="";
			String Copaycal_DSC="";
			String Min_Dollar="";
			String Max_Dollar="";
			String Reverse_DSC="";
			x=false;
			LOOP1:
			for(int i=0;i<arrMAPID.size();i++) {
				values=true;
				mappingvalue=(String) arrMAPID.get(i);
				if(!T_DSC_Retail_FormularyGroup.equals("")) {
			 LOOP2:
				
			    for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
			    	
				    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
				    	
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Formulary Group") ) {
					    	
					    	String[] FormularygroupBT = T_DSC_Retail_FormularyGroup.split(";");
					    	FGReport=eighthColumnValue.get(formularyIteraor);
					    	String[] FormularygroupReport =eighthColumnValue.get(formularyIteraor).split(";");
			     //for(int m=0;m<FormularygroupBT.length;m++) {
			    	// FormularygroupReport.
					    	ArrayList<String> FBT= new ArrayList();
					    	ArrayList<String> FReport= new ArrayList();
			     
					    	for(int m=0;m<FormularygroupBT.length;m++) {
					    		FBT.add(FormularygroupBT[m]);
					    	}
					    	for(int n=0;n<FormularygroupReport.length;n++) {
					    		FReport.add(FormularygroupReport[n]);
					    	}
					    	if(FBT.size()==FReport.size()) {
					    		bol=true;
					    		for(int l=0;l<FBT.size();l++) {
			        	
					    			if(FBT.contains(FReport.get(l).toString().trim().replaceAll("\\s+", ""))) {
			        		
					    			}
					    			else {
					    				bol=false;
					    			}
					    		}
					    		
					    	}
					    	else
					    	{
					    		bol=false;
					    	}
						//if(eighthColumnValue.get(formularyIteraor).toString().equals(T_DSC_Retail_FormularyGroup)) {
							//testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Passed");
							if(bol==true) {
								System.out.println("Test1:Formulary");
								
								break LOOP2;
								
							}
							else {
								values= false;
								continue LOOP1;						
							}
					    }
					    
						   }
					    }
				}
					/*if(seventhColumnValue.get(formularyIteraor).toString().equals("DrugListSel") ) {
						if(eighthColumnValue.get(formularyIteraor).toString().equals(DrugListSel)) {
							
						}
						else {
							values= false;
							continue;
						}
					}*/
				LOOP3:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Drug List") ) {
					    	GetReportValues.findDrugList();
					    	System.out.println("Test4"+eighthColumnValue.get(formularyIteraor).toString());
					    	System.out.println("Test4"+drugListValueID);
					    	if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)) {
					    		System.out.println("Test1:"+drugListValueID);
					    		if(!T_DSC_Retail_FormularyGroup.equals("")) {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Formulary", T_DSC_Retail_FormularyGroup, FGReport, mappingvalue, "Pass");
					    		}
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Drug List", DrugListSel, drugListValueID, mappingvalue, "Pass");
					    		
					    		break LOOP3;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Drug Group") ) {
					    	GetReportValues.findDrugGroupName();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equals(drugGroupListValueID)) {
					    		System.out.println("Test1:"+drugGroupListValueID);
					    		if(T_DSC_Retail_FormularyGroup.equals("")) {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Formulary", T_DSC_Retail_FormularyGroup, FGReport, mappingvalue, "Pass");
					    		}
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Drug List", DrugListSel, drugListValueID, mappingvalue, "Pass");
					    		break LOOP3;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					   // break;
						   }
					    }
				
				 LOOP4:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Stepped Copay") ) {
					    	Stepped_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Stepped)) {
					    		System.out.println("Test1:stepped");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Stepped Copay", Stepped, FGReport, mappingvalue, "Pass");
					    		break LOOP4;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Stepped Copay", Stepped, FGReport, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP5:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {					    
					    if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("M") ) {
					    	M_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(M)) {
					    		System.out.println("Test1:M");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "M ", M,M_DSC, mappingvalue, "Pass");
					    		break LOOP5;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "N ", N,N_DSC, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP6:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("N") ) {
					    	N_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(N)) {
					    		System.out.println("Test1:N");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "N", N,N_DSC, mappingvalue, "Pass");
					    		break LOOP6;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "N", N,N_DSC, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP7:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("O") ) {
					    	O_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(O)) {
					    		System.out.println("Test1:O");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "O", O,O_DSC, mappingvalue, "Pass");
					    		break LOOP7;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "N", N,N_DSC, mappingvalue, "Fail");
					    		//values= false;
					    			//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP8:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Y") ) {
					    	Y_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Y)) {
					    		System.out.println("Test1:Y");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Y", Y,Y_DSC, mappingvalue, "Pass");
					    		break LOOP8;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Y", Y,Y_DSC, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP9:
					 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
					    	
						    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
						    if(seventhColumnValue.get(formularyIteraor).toString().equals("PreferredGeneric") ) {
						    	PreferredGeneric_DSC=eighthColumnValue.get(formularyIteraor).toString();
						    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Y)) {
						    		System.out.println("Test1:PreferredGeneric");
						    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredGeneric", PreferredGeneric,PreferredGeneric_DSC, mappingvalue, "Pass");
						    		break LOOP9;
						    	}
						    	else {
						    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredGeneric", PreferredGeneric,PreferredGeneric_DSC, mappingvalue, "Fail");
						    		//values= false;
						    		//continue LOOP2;
						    	}
						    }
						    }
					 }
				 LOOP10:
					 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
					    	
						    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
						    if(seventhColumnValue.get(formularyIteraor).toString().equals("Non_PreferredGeneric") ) {
						    	Non_PreferredGeneric_DSC=eighthColumnValue.get(formularyIteraor).toString();
						    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Y)) {
						    		System.out.println("Test1:Non_PreferredGeneric");
						    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredGeneric", Non_PreferredGeneric,Non_PreferredGeneric_DSC, mappingvalue, "Pass");
						    		break LOOP10;
						    	}
						    	else {
						    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredGeneric", Non_PreferredGeneric,Non_PreferredGeneric_DSC, mappingvalue, "Fail");
						    		//values= false;
						    		//continue LOOP2;
						    	}
						    }
						    }
					 }
					 LOOP11:
						 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
						    	
							    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
							    if(seventhColumnValue.get(formularyIteraor).toString().equals("PreferredBrand") ) {
							    	PreferredBrand_DSC=eighthColumnValue.get(formularyIteraor).toString();
							    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Y)) {
							    		System.out.println("Test1:PreferredBrand");
							    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredBrand", PreferredBrand,PreferredBrand_DSC, mappingvalue, "Pass");
							    		break LOOP11;
							    	}
							    	else {
							    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredBrand", PreferredBrand,PreferredBrand_DSC, mappingvalue, "Fail");
							    		//values= false;
							    		//continue LOOP2;
							    	}
							    }
							    }
						 }
					 LOOP12:
						 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
						    	
							    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
							    if(seventhColumnValue.get(formularyIteraor).toString().equals("Non_PreferredBrand") ) {
							    	Non_PreferredBrand_DSC=eighthColumnValue.get(formularyIteraor).toString();
							    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Y)) {
							    		System.out.println("Test1:Non_PreferredBrand");
							    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredBrand", Non_PreferredBrand,Non_PreferredBrand_DSC, mappingvalue, "Pass");
							    		break LOOP12;
							    	}
							    	else {
							    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredBrand", Non_PreferredBrand,Non_PreferredBrand_DSC, mappingvalue, "Fail");
							    		//values= false;
							    		//continue LOOP2;
							    	}
							    }
							    }
						 }
				 LOOP13:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Dollar Amount") ) {
					    	System.out.println(eighthColumnValue.get(formularyIteraor).toString());
					    	System.out.println(DollarAmount);
					    	DollarAmount=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(DollarAmount)) {
					    		
					    		System.out.println("Test1:DM");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Dollar Amount", DollarAmount,DollarAmount_DSC, mappingvalue, "Pass");
					    		break LOOP13;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Dollar Amount", DollarAmount,DollarAmount_DSC, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP14:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Percent") ) {
					    	Percent_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Percent)) {
					    		
					    		System.out.println("Test1:Per");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Percent", Percent,Percent_DSC, mappingvalue, "Pass");
					    		break LOOP14;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Percent", Percent,Percent_DSC, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP15:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Copay Calculation") ) {
					    	Copaycal_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Copaycal)) {
					    		
					    		System.out.println("Test1:CC");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Copay Calculation", Copaycal,Copaycal_DSC, mappingvalue, "Pass");
					    		break LOOP15;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Copay Calculation", Copaycal,Copaycal_DSC, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP16:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Minimum Dollar") ) {
					    	Min_Dollar=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(MinimumDollar)) {
					    		
					    		System.out.println("Test1:MD");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Minimum Dollar", MinimumDollar,Min_Dollar, mappingvalue, "Pass");
					    		break LOOP16;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Minimum Dollar", MinimumDollar,Min_Dollar, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP17:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Maximum Dollar") ) {
					    	Max_Dollar=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(MaximumDollar)) {
					    		System.out.println("Test1:Max");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Maximum Dollar", MaximumDollar,Max_Dollar, mappingvalue, "Pass");
					    		break LOOP17;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Maximum Dollar", MaximumDollar,Max_Dollar, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    }
					    }
				 }
				 LOOP18:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Reverse") ) {
					    	Reverse_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Reverse)) {
					    		System.out.println("Test1:Rev");
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Reverse", Reverse,Reverse_DSC, mappingvalue, "Pass");
					    		break LOOP18;
					    	}
					    	else {
					    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Reverse", Reverse,Reverse_DSC, mappingvalue, "Fail");
					    		//values= false;
					    		//continue LOOP2;
					    	}
					    	
					    }
				    }
			    }
				LOOP19:
					 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
					    	
						    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
						    if(seventhColumnValue.get(formularyIteraor).toString().equals("Formulary Group ") ) {
						    	FGReport=eighthColumnValue.get(formularyIteraor).toString();
						    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(T_DSC_Retail_FormularyGroup)) {
						    		System.out.println("Test1:Formulary");
						    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Formulary Group", T_DSC_Retail_FormularyGroup,"", "", "Fail");	
						    	}
						    }
						    }
					 }
			
				
			    if(values==true) {
			    	x=true;
			    	System.out.println("pass:");
				//arrMAPID.remove(mappingvalue);
			    	break;
			    }else {
			    }	
				}
			
				if(x==false)
				{
					System.out.println("Business template didn't match");
					if(!T_DSC_Retail_FormularyGroup.equals("")) {
						testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Formulary", T_DSC_Retail_FormularyGroup, "", "", "Fail");
						}
						if(!DrugListSel.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Drug List", DrugListSel, "", "", "Fail");
						}
						if(!Stepped.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Stepped Copay", Stepped, "", "", "Fail");
						}
						if(!M.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "M", M, "", "", "Fail");
						}
						if(!N.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "N", N, "", "", "Fail");
						}
						if(!O.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "O", O, "", "", "Fail");
						}
						if(!Y.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Y", Y, "", "", "Fail");
						}
						if(!PreferredGeneric.equals("")) {
					    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredGeneric",PreferredGeneric , "", "", "Fail");
							}
						if(!Non_PreferredGeneric.equals("")) {
					    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredGeneric",Non_PreferredGeneric , "", "", "Fail");
							}
						if(!PreferredBrand.equals("")) {
					    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredBrand",PreferredBrand , "", "", "Fail");
							}
						if(!Non_PreferredBrand.equals("")) {
					    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredBrand",Non_PreferredBrand , "", "", "Fail");
							}
						if(!DollarAmount.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Dollar Amount", DollarAmount, "", "", "Fail");
						}
						if(!Percent.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Percent", Percent, "", "", "Fail");
						}
						if(!Copaycal.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Copay Calculation", Copaycal, "", "", "Fail");
						}
						if(!MinimumDollar.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Minimum Dollar", MinimumDollar, "", "", "Fail");
						}
						if(!MaximumDollar.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Maximum Dollar", MaximumDollar, "", "", "Fail");
						}
						if(!Reverse.equals("")) {
				    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec,"Reverse", Reverse, "", "", "Fail");
						}
				
		//testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Passed");
				}
			}
			
	
		}
	
	public static void duplicateDrugList(String PNo,String LValue,String Sub_Sec,String T_DSC_RetailFieldValue,String T_DSC_Retail_FormularyGroup,String DrugListSel,String DrugListID,String Stepped,String M, String N, String O, String Y,String PreferredGeneric,String Non_PreferredGeneric,String PreferredBrand,String Non_PreferredBrand,String DollarAmount, String Percent, String Copaycal, String MinimumDollar, String MaximumDollar, String Reverse ) {
		String DL_DG="";
		//if(Sub_Sec.equalsIgnoreCase("DSC_Retail")) 
		{
			LOOP1:
			for(int i=0;i<arrMAPID.size();i++) {
				values=true;
				mappingvalue=(String) arrMAPID.get(i);
				String FGReport="";
				String DL_DG_value="";
				
				String Stepped_copay="";
				String M_DSC="";
				String N_DSC="";
				String O_DSC="";
				String Y_DSC="";
				String PreferredGeneric_DSC="";
				String Non_PreferredGeneric_DSC="";
				String PreferredBrand_DSC="";
				String Non_PreferredBrand_DSC="";
				String Dollar_Amount="";
				String Percent_DSC="";
				String Copay_cal="";
				String Min_Dollar="";
				String Max_Dollar="";
				String Reverse_DSC="";
			
				if(T_DSC_Retail_FormularyGroup.equals("")) {
			 LOOP2:
				
			    for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
			    	
				    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
				    	
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Formulary Group") ) {
					    	FGReport="";
					    	String[] FormularygroupBT = T_DSC_Retail_FormularyGroup.split(";");
					    	String[] FormularygroupReport =eighthColumnValue.get(formularyIteraor).split(";");
					    	FGReport=eighthColumnValue.get(formularyIteraor);
			     //for(int m=0;m<FormularygroupBT.length;m++) {
			    	// FormularygroupReport.
					    	ArrayList<String> FBT= new ArrayList();
					    	ArrayList<String> FReport= new ArrayList();
			     
					    	for(int m=0;m<FormularygroupBT.length;m++) {
					    		FBT.add(FormularygroupBT[m]);
					    	}
					    	for(int n=0;n<FormularygroupReport.length;n++) {
					    		FReport.add(FormularygroupReport[n]);
					    	}
					    	if(FBT.size()==FReport.size()) {
					    		bol=true;
					    		for(int l=0;l<FBT.size();l++) {
			        	
					    			if(FBT.contains(FReport.get(l).toString().trim().replaceAll("\\s+", ""))) {
			        		
					    			}
					    			else {
					    				bol=false;
					    			}
					    		}
					    		
					    	}
					    	else
					    	{
					    		bol=false;
					    	}
						//if(eighthColumnValue.get(formularyIteraor).toString().equals(T_DSC_Retail_FormularyGroup)) {
							//testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Passed");
							if(bol==true) {
								System.out.println("Test1:Formulary");	
								break LOOP2;
							}
							else {
								values= false;
								continue LOOP1;						
							}
					    }
					    
						   }
					    }
				}
					/*if(seventhColumnValue.get(formularyIteraor).toString().equals("DrugListSel") ) {
						if(eighthColumnValue.get(formularyIteraor).toString().equals(DrugListSel)) {
							
						}
						else {
							values= false;
							continue;
						}
					}*/
				LOOP3:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Drug List") ) {
					    	GetReportValues.findDrugList();
					    	System.out.println("Test4"+eighthColumnValue.get(formularyIteraor).toString());
					    	System.out.println("Test4"+drugListValueID);
					    	if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)) {
					    		DL_DG="Drug List";
					    		DL_DG_value=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:"+drugListValueID);
					    		break LOOP3;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Drug Group") ) {
					    	GetReportValues.findDrugGroupName();
					    	if(eighthColumnValue.get(formularyIteraor).toString().equals(drugGroupListValueID)) {
					    		DL_DG=eighthColumnValue.get(formularyIteraor).toString();
					    		DL_DG_value=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:"+drugGroupListValueID);
					    		break LOOP3;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					   // break;
						   }
					    }
				
				 LOOP4:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Stepped Copay") ) {
					    	if(eighthColumnValue.get(formularyIteraor).equalsIgnoreCase(Stepped)) {
					    		Stepped_copay=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:stepped");
					    		break LOOP4;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				
				 LOOP5:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {					    
					    if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("M") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(M)) {
					    		M_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:M");
					    		break LOOP5;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP6:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("N") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(N)) {
					    		N_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:N");
					    		break LOOP6;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP7:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("O") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(O)) {
					    		O_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:O");
					    		break LOOP7;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP8:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Y") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Y)) {
					    		Y_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:Y");
					    		break LOOP8;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP9:
					 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
					    	
						    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
						    if(seventhColumnValue.get(formularyIteraor).toString().equals("PreferredGeneric") ) {
						    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(PreferredGeneric)) {
						    		PreferredGeneric_DSC=eighthColumnValue.get(formularyIteraor).toString();
						    		System.out.println("Test1:PreferredGeneric");
						    		break LOOP9;
						    	}
						    	else {
						    		values= false;
						    		continue LOOP1;
						    	}
						    }
						    }
					 }
				 LOOP10:
					 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
					    	
						    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
						    if(seventhColumnValue.get(formularyIteraor).toString().equals("Non_PreferredGeneric") ) {
						    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Non_PreferredGeneric)) {
						    		Non_PreferredGeneric_DSC=eighthColumnValue.get(formularyIteraor).toString();
						    		System.out.println("Test1:Non_PreferredGeneric");
						    		break LOOP10;
						    	}
						    	else {
						    		values= false;
						    		continue LOOP1;
						    	}
						    }
						    }
					 }
					 LOOP11:
						 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
						    	
							    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
							    if(seventhColumnValue.get(formularyIteraor).toString().equals("PreferredBrand") ) {
							    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(PreferredBrand)) {
							    		PreferredBrand_DSC=eighthColumnValue.get(formularyIteraor).toString();
							    		System.out.println("Test1:PreferredBrand");
							    		break LOOP11;
							    	}
							    	else {
							    		values= false;
							    		continue LOOP1;
							    	}
							    }
							    }
						 }
					 LOOP12:
						 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
						    	
							    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
							    if(seventhColumnValue.get(formularyIteraor).toString().equals("Non_PreferredBrand") ) {
							    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Non_PreferredBrand)) {
							    		Non_PreferredBrand_DSC=eighthColumnValue.get(formularyIteraor).toString();
							    		System.out.println("Test1:Non_PreferredBrand");
							    		break LOOP12;
							    	}
							    	else {
							    		values= false;
							    		continue LOOP1;
							    	}
							    }
							    }
						 }
					
				 LOOP13:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Dollar Amount") ) {
					    	System.out.println(eighthColumnValue.get(formularyIteraor).toString());
					    	System.out.println(DollarAmount);
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(DollarAmount)) {
					    		Dollar_Amount=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:DM");
					    		break LOOP13;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP14:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Percent") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Percent)) {
					    		Percent_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:Per");
					    		break LOOP14;
					    	}
					    	else { 
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP15:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Copay Calculation") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Copaycal)) {
					    		Copay_cal=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:CC");
					    		break LOOP15;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP16:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Minimum Dollar") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(MinimumDollar)) {
					    		Min_Dollar=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:MD");
					    		break LOOP16;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP17:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Maximum Dollar") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(MaximumDollar)) {
					    		Max_Dollar=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:Max");
					    		break LOOP17;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    }
					    }
				 }
				 LOOP18:
				 for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++) {
				    	
					    if(ninthColumnValue.get(formularyIteraor).toString().equals((String) arrMAPID.get(i))) {
					    if(seventhColumnValue.get(formularyIteraor).toString().equals("Reverse") ) {
					    	if(eighthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(Reverse)) {
					    		Reverse_DSC=eighthColumnValue.get(formularyIteraor).toString();
					    		System.out.println("Test1:Rev");
					    		break LOOP18;
					    	}
					    	else {
					    		values= false;
					    		continue LOOP1;
					    	}
					    	
					    }
				    }
			    }
			
				
			    if(values==true) {
			    	x=true;
			    	System.out.println("pass:");
			    	if(!T_DSC_Retail_FormularyGroup.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Formulary", T_DSC_Retail_FormularyGroup, FGReport, mappingvalue, "Pass");
			    	}
			    	if(!DrugListSel.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, DL_DG,drugListValueID , DL_DG_value, mappingvalue, "Pass");
			    	}
			    	if(!Stepped.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Stepped Copay",Stepped , Stepped_copay, mappingvalue, "Pass");
			    	}
			    	if(!M.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "M", M, M_DSC, mappingvalue, "Pass");
			    	}
			    	if(!N.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "N", N, N_DSC, mappingvalue, "Pass");
			    	}
			    	if(!O.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "O", O, O_DSC, mappingvalue, "Pass");
			    	}
			    	if(!Y.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Y", Y, Y_DSC, mappingvalue, "Pass");
			    	}
			    	if(!PreferredGeneric.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredGeneric", PreferredGeneric, PreferredGeneric_DSC, mappingvalue, "Pass");
			    	}
			    	if(!Non_PreferredGeneric.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredGeneric", Non_PreferredGeneric, Non_PreferredGeneric_DSC, mappingvalue, "Pass");
			    	}
			    	if(!PreferredBrand.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredBrand", PreferredBrand, PreferredBrand_DSC, mappingvalue, "Pass");
			    	}
			    	if(!Non_PreferredBrand.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredBrand", Non_PreferredBrand, Non_PreferredBrand_DSC, mappingvalue, "Pass");
			    	}
			    	if(!DollarAmount.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Dollar Amount", DollarAmount, Dollar_Amount, mappingvalue, "Pass");
			    	}
			    	if(!Percent.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Percent", Percent, Percent_DSC, mappingvalue, "Pass");
			    	}
			    	if(!Copaycal.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Copay Calculation", Copaycal, Copay_cal, mappingvalue, "Pass");
			    	}
			    	if(!MinimumDollar.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Minimum Dollar", MinimumDollar, Min_Dollar, mappingvalue, "Pass");
			    	}
			    	if(!MaximumDollar.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Maximum Dollar", MaximumDollar, Max_Dollar, mappingvalue, "Pass");
			    	}
			    	if(!Reverse.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec,"Reverse", Reverse, Reverse_DSC, mappingvalue, "Pass");
			    	}
				//arrMAPID.remove(mappingvalue);
			    	break;
			    }else {
			    }	
				}
			
				if(x==false)
				{
					System.out.println("Business template didn't match");
					if(!T_DSC_Retail_FormularyGroup.equals("")) {
					testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Formulary", T_DSC_Retail_FormularyGroup, "", "", "Fail");
					}
					if(!DrugListSel.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, DL_DG, DrugListSel, "", "", "Fail");
					}
					if(!Stepped.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Stepped Copay", Stepped, "", "", "Fail");
					}
					if(!M.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "M", M, "", "", "Fail");
					}
					if(!N.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "N", N, "", "", "Fail");
					}
					if(!O.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "O", O, "", "", "Fail");
					}
					if(!Y.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Y", Y, "", "", "Fail");
					}
					if(!PreferredGeneric.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredGeneric", PreferredGeneric, "", "", "Pass");
			    	}
			    	if(!Non_PreferredGeneric.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredGeneric",  "", "", mappingvalue, "Pass");
			    	}
			    	if(!PreferredBrand.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "PreferredBrand", "", "", mappingvalue, "Pass");
			    	}
			    	if(!Non_PreferredBrand.equals("")) {
			    		testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Non_PreferredBrand", "", "", mappingvalue, "Pass");
			    	}
					if(!DollarAmount.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Dollar Amount", DollarAmount, "", "", "Fail");
					}
					if(!Percent.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Percent", Percent, "", "", "Fail");
					}
					if(!Copaycal.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Copay Calculation", Copaycal, "", "", "Fail");
					}
					if(!MinimumDollar.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Minimum Dollar", MinimumDollar, "", "", "Fail");
					}
					if(!MaximumDollar.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec, "Maximum Dollar", MaximumDollar, "", "", "Fail");
					}
					if(!Reverse.equals("")) {
			    	testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, Sub_Sec,"Reverse", Reverse, "", "", "Fail");
					}
		//testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Passed");
				}
			}
			
	
	}


	public static void getAllMapId_DSC(String Pr,String Lv,String Sub_Sec)	{
		arrMAPID.clear(); 
		if(Sub_Sec.equalsIgnoreCase("DSC_Retail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
				//	if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
					//	if((Sub_Sec.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){
							//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
					if(Sub_Sec.contains("DSC_Retail") && fourteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1")){
						arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
					//arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
								System.out.println(arrMAPID);
							}
						//}
					//}
				}			
			}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_Mail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					//if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						//if((Sub_Sec.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")))){
							//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
					if(Sub_Sec.contains("DSC_Mail") && fourteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHnz")){
						arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
					//arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
								System.out.println(arrMAPID);
							}
							
						
					}
				}	
		}



		if(Sub_Sec.equalsIgnoreCase("DSC_SpecialtyTiers")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					//if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						//if((Sub_Sec.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){
							//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
					if(Sub_Sec.contains("DSC_SpecialtyTiers") && fourteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo2")){
						arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
					//arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
								System.out.println(arrMAPID);
							}
							
						
					}
				}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					//if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						//if((Sub_Sec.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){
							//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
					if(Sub_Sec.contains("DSC_SpecialtyOutOfNetwork") && fourteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UOME")){
						arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
					//arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
								System.out.println(arrMAPID);
							}
							
						
					}
				}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_PaperTiers")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					//if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						//if((Sub_Sec.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){
							//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
					if(Sub_Sec.contains("DSC_PaperTiers") && fourteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo0")){
						arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
					//arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
								System.out.println(arrMAPID);
							}
							
						
					}
				}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					//if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						//if((Sub_Sec.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
							//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
					if(Sub_Sec.contains("DSC_PaperOutOfNetwork") && fourteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo0")){
						arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
					//arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
								System.out.println(arrMAPID);
							}
							
						
					}
				}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					//if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						//if((Sub_Sec.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network"))))){
							//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
					if(Sub_Sec.contains("DSC_Mail_PaperOutOfNetwork") && fourteenthColumnValue.get(formularyIteraor).toString().contains("0121F000000F6Ge")){
						arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
					//arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
								System.out.println(arrMAPID);
							}
							
						
					}
				}	
		}


	}
	public static void FailedReportValues(String Sub_Sec){
		//System.out.println(arrMAPID);
		for(int i=0;i<arrMAPID.size();i++){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
				if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase((String) arrMAPID.get(i))){
					if(seventhColumnValue.get(formularyIteraor).toString().equals("CRD ID") ){}
					else{
						testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Failed");
					}
				}
			}
		}
	}


	public static void getFormularyId()	{
		strFormularyIDMappingValue.clear();
		int mIterator = 0;
		//		int formularyIteraor;
		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail")){
			Loop:
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
						if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
									arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
									//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
									strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
								}
							}
						}
					}
					if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (formularyIteraor==row) )	{
						break Loop;
					}
				}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}


		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers"))	{

			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}
		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork")){

			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}
		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") )	{

			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}





	}
	//
	
	
	public static ArrayList arr_DrugCount = new ArrayList();
	public static void MultipleDruglist(){
		ArrayList test = new ArrayList();
		arr_DrugCount.clear();
		test.clear();
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
				if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){

					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
							arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());						
						}
					}
					else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
					{
						if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
							arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
						}
					}

				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Maill")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
			}
		}
		System.out.println("arr_DrugCount :" + arr_DrugCount.size());
	}


	public static void MultipleDrugMap(){
		Flag = false;
		parntMappingValueFinal="";
		Loop3:
			for(int i=0;i<arr_DrugCount.size();i++){
				System.out.println(arr_DrugCount.get(i));			
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
						if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){				
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}
						}

						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Maill")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")))){					if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									//parntMappingValueFinal = arr_DrugCount.get(i).toString();




									parntMappingValueFinal = arr_DrugCount.get(i).toString();

									getStepped_Value();getM_Value();getN_Value();
									parntMappingValueFinal="";
									if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
										if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
											if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
												System.out.println("Final Mapping Val:"+parntMappingValueFinal);
												parntMappingValueFinal = arr_DrugCount.get(i).toString();
												Flag = true;
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
												if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
												}else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
												}
												if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
												}
												else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
												}
												break Loop3;
											}else{
												continue Loop3;
											}

										}else{
											continue Loop3;
										}
									}else{
										continue Loop3;
									}
								}
							}
						}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){					if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									//parntMappingValueFinal = arr_DrugCount.get(i).toString();




									parntMappingValueFinal = arr_DrugCount.get(i).toString();

									getStepped_Value();getM_Value();getN_Value();
									parntMappingValueFinal="";
									if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
										if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
											if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
												System.out.println("Final Mapping Val:"+parntMappingValueFinal);
												parntMappingValueFinal = arr_DrugCount.get(i).toString();
												Flag = true;
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
												if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
												}else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
												}
												if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
												}
												else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
												}
												break Loop3;
											}else{
												continue Loop3;
											}

										}else{
											continue Loop3;
										}
									}else{
										continue Loop3;
									}
								}
							}
						}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){					if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									//parntMappingValueFinal = arr_DrugCount.get(i).toString();




									parntMappingValueFinal = arr_DrugCount.get(i).toString();

									getStepped_Value();getM_Value();getN_Value();
									parntMappingValueFinal="";
									if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
										if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
											if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
												System.out.println("Final Mapping Val:"+parntMappingValueFinal);
												parntMappingValueFinal = arr_DrugCount.get(i).toString();
												Flag = true;
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
												if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
												}else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
												}
												if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
												}
												else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
												}
												break Loop3;
											}else{
												continue Loop3;
											}

										}else{
											continue Loop3;
										}
									}else{
										continue Loop3;
									}
								}
							}
						}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){  
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}


						}
						
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){  
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}


						}
						//

					}
				}
			}
	}

	public static void DrugList_DrugGroup(){
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
			if(parntMappingValueFinal.equals(ninthColumnValue.get(formularyIteraor).toString()))
			{

			}
		}
	}

	//

	static int drugIterator;
	static int parentIterator=0;
	//static String parntMappingValueFinal="";	

	public static void getParentMappingValue()	{

		Flag = false;
		parntMappingValueFinal="";

		if(arrFRMID.size()!=0)	{ //if(arrFRMID.size()!=0)
			Loop:
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{					
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
						if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network")))) || ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network"))) ){
							//||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network")
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
									parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();

									Loop2:
										for(int i=0;i<arrFRMID.size();i++)	{

											if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arrFRMID.get(i).toString()))	{
												parntMappingValueFinal = arrFRMID.get(i).toString();
												if(arrFRMID.size()>1)	{
													arrFRMID.remove(i).toString();
												}

												//										arrFRMID.remove(i);

												if(ValidateProvisionTemplate.provisionNumber.equals("146")){
													getStepped_Value();getM_Value();getN_Value();

													if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
														if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
															if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
																System.out.println("Values mathced");
																Flag = true;														
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
																/*if(arrFRMID.size()>1)	{
															arrFRMID.remove(i).toString();
															}*/
																break Loop;

															}else	{
																i--;
																parntMappingValueFinal = "";
																formularyIteraor= 0;
																continue Loop;
															}
														}else	{
															i--;
															parntMappingValueFinal = "";
															formularyIteraor= 0;
															continue Loop;
														}
													}	else	{
														i--;
														parntMappingValueFinal = "";
														formularyIteraor= 0;
														continue Loop;
													}
												}

											}else{

												parntMappingValueFinal = "";
												//testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, GetReportValues.eighthColumnValue.get(rowIterator).toString(), parntMappingValueFinal , "Fail");
												//testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Fail");
												//testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Fail");
												//testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGrouValue", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Fail");


											}
										}							
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
							{
								if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
									parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();								
									int size = arrFRMID.size();
									int Drugsize = ValidateProvisionTemplate.CountOfDrugList;
									//ArrayList arrFRMID_Test = new ArrayList();

									Loop2:
										for(int i=0;i<arrFRMID.size();i++)	{
											System.out.println(arrFRMID);
											//	if(!arrFRMID.contains(arrFRMID.get(i).toString())){
											//System.out.println(arrFRMID.size());
											//System.out.println(i);
											//System.out.println("TEST");
											if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arrFRMID.get(i).toString()))	{
												parntMappingValueFinal = arrFRMID.get(i).toString();
												System.out.println("TEST!!!"+parntMappingValueFinal);
												//System.out.println(i);
												if(arrFRMID.size()>1)	{
													arrFRMID.remove(i).toString();
													System.out.println(arrFRMID.size());
												}
												//										arrFRMID.remove(i);
												if(ValidateProvisionTemplate.provisionNumber.equals("146")){
													getStepped_Value();getM_Value();getN_Value();
													if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
														if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
															if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
																System.out.println("Values mathced");
																Flag = true;
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
																/*	if(arrFRMID.size()>1)	{
															arrFRMID.remove(i).toString();
														}*/
																//i--;
																//arrFRMID_Test.add(parntMappingValueFinal);
																break Loop;

															}else {
																i--;
																parntMappingValueFinal = "";
																formularyIteraor= 0;
																continue Loop;

															}
														}else {
															i--;
															parntMappingValueFinal = "";
															formularyIteraor= 0;
															continue Loop;
														}
													}	else {
														i--;	
														parntMappingValueFinal = "";
														formularyIteraor= 0;
														continue Loop;
													}


												}
												else
												{
													System.out.println("Values mathced");
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													/*if(arrFRMID.size()>1)	{
													arrFRMID.remove(i).toString();
												}*/
													//i--;

													break Loop;
												}
											}

											else{
												parntMappingValueFinal = "";
												//	testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, GetReportValues.eighthColumnValue.get(rowIterator).toString(), parntMappingValueFinal , "Fail");
												//	testResultFunctions.set_custom_message_in_Report_Test("","Formulary Group", ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Any drug specific Retail copays?",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", ""), parntMappingValueFinal , "Fail");														
												//	testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Fail");
												//	testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugListValue", drugListValueID, drugListValueID, parntMappingValueFinal, "Fail");


											}
											//	}	

											//size = 0;
										}
								}


							}




							/*
//							int i=0;
							if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
								parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();	
								Loop2:
									for(int i=0;i<strFormularyIDMappingValue.size();i++)	{
										System.out.println("ninthColumnValue.get(formularyIteraor).toString() "+ninthColumnValue.get(formularyIteraor).toString());
										if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(strFormularyIDMappingValue.get(i).toString()))	{
											parntMappingValueFinal = strFormularyIDMappingValue.get(i).toString();
											arrFRMID.remove(i);
											getStepped_Value();getM_Value();getN_Value();
											if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
												if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
													if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
														System.out.println("Values mathced");
														break Loop;
													}else	{
														i--;
														continue Loop2;

													}
												}else	{
													i--;
													continue Loop2;

												}
											}	else	{
												i--;
												continue Loop2;

											}
//											break Loop;
										}else{
											parntMappingValueFinal = "";

											continue Loop;
										}
									}							
							}
							 */
						}
					}

				}
		}
		//}
	}

	public static void getStepped_Value()	{

		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strsteppedCopay  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					
					{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Stepped Copay"))	{
						
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								
								strsteppedCopay  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getM_Value()	{


		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strM_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("M"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							//System.out.println(parntMappingValueFinal);
							strM_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}
	public static void getN_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strN_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{					
					//System.out.println("TEST!!! 1");
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))))) 
					{
						//System.out.println("TEST!!! 2");
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("N"))	{
							//System.out.println("TEST!!! 3");
							//System.out.println(parntMappingValueFinal);
							//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{								
								//System.out.println("TEST!!! 4");
								strN_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getO_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strO_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("O"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strO_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							break;	
						}
					}
					}
				}
			}
	}
	public static void getY_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strY_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strY_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getPreferredGeneric_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strPreferredGeneric = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("PreferredGeneric"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strPreferredGeneric  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getNon_PreferredGeneric_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strNon_PreferredGeneric = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Non_PreferredGeneric"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strNon_PreferredGeneric  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getPreferredBrand_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strPreferredBrand = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("PreferredBrand"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strPreferredBrand  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getNon_PreferredBrand_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strNon_PreferredBrand = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Non_PreferredBrand"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strNon_PreferredBrand  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getDollarAmount_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strDollarAmount_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strDollarAmount_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getPercent_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strPercent_Value ="";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strPercent_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getMindollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strMinimumDollar_Value  = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strMinimumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getMaxdollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strMaximumDollar_Value  = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strMaximumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}

	public static String strByPassOOn = "";
	public static void getByPassOON_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strByPassOOn  = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{

					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("ByPassOON"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strByPassOOn  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}


	public static void getCopaycalc_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		CRDCopayLogic  ="";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							CRDCopayLogic  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}
	public static void getReverse_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strReverse = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Reverse"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strReverse = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}
	//---------
	public static void findDrugGroupName_DC()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.strDrugGroup);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> drugGroupID  = new ArrayList<String>();
		ArrayList<String> drugGroupnameValue = new ArrayList<String>();
		ArrayList<String> drugGroupName = new ArrayList<String>();
		drugGroupID.clear();
		drugGroupnameValue.clear();
		drugGroupName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				drugGroupID.add(strPosition[1]);
				drugGroupnameValue.add(strPosition[2]);
				drugGroupName.add(strPosition[0]);
			}
			for(rowIterator = 0;rowIterator<drugGroupID.size();rowIterator++)	{
				System.out.println(ValidateProvisionTemplate_Test.DSC__DrugList);
				//System.out.println(drugGroupnameValue.get(rowIterator).toString());
				/*if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equals("DCA-0000705"))
				{
					System.out.println(drugGroupnameValue.get(rowIterator).toString());
				} *///equalsIgnoreCase(ValidateProvisionTemplate_Test.DSC__DrugList.trim()) //drugGroupnameValue.get(rowIterator).toString()
				//drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1)
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equalsIgnoreCase(ValidateProvisionTemplate_Test.DSC__DrugList.trim()))	{					
					drugGrouplistName = drugGroupName.get(rowIterator).toString();
					drugGroupListValueID = drugGroupID.get(rowIterator).toString().substring(1,drugGroupID.get(rowIterator).toString().length()-1);
					System.out.println(drugGroupListValueID);
					System.out.println("drugGroupListValueID length : " + drugGroupListValueID.length());
					if(drugGroupListValueID.length()>15){
						drugGroupListValueID = drugGroupListValueID.substring(0,15);
						System.out.println(drugGroupListValueID);
					}
					break;
				}
				else
				{
					drugGroupListValueID = "";
				}

			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}
	public static void findDrugGroupName()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.strDrugGroup);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> drugGroupID  = new ArrayList<String>();
		ArrayList<String> drugGroupnameValue = new ArrayList<String>();
		ArrayList<String> drugGroupName = new ArrayList<String>();
		drugGroupID.clear();
		drugGroupnameValue.clear();
		drugGroupName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				drugGroupID.add(strPosition[1]);
				drugGroupnameValue.add(strPosition[2]);
				drugGroupName.add(strPosition[0]);
			}
			for(rowIterator = 0;rowIterator<drugGroupID.size();rowIterator++)	{
				//System.out.println(ValidateProvisionTemplate.DSC__DrugList);
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equals("DCA-0000705"))
				{
					System.out.println(drugGroupnameValue.get(rowIterator).toString());
				} //equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()) //drugGroupnameValue.get(rowIterator).toString()
				//drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1)
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()))	{					
					drugGrouplistName = drugGroupName.get(rowIterator).toString();
					drugGroupListValueID = drugGroupID.get(rowIterator).toString().substring(1,drugGroupID.get(rowIterator).toString().length()-1);
					System.out.println(drugGroupListValueID);
					System.out.println("drugGroupListValueID length : " + drugGroupListValueID.length());
					if(drugGroupListValueID.length()>15){
						drugGroupListValueID = drugGroupListValueID.substring(0,15);
						//	System.out.println(drugGroupListValueID);
					}
					break;
				}
				else
				{
					drugGroupListValueID = "";
				}

			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}

	public static void findDrugList_DC()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.drugListPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> idValue  = new ArrayList<String>();
		ArrayList<String> nameValue = new ArrayList<String>();
		ArrayList<String> drugName = new ArrayList<String>();
		idValue.clear();
		nameValue.clear();
		drugName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				idValue.add(strPosition[0]);
				nameValue.add(strPosition[1]);
				drugName.add(strPosition[2]);
			}
			//			System.out.println("ValidateProvisionTemplate_Test.DSC__DrugList.trim() : " + ValidateProvisionTemplate_Test.DSC__DrugList.trim());
			for(rowIterator = 0;rowIterator<idValue.size();rowIterator++)	{
				if(nameValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DSC__DrugList.trim()))	{
					druglistName = drugName.get(rowIterator).toString();
					drugListValueID = idValue.get(rowIterator).toString();
					System.out.println(druglistName+" "+drugListValueID);
					//drugListValueID = drugListValueID.substring(0,15);
					break;
					//					System.out.println("Drug List value is matched");
				}
				else
				{
					drugListValueID = "";
				}
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}


	public static void findDrugList()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.drugListPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> idValue  = new ArrayList<String>();
		ArrayList<String> nameValue = new ArrayList<String>();
		ArrayList<String> drugName = new ArrayList<String>();
		idValue.clear();
		nameValue.clear();
		drugName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				idValue.add(strPosition[0]);
				nameValue.add(strPosition[1]);
				drugName.add(strPosition[2]);
			}
			//			System.out.println("ValidateProvisionTemplate.DSC__DrugList.trim() : " + ValidateProvisionTemplate.DSC__DrugList.trim());
			for(rowIterator = 0;rowIterator<idValue.size();rowIterator++)	{
				if(nameValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()))	{
					druglistName = drugName.get(rowIterator).toString();
					drugListValueID = idValue.get(rowIterator).toString();
					System.out.println(druglistName+" "+drugListValueID);
					//drugListValueID = drugListValueID.substring(0,15);
					break;
					//					System.out.println("Drug List value is matched");
				}
				else
				{
					drugListValueID = "";
				}
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}

	//

	public static ArrayList arrMAPID_Copay = new ArrayList();

	public static void getAllMapId_Copay(String Pr,String Lv,String Sub_Sec)	{
		arrMAPID_Copay.clear();
		if(Sub_Sec.equalsIgnoreCase("Retail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(Sub_Sec.equalsIgnoreCase("Retail") && (thirteenColumnValue.get(formularyIteraor).toString().contains("01250000000UHno") ) && (eleventhColumnValue.get(formularyIteraor).toString().equals("1")))	{
							{
								arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
							}
				}			
			}	
		}
	}
			
		if(Sub_Sec.equalsIgnoreCase("Paper")){
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
						if(Sub_Sec.equalsIgnoreCase("Paper") && (thirteenColumnValue.get(formularyIteraor).toString().contains("01250000000UHnn") ) && (eleventhColumnValue.get(formularyIteraor).toString().equals("1")))	{
								{
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
					}			
				}	
			}
		}			
		
		if(Sub_Sec.equalsIgnoreCase("Mail")){
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
						if(Sub_Sec.equalsIgnoreCase("Mail") && (thirteenColumnValue.get(formularyIteraor).toString().contains("01250000000UHnm") ) && (eleventhColumnValue.get(formularyIteraor).toString().equals("1")))	{
								{
									System.out.println("TEST>>>>>"+secondColumnValue.get(formularyIteraor).toString());
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
				}			
			}	
		}
	}
		if(Sub_Sec.equalsIgnoreCase("Mail Paper OON")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(Sub_Sec.equalsIgnoreCase("Mail") && (thirteenColumnValue.get(formularyIteraor).toString().contains("01250000000UHnm") ) && (eleventhColumnValue.get(formularyIteraor).toString().equals("1")))	{
							{
								System.out.println("TEST>>>>>"+secondColumnValue.get(formularyIteraor).toString());
								arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
							}
			}			
		}	
	}
}
			MapCountVal = arrMAPID_Copay.size();
			
			//01250000000UHno - Retail
			//01250000000UHnn - Paper
			//01250000000UHnm - Mail
			//01250000000UHnz - Mail Paper OON
			
	}
	public static void FailedReportValues_Copay(String Sub_Sec){
		//System.out.println(arrMAPID);
		for(int i=0;i<arrMAPID_Copay.size();i++){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
				if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase((String) arrMAPID_Copay.get(i))){
					if(seventhColumnValue.get(formularyIteraor).toString().equals("CRD") ){}
					else{
						testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Fail");
					}
				}
			}
		}
	}



	public static void getCopayValues()

	{
		ParentMapVal = "";
		strNumberOfTierValue ="";
		srtTierType = "";
		CRDCopayLogic ="";
		strDollarAmountValue = "";
		strPercentRepo = "";
		strmindollarreport = "";
		strmaxdollarreport = "";
		strCopayCalculationreport = "";
		strNonFormularyAmountValueOrder = "";
		/*
		for(rowIterator=0;rowIterator<row;rowIterator++){
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay_Tier__c"))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Mail")||tenthColumnValue.get(rowIterator).toString().contains("Mail Copay")))
							&&(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier") && eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))
							&&(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))

							)	{

			}
		}*/

		int MapCount =ValidateProvisionTemplate_Test.CountVal; 

		if(MapCount == 0 || ValidateProvisionTemplate_Test.FailCheck.contains("Fail")) 
		{


			for(rowIterator=0;rowIterator<row;rowIterator++)	{
				if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay_Tier__c"))	{
						//if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Retail") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Retail") || tenthColumnValue.get(rowIterator).toString().contains("creates retail")||tenthColumnValue.get(rowIterator).toString().contains("retail copay")))	{
						if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Retail"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										//if(tenthColumnValue.get(rowIterator).toString().contains("Creates Retail"))
										//{
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//arrMAPID_Copay.remove(ParentMapVal);
										//}
										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
										CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										//if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
										strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
										strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
										strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
										strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
									//if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
									strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
									ParentMapVal = "";
									ParentMapVal = ninthColumnValue.get(rowIterator).toString();
									//}
								}
							}

						}	
						//if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Mail")||tenthColumnValue.get(rowIterator).toString().contains("Mail Copay")))	{
							if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();

										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");

										}
									}
								}
							}


							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!(ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null) || ValidateProvisionTemplate_Test.strCRDCopayLogic.equals("")  ))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
										//if(ParentMapVal.equals(ninthColumnValue.get(rowIterator).toString())){
										CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
										//ParentMapVal = "";

										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										//if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
										strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

										strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
										strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
										strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
										strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									//if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
									strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
									ParentMapVal = "";
									ParentMapVal = ninthColumnValue.get(rowIterator).toString();
								}
								//}
							}

							/*if(!ParentMapVal.equals("")){
							arrMAPID_Copay.remove(ParentMapVal);
							break;
						}*/

						}	
						//if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Paper") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Paper") || tenthColumnValue.get(rowIterator).toString().contains("Creates paper") || tenthColumnValue.get(rowIterator).toString().contains("creates paper")|| tenthColumnValue.get(rowIterator).toString().contains("creates Paper")))	{
							if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Paper"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//	arrMAPID_Copay.remove(ParentMapVal);
										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
											CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
											strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

											strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
											strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
											strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
											strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
										strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
									}
								}
							}

						}	
						//if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Paper Out of Network") && tenthColumnValue.get(rowIterator).toString().contains("Creates Paper Out Of Network"))	{
							if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Paper Out of Network"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//	arrMAPID_Copay.remove(ParentMapVal);
										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
											CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
											strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

											strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
											strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
											strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
											strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
										strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
									}
								}
							}

						}	
							
							if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail Paper Out of Network"))	{
								if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
											strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											//	arrMAPID_Copay.remove(ParentMapVal);
											//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
											System.out.println("Field Name: No. of tiers\t<<matched>>");
										}
									}
								}	

								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
									if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

											if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
												srtTierType = getCommonData("TestData", "TierType", 1);
												ParentMapVal = "";
												ParentMapVal = ninthColumnValue.get(rowIterator).toString();
												System.out.println("Field Name: Tier Type\t<<matched>>");
											}
										}
									}
								}	

								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
									if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

											if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
												CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
												ParentMapVal = "";
												ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											}
										}
									}
								}	

								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
									if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

											//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
											if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
												strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
												ParentMapVal = "";
												ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											}
										}
									}

								}
								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
									if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

											if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

												strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
												ParentMapVal = "";
												ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											}
										}
									}

								}

								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
									if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

											if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
												strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
												ParentMapVal = "";
												ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											}
										}
									}
								}

								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
									if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

											if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
												strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
												ParentMapVal = "";
												ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											}
										}
									}
								}

								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
									if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

											if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
												strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
												ParentMapVal = "";
												ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											}
										}	
									}
								}

								else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
											strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}
							
					}
				}
			}
		}
	}
	
	
	public static String getCommonData(String sheetName,String ColName, int RowNum)
	{
		String CellValue="";
		FileInputStream file;
		try {
			file = new FileInputStream(frameworkParameters.InputFilepath);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet xssfSheet = workbook.getSheet(sheetName);
			int ColNum =getColumnContains(xssfSheet,0,ColName);

			FormulaEvaluator formulaEvaluator = workbook.getCreationHelper()
					.createFormulaEvaluator();
			XSSFRow row = xssfSheet.getRow(RowNum);
			XSSFCell cell = row.getCell(ColNum);
			CellValue = getCellValueAsString(cell, formulaEvaluator).trim();
		} catch (Exception e) {
			e.printStackTrace();
		}	           

		return CellValue;
	}
	private static String getCellValueAsString(XSSFCell cell,FormulaEvaluator formulaEvaluator) {
		if (cell == null || cell.getCellType() == XSSFCell.CELL_TYPE_BLANK) {
			return null;
		} else {
			if (formulaEvaluator.evaluate(cell).getCellType() == XSSFCell.CELL_TYPE_ERROR) {
				System.out.println(
						"Error in formula within this cell! " + "Error code: "
								+ cell.getErrorCellValue());
			}
			DataFormatter dataFormatter = new DataFormatter();
			return dataFormatter.formatCellValue(formulaEvaluator
					.evaluateInCell(cell));
		}
	}

	public static int getColumnContains(XSSFSheet xssfsheetname2, int Rownum, String value) throws Exception {

		int a;
		try {

			int columncount=getColumnUsed(xssfsheetname2);
			for ( a=0 ; a<columncount; a++){
				if  (getCellData(xssfsheetname2,Rownum,a).equalsIgnoreCase(value)){
					break;
				}
			}
			return a;
		}catch (Exception e){
			throw(e);
		}
	}

	public static int getColumnUsed(XSSFSheet xssfsheetname2) throws Exception 
	{
		int ColumnCount= xssfsheetname2.getRow(0).getLastCellNum();
		return ColumnCount;
	}

	public static String getCellData(XSSFSheet xssfsheetname2, int RowNum, int ColNum) throws Exception

	{	
		try{
			cell = xssfsheetname2.getRow(RowNum).getCell(ColNum);
			String CellData = formatter.formatCellValue(cell);//cell.getStringCellValue();
			return CellData;

		}
		catch (Exception e)
		{

			return"";

		}

	}

}

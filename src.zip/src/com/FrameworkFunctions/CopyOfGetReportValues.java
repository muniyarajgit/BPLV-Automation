package com.FrameworkFunctions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.framework.frameworkParameters;
import com.keywords.ValidateProvisionTemplate;
import com.keywords.ValidateProvisionTemplate_Test;
import com.keywords.getTemplateValues_9;



public class CopyOfGetReportValues {
	
	//Copay
		public static String strPlanTypePaperFieldalue	= null;

		public static String strSpecialty				= null;
		public static String strSpecialty_OON			= null;
//		public static String strpaper_DSC				= null;
		public static String strpaperOON_DSC			= null;
		public static String strPercentRepo	 			= null;
		public static  String strmindollarreport 		= null;
		public static  String strmaxdollarreport 		= null;
		public static  String strCopayCalculationreport = null;
	
	public static String FilePath = frameworkParameters.FilePath;
	public static String strNumberOfTierValue 	= null;
	public static String strsubProcessValue 	= null;
	public static String srtTierType			= null;
	public static String strDollarAmountValue 	= "";
	public static String strNonFormularyAmountValueOrder = "";
	public static String strsteppedCopay 		= null;
	static Cell cell;
	public static XSSFSheet xssfSheet = null;
	static boolean retailtire		  = false;
	public static boolean ExpectedFlag;
	public static String strsubsection2	= null;
	public static String strProvisionLineValue_id	= null;
	public static boolean drugGrouplist			 = false;
	public static boolean druglist				 = false;
	public static boolean lineValue_Temp = false;
	//	DC Fields
	public static String strDC_Retail_IncExcl_DC 		= null;
	public static String strDC_Retail_IncExcl_1 		= null;
	public static String strDC_ApplyLimit_1 		= null;
	public static String strDC_Retail_DrugListorDrugGroup_1 		= null;
	public static String strDC_Retail_StartAge_1 		= null;
	public static String strDC_Retail_EndAge_1 		= null;
	public static String strDC_Gender_1 		= null;
	public static String strDC_MinDays_1 		= null;
	public static String strDC_DailyDose_1 		= null;
	public static String strDC_StartAgeType_1 		= null;
	public static String strDC_EndAgeType_1 		= null;
	public static String strDC_MaxDays_1 		= null;
	public static String strDC_MaxDaysperfill_1 		= null;
	public static String strDC_DOTTP_1 		= null;
	public static String strDC_DOTDays_1 		= null;
	public static String strDC_DOTTV_1 		= null;
	public static String strDC_QOTQty_1 		= null;
	public static String strDC_QOTTP_1 		= null;
	public static String strDC_QOTTV_1 		= null;
	public static String strDC_MaxFills_1 		= null;
	public static String strDC_MinQty_1 		= null;


	//Accums DSC
	public static String strAccum_DrugSpecific_MAB                      = null;
	public static String strAccum_DrugSpecific_M                        = null;
	public static String strAccum_DrugSpecific_N                        = null;
	public static String strAccum_DrugSpecific_O                        = null;
	public static String strAccum_DrugSpecific_Y                        = null;
	public static String strAccum_DrugSpecific_DL                       = null;
	public static String strAccum_DrugSpecific_DG                       = null;
	public static String strAccum_DrugSpecific_MABAmount                = null;
	public static String strAccum_DrugSpecific_MABPeriod                = null;
	public static String strAccum_DrugSpecific_MABMet                   = null;

	public static boolean DLColorFlag= true;
	public static boolean IncExclDCColorFlag= true;
	public static boolean IncExclColorFlag= true;
	public static boolean DLALFlag= true;

	

	static DataFormatter formatter=new DataFormatter();
	public static String drugListValueID		= "";


	public static String druglistName				= null;	
	public static String drugGrouplistName		 = null;
	public static String drugGroupListValueID 	 = "";

	public static ArrayList<String> strFormularyIDMappingValue = new ArrayList<String>();
	
	public static String strDrugSpecificCopay	= null;
	public static String strFormularyGroup 		= null;
	public static String ParentMappingValue	 	= null;
	public static String strM_Value 			= null;
	public static String strN_Value				= null;
	public static String strO_Value				= null;
	public static String strY_Value				= null;
	public static String strDollarAmount_Value	= null;
	public static String strPercent_Value	= null;
	public static String strMinimumDollar_Value	= null;
	public static String strMaximumDollar_Value	= null;
	public static String CRDCopayLogic			= "";
	public static String strReverse			= null;
	
	public static boolean steppedColorFlag= true;
	public static boolean MColorFlag= true;
	public static boolean NColorFlag= true;
	public static boolean OColorFlag= true;
	public static boolean YColorFlag= true;
	public static boolean DollarAmountColorFlag= true;
	public static boolean ReverseColorFlag= true;
	public static boolean MaxdollarColorFlag= true;
	public static boolean PercentColorFlag= true;
	public static boolean MindollarColorFlag= true;
	public static boolean CopaycalcColorFlag= true;


	public static ArrayList<String> firstColumnValue  = new ArrayList<String>();
	static ArrayList<String> secondColumnValue = new ArrayList<String>();
	public static ArrayList<String> ThirdColumnValue  = new ArrayList<String>();
	static ArrayList<String> fourthColumnValue = new ArrayList<String>();
	static ArrayList<String> fifthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> sixthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> seventhColumnValue= new ArrayList<String>();
	public static ArrayList<String> eighthColumnValue = new ArrayList<String>();
	public static ArrayList<String> ninthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> tenthColumnValue  = new ArrayList<String>();
	static ArrayList<String> eleventhColumnValue  = new ArrayList<String>();

	static int mappingName=0,mappingValuesName=1,lineValueID=2,provisionValue=3,lineValue=4,objectAPI=5,fieldLabel=6,fieldValue=8;
	public static int row=0;
	static int parentMapping=9;
	static int parentMapNotes=10;
	static int NotesColumn=11;
	static int rowIterator;


	public static void readReportValue()	{

		File csvFile= new File("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P146.csv");
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				row++;
				//strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				firstColumnValue.add(strPosition[mappingName]);
				secondColumnValue.add(strPosition[mappingValuesName]);
				ThirdColumnValue.add(strPosition[lineValueID]);
				fourthColumnValue.add(strPosition[provisionValue]);
				fifthColumnValue.add(strPosition[lineValue]);
				sixthColumnValue.add(strPosition[objectAPI]);
				seventhColumnValue.add(strPosition[fieldLabel]);
				eighthColumnValue.add(strPosition[fieldValue]);
				ninthColumnValue.add(strPosition[parentMapping]);
				tenthColumnValue.add(strPosition[parentMapNotes]);
				eleventhColumnValue.add(strPosition[NotesColumn]);
			}	

		}catch 	(Exception e)	{
			e.printStackTrace();
		}



	}


	// To get Parent Mapping Value
	static int formularyIteraor;

	public static String parntMappingValueFinal="";
	public static void getparentmapping()	{
		int mIterator = 0;
		//		int formularyIteraor;
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
				if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugListValueID))	{
							parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
				}
			}
		}
	}
	public static void getInExDCField_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion Exclusion Drug Class"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_DC  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getInExField_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion/Exclusion"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getApplylimit_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Apply Limitations"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_ApplyLimit_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getStartAge_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_StartAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndAge_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_EndAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getGender_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Gender"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Gender_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMindays_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMinQty_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDailyDose_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Daily Dose"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DailyDose_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getstartagetype_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_StartAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndagetype_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_EndAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDays_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxFills_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Fills"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxFills_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDaysperfill_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Max Days per Fill"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDaysperfill_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTP_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTDays_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: # of Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTV_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTQty_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTP_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTV_Value()	{
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if(ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || ValidateProvisionTemplate.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getAccumulationsDrugSpecific(){


		for(rowIterator=0;rowIterator<row;rowIterator++){
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue)){
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Accumulations__c")){
					if(tenthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Creates Accumulation - Individual All")){

						if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Are there any drug specific MAB?")){
							if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MAB)){
								strAccum_DrugSpecific_MAB = eighthColumnValue.get(rowIterator).toString();
							}
						}      
					}
				}      

				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("AccumulationSpecificDrug__c")){

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("M")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_M)){
							strAccum_DrugSpecific_M = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("N")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_N)){
							strAccum_DrugSpecific_N = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("O")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_O)){
							strAccum_DrugSpecific_O = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Y")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_Y)){
							strAccum_DrugSpecific_Y = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Amount")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABAmount)){
							strAccum_DrugSpecific_MABAmount = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Period")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABPeriod)){
							strAccum_DrugSpecific_MABPeriod = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("What happens when MAB is met?")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABMet)){
							strAccum_DrugSpecific_MABMet = eighthColumnValue.get(rowIterator).toString();
						}
					}


					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Drug List")){
						if(eighthColumnValue.get(rowIterator).toString().contains(drugListValueID)){

							strAccum_DrugSpecific_DL = eighthColumnValue.get(rowIterator).toString();
						}
					}
				}
			}
		}

	}

	public static void getFormularyId()	{
		strFormularyIDMappingValue.clear();
		int mIterator = 0;
		//		int formularyIteraor;
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
				if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
							strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
							//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
							strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
						}
					}
				}
			}
		}
	}
	static int drugIterator;
	static int parentIterator=0;
	//static String parntMappingValueFinal="";	
	
	public static void getParentMappingValue()	{



		parntMappingValueFinal="";
		Loop:
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
				if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
						if((eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
							parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();	
							for(int i=0;i<strFormularyIDMappingValue.size();i++)	{
								if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(strFormularyIDMappingValue.get(i)))	{
									parntMappingValueFinal = strFormularyIDMappingValue.get(i);
									break Loop;
								}else{
									parntMappingValueFinal = "";
								}
							}							
						}
					}
					else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
					{
						if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
							parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();	
							for(int i=0;i<strFormularyIDMappingValue.size();i++)	{
									if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(strFormularyIDMappingValue.get(i)))	{
									parntMappingValueFinal = strFormularyIDMappingValue.get(i);
									break Loop;
								}else{
									parntMappingValueFinal = "";
								}
							}							
						}
					}
					}
			
				}
			}
		}
	
	public static void getStepped_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strsteppedCopay  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Stepped Copay"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								System.out.println(parntMappingValueFinal);
								strsteppedCopay  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getM_Value()	{

		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strM_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("M"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								//System.out.println(parntMappingValueFinal);
								strM_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getN_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strN_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//System.out.println("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue);
					//String test1 = tenthColumnValue.get(formularyIteraor).toString();
					//System.out.println(test1);
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))))) 
						{
						//System.out.println("pass");
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("N"))	{
							//System.out.println(seventhColumnValue.get(formularyIteraor).toString());
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strN_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getO_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strO_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("O"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strO_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;	
							}
						}
					}
				}
			}
	}
	public static void getY_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strY_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strY_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDollarAmount_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strDollarAmount_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDollarAmount_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getPercent_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strPercent_Value ="";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strPercent_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMindollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strMinimumDollar_Value  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strMinimumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxdollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strMaximumDollar_Value  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strMaximumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getCopaycalc_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		CRDCopayLogic  ="";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								CRDCopayLogic  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getReverse_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strReverse = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Reverse"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strReverse = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	//---------
	public static void findDrugGroupName()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.strDrugGroup);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> drugGroupID  = new ArrayList<String>();
		ArrayList<String> drugGroupnameValue = new ArrayList<String>();
		ArrayList<String> drugGroupName = new ArrayList<String>();
		drugGroupID.clear();
		drugGroupnameValue.clear();
		drugGroupName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				drugGroupID.add(strPosition[1]);
				drugGroupnameValue.add(strPosition[2]);
				drugGroupName.add(strPosition[0]);
			}
			for(rowIterator = 0;rowIterator<drugGroupID.size();rowIterator++)	{
				//System.out.println(ValidateProvisionTemplate.DSC__DrugList);
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equals("DCA-0000705"))
				{
				System.out.println(drugGroupnameValue.get(rowIterator).toString());
				} //equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()) //drugGroupnameValue.get(rowIterator).toString()
				//drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1)
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()))	{					
					drugGrouplistName = drugGroupName.get(rowIterator).toString();
					drugGroupListValueID = drugGroupID.get(rowIterator).toString().substring(1,drugGroupID.get(rowIterator).toString().length()-1);
					System.out.println(drugGroupListValueID);
					System.out.println("drugGroupListValueID length : " + drugGroupListValueID.length());
					if(drugGroupListValueID.length()>15){
						drugGroupListValueID = drugGroupListValueID.substring(0,15);
					//	System.out.println(drugGroupListValueID);
					}
					break;
				}
				else
				{
					drugGroupListValueID = "";
				}
				
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}


	public static void findDrugList()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.drugListPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> idValue  = new ArrayList<String>();
		ArrayList<String> nameValue = new ArrayList<String>();
		ArrayList<String> drugName = new ArrayList<String>();
		idValue.clear();
		nameValue.clear();
		drugName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				idValue.add(strPosition[0]);
				nameValue.add(strPosition[1]);
				drugName.add(strPosition[2]);
			}
			//			System.out.println("ValidateProvisionTemplate.DSC__DrugList.trim() : " + ValidateProvisionTemplate.DSC__DrugList.trim());
			for(rowIterator = 0;rowIterator<idValue.size();rowIterator++)	{
				if(nameValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()))	{
					druglistName = drugName.get(rowIterator).toString();
					drugListValueID = idValue.get(rowIterator).toString();
					System.out.println(druglistName+" "+drugListValueID);
					//drugListValueID = drugListValueID.substring(0,15);
					break;
					//					System.out.println("Drug List value is matched");
				}
				else
				{
					drugListValueID = "";
				}
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}
	
	public static void getCopayValues()

	{
		for(rowIterator=0;rowIterator<row;rowIterator++)	{
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay_Tier__c"))	{
					if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Retail") || ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail") || ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Paper") || ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("PaperOutOfNetwork"))	{
						//if(tenthColumnValue.get(rowIterator).toString().contains("Creates Retail copay ")|| tenthColumnValue.get(rowIterator).toString().contains("Creates Mail Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper OON"))	{

							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
									strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
									System.out.println("Field Name: No. of tiers\t<<matched>>");
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
										srtTierType = getCommonData("TestData", "TierType", 1);
										System.out.println("Field Name: Tier Type\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
										CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

										strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
										strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
										strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
										strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
									strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
								}
							}

						}	
					}
				}
			}
		}
	public static String getCommonData(String sheetName,String ColName, int RowNum)
	{
		String CellValue="";
		FileInputStream file;
		try {
			file = new FileInputStream(frameworkParameters.InputFilepath);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet xssfSheet = workbook.getSheet(sheetName);
			int ColNum =getColumnContains(xssfSheet,0,ColName);

			FormulaEvaluator formulaEvaluator = workbook.getCreationHelper()
					.createFormulaEvaluator();
			XSSFRow row = xssfSheet.getRow(RowNum);
			XSSFCell cell = row.getCell(ColNum);
			CellValue = getCellValueAsString(cell, formulaEvaluator).trim();
		} catch (Exception e) {
			e.printStackTrace();
		}	           

		return CellValue;
	}
	private static String getCellValueAsString(XSSFCell cell,FormulaEvaluator formulaEvaluator) {
		if (cell == null || cell.getCellType() == XSSFCell.CELL_TYPE_BLANK) {
			return null;
		} else {
			if (formulaEvaluator.evaluate(cell).getCellType() == XSSFCell.CELL_TYPE_ERROR) {
				System.out.println(
						"Error in formula within this cell! " + "Error code: "
								+ cell.getErrorCellValue());
			}
			DataFormatter dataFormatter = new DataFormatter();
			return dataFormatter.formatCellValue(formulaEvaluator
					.evaluateInCell(cell));
		}
	}

	public static int getColumnContains(XSSFSheet xssfsheetname2, int Rownum, String value) throws Exception {

		int a;
		try {

			int columncount=getColumnUsed(xssfsheetname2);
			for ( a=0 ; a<columncount; a++){
				if  (getCellData(xssfsheetname2,Rownum,a).equalsIgnoreCase(value)){
					break;
				}
			}
			return a;
		}catch (Exception e){
			throw(e);
		}
	}

	public static int getColumnUsed(XSSFSheet xssfsheetname2) throws Exception 
	{
		int ColumnCount= xssfsheetname2.getRow(0).getLastCellNum();
		return ColumnCount;
	}

	public static String getCellData(XSSFSheet xssfsheetname2, int RowNum, int ColNum) throws Exception

	{	
		try{
			cell = xssfsheetname2.getRow(RowNum).getCell(ColNum);
			String CellData = formatter.formatCellValue(cell);//cell.getStringCellValue();
			return CellData;

		}
		catch (Exception e)
		{

			return"";

		}

	}

}

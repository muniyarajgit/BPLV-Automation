package com.keywords;

import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;
import com.application.provision_24;
import com.framework.BPLV_Functions;
import com.framework.commonExcelFunctions;

public class ValidateProvisionTemplate {
	
	public static int match = 0;
	
	private static final String[][] String 				= null;
	public static String tempDLSel = null;
	public static String provisionNumber 				= null;
	public static String provisionLineValue				= null;
	public static String Provision_LineText 			= null;
	public static String subSection 					= null;
	public static String FieldName						= null;
	public static String strFieldName 					= null;
	//Drug Specific Copay - Speciality Tiers 
	public static String DSC_SpecialtyTiers_1      		= null;	
	public static String DSC_RetailTier;
	public static String DSC_RetailFieldValue 			= null;
	public static String strcopayNonFormularyValue		= null;
	// common Variable
	public static int row;
	public static int Subsection;
	//ExpectedReport Variable declarations
	public static String Rep_provisionNumber 				= null;
	public static String Rep_provisionLineValue				= null;
	public static String Rep_Provision_LineText 			= null;
	public static String Rep_subSection 					= null;
	public static String Rep_FieldName						= null;
	public static String Rep_planTypeRetailFieldValue_1		= null;
	public static String Rep_NumberOfTiers_1				= null;
	public static String Rep_CopayToPaper_1					= null;
	public static String Rep_TierType_1 					= null;
	public static String Rep_CRDCopayLogic_1				= null;
	public static String Rep_DollarAmount_1					= null;
	public static String Rep_Percent_1 						= null;
	public static String Rep_CoPayCalculation_1				= null;
	public static String Rep_MinimunDollar_1				= null;
	public static String Rep_MaximumDollar_1				= null;
	public static String Rep_NonFormularyDollarAmount_1		= null;
	public static String Rep_NonFormularyPercent_1			= null;
	public static String Rep_NonFormularyCopayCalculation_1 = null;
	public static String Rep_NonFormularyMinimumDollar_1	= null;
	public static String Rep_NonFormularyMaximumDollar_1	= null;
	//
	public static XSSFSheet xssfSheet = null;
	//
	public static String strNumberOfTierValue 			 = null;
	public static String strsubProcessValue 	 		 = null;
	public static String srtTierType			 		 = null;
	public static String strDollarAmountValue 			 = null;
	public static String strNonFormularyAmountValueOrder = null;

	public static String subsectionProcessType_Value	 = null;
	public static String DSC_FieldValue					 = null;
	public static String strCRDCopayLogic 				 = null;
	public static String DSC__DrugList					 = null;
	//public static String DC__DrugList					 = null;
	public static String planTypePaperFieldValue    	 = null;
	public static String dsc_Subsection					 = null;
	public static String strProvisionLineValue_id		 = null;
	public static int rowCount;
	public static String DSC__DrugListSelection			 = null;
	public static ArrayList arr_ProvisionLineValue =  new ArrayList();
	public static ArrayList arrRowValue = new ArrayList();
	//Jayashree
	public static String DC_Retail_DrugListorDrugGroup_1 		= null; 
	public static String DC__DrugListDrugGroupSelection_1		= null; 

	public static String DC_Retail_DrugClass_1 		= null;
	public static String DC_Retail_IncExcl_1 		= null;
	public static String DC_ApplyLimit_1 			= null;
	public static String DC_Retail_StartAge_1 		= null;
	public static String DC_Retail_EndAge_1 		= null;
	public static String DC_Gender_1 				= null;
	public static String DC_Mindays_1 				= null;
	public static String DC_Minquantity_1 			= null;
	public static String DC_DailyDose_1 			= null;
	public static String DC_Retail_StrtAgeType_1 	= null;
	public static String DC_Retail_EnAgeType_1 		= null;
	public static String DC_Retail_Day_QuantityRule_1= null;
	public static String DC_Retail_MaxDaysperFill_1 = null;
	public static String DC_Retail_MaxDays_1 		= null;
	public static String DC_Retail_MaxFills_1 		= null;
	public static String DC_Retail_DOT1_TP_1 		= null;
	public static String DC_Retail_DOT_Days_1		= null;
	public static String DC_Retail_DOT_TV_1			= null;
	public static String DC_Retail_MaxQtyperFill_1 	= null;
	public static String DC_Retail_QOT_Qty_1 		= null;
	public static String DC_Retail_QOT_TP_1 		= null;
	public static String DC_Retail_QOT_TV_1 		= null;
	public static String DC_Retail_BypassMOOP_1 	= null;

	//Accums specific DSC
	public static String Accum_DrugSpecific_MAB    	  = null;
	public static String Accum_DrugSpecific_M      	  = null;
	public static String Accum_DrugSpecific_N      	  = null;
	public static String Accum_DrugSpecific_O      	  = null;
	public static String Accum_DrugSpecific_Y         = null;
	public static String Accum_DrugSpecific_DL        = null;
	public static String Accum_DrugSpecific_DG  	  = null;
	public static String Accum_DrugSpecific_MABAmount = null;
	public static String Accum_DrugSpecific_MABPeriod = null;
	public static String Accum_DrugSpecific_MABMet    = null;
	//

	public static String tempsubsec = "";
	public static String tempDLid = "";
	public static String tempIncExcl = "";
	public static String tempIncExclDC = "";
	public static String tempApplylimit = "";
	public static String tempStartAge = "";
	public static String tempEndAge = "";
	public static String tempGender = "";
	public static String tempMindays = "";
	public static String tempMinquantity = "";
	public static String tempDailyDose = "";
	public static String tempStartAgeType = "";
	public static String tempEndAgeType = "";
	public static String tempDay_QuantityRule = "";
	public static String tempMaxDaysperFill = "";
	public static String tempMaxDays = "";
	public static String tempMaxFills = "";
	public static String tempDOT_TP = "";
	public static String tempDOT_Days = "";
	public static String tempDOT_TV = "";
	public static String tempMaxQtyperFill = "";
	public static String tempQOT_Qty = "";
	public static String tempQOT_TP = "";
	public static String tempQOT_TV = "";
	public static String tempBypassMOOP = "";

	//DSC
	public static String tempStepped = "";
	public static String tempM = "";
	public static String tempN = "";
	public static String tempO = "";
	public static String tempY = "";
	public static String tempDollarAmount = "";
	public static String tempPercentAmount = "";
	public static String tempMindollar = "";
	public static String tempMaxdollar = "";
	public static String tempCopayCalc = "";
	public static String tempReverse = "";

	// Drug Specific CoPay - Retail Tiers 
	public static String DSC_Retail_FormularyGroup = null;
	public static String DSC_Retail_DrugList 	   = null;
	public static String DSC_Retail_Stepped 	   = null;
	public static String DSC_Retail_M 	   		   = null;
	public static String DSC_Retail_N 	  		   = null;
	public static String DSC_Retail_O 	   		   = null;
	public static String DSC_Retail_Y 	   		   = null;
	public static String DSC_Retail_DollarAmount   = null;
	public static String DSC_Retail_Percent 	   = null;
	public static String DSC_Retail_CopayCalculation= null;
	public static String DSC_Retail_MinimumDollar  = null;
	public static String DSC_Retail_MaximumDollar  = null;
	public static String DSC_Retail_Reverse 	   = null;

	public static String DC_Retail_DrugList_1 = "";	

	public static String strsubsection2	= null;
	public static String AnyDrugSpecificCopays = "";
	public static int CountOfDrugList = 0;


	public static void getDrugCoverageDetails(String subsectionProcessType, String process, String value, int row) throws Exception	{

		// Read Values from Template
		subsectionProcessType_Value = process;
		//		dsc_Subsection 		   				 = commonExcelFunctions.getInputData("Sheet 1", "SubSectionProcess_1", row);
		DC_Retail_DrugListorDrugGroup_1 	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugListorDrugGroup_"+value, row);
		DC_Retail_DrugList_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugList_"+value, row);
		DC_Retail_DrugClass_1			 	 = commonExcelFunctions.getInputData("Sheet 1", process+"_DrugClass_"+value, row);
		DC_Retail_IncExcl_1 	 			 = commonExcelFunctions.getInputData("Sheet 1", process+"_IncExcl_"+value, row);
		DC_ApplyLimit_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_ApplyLimit_"+value, row);
		DC_Retail_StartAge_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_StartAge_"+value, row);
		DC_Retail_EndAge_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_EndAge_"+value, row);
		DC_Gender_1 						 = commonExcelFunctions.getInputData("Sheet 1", process+"_Gender_"+value, row);
		DC_Mindays_1 						 = commonExcelFunctions.getInputData("Sheet 1", process+"_Mindays_"+value, row);
		DC_Minquantity_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_Minquantity_"+value, row);
		DC_DailyDose_1 						 = commonExcelFunctions.getInputData("Sheet 1", process+"_DailyDose_"+value, row);
		DC_Retail_StrtAgeType_1				 = commonExcelFunctions.getInputData("Sheet 1", process+"_StartAgeType_"+value, row);
		DC_Retail_EnAgeType_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_EndAgeType_"+value, row);
		DC_Retail_Day_QuantityRule_1 		 = commonExcelFunctions.getInputData("Sheet 1", process+"_Day_QuantityRule_"+value, row);
		DC_Retail_MaxDaysperFill_1 			 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxDaysperFill_"+value, row);
		DC_Retail_MaxDays_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxDays_"+value, row);
		DC_Retail_MaxFills_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxFills_"+value, row);
		DC_Retail_DOT1_TP_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DOT_TP_"+value, row);
		DC_Retail_DOT_Days_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_DOT_Days_"+value, row);
		DC_Retail_DOT_TV_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_DOT_TV_"+value, row);
		DC_Retail_MaxQtyperFill_1 			 = commonExcelFunctions.getInputData("Sheet 1", process+"_MaxQtyperFill_"+value, row);
		DC_Retail_QOT_Qty_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_QOT_Qty_"+value, row);
		DC_Retail_QOT_TP_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_QOT_TP_"+value, row);
		DC_Retail_QOT_TV_1 					 = commonExcelFunctions.getInputData("Sheet 1", process+"_QOT_TV_"+value, row);
		DC_Retail_BypassMOOP_1 				 = commonExcelFunctions.getInputData("Sheet 1", process+"_BypassMOOP_"+value, row);


		//Split and store values in array
		tempsubsec = DC_Retail_DrugListorDrugGroup_1;
		tempDLid = DC_Retail_DrugList_1;
		tempIncExclDC = DC_Retail_DrugClass_1;
		tempIncExcl = DC_Retail_IncExcl_1;
		tempApplylimit= DC_ApplyLimit_1;
		tempStartAge= DC_Retail_StartAge_1;
		tempEndAge = DC_Retail_EndAge_1; 
		tempGender= DC_Gender_1; 
		tempMindays = DC_Mindays_1;
		tempMinquantity= DC_Minquantity_1 ;
		tempDailyDose =  DC_DailyDose_1 ;
		tempStartAgeType = DC_Retail_StrtAgeType_1 ;
		tempEndAgeType = DC_Retail_EnAgeType_1 ;
		tempDay_QuantityRule =  DC_Retail_Day_QuantityRule_1 ;
		tempMaxDaysperFill = DC_Retail_MaxDaysperFill_1 ;
		tempMaxDays = DC_Retail_MaxDays_1;		
		tempMaxFills = DC_Retail_MaxFills_1;
		tempDOT_TP = DC_Retail_DOT1_TP_1;
		tempDOT_Days = DC_Retail_DOT_Days_1;
		tempDOT_TV = DC_Retail_DOT_TV_1;
		tempMaxQtyperFill = DC_Retail_MaxQtyperFill_1;
		tempQOT_Qty = DC_Retail_QOT_Qty_1;
		tempQOT_TP = DC_Retail_QOT_TP_1;
		tempQOT_TV = DC_Retail_QOT_TV_1;
		tempBypassMOOP = DC_Retail_BypassMOOP_1;		 


		/*	if(!DC_Retail_DrugListorDrugGroup_1.equalsIgnoreCase(""))	{
			String[] DrugListSel = DC_Retail_DrugListorDrugGroup_1.split("\n");
			String[] DrugListID = DC_Retail_DrugList_1.split("\n");
			commonExcelFunctions.readReportValue();
			for(int i=0;i<DrugListSel.length;i++) {
				if(DrugListSel[i].equalsIgnoreCase("Drug List")) {
					DSC__DrugList = DrugListID[i];
					commonExcelFunctions.findDrugList();
					commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugList_"+value, commonExcelFunctions.drugListValueID);
					System.out.println("<<< Drug List value is matched>>>>");
					commonExcelFunctions.getparentmapping();
					/*if(DC__DrugListDrugGroupSelection_1.equalsIgnoreCase("Drug Group"))	{
						commonExcelFunctions.findDrugGroupName();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugListSelection_"+value, "Drug Group");
					}*/
		/*				if(!DC_Retail_DrugClass_1.equalsIgnoreCase(""))	
					{
						String[] IncExcl_DC = tempIncExclDC.split("\n");
						DC_Retail_DrugClass_1 = IncExcl_DC[i];
						commonExcelFunctions.getInExDCField_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DrugClass_"+value, commonExcelFunctions.strDC_Retail_IncExcl_DC);
						System.out.println("<<< Inclusion Exclusion Drug Class value is matched>>>>");
					}
					if(!DC_Retail_IncExcl_1.equalsIgnoreCase(""))	
					{
						String[] IncExcl = tempIncExcl.split("\n");
						DC_Retail_IncExcl_1 = IncExcl[i];
						commonExcelFunctions.getInExField_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_IncExcl_"+value, commonExcelFunctions.strDC_Retail_IncExcl_1);
						System.out.println("<<< Inclusion Exclusion value is matched>>>>");
					}
					if(!DC_ApplyLimit_1.equalsIgnoreCase(""))	
					{
						String[] ApplyLimit = tempApplylimit.split("\n");
						DC_ApplyLimit_1 = ApplyLimit[i];
						commonExcelFunctions.getApplylimit_Value();
						Thread.sleep(3000);
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_ApplyLimit_"+value, commonExcelFunctions.strDC_ApplyLimit_1);
						System.out.println("<<<  Apply Limitations value is matched>>>>");


					}
					if(!DC_Retail_StartAge_1.equalsIgnoreCase(""))	
					{
						String[] StartAge = tempStartAge.split("\n");
						DC_Retail_StartAge_1 = StartAge[i];
						commonExcelFunctions.getStartAge_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_StartAge_"+value, commonExcelFunctions.strDC_Retail_StartAge_1);
						System.out.println("<<<  Start Age value is matched>>>>");


					}
					if(!DC_Retail_EndAge_1.equalsIgnoreCase(""))	
					{
						String[] EndAge = tempEndAge.split("\n");
						DC_Retail_EndAge_1  = EndAge[i];
						commonExcelFunctions.getEndAge_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_EndAge_"+value, commonExcelFunctions.strDC_Retail_EndAge_1);
						System.out.println("<<<  End Age value is matched>>>>");
					}
					if(!DC_Gender_1.equalsIgnoreCase(""))	
					{
						String[] Gender = tempGender.split("\n");
						DC_Gender_1   = Gender[i];
						commonExcelFunctions.getGender_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Gender_"+value, commonExcelFunctions.strDC_Gender_1);
						System.out.println("<<<  Gender value is matched>>>>");
					}
					if(!DC_Mindays_1.equalsIgnoreCase(""))	
					{
						String[] Mindays = tempMindays.split("\n");
						DC_Mindays_1   = Mindays[i];
						commonExcelFunctions.getMindays_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Mindays_"+value, commonExcelFunctions.strDC_MinDays_1);
						System.out.println("<<<  Gender value is matched>>>>");
					}
					if(!DC_Minquantity_1.equalsIgnoreCase(""))	
					{
						String[] Minquantity = tempMinquantity.split("\n");
						DC_Minquantity_1    = Minquantity[i];
						commonExcelFunctions.getMindays_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_Minquantity_"+value, commonExcelFunctions.strDC_MinQty_1);
						System.out.println("<<<  Minimum quantity value is matched>>>>");
					}
					if(!DC_DailyDose_1.equalsIgnoreCase(""))	
					{
						String[] DailyDose = tempDailyDose.split("\n");
						DC_DailyDose_1     = DailyDose[i];
						commonExcelFunctions.getDailyDose_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DailyDose_"+value, commonExcelFunctions.strDC_DailyDose_1);
						System.out.println("<<<  Daily Dose value is matched>>>>");
					}
					if(!DC_Retail_StrtAgeType_1.equalsIgnoreCase(""))	
					{
						String[] StartAgeType = tempStartAgeType.split("\n");
						DC_Retail_StrtAgeType_1      = StartAgeType[i];
						commonExcelFunctions.getstartagetype_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_StartAgeType_"+value, commonExcelFunctions.strDC_StartAgeType_1);
						System.out.println("<<< StartAgeType value is matched>>>>");
					}
					if(!DC_Retail_EnAgeType_1.equalsIgnoreCase(""))	
					{
						String[] EndAgeType =  tempEndAgeType.split("\n");
						DC_Retail_EnAgeType_1       = EndAgeType[i];
						commonExcelFunctions.getEndagetype_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_EndAgeType_"+value, commonExcelFunctions.strDC_StartAgeType_1);
						System.out.println("<<< EndAgeType value is matched>>>>");
					}
					if(!DC_Retail_MaxDays_1.equalsIgnoreCase(""))	
					{
						String[] MaxDays =   tempMaxDays.split("\n");
						DC_Retail_MaxDays_1       = MaxDays[i];
						commonExcelFunctions.getMaxDays_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaxDays_"+value, commonExcelFunctions.strDC_MaxDays_1);
						System.out.println("<<< Maximum Days value is matched>>>>");
					}
					if(!DC_Retail_MaxFills_1.equalsIgnoreCase(""))	
					{
						String[] MaxFills =    tempMaxFills.split("\n");
						DC_Retail_MaxFills_1       = MaxFills[i];
						commonExcelFunctions.getMaxFills_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaxFills_"+value, commonExcelFunctions.strDC_MaxFills_1);
						System.out.println("<<< Maximum Fills value is matched>>>>");
					}
					if(!DC_Retail_MaxDaysperFill_1.equalsIgnoreCase(""))	
					{
						String[] MaxDaysperFill =    tempMaxDaysperFill.split("\n");
						DC_Retail_MaxDaysperFill_1       = MaxDaysperFill[i];
						commonExcelFunctions.getMaxDaysperfill_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_MaxDaysperFill_"+value, commonExcelFunctions.strDC_MaxDaysperfill_1);
						System.out.println("<<< Maximum Days per Fill value is matched>>>>");
					}
					if(!DC_Retail_DOT1_TP_1.equalsIgnoreCase(""))	
					{
						String[] DOT_TP =    tempMaxDaysperFill.split("\n");
						DC_Retail_DOT1_TP_1       = DOT_TP[i];
						commonExcelFunctions.getDOTTP_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DOT_TP_"+value, commonExcelFunctions.strDC_DOTTP_1);
						System.out.println("<<< DOT Time period value is matched>>>>");
					}
					if(!DC_Retail_DOT_Days_1.equalsIgnoreCase(""))	
					{
						String[] DOT_Days =    tempDOT_Days.split("\n");
						DC_Retail_DOT_Days_1       = DOT_Days[i];
						commonExcelFunctions.getDOTTP_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DOT_Days_"+value, commonExcelFunctions.strDC_DOTDays_1);
						System.out.println("<<< DOT Days value is matched>>>>");
					}
					if(!DC_Retail_DOT_TV_1.equalsIgnoreCase(""))	
					{
						String[] DOT_TV =    tempDOT_TV.split("\n");
						DC_Retail_DOT_TV_1       = DOT_TV[i];
						commonExcelFunctions.getDOTTV_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_DOT_TV_"+value, commonExcelFunctions.strDC_DOTTV_1);
						System.out.println("<<< DOT Timevalue value is matched>>>>");
					}
					if(!DC_Retail_QOT_Qty_1.equalsIgnoreCase(""))	
					{
						String[] QOT_Qty =    tempQOT_Qty.split("\n");
						DC_Retail_QOT_Qty_1       = QOT_Qty[i];
						commonExcelFunctions.getQOTQty_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_QOT_Qty_"+value, commonExcelFunctions.strDC_QOTQty_1);
						System.out.println("<<< QOT Quantity value is matched>>>>");
					}
					if(!DC_Retail_QOT_TP_1.equalsIgnoreCase(""))	
					{
						String[] QOT_TP =     tempQOT_TP.split("\n");
						DC_Retail_QOT_TP_1       = QOT_TP[i];
						commonExcelFunctions.getQOTTP_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_QOT_TP_"+value, commonExcelFunctions.strDC_QOTTP_1);
						System.out.println("<<< QOT Time period value is matched>>>>");
					}
					if(!DC_Retail_QOT_TV_1.equalsIgnoreCase(""))	
					{
						String[] QOT_TV =     tempQOT_TV.split("\n");
						DC_Retail_QOT_TV_1       = QOT_TV[i];
						commonExcelFunctions.getQOTTV_Value();
						commonExcelFunctions.CellValue_Comparator(FilePath, "Sheet 1", row, process+"_QOT_TV_"+value, commonExcelFunctions.strDC_QOTTV_1);
						System.out.println("<<< QOT Time value is matched>>>>");
					}
				}




			}
		}*/

	}

	//

	public static void validate_WOD_DrugClass(String P, String L, String DrugClass)
	{
		provisionNumber = P;
		provisionLineValue = L;
		GetReportValues.WOD();
		//if(GetReportValues.DrugclassVal.equals(DrugClass)){
		if(GetReportValues.DrugclassVal.contains(DrugClass)){
			//System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Stepped: Matched");
			testResultFunctions.set_custom_message_in_Report_Test("", provisionNumber, provisionLineValue, "WOD", "Drug Class", DrugClass, GetReportValues.DrugclassVal, GetReportValues.parntMappingValueFinal, "Pass");
		}	
		else
		{
			testResultFunctions.set_custom_message_in_Report_Test("", provisionNumber, provisionLineValue, "WOD", "Drug Class", DrugClass, GetReportValues.DrugclassVal, GetReportValues.parntMappingValueFinal, "Failed");
		}
	}


	//Drug specific copay
	public static String DSC_ByPassOON = "";
	public static void validateDrugSpecificCopayDetails(String PNo,String LValue,String T_subsectionProcessType_Value,String T_DSC_RetailFieldValue,String T_DSC_Retail_FormularyGroup,String T_DSC__DrugListSelection,String T_DSC__DrugList,String T_DSC_Retail_Stepped,String T_DSC_Retail_M,String T_DSC_Retail_N,String T_DSC_Retail_O,String T_DSC_Retail_Y,String T_DSC_Retail_DollarAmount,String T_DSC_Retail_Percent,String T_DSC_Retail_CopayCalculation,String T_DSC_Retail_MinimumDollar,String T_DSC_Retail_MaximumDollar,String T_DSC_Retail_Reverse,String byPassOoN) throws Exception

	{
		
		provisionNumber = PNo.trim();
		provisionLineValue = LValue;		
		subsectionProcessType_Value = T_subsectionProcessType_Value.trim();
		DSC_RetailFieldValue = T_DSC_RetailFieldValue.trim();
		DSC_ByPassOON = byPassOoN.trim();
		DSC_Retail_FormularyGroup	= T_DSC_Retail_FormularyGroup.trim();		
		DSC__DrugList  		   				 = T_DSC__DrugList.trim();
		DSC__DrugListSelection	   			 = T_DSC__DrugListSelection.trim();
		DSC_Retail_Stepped		 		   	 = T_DSC_Retail_Stepped.trim();
		DSC_Retail_M		 		  	 	 = T_DSC_Retail_M.trim();
		DSC_Retail_N		 		   		 = T_DSC_Retail_N.trim();
		DSC_Retail_O		 		   		 = T_DSC_Retail_O.trim();
		DSC_Retail_Y		 		   		 = T_DSC_Retail_Y.trim();
		DSC_Retail_DollarAmount		 	   	 = T_DSC_Retail_DollarAmount;
		DSC_Retail_Percent		 		   	 = T_DSC_Retail_Percent;
		DSC_Retail_CopayCalculation		   	 = T_DSC_Retail_CopayCalculation.trim();
		DSC_Retail_MinimumDollar		   	 = T_DSC_Retail_MinimumDollar;
		DSC_Retail_MaximumDollar		   	 = T_DSC_Retail_MaximumDollar;
		DSC_Retail_Reverse		 		   	 = T_DSC_Retail_Reverse.trim();
		
		Validate_DSC();
		tempStepped = DSC_Retail_Stepped;
		tempM = DSC_Retail_M;
		tempN = DSC_Retail_N;
		tempO = DSC_Retail_O;
		tempY = DSC_Retail_Y;
		tempDollarAmount = DSC_Retail_DollarAmount;
		tempPercentAmount = DSC_Retail_Percent;
		tempMindollar = DSC_Retail_MinimumDollar;
		tempMaxdollar = DSC_Retail_MaximumDollar;
		tempCopayCalc = DSC_Retail_CopayCalculation;
		tempReverse = DSC_Retail_Reverse;

		String value2 = "";
		String[] data = DSC_Retail_FormularyGroup.split("\n");
		for(int i=0;i<data.length;i++)	{
			value2 = value2.trim().replaceAll("\\s", "")+data[i].trim().replaceAll("\\s", "")+";";
		}
		DSC_Retail_FormularyGroup = value2;
		if(DSC_Retail_FormularyGroup.endsWith(";"))	{
			DSC_Retail_FormularyGroup = DSC_Retail_FormularyGroup.substring(0,DSC_Retail_FormularyGroup.length()-1).trim();
		}
		if(!DSC__DrugListSelection.equalsIgnoreCase(""))	
		{
			String[] DrugListSel = null;
			String[] DrugListID = null;	

			int Drugcount = 0;
			DrugListSel = DSC__DrugListSelection.split("\n");
			DrugListID = DSC__DrugList.split("\n");	
			System.out.println(DSC__DrugList);
			System.out.println("DL Count:" +DrugListSel.length);
			System.out.println("DL Name Count:" +DrugListID.length);
			for(int i=0;i<DrugListSel.length;i++) {
				GetReportValues.arrFRMID.clear();
				GetReportValues.getFormularyId();				
				if(GetReportValues.arrFRMID.size()!=0)	{
					match=1;
					//System.out.println("TEST");
					tempDLSel = DrugListSel[i].trim();
					//System.out.println(tempDLSel + i);
					if(tempDLSel.equalsIgnoreCase("Drug List")) {

						//System.out.println("TEST1");
						DSC__DrugList = DrugListID[i].trim();


						//System.out.println(DSC__DrugList);
						GetReportValues.findDrugList();	
						//	GetReportValues.MultipleDruglist();

						/*	if((GetReportValues.drugListValueID).equals(null) || (GetReportValues.drugListValueID).equals(""))
					{
						System.out.println("Drug List Not Available in Report");
					}else{ */
						//GetReportValues.MultipleDruglist();

						String[] DSC_Stepped = tempStepped.split("\n");
						DSC_Retail_Stepped = DSC_Stepped[i];
						String[] DSC_M = tempM.split("\n");
						DSC_Retail_M = DSC_M[i];

						String[] DSC_N = tempN.split("\n");
						DSC_Retail_N = DSC_N[i];
						//GetReportValues.MultipleDrugMap();
						//GetReportValues.MultipleDrugMap();

						GetReportValues.getParentMappingValue();

						System.out.println("DSC__DrugList : "+DSC__DrugList);
						System.out.println("parntMappingValueFinal : "+GetReportValues.parntMappingValueFinal);


					}
					else if(DrugListSel[i].equalsIgnoreCase("Drug Group")) {

						DSC__DrugList = DrugListID[i];
						System.out.println(DSC__DrugList);
						GetReportValues.findDrugGroupName();

						String[] DSC_Stepped = tempStepped.split("\n");
						DSC_Retail_Stepped = DSC_Stepped[i];
						String[] DSC_M = tempM.split("\n");
						DSC_Retail_M = DSC_M[i];

						String[] DSC_N = tempN.split("\n");
						DSC_Retail_N = DSC_N[i];
						GetReportValues.getParentMappingValue();
						System.out.println("DSC__DrugList : "+DSC__DrugList);
						System.out.println("parntMappingValueFinal : "+GetReportValues.parntMappingValueFinal);
						//}
					}

					GetReportValues.arrMAPID.remove(GetReportValues.parntMappingValueFinal);
					if(!(tempStepped.equalsIgnoreCase("")||tempStepped.equalsIgnoreCase("Null")))	
					{
						String[] DSC_Stepped = tempStepped.split("\n");
						DSC_Retail_Stepped = DSC_Stepped[i];
						if(DSC_Retail_Stepped.equalsIgnoreCase("Null")){
							//DSC_Retail_Stepped = "";
						}else{
							GetReportValues.getStepped_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_Stepped : "+DSC_Retail_Stepped);
							System.out.println("strsteppedCopay : "+GetReportValues.strsteppedCopay);
							if(DSC_Retail_Stepped.equalsIgnoreCase(GetReportValues.strsteppedCopay)){
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Stepped: Matched");
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "Stepped", DSC_Retail_Stepped, GetReportValues.strsteppedCopay, GetReportValues.parntMappingValueFinal, "Pass");
							}else
							{
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Stepped: Not Matched");
							}
						}
					}

					if(!(tempM.equalsIgnoreCase("")||tempM.equalsIgnoreCase("Null")))	
					{
						String[] DSC_M = tempM.split("\n");
						DSC_Retail_M = DSC_M[i];
						if(DSC_Retail_M.equalsIgnoreCase("Null")){
							//DSC_Retail_Stepped = "";
						}	else	{
							GetReportValues.getM_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_M : "+DSC_Retail_M);
							System.out.println("strM_Value : "+GetReportValues.strM_Value);
							if(DSC_Retail_M.equalsIgnoreCase(GetReportValues.strM_Value)){
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" M: Matched");
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "M", DSC_Retail_M, GetReportValues.strM_Value, GetReportValues.parntMappingValueFinal, "Pass");

							}	else	{
								if(GetReportValues.Flag==true)	{
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "M", DSC_Retail_M, GetReportValues.strM_Value, GetReportValues.parntMappingValueFinal, "Failed");
								}
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" M: Not Matched");
							}
						}
					}
					if(!(tempN.equalsIgnoreCase("")||tempN.equalsIgnoreCase("Null")))	
					{
						String[] DSC_N = tempN.split("\n");
						DSC_Retail_N = DSC_N[i];
						if(DSC_Retail_N.equalsIgnoreCase("Null")){
							//DSC_Retail_Stepped = "";
						}else{
							GetReportValues.getN_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_N : "+DSC_Retail_N);
							System.out.println("strN_Value : "+GetReportValues.strN_Value);
							if(DSC_Retail_N.equalsIgnoreCase(GetReportValues.strN_Value)){
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "N", DSC_Retail_N, GetReportValues.strN_Value, GetReportValues.parntMappingValueFinal, "Pass");
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" N: Matched");
							}else
							{
								if(GetReportValues.Flag==true){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "N", DSC_Retail_N, GetReportValues.strN_Value, GetReportValues.parntMappingValueFinal, "Failed");
								}
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" N: Not Matched");
							}
						}
					}
					if(!(tempO.equalsIgnoreCase("")||tempO.equalsIgnoreCase("Null")))	
					{
						String[] DSC_O = tempO.split("\n");
						DSC_Retail_O = DSC_O[i];
						if(DSC_Retail_O.equalsIgnoreCase("Null")){
							//DSC_Retail_Stepped = "";
						}else{
							GetReportValues.getO_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_O : "+DSC_Retail_O);
							System.out.println("strO_Value : "+GetReportValues.strO_Value);
							if(DSC_Retail_O.equalsIgnoreCase(GetReportValues.strO_Value)){
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "O", DSC_Retail_O, GetReportValues.strO_Value, GetReportValues.parntMappingValueFinal, "Pass");
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" O: Matched");
							}else
							{
								if(GetReportValues.Flag==true){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "O", DSC_Retail_O, GetReportValues.strO_Value, GetReportValues.parntMappingValueFinal, "Failed");
								}
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" O: Not Matched");
							}
						}
					}
					if(!(tempY.equalsIgnoreCase("")||tempY.equalsIgnoreCase("Null")))	
					{
						String[] DSC_Y = tempY.split("\n");
						DSC_Retail_Y = DSC_Y[i];
						if(DSC_Retail_Y.equalsIgnoreCase("Null")){
						}else{
							GetReportValues.getY_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_Y : "+DSC_Retail_Y);
							System.out.println("strY_Value : "+GetReportValues.strY_Value);	
							if(DSC_Retail_Y.equalsIgnoreCase(GetReportValues.strY_Value)){
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "Y", DSC_Retail_Y, GetReportValues.strY_Value, GetReportValues.parntMappingValueFinal, "Pass");
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Y: Matched");
							}else
							{
								if(GetReportValues.Flag==true){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "Y", DSC_Retail_Y, GetReportValues.strY_Value, GetReportValues.parntMappingValueFinal, "Failed");
								}
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Y: Not Matched");
							}
						}
					}
					if(!(tempDollarAmount.equalsIgnoreCase("")||tempDollarAmount.equalsIgnoreCase("Null")))  
					{
						String[] DSC_Dollar = tempDollarAmount.split("\n");
						//if(DSC_Dollar[i].equals(null)||DSC_Dollar[i].equals(" ")||DSC_Dollar[i].equals("")){
						//DSC_Retail_DollarAmount = "null";
						//}else{						
						DSC_Retail_DollarAmount = DSC_Dollar[i];
						if(DSC_Retail_DollarAmount.equalsIgnoreCase("Null")){
							//DSC_Retail_Stepped = "";
						}else{
							GetReportValues.getDollarAmount_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_DollarAmount : "+DSC_Retail_DollarAmount);
							System.out.println("strDollarAmount_Value : "+GetReportValues.strDollarAmount_Value);	
							if(DSC_Retail_DollarAmount.contains(GetReportValues.strDollarAmount_Value)&&(!GetReportValues.strDollarAmount_Value.equals(""))){
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "DollarAmount", DSC_Retail_DollarAmount, GetReportValues.strDollarAmount_Value, GetReportValues.parntMappingValueFinal, "Pass");
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Dollar Amount: Matched");
							}else
							{	
								if(GetReportValues.Flag==true){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "DollarAmount", DSC_Retail_DollarAmount, GetReportValues.strDollarAmount_Value, GetReportValues.parntMappingValueFinal, "Failed");
								}
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Dollar Amount: Not Matched");
							}
							//}
						}

					}
					if(!(tempPercentAmount.equalsIgnoreCase("")||tempPercentAmount.equalsIgnoreCase("Null")))  
					{				
						String[] DSC_Percent = tempPercentAmount.split("\n");
						DSC_Retail_Percent = DSC_Percent[i];
						if(DSC_Retail_Percent.equalsIgnoreCase("Null")){

						}else{
							GetReportValues.getPercent_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_Percent : "+DSC_Retail_Percent);
							System.out.println("strPercent_Value : "+GetReportValues.strPercent_Value);	
							if(DSC_Retail_Percent.equalsIgnoreCase(GetReportValues.strPercent_Value)){
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "Percent", DSC_Retail_Percent, GetReportValues.strPercent_Value, GetReportValues.parntMappingValueFinal, "Pass");
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Percent : Matched");
							}else
							{
								if(GetReportValues.Flag==true){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "Percent", DSC_Retail_Percent, GetReportValues.strPercent_Value, GetReportValues.parntMappingValueFinal, "Failed");
								}	System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Percent : Not Matched");
							}
						}
						//}
					}
					if(!(tempMindollar.equalsIgnoreCase("")||tempMindollar.equalsIgnoreCase("Null")))  
					{					
						String[] DSC_Mindollar = tempMindollar.split("\n");
						if(DSC_Mindollar[i].equals(null)||DSC_Mindollar[i].equals(" ")||DSC_Mindollar[i].equals("")){
							//DSC_Retail_MinimumDollar = "null";
						}	else	{
							DSC_Retail_MinimumDollar = DSC_Mindollar[i];
							if(DSC_Retail_MinimumDollar.equalsIgnoreCase("Null")){
								//DSC_Retail_Stepped = "";
							}	else	{
								GetReportValues.getMindollar_Value();
								System.out.println("DSC_"+subsectionProcessType_Value+"_MinimumDollar : "+DSC_Retail_MinimumDollar);
								System.out.println("strMinimumDollar_Value : "+GetReportValues.strMinimumDollar_Value);	
								if(DSC_Retail_MinimumDollar.equalsIgnoreCase(GetReportValues.strMinimumDollar_Value)){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "MinimumDollar", DSC_Retail_MinimumDollar, GetReportValues.strMinimumDollar_Value, GetReportValues.parntMappingValueFinal, "Pass");
									System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Minimum Dollar : Matched");
								}	else
								{
									if(GetReportValues.Flag==true){
										testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "MinimumDollar", DSC_Retail_MinimumDollar, GetReportValues.strMinimumDollar_Value, GetReportValues.parntMappingValueFinal, "Failed");
									}System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Minimum Dollar : Not Matched");
								}
							}
						}
					}
					
					if(PNo.equals("146"))	{
						if(!(DSC_ByPassOON.equalsIgnoreCase("")||DSC_ByPassOON.equalsIgnoreCase("Null")))  
						{
							String[] arr_DSC_ByPassOON = DSC_ByPassOON.split("\n");
							if(arr_DSC_ByPassOON[i].equals(null)||arr_DSC_ByPassOON[i].equals(" ")||arr_DSC_ByPassOON[i].equals("")){
								//DSC_Retail_MaximumDollar = "null";
							}else{
								DSC_ByPassOON = arr_DSC_ByPassOON[i];
								if(DSC_ByPassOON.equalsIgnoreCase("Null")){
									//DSC_Retail_Stepped = "";
								}else{
									GetReportValues.getByPassOON_Value();
									System.out.println("DSC_"+subsectionProcessType_Value+"_BypassOON : "+DSC_ByPassOON);
									System.out.println("strByPassOOn : "+GetReportValues.strByPassOOn);	
									if(DSC_ByPassOON.equalsIgnoreCase(GetReportValues.strByPassOOn)){
										testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "ByPassOON", DSC_ByPassOON, GetReportValues.strByPassOOn, GetReportValues.parntMappingValueFinal, "Pass");
										System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" ByPassOON : Matched");
									}	else
									{
										if(GetReportValues.Flag==true){
											testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "ByPassOON", DSC_ByPassOON, GetReportValues.strByPassOOn, GetReportValues.parntMappingValueFinal, "Failed");
											System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" ByPassOON : Not Matched");
										}
									}
								}

							}
						}
					}	else	{
						testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "ByPassOON", DSC_ByPassOON, GetReportValues.strByPassOOn, GetReportValues.parntMappingValueFinal, "Pass");
					}
					

					if(!(tempMaxdollar.equalsIgnoreCase("")||tempMaxdollar.equalsIgnoreCase("Null")))  
					{
						String[] DSC_Maxdollar = tempMaxdollar.split("\n");
						if(DSC_Maxdollar[i].equals(null)||DSC_Maxdollar[i].equals(" ")||DSC_Maxdollar[i].equals("")){
							//DSC_Retail_MaximumDollar = "null";
						}else{
							DSC_Retail_MaximumDollar = DSC_Maxdollar[i];
							if(DSC_Retail_MaximumDollar.equalsIgnoreCase("Null")){
								//DSC_Retail_Stepped = "";
							}else{
								GetReportValues.getMaxdollar_Value();
								System.out.println("DSC_"+subsectionProcessType_Value+"_MaximumDollar : "+DSC_Retail_MaximumDollar);
								System.out.println("strMaximumDollar_Value : "+GetReportValues.strMaximumDollar_Value);	
								if(DSC_Retail_MaximumDollar.equalsIgnoreCase(GetReportValues.strMaximumDollar_Value)){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "MaximumDollar", DSC_Retail_MaximumDollar, GetReportValues.strMaximumDollar_Value, GetReportValues.parntMappingValueFinal, "Pass");
									System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Maximum Dollar : Matched");
								}else
								{
									if(GetReportValues.Flag==true){
										testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "MaximumDollar", DSC_Retail_MaximumDollar, GetReportValues.strMaximumDollar_Value, GetReportValues.parntMappingValueFinal, "Failed");
									}	System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Maximum Dollar : Not Matched");
								}
							}
						}

					}

					if(!(tempCopayCalc.equalsIgnoreCase("")||tempCopayCalc.equalsIgnoreCase("Null")))  
					{
						String[] DSC_Copaycalc = tempCopayCalc.split("\n");
						DSC_Retail_CopayCalculation = DSC_Copaycalc[i];
						if(DSC_Retail_CopayCalculation.equalsIgnoreCase("Null")){
							//DSC_Retail_Stepped = "";
						}else{
							GetReportValues.getCopaycalc_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_CopayCalculation : "+DSC_Retail_CopayCalculation);
							System.out.println("CRDCopayLogic : "+GetReportValues.CRDCopayLogic);					
							if(DSC_Retail_CopayCalculation.equalsIgnoreCase(GetReportValues.CRDCopayLogic)){
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "CopayCalculation", DSC_Retail_CopayCalculation, GetReportValues.CRDCopayLogic, GetReportValues.parntMappingValueFinal, "Pass");
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Copay Calculation : Matched");
							}else
							{
								if(GetReportValues.Flag==true){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "CopayCalculation", DSC_Retail_CopayCalculation, GetReportValues.CRDCopayLogic, GetReportValues.parntMappingValueFinal, "Failed");
								}	System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Copay Calculation : Not Matched");
							}
						}
					}
					if(!(tempReverse.equalsIgnoreCase("")||tempReverse.equalsIgnoreCase("Null")))  
					{
						String[] DSC_Reverse = tempReverse.split("\n");
						DSC_Retail_Reverse = DSC_Reverse[i];
						if(DSC_Retail_Reverse.equalsIgnoreCase("Null")){
							//DSC_Retail_Stepped = "";
						}else{
							GetReportValues.getReverse_Value();
							System.out.println("DSC_"+subsectionProcessType_Value+"_Reverse : "+DSC_Retail_Reverse);
							System.out.println("strReverse : "+GetReportValues.strReverse);					
							if(DSC_Retail_Reverse.equalsIgnoreCase(GetReportValues.strReverse)){
								testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "Reverse", DSC_Retail_Reverse, GetReportValues.strReverse, GetReportValues.parntMappingValueFinal, "Pass");
								System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Reverse : Matched");
							}else
							{
								if(GetReportValues.Flag==true){
									testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, "Reverse", DSC_Retail_Reverse, GetReportValues.strReverse, GetReportValues.parntMappingValueFinal, "Failed");
								}	System.out.println(subsectionProcessType_Value+" "+DSC__DrugList +" Reverse : Not Matched");
							}
						}
					}


				}	else	{

				}

			}
			if(match==0)
			{
				testResultFunctions.set_custom_message_in_Report_Test("", PNo, LValue, T_subsectionProcessType_Value, DSC_Retail_FormularyGroup, "", "", "", "Failed-No Mapping");
			}
			match=0;
		}
		//System.out.println(GetReportValues.arrMAPID);
	}


	public static void Validate_DSC()	

	{


		for(int rowIterator=0;rowIterator<GetReportValues.row;rowIterator++)	{			
			if(GetReportValues.ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+provisionNumber+"L"+provisionLineValue))	{
				if(GetReportValues.sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRD__c"))	{
					if(GetReportValues.tenthColumnValue.get(rowIterator).toString().contains("Creates CRD"))	{
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail")){
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Retail copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										AnyDrugSpecificCopays = "Any drug specific Retail copays?";
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Retail Col Matched");
										strsubsection2 = DSC_RetailFieldValue;
									}
								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Mail copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										AnyDrugSpecificCopays = "Any drug specific Mail copays?";
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Mail Col Matched");
									}
								}
							}
						}

						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										AnyDrugSpecificCopays = "Any drug specific Specialty copays?";
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Specialty Col Matched");
									}
								}
							}
						}	
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty OON copays"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										AnyDrugSpecificCopays = "Any drug specific Specialty OON copays?";
										System.out.println("Line Value: "+provisionLineValue+" Any DSC SpecialtyOoN Col Matched");
									}

								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										AnyDrugSpecificCopays = "Any drug specific Paper copays?";
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Paper Col Matched");
									}

								}
							}
						}

						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper Out of Network copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										AnyDrugSpecificCopays = "Any drug specific Paper OON copays?";
										System.out.println("Line Value: "+provisionLineValue+" Any DSC PaperOoN Col Matched");
									}

								}
							}
						}	

						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Mail Paper OON copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										AnyDrugSpecificCopays = "Any drug specific Mail Paper OON copays?";
										System.out.println("Line Value: "+provisionLineValue+" Any DSC PaperOoN Col Matched");
									}

								}
							}
						}	


					}
				}	
			}
		}
	}

}


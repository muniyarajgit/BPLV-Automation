package com.FrameworkFunctions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.framework.frameworkParameters;
import com.keywords.ValidateProvisionTemplate;
import com.keywords.ValidateProvisionTemplate_Test;
import com.keywords.getTemplateValues_9;



public class GetReportValues_old {
	public static boolean Flag	= false;
	public static int MapCountVal = 0;
	//Copay DrugclassVal
	public static String DrugclassVal	= null;
	public static String strPlanTypePaperFieldalue	= null;

	public static String strSpecialty				= null;
	public static String strSpecialty_OON			= null;
	//		public static String strpaper_DSC				= null;
	public static String strpaperOON_DSC			= null;
	public static String strPercentRepo	 			= null;
	public static  String strmindollarreport 		= null;
	public static  String strmaxdollarreport 		= null;
	public static  String strCopayCalculationreport = null;

	public static String FilePath = frameworkParameters.FilePath;
	public static String strNumberOfTierValue 	= null;
	public static String strsubProcessValue 	= null;
	public static String srtTierType			= null;
	public static String strDollarAmountValue 	= "";
	public static String strNonFormularyAmountValueOrder = "";
	public static String strsteppedCopay 		= null;
	static Cell cell;
	public static XSSFSheet xssfSheet = null;
	static boolean retailtire		  = false;
	public static boolean ExpectedFlag;
	public static String strsubsection2	= null;
	public static String strProvisionLineValue_id	= null;
	public static boolean drugGrouplist			 = false;
	public static boolean druglist				 = false;
	public static boolean lineValue_Temp = false;
	//	DC Fields
	public static String strDC_Retail_IncExcl_DC 		= null;
	public static String strDC_Retail_IncExcl_1 		= null;
	public static String strDC_ApplyLimit_1 		= null;
	public static String strDC_Retail_DrugListorDrugGroup_1 		= null;
	public static String strDC_Retail_StartAge_1 		= null;
	public static String strDC_Retail_EndAge_1 		= null;
	public static String strDC_Gender_1 		= null;
	public static String strDC_MinDays_1 		= null;
	public static String strDC_DailyDose_1 		= null;
	public static String strDC_StartAgeType_1 		= null;
	public static String strDC_EndAgeType_1 		= null;
	public static String strDC_MaxDays_1 		= null;
	public static String strDC_MaxDaysperfill_1 		= null;
	public static String strDC_DOTTP_1 		= null;
	public static String strDC_DOTDays_1 		= null;
	public static String strDC_DOTTV_1 		= null;
	public static String strDC_QOTQty_1 		= null;
	public static String strDC_QOTTP_1 		= null;
	public static String strDC_QOTTV_1 		= null;
	public static String strDC_MaxFills_1 		= null;
	public static String strDC_MinQty_1 		= null;

	public static String ParentMapVal = null;
	//Accums DSC
	public static String strAccum_DrugSpecific_MAB                      = null;
	public static String strAccum_DrugSpecific_M                        = null;
	public static String strAccum_DrugSpecific_N                        = null;
	public static String strAccum_DrugSpecific_O                        = null;
	public static String strAccum_DrugSpecific_Y                        = null;
	public static String strAccum_DrugSpecific_DL                       = null;
	public static String strAccum_DrugSpecific_DG                       = null;
	public static String strAccum_DrugSpecific_MABAmount                = null;
	public static String strAccum_DrugSpecific_MABPeriod                = null;
	public static String strAccum_DrugSpecific_MABMet                   = null;

	public static boolean DLColorFlag= true;
	public static boolean IncExclDCColorFlag= true;
	public static boolean IncExclColorFlag= true;
	public static boolean DLALFlag= true;



	static DataFormatter formatter=new DataFormatter();
	public static String drugListValueID		= "";


	public static String druglistName				= null;	
	public static String drugGrouplistName		 = null;
	public static String drugGroupListValueID 	 = "";

	public static ArrayList<String> strFormularyIDMappingValue = new ArrayList<String>();

	public static String strDrugSpecificCopay	= null;
	public static String strFormularyGroup 		= null;
	public static String ParentMappingValue	 	= null;
	public static String strM_Value 			= null;
	public static String strN_Value				= null;
	public static String strO_Value				= null;
	public static String strY_Value				= null;
	  //addedd 4 new fields
	public static String strPreferredGeneric_Value = null;
	public static String strNonPreferredGeneric_Value = null;
	public static String strPreferredBrand_Value = null;
	public static String strNonPreferredBrand_Value =null;
	public static String strDollarAmount_Value	= null;
	public static String strPercent_Value	= null;
	public static String strMinimumDollar_Value	= null;
	public static String strMaximumDollar_Value	= null;
	public static String CRDCopayLogic			= "";
	public static String strReverse			= null;

	public static boolean steppedColorFlag= true;
	public static boolean MColorFlag= true;
	public static boolean NColorFlag= true;
	public static boolean OColorFlag= true;
	public static boolean YColorFlag= true;
	public static boolean DollarAmountColorFlag= true;
	public static boolean ReverseColorFlag= true;
	public static boolean MaxdollarColorFlag= true;
	public static boolean PercentColorFlag= true;
	public static boolean MindollarColorFlag= true;
	public static boolean CopaycalcColorFlag= true;


	public static ArrayList<String> firstColumnValue  = new ArrayList<String>();
	static ArrayList<String> secondColumnValue = new ArrayList<String>();
	public static ArrayList<String> ThirdColumnValue  = new ArrayList<String>();
	static ArrayList<String> fourthColumnValue = new ArrayList<String>();
	static ArrayList<String> fifthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> sixthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> seventhColumnValue= new ArrayList<String>();
	public static ArrayList<String> eighthColumnValue = new ArrayList<String>();
	public static ArrayList<String> ninthColumnValue  = new ArrayList<String>();
	public static ArrayList<String> tenthColumnValue  = new ArrayList<String>();
	static ArrayList<String> eleventhColumnValue  = new ArrayList<String>();
	static ArrayList<String> twelfthColumnValue = new ArrayList<String>();
	static ArrayList<String> thirteenthColumnValue =new ArrayList<String>();
	static ArrayList<String> fourteenthColumnValue = new ArrayList<String>();

	static int mappingName=0,mappingValuesName=1,lineValueID=2,provisionValue=3,lineValue=4,objectAPI=5,fieldLabel=6,fieldValue=8;
	public static int row=0;
	static int parentMapping=9;
	static int parentMapNotes=10;
	static int Create=11;
	static int Delete=12;
	static int RecordTypeId=13;
	static int rowIterator;


	public static void readReportValue(String path)	{
		File csvFile= new File(path);

		//File csvFile= new File("C:\\Automation_BPLV\\BPLV_Validation\\Report\\P9_New.csv");
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				row++;
				//strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
			int z= strPosition.length;
			//System.out.println(z);
				firstColumnValue.add(strPosition[mappingName]);
				secondColumnValue.add(strPosition[mappingValuesName]);
				ThirdColumnValue.add(strPosition[lineValueID]);
				fourthColumnValue.add(strPosition[provisionValue]);
				fifthColumnValue.add(strPosition[lineValue]);
				sixthColumnValue.add(strPosition[objectAPI]);
				seventhColumnValue.add(strPosition[fieldLabel]);
				eighthColumnValue.add(strPosition[fieldValue]);
				ninthColumnValue.add(strPosition[parentMapping]);
				tenthColumnValue.add(strPosition[parentMapNotes]);
				eleventhColumnValue.add(strPosition[Create]);
				twelfthColumnValue.add(strPosition[Delete]);
				thirteenthColumnValue.add(strPosition[RecordTypeId]);
				
				}	

		}catch 	(Exception e)	{
			e.printStackTrace();
		}



	}
	public static void LineValueCheck(String P, String L){
		int PvLn = 0;
		for(rowIterator=0;rowIterator<row;rowIterator++)	{
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+P+"L"+L))	{
				PvLn++;
			}
		}
		if(PvLn==0){
			testResultFunctions.set_custom_message_in_Report_Test("", ValidateProvisionTemplate_Test.provisionNumber, ValidateProvisionTemplate_Test.provisionLineValue, "", "", "", "", "", "Failed - Mapping LineValue not available in the Salesforce report");		
		}
	}
	// To get Parent Mapping Value
	static int formularyIteraor;
	public static ArrayList arr_DC_MAPID = new ArrayList();
	public static void MapValDC(String P, String L, String Sub_Sec){
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+P+"L"+L))	{
			if(Sub_Sec.contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")||tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))){
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Related Drug Coverage"))	{
						arr_DC_MAPID.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}				
				else if(Sub_Sec.contains("DC_Mail") && (thirteenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")||thirteenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail"))){
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Related Drug Coverage"))	{
						arr_DC_MAPID.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
			}

		}
		System.out.println(arr_DC_MAPID);	
	}
	public static void FailedReportValues_DC(String Sub_Sec){
		//System.out.println(arrMAPID);
		for(int i=0;i<arr_DC_MAPID.size();i++){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
				if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase((String) arr_DC_MAPID.get(i))){
					if(seventhColumnValue.get(formularyIteraor).toString().equals("Related Drug Coverage") ){}
					else{
						testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Failed");
					}
				}
			}
		}
		arr_DC_MAPID.clear();
	}
	public static String parntMappingValueFinal="";
	public static void WOD()	{
		DrugclassVal = "";
		parntMappingValueFinal = "";
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	
		{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Class"))	{
					DrugclassVal = eighthColumnValue.get(formularyIteraor).toString(); 
					parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
					break;

				}
			}
		}
	}



	public static void getparentmapping()	{
		int mIterator = 0;
		//		int formularyIteraor;
		parntMappingValueFinal="";
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
				if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")||tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))){
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugListValueID))	{
							System.out.println("Test Retail DL");
							parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}else{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugGroupListValueID))	{
								System.out.println(tenthColumnValue.get(formularyIteraor).toString());
								System.out.println("Test Retail DG");
								parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
								break;
							}
						}
					}
				}
				else if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL")||tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail"))){
					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugListValueID))	{
							System.out.println("Test Mail DL");
							parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}else{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").contains(drugGroupListValueID))	{
								System.out.println("Test Mail DG");
								parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();
								break;
							}
						}
					}
				}

			}
		}
	}
	public static void getInExDCField_Value()	{
		strDC_Retail_IncExcl_DC = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion Exclusion Drug Class"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_DC  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getInExField_Value()	{
		strDC_Retail_IncExcl_1 = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Inclusion/Exclusion"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_IncExcl_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getApplylimit_Value()	{
		strDC_ApplyLimit_1 = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Apply Limitations"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_ApplyLimit_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getStartAge_Value()	{
		strDC_Retail_StartAge_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_StartAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndAge_Value()	{
		strDC_Retail_EndAge_1  ="";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Retail_EndAge_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getGender_Value()	{
		strDC_Gender_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Gender"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_Gender_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMindays_Value()	{
		strDC_MinDays_1  ="";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMinQty_Value()	{
		strDC_MinQty_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MinQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDailyDose_Value()	{
		strDC_DailyDose_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Daily Dose"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DailyDose_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getstartagetype_Value()	{
		strDC_StartAgeType_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Start Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_StartAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getEndagetype_Value()	{
		strDC_EndAgeType_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("End Age Type"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_EndAgeType_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDays_Value()	{
		strDC_MaxDays_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxFills_Value()	{
		strDC_MaxFills_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Fills"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxFills_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getMaxDaysperfill_Value()	{
		strDC_MaxDaysperfill_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Max Days per Fill"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_MaxDaysperfill_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTP_Value()	{
		strDC_DOTTP_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTDays_Value()	{
		strDC_DOTDays_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: # of Days"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTDays_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getDOTTV_Value()	{
		strDC_DOTTV_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Days over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_DOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTQty_Value()	{
		strDC_QOTQty_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Quantity"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTQty_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTP_Value()	{
		strDC_QOTTP_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity Over Time: Time Period"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTP_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getQOTTV_Value()	{
		strDC_QOTTV_1  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail DCDL")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Coverage Retail"))) || (ValidateProvisionTemplate_Test.subsectionProcessType_Value.toString().contains("DC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail DCDL"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug CoverageMail")) ))	{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Quantity over Time: Time Value"))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
								strDC_QOTTV_1  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getAccumulationsDrugSpecific(){
		for(rowIterator=0;rowIterator<row;rowIterator++){
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue)){
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Accumulations__c")){
					if(tenthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Creates Accumulation - Individual All")){

						if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Are there any drug specific MAB?")){
							if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MAB)){
								strAccum_DrugSpecific_MAB = eighthColumnValue.get(rowIterator).toString();
							}
						}      
					}
				}      

				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("AccumulationSpecificDrug__c")){

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("M")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_M)){
							strAccum_DrugSpecific_M = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("N")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_N)){
							strAccum_DrugSpecific_N = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("O")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_O)){
							strAccum_DrugSpecific_O = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Y")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_Y)){
							strAccum_DrugSpecific_Y = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Amount")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABAmount)){
							strAccum_DrugSpecific_MABAmount = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("MAB Period")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABPeriod)){
							strAccum_DrugSpecific_MABPeriod = eighthColumnValue.get(rowIterator).toString();
						}
					}

					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("What happens when MAB is met?")){
						if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.Accum_DrugSpecific_MABMet)){
							strAccum_DrugSpecific_MABMet = eighthColumnValue.get(rowIterator).toString();
						}
					}


					if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Drug List")){
						if(eighthColumnValue.get(rowIterator).toString().contains(drugListValueID)){

							strAccum_DrugSpecific_DL = eighthColumnValue.get(rowIterator).toString();
						}
					}
				}
			}
		}

	}
	public static ArrayList arrFRMID = new ArrayList();
	public static ArrayList arrMAPID = new ArrayList();

	public static void getAllMapId_DSC(String Pr,String Lv,String Sub_Sec)	{
		arrMAPID.clear(); 
		if(Sub_Sec.equalsIgnoreCase("DSC_Retail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						/*if((Sub_Sec.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());*/
						if((Sub_Sec.equalsIgnoreCase("DSC_Retail") && ((thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1")) || (thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1AAG")))&&(eleventhColumnValue.get(formularyIteraor).equals("1")))){
							arrMAPID.add(secondColumnValue.get(formularyIteraor).toString());
							System.out.println(arrMAPID);
							}
						}
					}
				}			
			}	
		

		if(Sub_Sec.equalsIgnoreCase("DSC_Mail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						if((Sub_Sec.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Maill Drug Specific Copay  ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
							}
						}
					}
				}			
			}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_SpecialtyTiers")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						if((Sub_Sec.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
							}
						}
					}
				}			
			}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						if((Sub_Sec.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON Drug Specific  Copay  "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
							}
						}
					}
				}			
			}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_PaperTiers")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						if((Sub_Sec.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
							}
						}
					}
				}			
			}	
		}
		if(Sub_Sec.equalsIgnoreCase("DSC_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						if((Sub_Sec.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
							}
						}
					}
				}			
			}	
		}

		if(Sub_Sec.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug_Specific_Copay__c")){
						if((Sub_Sec.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific  Copay "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific  Copay  ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network drug specific Copay Tier1 ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network"))))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								arrMAPID.add(ninthColumnValue.get(formularyIteraor).toString());
							}
						}
					}
				}			
			}	
		}



	}
	public static void FailedReportValues(String Sub_Sec){
		//System.out.println(arrMAPID);
		for(int i=0;i<arrMAPID.size();i++){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
				if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase((String) arrMAPID.get(i))){
					if(seventhColumnValue.get(formularyIteraor).toString().equals("CRD ID") ){}
					else{
						testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Failed");
					}
				}
			}
		}
	}


	public static void getFormularyId()	{

		strFormularyIDMappingValue.clear();
		int mIterator = 0;
		//		int formularyIteraor;
		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail")){
			Loop:
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
						//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){
						
						//ArrayList arrMAPID1 = new ArrayList();
						//arrMAPID1 = arrMAPID;
						//System.out.println("Size:"+arrMAPID.size());
						for(int m=0;m<arrMAPID.size();m++) {
							String s = (String) arrMAPID.get(m);
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(s))	{
								//System.out.println("TEST!");
						//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && ((thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1")) || (thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1AAG")))&&(eleventhColumnValue.get(formularyIteraor).equals("1")))){
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								System.out.println("TEST1");
								System.out.println("Report FRM:"+eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", ""));
								System.out.println("BT FRM:"+ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", ""));
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									System.out.println("TEST2");
									strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
									//strFormularyIDMappingValue.add(secondColumnValue.get(formularyIteraor).toString());
								//	arrFRMID.add(secondColumnValue.get(formularyIteraor).toString());
									arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
									System.out.println(arrFRMID);
									System.out.println("TEST");
									System.out.println(ninthColumnValue.get(formularyIteraor).toString());
									strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
								}
							}
								}
							}
					
				
		
						}
		
					if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (formularyIteraor==row) )	{
						break Loop;
					}
	}



		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().startsWith("Creates Drug Specific Copay Mail P"))|| (tenthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Creates  Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail drug specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Drug Specific Copay ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail ")))){
 						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{   
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers"))	{
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork")){

			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") )	{

			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}

		if(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific  Copay ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network drug specific Copay Tier1 "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network"))))){
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
							if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
								strFormularyIDMappingValue.add(ninthColumnValue.get(formularyIteraor).toString());
								arrFRMID.add(ninthColumnValue.get(formularyIteraor).toString());
								//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
								strDrugSpecificCopay = eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "");
							}
						}
					}
				}
			}
		}
		}
		





	}
	//
	public static ArrayList arr_DrugCount = new ArrayList();
	public static void MultipleDruglist(){
		ArrayList test = new ArrayList();
		arr_DrugCount.clear();
		test.clear();
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
			if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
				/*if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){

					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
							arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());		*/
				if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && ((thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1")) || (thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1AAG")))&&(eleventhColumnValue.get(formularyIteraor).equals("1")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){

					if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
						if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
							arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
						}
					}
					else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
					{
						if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
							arr_DrugCount.add(secondColumnValue.get(formularyIteraor).toString());
						}
					}

				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Maill")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
				else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){				if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
				{
					if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
						arr_DrugCount.add(ninthColumnValue.get(formularyIteraor).toString());
					}
				}
				}
			}
		}
		System.out.println("arr_DrugCount :" + arr_DrugCount.size());
	}


	public static void MultipleDrugMap(){
		Flag = false;
		parntMappingValueFinal="";
		Loop3:
			for(int i=0;i<arr_DrugCount.size();i++){
				System.out.println(arr_DrugCount.get(i));			
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
						if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){				
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}
						}

						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Maill")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")))){					if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									//parntMappingValueFinal = arr_DrugCount.get(i).toString();




									parntMappingValueFinal = arr_DrugCount.get(i).toString();

									getStepped_Value();getM_Value();getN_Value();
									parntMappingValueFinal="";
									if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
										if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
											if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
												System.out.println("Final Mapping Val:"+parntMappingValueFinal);
												parntMappingValueFinal = arr_DrugCount.get(i).toString();
												Flag = true;
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
												if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
												}else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
												}
												if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
												}
												else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
												}
												break Loop3;
											}else{
												continue Loop3;
											}

										}else{
											continue Loop3;
										}
									}else{
										continue Loop3;
									}
								}
							}
						}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty P"))))){					if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									//parntMappingValueFinal = arr_DrugCount.get(i).toString();




									parntMappingValueFinal = arr_DrugCount.get(i).toString();

									getStepped_Value();getM_Value();getN_Value();
									parntMappingValueFinal="";
									if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
										if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
											if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
												System.out.println("Final Mapping Val:"+parntMappingValueFinal);
												parntMappingValueFinal = arr_DrugCount.get(i).toString();
												Flag = true;
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
												if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
												}else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
												}
												if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
												}
												else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
												}
												break Loop3;
											}else{
												continue Loop3;
											}

										}else{
											continue Loop3;
										}
									}else{
										continue Loop3;
									}
								}
							}
						}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))){					if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
								if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
									//parntMappingValueFinal = arr_DrugCount.get(i).toString();




									parntMappingValueFinal = arr_DrugCount.get(i).toString();

									getStepped_Value();getM_Value();getN_Value();
									parntMappingValueFinal="";
									if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
										if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
											if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
												System.out.println("Final Mapping Val:"+parntMappingValueFinal);
												parntMappingValueFinal = arr_DrugCount.get(i).toString();
												Flag = true;
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
												if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
												}else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
												}
												if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
												}
												else
												{
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
												}
												break Loop3;
											}else{
												continue Loop3;
											}

										}else{
											continue Loop3;
										}
									}else{
										continue Loop3;
									}
								}
							}
						}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper Copay"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper P"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper P"))))){
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}
						}
						//
						//
						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){  
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}


						}

						else if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))){  
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arr_DrugCount.get(i).toString()))	{
								if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Formulary Group"))	{
									if(eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", "").equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", "")))	{
										//parntMappingValueFinal = arr_DrugCount.get(i).toString();




										parntMappingValueFinal = arr_DrugCount.get(i).toString();

										getStepped_Value();getM_Value();getN_Value();
										parntMappingValueFinal="";
										if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
											if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
												if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
													System.out.println("Final Mapping Val:"+parntMappingValueFinal);
													parntMappingValueFinal = arr_DrugCount.get(i).toString();
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													if(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().equalsIgnoreCase(ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim()))
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													}else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Failed");														
													}
													if(ValidateProvisionTemplate.tempDLSel.equalsIgnoreCase("Drug Group")){
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
													}
													else
													{
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
														testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													}
													break Loop3;
												}else{
													continue Loop3;
												}

											}else{
												continue Loop3;
											}
										}else{
											continue Loop3;
										}
									}
								}
							}


						}
						//

					}
				}
			}
	}

	public static void DrugList_DrugGroup(){
		for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
			if(parntMappingValueFinal.equals(ninthColumnValue.get(formularyIteraor).toString()))
			{

			}
		}
	}

	//

	static int drugIterator;
	static int parentIterator=0;
	public static String strmapValue="";
	//static String parntMappingValueFinal="";	

	public static void getParentMappingValue()	{

		Flag = false;
		parntMappingValueFinal="";

		if(arrFRMID.size()!=0)	{ //if(arrFRMID.size()!=0)
			Loop:
				for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{					
					if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
						//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Specialty OON Drug Specific Copay") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Paper Drug Specific Copay") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Paper OON Drug Specific Copay") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network")))) || ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Mail Paper out of network") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific  Copay  "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network drug specific Copay Tier1 "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific  Copay ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay  "))    ) ){
							//||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network")
						//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && ((thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1")) || (thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1AAG")) )&&(eleventhColumnValue.get(formularyIteraor).equals("1")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug Specific Copay")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Specialty OON Drug Specific Copay") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Paper Drug Specific Copay") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Paper OON Drug Specific Copay") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network")))) || ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("Creates Mail Paper out of network") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific  Copay  "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network drug specific Copay Tier1 "))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific  Copay ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail Paper Out of Network Drug Specific Copay  "))    ) ){	
						for(int m=0;m<arrMAPID.size();m++) {
							String s = (String) arrMAPID.get(m);
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(s)) {
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug Group"))	{
								System.out.println("Report FRM:"+eighthColumnValue.get(formularyIteraor).toString().trim().replaceAll("\\s+", ""));
								System.out.println("BT FRM:"+ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim().replaceAll("\\s+", ""));
							}
								if(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID)){ //||(eighthColumnValue.get(formularyIteraor).toString().contains(drugGroupListValueID))
									parntMappingValueFinal = secondColumnValue.get(formularyIteraor).toString();

									Loop2:
										
									//	while(arrFRMID.size()!=0){
											//int i =0;
										ArrayList arrFRMID1 = new ArrayList();
									arrFRMID1 = arrMAPID;
									System.out.println("Size:"+arrMAPID.size());
										for(int i=0;arrFRMID1.size()!=0;i++)	{

											if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arrFRMID.get(i).toString()))	{
												strmapValue = ninthColumnValue.get(formularyIteraor).toString();
											//if(secondColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arrFRMID.get(i).toString()))	{
												//strmapValue = secondColumnValue.get(formularyIteraor).toString();
												parntMappingValueFinal = arrFRMID.get(i).toString();
												
												if(arrFRMID.size()>1)	{
													arrFRMID.remove(i).toString();
												}
											}
														
												//										arrFRMID.remove(i);

												if(ValidateProvisionTemplate.provisionNumber.equals("146")){
													getStepped_Value();getM_Value();getN_Value();

													if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
														if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
															if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
																System.out.println("Values mathced");
																Flag = true;														
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Pass");
																/*if(arrFRMID.size()>1)	{
															arrFRMID.remove(i).toString();
															}*/
																break Loop;

															}else	{
																i--;
																parntMappingValueFinal = "";
																formularyIteraor= 0;
																continue Loop;
															}
														}else	{
															i--;
															parntMappingValueFinal = "";
															formularyIteraor= 0;
															continue Loop;
														}
													}	else	{
														i--;
														parntMappingValueFinal = "";
														formularyIteraor= 0;
														continue Loop;
													}
												}
												break Loop;
										}
								}

											else{

												parntMappingValueFinal = "";
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, GetReportValues.eighthColumnValue.get(rowIterator).toString(), parntMappingValueFinal , "Fail");
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Fail");
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug Group", "Drug Group", parntMappingValueFinal, "Fail");
												testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGrouValue", drugGroupListValueID, drugGroupListValueID, parntMappingValueFinal, "Fail");


											}
										}							
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Drug List"))				
							{
								if(eighthColumnValue.get(formularyIteraor).toString().contains(drugListValueID) ){
									strmapValue = ninthColumnValue.get(formularyIteraor).toString();
									//strmapValue = secondColumnValue.get(formularyIteraor).toString();
									
									//parntMappingValueFinal = ninthColumnValue.get(formularyIteraor).toString();	
									parntMappingValueFinal = secondColumnValue.get(formularyIteraor).toString();	
									int size = arrFRMID.size();
									int Drugsize = ValidateProvisionTemplate.CountOfDrugList;
									//ArrayList arrFRMID_Test = new ArrayList();

									Loop2:
										
									//	for(int i=0;arrFRMID.size()!=0;i++)	{
										for(int i=0;i<arrFRMID.size();i++)	{
										//	System.out.println(arrFRMID);
											//	if(!arrFRMID.contains(arrFRMID.get(i).toString())){
											//System.out.println(arrFRMID.size());
											//System.out.println(i);
											//System.out.println("TEST");
											if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arrFRMID.get(i).toString()))	{
											//if(secondColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(arrFRMID.get(i).toString()))	{
												parntMappingValueFinal = arrFRMID.get(i).toString();
												System.out.println("TEST!!!"+parntMappingValueFinal);
												//System.out.println(i);
												if(arrFRMID.size()>1)	{
													arrFRMID.remove(i).toString();
													System.out.println(arrFRMID.size());
												}
												//										arrFRMID.remove(i);
												if(ValidateProvisionTemplate.provisionNumber.equals("146")){
													getStepped_Value();getM_Value();getN_Value();
													if(ValidateProvisionTemplate.DSC_Retail_Stepped.equalsIgnoreCase(strsteppedCopay))	{
														if(ValidateProvisionTemplate.DSC_Retail_M.equalsIgnoreCase(strM_Value))	{
															if(ValidateProvisionTemplate.DSC_Retail_N.equalsIgnoreCase(strN_Value))	{
																System.out.println("Values mathced");
																Flag = true;
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
																testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", ValidateProvisionTemplate.DSC__DrugList.trim(), druglistName, parntMappingValueFinal, "Pass");
																/*	if(arrFRMID.size()>1)	{
															arrFRMID.remove(i).toString();
														}*/
																//i--;
																//arrFRMID_Test.add(parntMappingValueFinal);
																break Loop;

															}else {
																i--;
																parntMappingValueFinal = "";
																formularyIteraor= 0;
																continue Loop;

															}
														}else {
															i--;
															parntMappingValueFinal = "";
															formularyIteraor= 0;
															continue Loop;
														}
													}	else {
														i--;	
														parntMappingValueFinal = "";
														formularyIteraor= 0;
														continue Loop;
													}


												}
												else
												{
													System.out.println("Values mathced");
													Flag = true;
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, ValidateProvisionTemplate.AnyDrugSpecificCopays, ValidateProvisionTemplate.DSC_RetailFieldValue, ValidateProvisionTemplate.DSC_RetailFieldValue, parntMappingValueFinal , "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "Formulary Group",ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), ValidateProvisionTemplate.DSC_Retail_FormularyGroup.trim(), parntMappingValueFinal , "Pass");														
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugList/DrugGroup", "Drug List", "Drug List", parntMappingValueFinal, "Pass");
													testResultFunctions.set_custom_message_in_Report_Test("",ValidateProvisionTemplate.provisionNumber, ValidateProvisionTemplate.provisionLineValue, ValidateProvisionTemplate.subsectionProcessType_Value, "DrugGroupValue/DrugList Value", drugListValueID, drugListValueID, parntMappingValueFinal, "Pass");
													/*if(arrFRMID.size()>1)	{
													arrFRMID.remove(i).toString();
												}*/
													//i--;

													break Loop;
												}
											}

											else{
												parntMappingValueFinal = "";
											}

										}
								}


							}



						}
					}

				}
		

	

	public static void getStepped_Value()	{

		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strsteppedCopay  = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{

					{
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Stepped Copay"))	{

							//if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{

								strsteppedCopay  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getM_Value()	{


		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strM_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("M"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							//System.out.println(parntMappingValueFinal);
							strM_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}
	public static void getN_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strN_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{					
					//System.out.println("TEST!!! 1");
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))))) 
					{
						//System.out.println("TEST!!! 2");
						if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("N"))	{
							//System.out.println("TEST!!! 3");
							//System.out.println(parntMappingValueFinal);
							//System.out.println(ninthColumnValue.get(formularyIteraor).toString());
							if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{								
								//System.out.println("TEST!!! 4");
								strN_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
								break;
							}
						}
					}
				}
			}
	}
	public static void getO_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strO_Value = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("O"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strO_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							break;	
						}
					}
					}
				}
			}
	}
	public static void getY_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strY_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strY_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	/*public static void getPreferredGeneric_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strY_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strY_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getNonPreferredGeneric_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strY_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strY_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getPreferredBrand_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strY_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strY_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getNonPreferredBrand_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strY_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Y"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strY_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}*/
	public static void getDollarAmount_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strDollarAmount_Value = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strDollarAmount_Value  = eighthColumnValue.get(formularyIteraor).toString();
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getPercent_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strPercent_Value ="";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//	if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strPercent_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getMindollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strMinimumDollar_Value  = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strMinimumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString();
							break;
						}
					}
					}
				}
			}
	}
	public static void getMaxdollar_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strMaximumDollar_Value  = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strMaximumDollar_Value  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}

	public static String strByPassOOn = "";
	public static void getByPassOON_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strByPassOOn  = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{

					{	if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Bypass OON Penalty"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strByPassOOn  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}


	public static void getCopaycalc_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		CRDCopayLogic  ="";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							CRDCopayLogic  = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}
	public static void getReverse_Value()	{
		String strFormularyId = "";
		boolean parent = false;
		int index =0;
		int forIter =0;
		strReverse = "";
		ParentMapVal = "";
		Loop1 :
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate.provisionNumber+"L"+ValidateProvisionTemplate.provisionLineValue))	{
					//if((ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Retail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Retail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Retail")))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Mail")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Mail"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Mail"))) ||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Specialty")) ||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Drug")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty DSC"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork") &&((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Speciality OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Specialty Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC SpecialtyOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Specialty Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Specialty Out of Network"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Copay")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper"))||(tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper DSC")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Drug"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper"))))||(ValidateProvisionTemplate.subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork") && ((tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates  Paper Out of Network")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper OON")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper out of network ")) || (tenthColumnValue.get(formularyIteraor).toString().contains("Creates PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates DSC PaperOON"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay - Paper Out of Network"))|| (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Drug Specific Copay Paper Out of Network"))))){
					{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Reverse"))	{
						if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase(parntMappingValueFinal))	{
							strReverse = eighthColumnValue.get(formularyIteraor).toString(); 
							ParentMapVal = ninthColumnValue.get(formularyIteraor).toString(); 
							break;
						}
					}
					}
				}
			}
	}
	//---------
	public static void findDrugGroupName_DC()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.strDrugGroup);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> drugGroupID  = new ArrayList<String>();
		ArrayList<String> drugGroupnameValue = new ArrayList<String>();
		ArrayList<String> drugGroupName = new ArrayList<String>();
		drugGroupID.clear();
		drugGroupnameValue.clear();
		drugGroupName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				drugGroupID.add(strPosition[1]);
				drugGroupnameValue.add(strPosition[2]);
				drugGroupName.add(strPosition[0]);
			}
			for(rowIterator = 0;rowIterator<drugGroupID.size();rowIterator++)	{
				System.out.println(ValidateProvisionTemplate_Test.DSC__DrugList);
				//System.out.println(drugGroupnameValue.get(rowIterator).toString());
				/*if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equals("DCA-0000705"))
				{
					System.out.println(drugGroupnameValue.get(rowIterator).toString());
				} *///equalsIgnoreCase(ValidateProvisionTemplate_Test.DSC__DrugList.trim()) //drugGroupnameValue.get(rowIterator).toString()
				//drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1)
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equalsIgnoreCase(ValidateProvisionTemplate_Test.DSC__DrugList.trim()))	{					
					drugGrouplistName = drugGroupName.get(rowIterator).toString();
					drugGroupListValueID = drugGroupID.get(rowIterator).toString().substring(1,drugGroupID.get(rowIterator).toString().length()-1);
					System.out.println(drugGroupListValueID);
					System.out.println("drugGroupListValueID length : " + drugGroupListValueID.length());
					if(drugGroupListValueID.length()>15){
						drugGroupListValueID = drugGroupListValueID.substring(0,15);
						System.out.println(drugGroupListValueID);
					}
					break;
				}
				else
				{
					drugGroupListValueID = "";
				}

			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}
	public static void findDrugGroupName()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.strDrugGroup);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> drugGroupID  = new ArrayList<String>();
		ArrayList<String> drugGroupnameValue = new ArrayList<String>();
		ArrayList<String> drugGroupName = new ArrayList<String>();
		drugGroupID.clear();
		drugGroupnameValue.clear();
		drugGroupName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				drugGroupID.add(strPosition[1]);
				drugGroupnameValue.add(strPosition[2]);
				drugGroupName.add(strPosition[0]);
			}
			for(rowIterator = 0;rowIterator<drugGroupID.size();rowIterator++)	{
				//System.out.println(ValidateProvisionTemplate.DSC__DrugList);
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equals("DCA-0000705"))
				{
					System.out.println(drugGroupnameValue.get(rowIterator).toString());
				} //equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()) //drugGroupnameValue.get(rowIterator).toString()
				//drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1)
				if(drugGroupnameValue.get(rowIterator).toString().substring(1,drugGroupnameValue.get(rowIterator).toString().length()-1).equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()))	{					
					drugGrouplistName = drugGroupName.get(rowIterator).toString();
					drugGroupListValueID = drugGroupID.get(rowIterator).toString().substring(1,drugGroupID.get(rowIterator).toString().length()-1);
					System.out.println(drugGroupListValueID);
					System.out.println("drugGroupListValueID length : " + drugGroupListValueID.length());
					if(drugGroupListValueID.length()>15){
						drugGroupListValueID = drugGroupListValueID.substring(0,15);
						//	System.out.println(drugGroupListValueID);
					}
					break;
				}
				else
				{
					drugGroupListValueID = "";
				}

			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}

	public static void findDrugList_DC()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.drugListPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> idValue  = new ArrayList<String>();
		ArrayList<String> nameValue = new ArrayList<String>();
		ArrayList<String> drugName = new ArrayList<String>();
		idValue.clear();
		nameValue.clear();
		drugName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				idValue.add(strPosition[0]);
				nameValue.add(strPosition[1]);
				drugName.add(strPosition[2]);
			}
			//			System.out.println("ValidateProvisionTemplate_Test.DSC__DrugList.trim() : " + ValidateProvisionTemplate_Test.DSC__DrugList.trim());
			for(rowIterator = 0;rowIterator<idValue.size();rowIterator++)	{
				if(nameValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DSC__DrugList.trim()))	{
					druglistName = drugName.get(rowIterator).toString();
					drugListValueID = idValue.get(rowIterator).toString();
					System.out.println(druglistName+" "+drugListValueID);
					//drugListValueID = drugListValueID.substring(0,15);
					break;
					//					System.out.println("Drug List value is matched");
				}
				else
				{
					drugListValueID = "";
				}
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}


	public static void findDrugList()	{
		drugGroupListValueID = "null";
		drugListValueID = "null";
		int rowIterator = 0;
		File drugFile= new File(frameworkParameters.drugListPath);
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] strPosition = null;
		ArrayList<String> idValue  = new ArrayList<String>();
		ArrayList<String> nameValue = new ArrayList<String>();
		ArrayList<String> drugName = new ArrayList<String>();
		idValue.clear();
		nameValue.clear();
		drugName.clear();
		try {
			br = new BufferedReader(new FileReader(drugFile));
			while ((line = br.readLine()) != null) {
				strPosition = line.split(cvsSplitBy);
				strPosition = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
				idValue.add(strPosition[0]);
				nameValue.add(strPosition[1]);
//				drugName.add(strPosition[2]);
			}
			//			System.out.println("ValidateProvisionTemplate.DSC__DrugList.trim() : " + ValidateProvisionTemplate.DSC__DrugList.trim());
 			for(rowIterator = 0;rowIterator<idValue.size();rowIterator++)	{
				if(nameValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate.DSC__DrugList.trim()))	{
					druglistName = nameValue.get(rowIterator).toString();
					drugListValueID = idValue.get(rowIterator).toString();
					System.out.println(druglistName+" "+drugListValueID);
					//drugListValueID = drugListValueID.substring(0,15);
					break;
					//					System.out.println("Drug List value is matched");
				}
				else
				{
					drugListValueID = "";
				}
			}
		}	catch	(Exception e)	{
			e.printStackTrace();
		}
	}

	//

	public static ArrayList arrMAPID_Copay = new ArrayList();

	public static void getAllMapId_Copay(String Pr,String Lv,String Sub_Sec)	{
		arrMAPID_Copay.clear();
		if(Sub_Sec.equalsIgnoreCase("Retail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay_Tier__c"))	{
						if(Sub_Sec.equalsIgnoreCase("Retail") && (thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1") || thirteenthColumnValue.get(formularyIteraor).toString().contains("01250000000UHo1AAG"))&&(eleventhColumnValue.get(formularyIteraor).equals("1")))	{
							{
								//if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier"))	{
								if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
							
							//else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier type")){
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
							
							//else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
							
							//else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}

							
							//else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
							
							//else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}

							
						//	else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
							
							//else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
							
							//else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Non Formulary String"))	{
								else if(!arrMAPID_Copay.contains(secondColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(secondColumnValue.get(formularyIteraor).toString());
								}
							}
							}
						}
					}
				}			
			}	
		
		if(Sub_Sec.equalsIgnoreCase("Paper")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay_Tier__c"))	{
						if(Sub_Sec.equalsIgnoreCase("Paper") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper") || tenthColumnValue.get(formularyIteraor).toString().contains("Creates paper") || tenthColumnValue.get(formularyIteraor).toString().contains("creates paper")|| tenthColumnValue.get(formularyIteraor).toString().contains("creates Paper")))	{
							{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier type")){
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							}
						}
					}
				}			
			}	
		}

		if(Sub_Sec.equalsIgnoreCase("Mail")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					//System.out.println("P"+Pr+"L"+Lv);
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay_Tier__c"))	{
						//System.out.println("Test1");
						//if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Mail")||tenthColumnValue.get(rowIterator).toString().contains("Mail Copay")))	{

						//if(Sub_Sec.equalsIgnoreCase("Mail") && (tenthColumnValue.get(formularyIteraor).toString().contains("Creates Mail")||tenthColumnValue.get(formularyIteraor).toString().contains("Mail Copay")||tenthColumnValue.get(formularyIteraor).toString().contains("")||tenthColumnValue.get(formularyIteraor).toString()==null))	{
						//System.out.println("Test2");
						{
							if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier type")){
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							//}
						}
					}
				}			
			}	
		}
		if(Sub_Sec.equalsIgnoreCase("Paper Out of Network")){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++)	{
				if(ThirdColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("P"+Pr+"L"+Lv))	{
					if(sixthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay_Tier__c"))	{
						if(Sub_Sec.equalsIgnoreCase("Paper Out of Network") && tenthColumnValue.get(formularyIteraor).toString().contains("Creates Paper Out Of Network"))	{

							{if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Tier type")){
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Percent"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}

							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							else if(seventhColumnValue.get(formularyIteraor).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(!arrMAPID_Copay.contains(ninthColumnValue.get(formularyIteraor).toString())){
									arrMAPID_Copay.add(ninthColumnValue.get(formularyIteraor).toString());
								}
							}
							}
						}
					}
				}			
			}	
		}
		MapCountVal = arrMAPID_Copay.size();
	}
	public static void FailedReportValues_Copay(String Sub_Sec){
		//System.out.println(arrMAPID);
		for(int i=0;i<arrMAPID_Copay.size();i++){
			for(formularyIteraor= 0; formularyIteraor<row;formularyIteraor++){
				//if(ninthColumnValue.get(formularyIteraor).toString().equalsIgnoreCase((String) arrMAPID_Copay.get(i))){
					if(secondColumnValue.get(formularyIteraor).toString().equalsIgnoreCase((String) arrMAPID_Copay.get(i))){
					if(seventhColumnValue.get(formularyIteraor).toString().equals("CRD") ){}
					else{
						testResultFunctions.set_custom_message_in_Report_Test("", fourthColumnValue.get(formularyIteraor).toString(), fifthColumnValue.get(formularyIteraor).toString(), Sub_Sec, seventhColumnValue.get(formularyIteraor).toString(), "", eighthColumnValue.get(formularyIteraor).toString(), ninthColumnValue.get(formularyIteraor).toString(), "Fail");
					}
				}
			}
		}
	}




	public static void getCopayValues()

	{
		ParentMapVal = "";
		strNumberOfTierValue ="";
		srtTierType = "";
		CRDCopayLogic ="";
		strDollarAmountValue = "";
		strPercentRepo = "";
		strmindollarreport = "";
		strmaxdollarreport = "";
		strCopayCalculationreport = "";
		strNonFormularyAmountValueOrder = "";
		/*
		for(rowIterator=0;rowIterator<row;rowIterator++){
			if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
				if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay_Tier__c"))	{
					if((ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Mail")||tenthColumnValue.get(rowIterator).toString().contains("Mail Copay")))
							&&(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier") && eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))
							&&(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))

							)	{

			}
		}*/

		int MapCount =ValidateProvisionTemplate_Test.CountVal; 

		if(MapCount == 0 || ValidateProvisionTemplate_Test.FailCheck.contains("Fail")) 
		{


			for(rowIterator=0;rowIterator<row;rowIterator++)	{
				if(ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+ValidateProvisionTemplate_Test.provisionNumber+"L"+ValidateProvisionTemplate_Test.provisionLineValue))	{
					if(sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay_Tier__c"))	{
						if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Retail") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Retail") || tenthColumnValue.get(rowIterator).toString().contains("creates retail")||tenthColumnValue.get(rowIterator).toString().contains("retail copay")))	{
							//if(tenthColumnValue.get(rowIterator).toString().contains("Creates Retail copay ")|| tenthColumnValue.get(rowIterator).toString().contains("Creates Mail Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper OON"))	{
							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										//if(tenthColumnValue.get(rowIterator).toString().contains("Creates Retail"))
										//{
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//arrMAPID_Copay.remove(ParentMapVal);
										//}
										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
										if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
										CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										//if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
										strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
										strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
										strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
										strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
									//if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
									strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
									ParentMapVal = "";
									ParentMapVal = ninthColumnValue.get(rowIterator).toString();
									//}
								}
							}

						}	
						if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Mail") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Mail")||tenthColumnValue.get(rowIterator).toString().contains("Mail Copay")))	{
							//if(tenthColumnValue.get(rowIterator).toString().contains("Creates Retail copay ")|| tenthColumnValue.get(rowIterator).toString().contains("Creates Mail Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper OON"))	{


							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){								
									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
										//if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();

										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){
										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");

										}
									}
								}
							}


							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!(ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null) || ValidateProvisionTemplate_Test.strCRDCopayLogic.equals("")  ))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
										//if(ParentMapVal.equals(ninthColumnValue.get(rowIterator).toString())){
										CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
										//ParentMapVal = "";

										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										//if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
										strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

										strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
										strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
										strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
										strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//}
									}
								}	
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									//if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
									strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
									ParentMapVal = "";
									ParentMapVal = ninthColumnValue.get(rowIterator).toString();
								}
								//}
							}

							/*if(!ParentMapVal.equals("")){
							arrMAPID_Copay.remove(ParentMapVal);
							break;
						}*/

						}	
						if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Paper") && (tenthColumnValue.get(rowIterator).toString().contains("Creates Paper") || tenthColumnValue.get(rowIterator).toString().contains("Creates paper") || tenthColumnValue.get(rowIterator).toString().contains("creates paper")|| tenthColumnValue.get(rowIterator).toString().contains("creates Paper")))	{
							//if(tenthColumnValue.get(rowIterator).toString().contains("Creates Retail copay ")|| tenthColumnValue.get(rowIterator).toString().contains("Creates Mail Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper OON"))	{

							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//	arrMAPID_Copay.remove(ParentMapVal);
										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
											CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
											strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

											strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
											strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
											strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
											strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
										strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
									}
								}
							}

						}	
						if(ValidateProvisionTemplate_Test.subsectionProcessType_Value.equalsIgnoreCase("Paper Out of Network") && tenthColumnValue.get(rowIterator).toString().contains("Creates Paper Out Of Network"))	{
							//if(tenthColumnValue.get(rowIterator).toString().contains("Creates Retail copay ")|| tenthColumnValue.get(rowIterator).toString().contains("Creates Mail Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper Copay ") || tenthColumnValue.get(rowIterator).toString().contains("Creates Paper OON"))	{

							if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "NumberOfTier", 1)))	{
										strNumberOfTierValue =getCommonData("TestData", "NumberOfTier", 1);
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										//	arrMAPID_Copay.remove(ParentMapVal);
										//testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
										System.out.println("Field Name: No. of tiers\t<<matched>>");
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Tier type"))	{
								if(!ValidateProvisionTemplate_Test.TierType_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(getCommonData("TestData", "TierType", 1)))	{
											srtTierType = getCommonData("TestData", "TierType", 1);
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
											System.out.println("Field Name: Tier Type\t<<matched>>");
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRDB Copay Logic"))	{
								if(!ValidateProvisionTemplate_Test.strCRDCopayLogic.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.strCRDCopayLogic))	{
											CRDCopayLogic = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}	

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Dollar Amount"))	{
								if(!ValidateProvisionTemplate_Test.DAmount_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										//if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.DAmount_1))	{
										if(ValidateProvisionTemplate_Test.DAmount_1.contains(eighthColumnValue.get(rowIterator).toString()))	{
											strDollarAmountValue = eighthColumnValue.get(rowIterator).toString();
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}
							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Percent"))	{
								if(!ValidateProvisionTemplate_Test.Percent_1.equals(null))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.Percent_1))	{

											strPercentRepo = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}

							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Minimum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MinimunDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MinimunDollar_1))	{
											strmindollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Maximum Dollar"))	{
								if(!ValidateProvisionTemplate_Test.MaximumDollar_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.MaximumDollar_1))	{
											strmaxdollarreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Copay Calculation"))	{
								if(!ValidateProvisionTemplate_Test.CoPayCalculation_1.equals(""))	{
									if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

										if(eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.CoPayCalculation_1))	{
											strCopayCalculationreport = eighthColumnValue.get(rowIterator).toString(); 
											ParentMapVal = "";
											ParentMapVal = ninthColumnValue.get(rowIterator).toString();
										}
									}	
								}
							}

							else if(seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Non Formulary String"))	{
								if(ninthColumnValue.get(rowIterator).toString().equals(arrMAPID_Copay.get(MapCount).toString())){

									if(eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "").equalsIgnoreCase(ValidateProvisionTemplate_Test.strcopayNonFormularyValue))	{
										strNonFormularyAmountValueOrder = eighthColumnValue.get(rowIterator).toString().replaceAll("\"", "");
										ParentMapVal = "";
										ParentMapVal = ninthColumnValue.get(rowIterator).toString();
									}
								}
							}

						}	
					}
				}
			}
		}
	}
	public static String getCommonData(String sheetName,String ColName, int RowNum)
	{
		String CellValue="";
		FileInputStream file;
		try {
			file = new FileInputStream(frameworkParameters.InputFilepath);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet xssfSheet = workbook.getSheet(sheetName);
			int ColNum =getColumnContains(xssfSheet,0,ColName);

			FormulaEvaluator formulaEvaluator = workbook.getCreationHelper()
					.createFormulaEvaluator();
			XSSFRow row = xssfSheet.getRow(RowNum);
			XSSFCell cell = row.getCell(ColNum);
			CellValue = getCellValueAsString(cell, formulaEvaluator).trim();
		} catch (Exception e) {
			e.printStackTrace();
		}	           

		return CellValue;
	}
	private static String getCellValueAsString(XSSFCell cell,FormulaEvaluator formulaEvaluator) {
		if (cell == null || cell.getCellType() == XSSFCell.CELL_TYPE_BLANK) {
			return null;
		} else {
			if (formulaEvaluator.evaluate(cell).getCellType() == XSSFCell.CELL_TYPE_ERROR) {
				System.out.println(
						"Error in formula within this cell! " + "Error code: "
								+ cell.getErrorCellValue());
			}
			DataFormatter dataFormatter = new DataFormatter();
			return dataFormatter.formatCellValue(formulaEvaluator
					.evaluateInCell(cell));
		}
	}

	public static int getColumnContains(XSSFSheet xssfsheetname2, int Rownum, String value) throws Exception {

		int a;
		try {

			int columncount=getColumnUsed(xssfsheetname2);
			for ( a=0 ; a<columncount; a++){
				if  (getCellData(xssfsheetname2,Rownum,a).equalsIgnoreCase(value)){
					break;
				}
			}
			return a;
		}catch (Exception e){
			throw(e);
		}
	}

	public static int getColumnUsed(XSSFSheet xssfsheetname2) throws Exception 
	{
		int ColumnCount= xssfsheetname2.getRow(0).getLastCellNum(); 
		return ColumnCount;
	}

	public static String getCellData(XSSFSheet xssfsheetname2, int RowNum, int ColNum) throws Exception

	{	
		try{
			cell = xssfsheetname2.getRow(RowNum).getCell(ColNum);
			String CellData = formatter.formatCellValue(cell);//cell.getStringCellValue();
			return CellData;

		}
		catch (Exception e)
		{

			return"";

		}

	}

}

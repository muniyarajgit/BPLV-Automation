package com.keywords;

import org.testng.annotations.Test;

import com.FrameworkFunctions.GetReportValues;

public class CopyOfgetTemplateValues_24  {
	
	public static String p24_DC_Line_Value = "";
	public static String p24_DC_Line_Text = "";

	public static String p24_DC_Retail_DrugList_DrugGroup_1 = "";

	public static String p24_DC_Retail_DrugListName_1 = "";
	public static String p24_DC_Retail_InclusionDrugClass_1 = "";
	public static String p24_DC_Retail_InclusionExclusion_1 = "";
	public static String p24_DC_Retail_ApplyLimitations_1 = "";
	public static String p24_DC_Retail_StartAge_1 = "";
	public static String p24_DC_Retail_EndAge_1 = "";
	public static String p24_DC_Retail_Gender_1 = "";
	public static String p24_DC_Retail_MinimumDays_1 = "";
	public static String p24_DC_Retail_MinimumQuantity_1 = "";
	public static String p24_DC_Retail_DailyDose_1 = "";
	public static String p24_DC_Retail_StartAgeType_1 = "";
	public static String p24_DC_Retail_EndAgeType_1 = "";
	public static String p24_DC_Retail_DayQuantityRule_1 = "";
	public static String p24_DC_Retail_MaximumDays_1 = "";
	public static String p24_DC_Retail_MaximumFills_1 = "";
	public static String p24_DC_Retail_MaxDaysPerFill_1 = "";
	public static String p24_DC_Retail_DOT_TimePeriod_1 = "";
	public static String p24_DC_Retail_DOT_NoOfDays_1 = "";
	public static String p24_DC_Retail_DOT_TimeValue_1 = "";
	public static String p24_DC_Retail_MaxQuantityPerFill_1 = "";
	public static String p24_DC_Retail_QOT_Quantity_1 = "";
	public static String p24_DC_Retail_QOT_TimePeriod_1 = "";
	public static String p24_DC_Retail_QOT_TimeValue_1 = "";
	public static String p24_DC_Retail_BypassMOOP_1 = "";

	public static String p24_DC_Retail_DrugList_DrugGroup_2 = "";
	public static String p24_DC_Retail_DrugListName_2 = "";
	public static String p24_DC_Retail_InclusionDrugClass_2 = "";
	public static String p24_DC_Retail_InclusionExclusion_2 = "";
	public static String p24_DC_Retail_ApplyLimitations_2 = "";
	public static String p24_DC_Retail_StartAge_2 = "";
	public static String p24_DC_Retail_EndAge_2 = "";
	public static String p24_DC_Retail_Gender_2 = "";
	public static String p24_DC_Retail_MinimumDays_2 = "";
	public static String p24_DC_Retail_MinimumQuantity_2 = "";
	public static String p24_DC_Retail_DailyDose_2 = "";
	public static String p24_DC_Retail_StartAgeType_2 = "";
	public static String p24_DC_Retail_EndAgeType_2 = "";
	public static String p24_DC_Retail_DayQuantityRule_2 = "";
	public static String p24_DC_Retail_MaximumDays_2 = "";
	public static String p24_DC_Retail_MaximumFills_2 = "";
	public static String p24_DC_Retail_MaxDaysPerFill_2 = "";
	public static String p24_DC_Retail_DOT_TimePeriod_2 = "";
	public static String p24_DC_Retail_DOT_NoOfDays_2 = "";
	public static String p24_DC_Retail_DOT_TimeValue_2 = "";
	public static String p24_DC_Retail_MaxQuantityPerFill_2 = "";
	public static String p24_DC_Retail_QOT_Quantity_2 = "";
	public static String p24_DC_Retail_QOT_TimePeriod_2 = "";
	public static String p24_DC_Retail_QOT_TimeValue_2 = "";
	public static String p24_DC_Retail_BypassMOOP_2 = "";

	public static String p24_DC_Retail_DrugList_DrugGroup_3 = "";
	public static String p24_DC_Retail_DrugListName_3 = "";
	public static String p24_DC_Retail_InclusionDrugClass_3 = "";
	public static String p24_DC_Retail_InclusionExclusion_3 = "";
	public static String p24_DC_Retail_ApplyLimitations_3 = "";
	public static String p24_DC_Retail_StartAge_3 = "";
	public static String p24_DC_Retail_EndAge_3 = "";
	public static String p24_DC_Retail_Gender_3 = "";
	public static String p24_DC_Retail_MinimumDays_3 = "";
	public static String p24_DC_Retail_MinimumQuantity_3 = "";
	public static String p24_DC_Retail_DailyDose_3 = "";
	public static String p24_DC_Retail_StartAgeType_3 = "";
	public static String p24_DC_Retail_EndAgeType_3 = "";
	public static String p24_DC_Retail_DayQuantityRule_3 = "";
	public static String p24_DC_Retail_MaximumDays_3 = "";
	public static String p24_DC_Retail_MaximumFills_3 = "";
	public static String p24_DC_Retail_MaxDaysPerFill_3 = "";
	public static String p24_DC_Retail_DOT_TimePeriod_3 = "";
	public static String p24_DC_Retail_DOT_NoOfDays_3 = "";
	public static String p24_DC_Retail_DOT_TimeValue_3 = "";
	public static String p24_DC_Retail_MaxQuantityPerFill_3 = "";
	public static String p24_DC_Retail_QOT_Quantity_3 = "";
	public static String p24_DC_Retail_QOT_TimePeriod_3 = "";
	public static String p24_DC_Retail_QOT_TimeValue_3 = "";
	public static String p24_DC_Retail_BypassMOOP_3 = "";

	public static String p24_DC_Retail_DrugList_DrugGroup_4 = "";
	public static String p24_DC_Retail_DrugListName_4 = "";
	public static String p24_DC_Retail_InclusionDrugClass_4 = "";
	public static String p24_DC_Retail_InclusionExclusion_4 = "";
	public static String p24_DC_Retail_ApplyLimitations_4 = "";
	public static String p24_DC_Retail_StartAge_4 = "";
	public static String p24_DC_Retail_EndAge_4 = "";
	public static String p24_DC_Retail_Gender_4 = "";
	public static String p24_DC_Retail_MinimumDays_4 = "";
	public static String p24_DC_Retail_MinimumQuantity_4 = "";
	public static String p24_DC_Retail_DailyDose_4 = "";
	public static String p24_DC_Retail_StartAgeType_4 = "";
	public static String p24_DC_Retail_EndAgeType_4 = "";
	public static String p24_DC_Retail_DayQuantityRule_4 = "";
	public static String p24_DC_Retail_MaximumDays_4 = "";
	public static String p24_DC_Retail_MaximumFills_4 = "";
	public static String p24_DC_Retail_MaxDaysPerFill_4 = "";
	public static String p24_DC_Retail_DOT_TimePeriod_4 = "";
	public static String p24_DC_Retail_DOT_NoOfDays_4 = "";
	public static String p24_DC_Retail_DOT_TimeValue_4 = "";
	public static String p24_DC_Retail_MaxQuantityPerFill_4 = "";
	public static String p24_DC_Retail_QOT_Quantity_4 = "";
	public static String p24_DC_Retail_QOT_TimePeriod_4 = "";
	public static String p24_DC_Retail_QOT_TimeValue_4 = "";
	public static String p24_DC_Retail_BypassMOOP_4 = "";

	public static String p24_DC_Mail_DrugList_DrugGroup_1 = "";

	public static String p24_DC_Mail_DrugListName_1 = "";
	public static String p24_DC_Mail_InclusionDrugClass_1 = "";
	public static String p24_DC_Mail_InclusionExclusion_1 = "";
	public static String p24_DC_Mail_ApplyLimitations_1 = "";
	public static String p24_DC_Mail_StartAge_1 = "";
	public static String p24_DC_Mail_EndAge_1 = "";
	public static String p24_DC_Mail_Gender_1 = "";
	public static String p24_DC_Mail_MinimumDays_1 = "";
	public static String p24_DC_Mail_MinimumQuantity_1 = "";
	public static String p24_DC_Mail_DailyDose_1 = "";
	public static String p24_DC_Mail_StartAgeType_1 = "";
	public static String p24_DC_Mail_EndAgeType_1 = "";
	public static String p24_DC_Mail_DayQuantityRule_1 = "";
	public static String p24_DC_Mail_MaximumDays_1 = "";
	public static String p24_DC_Mail_MaximumFills_1 = "";
	public static String p24_DC_Mail_MaxDaysPerFill_1 = "";
	public static String p24_DC_Mail_DOT_TimePeriod_1 = "";
	public static String p24_DC_Mail_DOT_NoOfDays_1 = "";
	public static String p24_DC_Mail_DOT_TimeValue_1 = "";
	public static String p24_DC_Mail_MaxQuantityPerFill_1 = "";
	public static String p24_DC_Mail_QOT_Quantity_1 = "";
	public static String p24_DC_Mail_QOT_TimePeriod_1 = "";
	public static String p24_DC_Mail_QOT_TimeValue_1 = "";
	public static String p24_DC_Mail_BypassMOOP_1 = "";

	public static String p24_DC_Mail_DrugList_DrugGroup_2 = "";
	public static String p24_DC_Mail_DrugListName_2 = "";
	public static String p24_DC_Mail_InclusionDrugClass_2 = "";
	public static String p24_DC_Mail_InclusionExclusion_2 = "";
	public static String p24_DC_Mail_ApplyLimitations_2 = "";
	public static String p24_DC_Mail_StartAge_2 = "";
	public static String p24_DC_Mail_EndAge_2 = "";
	public static String p24_DC_Mail_Gender_2 = "";
	public static String p24_DC_Mail_MinimumDays_2 = "";
	public static String p24_DC_Mail_MinimumQuantity_2 = "";
	public static String p24_DC_Mail_DailyDose_2 = "";
	public static String p24_DC_Mail_StartAgeType_2 = "";
	public static String p24_DC_Mail_EndAgeType_2 = "";
	public static String p24_DC_Mail_DayQuantityRule_2 = "";
	public static String p24_DC_Mail_MaximumDays_2 = "";
	public static String p24_DC_Mail_MaximumFills_2 = "";
	public static String p24_DC_Mail_MaxDaysPerFill_2 = "";
	public static String p24_DC_Mail_DOT_TimePeriod_2 = "";
	public static String p24_DC_Mail_DOT_NoOfDays_2 = "";
	public static String p24_DC_Mail_DOT_TimeValue_2 = "";
	public static String p24_DC_Mail_MaxQuantityPerFill_2 = "";
	public static String p24_DC_Mail_QOT_Quantity_2 = "";
	public static String p24_DC_Mail_QOT_TimePeriod_2 = "";
	public static String p24_DC_Mail_QOT_TimeValue_2 = "";
	public static String p24_DC_Mail_BypassMOOP_2 = "";

	public static String p24_DC_Mail_DrugList_DrugGroup_3 = "";
	public static String p24_DC_Mail_DrugListName_3 = "";
	public static String p24_DC_Mail_InclusionDrugClass_3 = "";
	public static String p24_DC_Mail_InclusionExclusion_3 = "";
	public static String p24_DC_Mail_ApplyLimitations_3 = "";
	public static String p24_DC_Mail_StartAge_3 = "";
	public static String p24_DC_Mail_EndAge_3 = "";
	public static String p24_DC_Mail_Gender_3 = "";
	public static String p24_DC_Mail_MinimumDays_3 = "";
	public static String p24_DC_Mail_MinimumQuantity_3 = "";
	public static String p24_DC_Mail_DailyDose_3 = "";
	public static String p24_DC_Mail_StartAgeType_3 = "";
	public static String p24_DC_Mail_EndAgeType_3 = "";
	public static String p24_DC_Mail_DayQuantityRule_3 = "";
	public static String p24_DC_Mail_MaximumDays_3 = "";
	public static String p24_DC_Mail_MaximumFills_3 = "";
	public static String p24_DC_Mail_MaxDaysPerFill_3 = "";
	public static String p24_DC_Mail_DOT_TimePeriod_3 = "";
	public static String p24_DC_Mail_DOT_NoOfDays_3 = "";
	public static String p24_DC_Mail_DOT_TimeValue_3 = "";
	public static String p24_DC_Mail_MaxQuantityPerFill_3 = "";
	public static String p24_DC_Mail_QOT_Quantity_3 = "";
	public static String p24_DC_Mail_QOT_TimePeriod_3 = "";
	public static String p24_DC_Mail_QOT_TimeValue_3 = "";
	public static String p24_DC_Mail_BypassMOOP_3 = "";

	public static String p24_DC_Mail_DrugList_DrugGroup_4 = "";
	public static String p24_DC_Mail_DrugListName_4 = "";
	public static String p24_DC_Mail_InclusionDrugClass_4 = "";
	public static String p24_DC_Mail_InclusionExclusion_4 = "";
	public static String p24_DC_Mail_ApplyLimitations_4 = "";
	public static String p24_DC_Mail_StartAge_4 = "";
	public static String p24_DC_Mail_EndAge_4 = "";
	public static String p24_DC_Mail_Gender_4 = "";
	public static String p24_DC_Mail_MinimumDays_4 = "";
	public static String p24_DC_Mail_MinimumQuantity_4 = "";
	public static String p24_DC_Mail_DailyDose_4 = "";
	public static String p24_DC_Mail_StartAgeType_4 = "";
	public static String p24_DC_Mail_EndAgeType_4 = "";
	public static String p24_DC_Mail_DayQuantityRule_4 = "";
	public static String p24_DC_Mail_MaximumDays_4 = "";
	public static String p24_DC_Mail_MaximumFills_4 = "";
	public static String p24_DC_Mail_MaxDaysPerFill_4 = "";
	public static String p24_DC_Mail_DOT_TimePeriod_4 = "";
	public static String p24_DC_Mail_DOT_NoOfDays_4 = "";
	public static String p24_DC_Mail_DOT_TimeValue_4 = "";
	public static String p24_DC_Mail_MaxQuantityPerFill_4 = "";
	public static String p24_DC_Mail_QOT_Quantity_4 = "";
	public static String p24_DC_Mail_QOT_TimePeriod_4 = "";
	public static String p24_DC_Mail_QOT_TimeValue_4 = "";
	public static String p24_DC_Mail_BypassMOOP_4 = "";


	public static String p24_DSC_Plan_Type_Retail_Present = "";
	public static String p24_DSC_Retail_DrugList_DrugGroup_1 = "";
	public static String p24_DSC_Retail_DL_DG_Name_1 = "";
	public static String p24_DSC_Retail_Stepped_1 = "";
	public static String p24_DSC_Retail_M_1 = "";
	public static String p24_DSC_Retail_N_1 = "";
	public static String p24_DSC_Retail_O_1 = "";
	public static String p24_DSC_Retail_Y_1 = "";
	public static String p24_DSC_Retail_PreferredGeneric_1 = "";
	public static String p24_DSC_Retail_NonPreferredGeneric_1 = "";
	public static String p24_DSC_Retail_PreferredBrand_1 = "";
	public static String p24_DSC_Retail_NonPreferredBrand_1 = "";
	public static String p24_DSC_Retail_DollarAmount_1 = "";
	public static String p24_DSC_Retail_Percent_1 = "";
	public static String p24_DSC_Retail_CoPayCalculation_1 = "";
	public static String p24_DSC_Retail_MinimumDollar_1 = "";
	public static String p24_DSC_Retail_MaximumDollar_1 = "";
	public static String p24_DSC_Retail_Reverse_1 = "";


	public static String p24_DSC_Plan_Type_Mail_Present = "";
	public static String p24_DSC_Mail_DrugList_DrugGroup_1 = "";
	public static String p24_DSC_Mail_DL_DG_Name_1 = "";
	public static String p24_DSC_Mail_Stepped_1 = "";
	public static String p24_DSC_Mail_M_1 = "";
	public static String p24_DSC_Mail_N_1 = "";
	public static String p24_DSC_Mail_O_1 = "";
	public static String p24_DSC_Mail_Y_1 = "";
	public static String p24_DSC_Mail_PreferredGeneric_1 = "";
	public static String p24_DSC_Mail_NonPreferredGeneric_1 = "";
	public static String p24_DSC_Mail_PreferredBrand_1 = "";
	public static String p24_DSC_Mail_NonPreferredBrand_1 = "";
	public static String p24_DSC_Mail_DollarAmount_1 = "";
	public static String p24_DSC_Mail_Percent_1 = "";
	public static String p24_DSC_Mail_CoPayCalculation_1 = "";
	public static String p24_DSC_Mail_MinimumDollar_1 = "";
	public static String p24_DSC_Mail_MaximumDollar_1 = "";
	public static String p24_DSC_Mail_Reverse_1 = "";


	public static String p24_DSC_Plan_Type_Specialty_Present = "";
	public static String p24_DSC_Specialty_DrugList_DrugGroup_1 = "";
	public static String p24_DSC_Specialty_DL_DG_Name_1 = "";
	public static String p24_DSC_Specialty_Stepped_1 = "";
	public static String p24_DSC_Specialty_M_1 = "";
	public static String p24_DSC_Specialty_N_1 = "";
	public static String p24_DSC_Specialty_O_1 = "";
	public static String p24_DSC_Specialty_Y_1 = "";
	public static String p24_DSC_Specialty_PreferredGeneric_1 = "";
	public static String p24_DSC_Specialty_NonPreferredGeneric_1 = "";
	public static String p24_DSC_Specialty_PreferredBrand_1 = "";
	public static String p24_DSC_Specialty_NonPreferredBrand_1 = "";
	public static String p24_DSC_Specialty_DollarAmount_1 = "";
	public static String p24_DSC_Specialty_Percent_1 = "";
	public static String p24_DSC_Specialty_CoPayCalculation_1 = "";
	public static String p24_DSC_Specialty_MinimumDollar_1 = "";
	public static String p24_DSC_Specialty_MaximumDollar_1 = "";
	public static String p24_DSC_Specialty_Reverse_1 = "";


	public static String p24_DSC_Plan_Type_Specialty_Out_of_Network_Present = "";
	public static String p24_DSC_SpecialtyOoN_DrugList_DrugGroup_1 = "";
	public static String p24_DSC_SpecialtyOoN_DL_DG_Name_1 = "";
	public static String p24_DSC_SpecialtyOoN_Stepped_1 = "";
	public static String p24_DSC_SpecialtyOoN_M_1 = "";
	public static String p24_DSC_SpecialtyOoN_N_1 = "";
	public static String p24_DSC_SpecialtyOoN_O_1 = "";
	public static String p24_DSC_SpecialtyOoN_Y_1 = "";
	public static String p24_DSC_SpecialtyOoN_PreferredGeneric_1 = "";
	public static String p24_DSC_SpecialtyOoN_NonPreferredGeneric_1 = "";
	public static String p24_DSC_SpecialtyOoN_PreferredBrand_1 = "";
	public static String p24_DSC_SpecialtyOoN_NonPreferredBrand_1 = "";
	public static String p24_DSC_SpecialtyOoN_DollarAmount_1 = "";
	public static String p24_DSC_SpecialtyOoN_Percent_1 = "";
	public static String p24_DSC_SpecialtyOoN_CoPayCalculation_1 = "";
	public static String p24_DSC_SpecialtyOoN_MinimumDollar_1 = "";
	public static String p24_DSC_SpecialtyOoN_MaximumDollar_1 = "";
	public static String p24_DSC_SpecialtyOoN_Reverse_1 = "";


	public static String p24_DSC_Plan_Type_Paper_Present = "";
	public static String p24_DSC_Paper_DrugList_DrugGroup_1 = "";
	public static String p24_DSC_Paper_DL_DG_Name_1 = "";
	public static String p24_DSC_Paper_Stepped_1 = "";
	public static String p24_DSC_Paper_M_1 = "";
	public static String p24_DSC_Paper_N_1 = "";
	public static String p24_DSC_Paper_O_1 = "";
	public static String p24_DSC_Paper_Y_1 = "";
	public static String p24_DSC_Paper_PreferredGeneric_1 = "";
	public static String p24_DSC_Paper_NonPreferredGeneric_1 = "";
	public static String p24_DSC_Paper_PreferredBrand_1 = "";
	public static String p24_DSC_Paper_NonPreferredBrand_1 = "";
	public static String p24_DSC_Paper_DollarAmount_1 = "";
	public static String p24_DSC_Paper_Percent_1 = "";
	public static String p24_DSC_Paper_CoPayCalculation_1 = "";
	public static String p24_DSC_Paper_MinimumDollar_1 = "";
	public static String p24_DSC_Paper_MaximumDollar_1 = "";
	public static String p24_DSC_Paper_Reverse_1 = "";


	public static String p24_DSC_Plan_Type_Paper_Out_of_Network_Present = "";
	public static String p24_DSC_PaperOoN_DrugList_DrugGroup_1 = "";
	public static String p24_DSC_PaperOoN_DL_DG_Name_1 = "";
	public static String p24_DSC_PaperOoN_Stepped_1 = "";
	public static String p24_DSC_PaperOoN_M_1 = "";
	public static String p24_DSC_PaperOoN_N_1 = "";
	public static String p24_DSC_PaperOoN_O_1 = "";
	public static String p24_DSC_PaperOoN_Y_1 = "";
	public static String p24_DSC_PaperOoN_PreferredGeneric_1 = "";
	public static String p24_DSC_PaperOoN_NonPreferredGeneric_1 = "";
	public static String p24_DSC_PaperOoN_PreferredBrand_1 = "";
	public static String p24_DSC_PaperOoN_NonPreferredBrand_1 = "";
	public static String p24_DSC_PaperOoN_DollarAmount_1 = "";
	public static String p24_DSC_PaperOoN_Percent_1 = "";
	public static String p24_DSC_PaperOoN_CoPayCalculation_1 = "";
	public static String p24_DSC_PaperOoN_MinimumDollar_1 = "";
	public static String p24_DSC_PaperOoN_MaximumDollar_1 = "";
	public static String p24_DSC_PaperOoN_Reverse_1 = "";


	public static String p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present = "";
	public static String p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_1 = "";
	public static String p24_DSC_Mail_PaperOoN_DL_DG_Name_1 = "";
	public static String p24_DSC_Mail_PaperOoN_Stepped_1 = "";
	public static String p24_DSC_Mail_PaperOoN_M_1 = "";
	public static String p24_DSC_Mail_PaperOoN_N_1 = "";
	public static String p24_DSC_Mail_PaperOoN_O_1 = "";
	public static String p24_DSC_Mail_PaperOoN_Y_1 = "";
	public static String p24_DSC_Mail_PaperOoN_PreferredGeneric_1 = "";
	public static String p24_DSC_Mail_PaperOoN_NonPreferredGeneric_1 = "";
	public static String p24_DSC_Mail_PaperOoN_PreferredBrand_1 = "";
	public static String p24_DSC_Mail_PaperOoN_NonPreferredBrand_1 = "";
	public static String p24_DSC_Mail_PaperOoN_DollarAmount_1 = "";
	public static String p24_DSC_Mail_PaperOoN_Percent_1 = "";
	public static String p24_DSC_Mail_PaperOoN_CoPayCalculation_1 = "";
	public static String p24_DSC_Mail_PaperOoN_MinimumDollar_1 = "";
	public static String p24_DSC_Mail_PaperOoN_MaximumDollar_1 = "";
	public static String p24_DSC_Mail_PaperOoN_Reverse_1 = "";


	public static String p24_Accumulations_MAB = "";

	public static String p24_Accumulations_M = "";
	public static String p24_Accumulations_O = "";
	public static String p24_Accumulations_N = "";
	public static String p24_Accumulations_Y = "";

	public static String p24_Accumulation_DrugList = "";
	public static String p24_Accumulation_DrugGroup = "";

	public static String p24_Accumulation_MABAmount = "";
	public static String p24_Accumulation_MABPeriod = "";
	public static String p24_Accumulation_MABMet = "";

	
  

	
	public static void validateDC() throws Exception {

		GetReportValues.MapValDC("24", p24_DC_Line_Value, "DC_Retail");
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("24", p24_DC_Line_Value, "DC_Retail", p24_DC_Retail_DrugList_DrugGroup_1, p24_DC_Retail_DrugListName_1, p24_DC_Retail_InclusionDrugClass_1, p24_DC_Retail_InclusionExclusion_1, p24_DC_Retail_ApplyLimitations_1, p24_DC_Retail_StartAge_1, p24_DC_Retail_EndAge_1, p24_DC_Retail_Gender_1, p24_DC_Retail_MinimumDays_1, p24_DC_Retail_MinimumQuantity_1, p24_DC_Retail_DailyDose_1, p24_DC_Retail_StartAgeType_1, p24_DC_Retail_EndAgeType_1, p24_DC_Retail_DayQuantityRule_1, p24_DC_Retail_MaximumDays_1, p24_DC_Retail_MaximumFills_1, p24_DC_Retail_MaxDaysPerFill_1, p24_DC_Retail_DOT_TimePeriod_1, p24_DC_Retail_DOT_NoOfDays_1, p24_DC_Retail_DOT_TimeValue_1, p24_DC_Retail_MaxQuantityPerFill_1, p24_DC_Retail_QOT_Quantity_1, p24_DC_Retail_QOT_TimePeriod_1, p24_DC_Retail_QOT_TimeValue_1, p24_DC_Retail_BypassMOOP_1);		
		GetReportValues.FailedReportValues_DC("DC_Retail");
		GetReportValues.MapValDC("24", p24_DC_Line_Value, "DC_Mail");
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("24", p24_DC_Line_Value, "DC_Mail", p24_DC_Mail_DrugList_DrugGroup_1, p24_DC_Mail_DrugListName_1, p24_DC_Mail_InclusionDrugClass_1, p24_DC_Mail_InclusionExclusion_1, p24_DC_Mail_ApplyLimitations_1, p24_DC_Mail_StartAge_1, p24_DC_Mail_EndAge_1, p24_DC_Mail_Gender_1, p24_DC_Mail_MinimumDays_1, p24_DC_Mail_MinimumQuantity_1, p24_DC_Mail_DailyDose_1, p24_DC_Mail_StartAgeType_1, p24_DC_Mail_EndAgeType_1, p24_DC_Mail_DayQuantityRule_1, p24_DC_Mail_MaximumDays_1, p24_DC_Mail_MaximumFills_1, p24_DC_Mail_MaxDaysPerFill_1, p24_DC_Mail_DOT_TimePeriod_1, p24_DC_Mail_DOT_NoOfDays_1, p24_DC_Mail_DOT_TimeValue_1, p24_DC_Mail_MaxQuantityPerFill_1, p24_DC_Mail_QOT_Quantity_1, p24_DC_Mail_QOT_TimePeriod_1, p24_DC_Mail_QOT_TimeValue_1, p24_DC_Mail_BypassMOOP_1);		
		GetReportValues.FailedReportValues_DC("DC_Mail");
	}
	
	public static void validateAccum() throws Exception {		
		ValidateProvisionTemplate_Test.validateAccumulationsDrugSpecific("24", p24_DC_Line_Value, p24_Accumulations_MAB, p24_Accumulations_M,p24_Accumulations_O, p24_Accumulations_N, p24_Accumulations_Y, p24_Accumulation_DrugList, p24_Accumulation_DrugGroup, p24_Accumulation_MABAmount, p24_Accumulation_MABPeriod, p24_Accumulation_MABMet);		
	}

	public static void validateDSC() throws Exception {


		GetReportValues.getAllMapId_DSC("24",p24_DC_Line_Value,"DSC_Retail");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_1,p24_DSC_Retail_DL_DG_Name_1,p24_DSC_Retail_Stepped_1,p24_DSC_Retail_M_1,p24_DSC_Retail_N_1,p24_DSC_Retail_O_1,p24_DSC_Retail_Y_1,p24_DSC_Retail_DollarAmount_1,p24_DSC_Retail_Percent_1,p24_DSC_Retail_CoPayCalculation_1,p24_DSC_Retail_MinimumDollar_1,p24_DSC_Retail_MaximumDollar_1,p24_DSC_Retail_Reverse_1,"False");
		/*ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_2,p24_DSC_Retail_DL_DG_Name_2,p24_DSC_Retail_Stepped_2,p24_DSC_Retail_M_2,p24_DSC_Retail_N_2,p24_DSC_Retail_O_2,p24_DSC_Retail_Y_2,p24_DSC_Retail_DollarAmount_2,p24_DSC_Retail_Percent_2,p24_DSC_Retail_CoPayCalculation_2,p24_DSC_Retail_MinimumDollar_2,p24_DSC_Retail_MaximumDollar_2,p24_DSC_Retail_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_3,p24_DSC_Retail_DL_DG_Name_3,p24_DSC_Retail_Stepped_3,p24_DSC_Retail_M_3,p24_DSC_Retail_N_3,p24_DSC_Retail_O_3,p24_DSC_Retail_Y_3,p24_DSC_Retail_DollarAmount_3,p24_DSC_Retail_Percent_3,p24_DSC_Retail_CoPayCalculation_3,p24_DSC_Retail_MinimumDollar_3,p24_DSC_Retail_MaximumDollar_3,p24_DSC_Retail_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_4,p24_DSC_Retail_DL_DG_Name_4,p24_DSC_Retail_Stepped_4,p24_DSC_Retail_M_4,p24_DSC_Retail_N_4,p24_DSC_Retail_O_4,p24_DSC_Retail_Y_4,p24_DSC_Retail_DollarAmount_4,p24_DSC_Retail_Percent_4,p24_DSC_Retail_CoPayCalculation_4,p24_DSC_Retail_MinimumDollar_4,p24_DSC_Retail_MaximumDollar_4,p24_DSC_Retail_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_5,p24_DSC_Retail_DL_DG_Name_5,p24_DSC_Retail_Stepped_5,p24_DSC_Retail_M_5,p24_DSC_Retail_N_5,p24_DSC_Retail_O_5,p24_DSC_Retail_Y_5,p24_DSC_Retail_DollarAmount_5,p24_DSC_Retail_Percent_5,p24_DSC_Retail_CoPayCalculation_5,p24_DSC_Retail_MinimumDollar_5,p24_DSC_Retail_MaximumDollar_5,p24_DSC_Retail_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_6,p24_DSC_Retail_DL_DG_Name_6,p24_DSC_Retail_Stepped_6,p24_DSC_Retail_M_6,p24_DSC_Retail_N_6,p24_DSC_Retail_O_6,p24_DSC_Retail_Y_6,p24_DSC_Retail_DollarAmount_6,p24_DSC_Retail_Percent_6,p24_DSC_Retail_CoPayCalculation_6,p24_DSC_Retail_MinimumDollar_6,p24_DSC_Retail_MaximumDollar_6,p24_DSC_Retail_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_7,p24_DSC_Retail_DL_DG_Name_7,p24_DSC_Retail_Stepped_7,p24_DSC_Retail_M_7,p24_DSC_Retail_N_7,p24_DSC_Retail_O_7,p24_DSC_Retail_Y_7,p24_DSC_Retail_DollarAmount_7,p24_DSC_Retail_Percent_7,p24_DSC_Retail_CoPayCalculation_7,p24_DSC_Retail_MinimumDollar_7,p24_DSC_Retail_MaximumDollar_7,p24_DSC_Retail_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Retail",p24_DSC_Plan_Type_Retail_Present,"",p24_DSC_Retail_DrugList_DrugGroup_8,p24_DSC_Retail_DL_DG_Name_8,p24_DSC_Retail_Stepped_8,p24_DSC_Retail_M_8,p24_DSC_Retail_N_8,p24_DSC_Retail_O_8,p24_DSC_Retail_Y_8,p24_DSC_Retail_DollarAmount_8,p24_DSC_Retail_Percent_8,p24_DSC_Retail_CoPayCalculation_8,p24_DSC_Retail_MinimumDollar_8,p24_DSC_Retail_MaximumDollar_8,p24_DSC_Retail_Reverse_8,"False");*/
		GetReportValues.FailedReportValues("DSC_Retail");
		GetReportValues.getAllMapId_DSC("24",p24_DC_Line_Value,"DSC_Mail");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_1,p24_DSC_Mail_DL_DG_Name_1,p24_DSC_Mail_Stepped_1,p24_DSC_Mail_M_1,p24_DSC_Mail_N_1,p24_DSC_Mail_O_1,p24_DSC_Mail_Y_1,p24_DSC_Mail_DollarAmount_1,p24_DSC_Mail_Percent_1,p24_DSC_Mail_CoPayCalculation_1,p24_DSC_Mail_MinimumDollar_1,p24_DSC_Mail_MaximumDollar_1,p24_DSC_Mail_Reverse_1,"False");
		/*ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_2,p24_DSC_Mail_DL_DG_Name_2,p24_DSC_Mail_Stepped_2,p24_DSC_Mail_M_2,p24_DSC_Mail_N_2,p24_DSC_Mail_O_2,p24_DSC_Mail_Y_2,p24_DSC_Mail_DollarAmount_2,p24_DSC_Mail_Percent_2,p24_DSC_Mail_CoPayCalculation_2,p24_DSC_Mail_MinimumDollar_2,p24_DSC_Mail_MaximumDollar_2,p24_DSC_Mail_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_3,p24_DSC_Mail_DL_DG_Name_3,p24_DSC_Mail_Stepped_3,p24_DSC_Mail_M_3,p24_DSC_Mail_N_3,p24_DSC_Mail_O_3,p24_DSC_Mail_Y_3,p24_DSC_Mail_DollarAmount_3,p24_DSC_Mail_Percent_3,p24_DSC_Mail_CoPayCalculation_3,p24_DSC_Mail_MinimumDollar_3,p24_DSC_Mail_MaximumDollar_3,p24_DSC_Mail_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_4,p24_DSC_Mail_DL_DG_Name_4,p24_DSC_Mail_Stepped_4,p24_DSC_Mail_M_4,p24_DSC_Mail_N_4,p24_DSC_Mail_O_4,p24_DSC_Mail_Y_4,p24_DSC_Mail_DollarAmount_4,p24_DSC_Mail_Percent_4,p24_DSC_Mail_CoPayCalculation_4,p24_DSC_Mail_MinimumDollar_4,p24_DSC_Mail_MaximumDollar_4,p24_DSC_Mail_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_5,p24_DSC_Mail_DL_DG_Name_5,p24_DSC_Mail_Stepped_5,p24_DSC_Mail_M_5,p24_DSC_Mail_N_5,p24_DSC_Mail_O_5,p24_DSC_Mail_Y_5,p24_DSC_Mail_DollarAmount_5,p24_DSC_Mail_Percent_5,p24_DSC_Mail_CoPayCalculation_5,p24_DSC_Mail_MinimumDollar_5,p24_DSC_Mail_MaximumDollar_5,p24_DSC_Mail_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_6,p24_DSC_Mail_DL_DG_Name_6,p24_DSC_Mail_Stepped_6,p24_DSC_Mail_M_6,p24_DSC_Mail_N_6,p24_DSC_Mail_O_6,p24_DSC_Mail_Y_6,p24_DSC_Mail_DollarAmount_6,p24_DSC_Mail_Percent_6,p24_DSC_Mail_CoPayCalculation_6,p24_DSC_Mail_MinimumDollar_6,p24_DSC_Mail_MaximumDollar_6,p24_DSC_Mail_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_7,p24_DSC_Mail_DL_DG_Name_7,p24_DSC_Mail_Stepped_7,p24_DSC_Mail_M_7,p24_DSC_Mail_N_7,p24_DSC_Mail_O_7,p24_DSC_Mail_Y_7,p24_DSC_Mail_DollarAmount_7,p24_DSC_Mail_Percent_7,p24_DSC_Mail_CoPayCalculation_7,p24_DSC_Mail_MinimumDollar_7,p24_DSC_Mail_MaximumDollar_7,p24_DSC_Mail_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail",p24_DSC_Plan_Type_Mail_Present,"",p24_DSC_Mail_DrugList_DrugGroup_8,p24_DSC_Mail_DL_DG_Name_8,p24_DSC_Mail_Stepped_8,p24_DSC_Mail_M_8,p24_DSC_Mail_N_8,p24_DSC_Mail_O_8,p24_DSC_Mail_Y_8,p24_DSC_Mail_DollarAmount_8,p24_DSC_Mail_Percent_8,p24_DSC_Mail_CoPayCalculation_8,p24_DSC_Mail_MinimumDollar_8,p24_DSC_Mail_MaximumDollar_8,p24_DSC_Mail_Reverse_8,"False");*/
		GetReportValues.FailedReportValues("DSC_Mail");
		GetReportValues.getAllMapId_DSC("24",p24_DC_Line_Value,"DSC_SpecialtyTiers");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_1,p24_DSC_Specialty_DL_DG_Name_1,p24_DSC_Specialty_Stepped_1,p24_DSC_Specialty_M_1,p24_DSC_Specialty_N_1,p24_DSC_Specialty_O_1,p24_DSC_Specialty_Y_1,p24_DSC_Specialty_DollarAmount_1,p24_DSC_Specialty_Percent_1,p24_DSC_Specialty_CoPayCalculation_1,p24_DSC_Specialty_MinimumDollar_1,p24_DSC_Specialty_MaximumDollar_1,p24_DSC_Specialty_Reverse_1,"False");
		/*ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_2,p24_DSC_Specialty_DL_DG_Name_2,p24_DSC_Specialty_Stepped_2,p24_DSC_Specialty_M_2,p24_DSC_Specialty_N_2,p24_DSC_Specialty_O_2,p24_DSC_Specialty_Y_2,p24_DSC_Specialty_DollarAmount_2,p24_DSC_Specialty_Percent_2,p24_DSC_Specialty_CoPayCalculation_2,p24_DSC_Specialty_MinimumDollar_2,p24_DSC_Specialty_MaximumDollar_2,p24_DSC_Specialty_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_3,p24_DSC_Specialty_DL_DG_Name_3,p24_DSC_Specialty_Stepped_3,p24_DSC_Specialty_M_3,p24_DSC_Specialty_N_3,p24_DSC_Specialty_O_3,p24_DSC_Specialty_Y_3,p24_DSC_Specialty_DollarAmount_3,p24_DSC_Specialty_Percent_3,p24_DSC_Specialty_CoPayCalculation_3,p24_DSC_Specialty_MinimumDollar_3,p24_DSC_Specialty_MaximumDollar_3,p24_DSC_Specialty_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_4,p24_DSC_Specialty_DL_DG_Name_4,p24_DSC_Specialty_Stepped_4,p24_DSC_Specialty_M_4,p24_DSC_Specialty_N_4,p24_DSC_Specialty_O_4,p24_DSC_Specialty_Y_4,p24_DSC_Specialty_DollarAmount_4,p24_DSC_Specialty_Percent_4,p24_DSC_Specialty_CoPayCalculation_4,p24_DSC_Specialty_MinimumDollar_4,p24_DSC_Specialty_MaximumDollar_4,p24_DSC_Specialty_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_5,p24_DSC_Specialty_DL_DG_Name_5,p24_DSC_Specialty_Stepped_5,p24_DSC_Specialty_M_5,p24_DSC_Specialty_N_5,p24_DSC_Specialty_O_5,p24_DSC_Specialty_Y_5,p24_DSC_Specialty_DollarAmount_5,p24_DSC_Specialty_Percent_5,p24_DSC_Specialty_CoPayCalculation_5,p24_DSC_Specialty_MinimumDollar_5,p24_DSC_Specialty_MaximumDollar_5,p24_DSC_Specialty_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_6,p24_DSC_Specialty_DL_DG_Name_6,p24_DSC_Specialty_Stepped_6,p24_DSC_Specialty_M_6,p24_DSC_Specialty_N_6,p24_DSC_Specialty_O_6,p24_DSC_Specialty_Y_6,p24_DSC_Specialty_DollarAmount_6,p24_DSC_Specialty_Percent_6,p24_DSC_Specialty_CoPayCalculation_6,p24_DSC_Specialty_MinimumDollar_6,p24_DSC_Specialty_MaximumDollar_6,p24_DSC_Specialty_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_7,p24_DSC_Specialty_DL_DG_Name_7,p24_DSC_Specialty_Stepped_7,p24_DSC_Specialty_M_7,p24_DSC_Specialty_N_7,p24_DSC_Specialty_O_7,p24_DSC_Specialty_Y_7,p24_DSC_Specialty_DollarAmount_7,p24_DSC_Specialty_Percent_7,p24_DSC_Specialty_CoPayCalculation_7,p24_DSC_Specialty_MinimumDollar_7,p24_DSC_Specialty_MaximumDollar_7,p24_DSC_Specialty_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyTiers",p24_DSC_Plan_Type_Specialty_Present,"",p24_DSC_Specialty_DrugList_DrugGroup_8,p24_DSC_Specialty_DL_DG_Name_8,p24_DSC_Specialty_Stepped_8,p24_DSC_Specialty_M_8,p24_DSC_Specialty_N_8,p24_DSC_Specialty_O_8,p24_DSC_Specialty_Y_8,p24_DSC_Specialty_DollarAmount_8,p24_DSC_Specialty_Percent_8,p24_DSC_Specialty_CoPayCalculation_8,p24_DSC_Specialty_MinimumDollar_8,p24_DSC_Specialty_MaximumDollar_8,p24_DSC_Specialty_Reverse_8,"False");*/
		GetReportValues.FailedReportValues("DSC_SpecialtyTiers");
		GetReportValues.getAllMapId_DSC("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_1,p24_DSC_SpecialtyOoN_DL_DG_Name_1,p24_DSC_SpecialtyOoN_Stepped_1,p24_DSC_SpecialtyOoN_M_1,p24_DSC_SpecialtyOoN_N_1,p24_DSC_SpecialtyOoN_O_1,p24_DSC_SpecialtyOoN_Y_1,p24_DSC_SpecialtyOoN_DollarAmount_1,p24_DSC_SpecialtyOoN_Percent_1,p24_DSC_SpecialtyOoN_CoPayCalculation_1,p24_DSC_SpecialtyOoN_MinimumDollar_1,p24_DSC_SpecialtyOoN_MaximumDollar_1,p24_DSC_SpecialtyOoN_Reverse_1,"False");
		/*ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_2,p24_DSC_SpecialtyOoN_DL_DG_Name_2,p24_DSC_SpecialtyOoN_Stepped_2,p24_DSC_SpecialtyOoN_M_2,p24_DSC_SpecialtyOoN_N_2,p24_DSC_SpecialtyOoN_O_2,p24_DSC_SpecialtyOoN_Y_2,p24_DSC_SpecialtyOoN_DollarAmount_2,p24_DSC_SpecialtyOoN_Percent_2,p24_DSC_SpecialtyOoN_CoPayCalculation_2,p24_DSC_SpecialtyOoN_MinimumDollar_2,p24_DSC_SpecialtyOoN_MaximumDollar_2,p24_DSC_SpecialtyOoN_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_3,p24_DSC_SpecialtyOoN_DL_DG_Name_3,p24_DSC_SpecialtyOoN_Stepped_3,p24_DSC_SpecialtyOoN_M_3,p24_DSC_SpecialtyOoN_N_3,p24_DSC_SpecialtyOoN_O_3,p24_DSC_SpecialtyOoN_Y_3,p24_DSC_SpecialtyOoN_DollarAmount_3,p24_DSC_SpecialtyOoN_Percent_3,p24_DSC_SpecialtyOoN_CoPayCalculation_3,p24_DSC_SpecialtyOoN_MinimumDollar_3,p24_DSC_SpecialtyOoN_MaximumDollar_3,p24_DSC_SpecialtyOoN_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_4,p24_DSC_SpecialtyOoN_DL_DG_Name_4,p24_DSC_SpecialtyOoN_Stepped_4,p24_DSC_SpecialtyOoN_M_4,p24_DSC_SpecialtyOoN_N_4,p24_DSC_SpecialtyOoN_O_4,p24_DSC_SpecialtyOoN_Y_4,p24_DSC_SpecialtyOoN_DollarAmount_4,p24_DSC_SpecialtyOoN_Percent_4,p24_DSC_SpecialtyOoN_CoPayCalculation_4,p24_DSC_SpecialtyOoN_MinimumDollar_4,p24_DSC_SpecialtyOoN_MaximumDollar_4,p24_DSC_SpecialtyOoN_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_5,p24_DSC_SpecialtyOoN_DL_DG_Name_5,p24_DSC_SpecialtyOoN_Stepped_5,p24_DSC_SpecialtyOoN_M_5,p24_DSC_SpecialtyOoN_N_5,p24_DSC_SpecialtyOoN_O_5,p24_DSC_SpecialtyOoN_Y_5,p24_DSC_SpecialtyOoN_DollarAmount_5,p24_DSC_SpecialtyOoN_Percent_5,p24_DSC_SpecialtyOoN_CoPayCalculation_5,p24_DSC_SpecialtyOoN_MinimumDollar_5,p24_DSC_SpecialtyOoN_MaximumDollar_5,p24_DSC_SpecialtyOoN_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_6,p24_DSC_SpecialtyOoN_DL_DG_Name_6,p24_DSC_SpecialtyOoN_Stepped_6,p24_DSC_SpecialtyOoN_M_6,p24_DSC_SpecialtyOoN_N_6,p24_DSC_SpecialtyOoN_O_6,p24_DSC_SpecialtyOoN_Y_6,p24_DSC_SpecialtyOoN_DollarAmount_6,p24_DSC_SpecialtyOoN_Percent_6,p24_DSC_SpecialtyOoN_CoPayCalculation_6,p24_DSC_SpecialtyOoN_MinimumDollar_6,p24_DSC_SpecialtyOoN_MaximumDollar_6,p24_DSC_SpecialtyOoN_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_7,p24_DSC_SpecialtyOoN_DL_DG_Name_7,p24_DSC_SpecialtyOoN_Stepped_7,p24_DSC_SpecialtyOoN_M_7,p24_DSC_SpecialtyOoN_N_7,p24_DSC_SpecialtyOoN_O_7,p24_DSC_SpecialtyOoN_Y_7,p24_DSC_SpecialtyOoN_DollarAmount_7,p24_DSC_SpecialtyOoN_Percent_7,p24_DSC_SpecialtyOoN_CoPayCalculation_7,p24_DSC_SpecialtyOoN_MinimumDollar_7,p24_DSC_SpecialtyOoN_MaximumDollar_7,p24_DSC_SpecialtyOoN_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_SpecialtyOutOfNetwork",p24_DSC_Plan_Type_Specialty_Out_of_Network_Present,"",p24_DSC_SpecialtyOoN_DrugList_DrugGroup_8,p24_DSC_SpecialtyOoN_DL_DG_Name_8,p24_DSC_SpecialtyOoN_Stepped_8,p24_DSC_SpecialtyOoN_M_8,p24_DSC_SpecialtyOoN_N_8,p24_DSC_SpecialtyOoN_O_8,p24_DSC_SpecialtyOoN_Y_8,p24_DSC_SpecialtyOoN_DollarAmount_8,p24_DSC_SpecialtyOoN_Percent_8,p24_DSC_SpecialtyOoN_CoPayCalculation_8,p24_DSC_SpecialtyOoN_MinimumDollar_8,p24_DSC_SpecialtyOoN_MaximumDollar_8,p24_DSC_SpecialtyOoN_Reverse_8,"False");*/
		GetReportValues.FailedReportValues("DSC_SpecialtyOutOfNetwork");
		GetReportValues.getAllMapId_DSC("24",p24_DC_Line_Value,"DSC_PaperTiers");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_1,p24_DSC_Paper_DL_DG_Name_1,p24_DSC_Paper_Stepped_1,p24_DSC_Paper_M_1,p24_DSC_Paper_N_1,p24_DSC_Paper_O_1,p24_DSC_Paper_Y_1,p24_DSC_Paper_DollarAmount_1,p24_DSC_Paper_Percent_1,p24_DSC_Paper_CoPayCalculation_1,p24_DSC_Paper_MinimumDollar_1,p24_DSC_Paper_MaximumDollar_1,p24_DSC_Paper_Reverse_1,"False");
		/*ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_2,p24_DSC_Paper_DL_DG_Name_2,p24_DSC_Paper_Stepped_2,p24_DSC_Paper_M_2,p24_DSC_Paper_N_2,p24_DSC_Paper_O_2,p24_DSC_Paper_Y_2,p24_DSC_Paper_DollarAmount_2,p24_DSC_Paper_Percent_2,p24_DSC_Paper_CoPayCalculation_2,p24_DSC_Paper_MinimumDollar_2,p24_DSC_Paper_MaximumDollar_2,p24_DSC_Paper_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_3,p24_DSC_Paper_DL_DG_Name_3,p24_DSC_Paper_Stepped_3,p24_DSC_Paper_M_3,p24_DSC_Paper_N_3,p24_DSC_Paper_O_3,p24_DSC_Paper_Y_3,p24_DSC_Paper_DollarAmount_3,p24_DSC_Paper_Percent_3,p24_DSC_Paper_CoPayCalculation_3,p24_DSC_Paper_MinimumDollar_3,p24_DSC_Paper_MaximumDollar_3,p24_DSC_Paper_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_4,p24_DSC_Paper_DL_DG_Name_4,p24_DSC_Paper_Stepped_4,p24_DSC_Paper_M_4,p24_DSC_Paper_N_4,p24_DSC_Paper_O_4,p24_DSC_Paper_Y_4,p24_DSC_Paper_DollarAmount_4,p24_DSC_Paper_Percent_4,p24_DSC_Paper_CoPayCalculation_4,p24_DSC_Paper_MinimumDollar_4,p24_DSC_Paper_MaximumDollar_4,p24_DSC_Paper_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_5,p24_DSC_Paper_DL_DG_Name_5,p24_DSC_Paper_Stepped_5,p24_DSC_Paper_M_5,p24_DSC_Paper_N_5,p24_DSC_Paper_O_5,p24_DSC_Paper_Y_5,p24_DSC_Paper_DollarAmount_5,p24_DSC_Paper_Percent_5,p24_DSC_Paper_CoPayCalculation_5,p24_DSC_Paper_MinimumDollar_5,p24_DSC_Paper_MaximumDollar_5,p24_DSC_Paper_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_6,p24_DSC_Paper_DL_DG_Name_6,p24_DSC_Paper_Stepped_6,p24_DSC_Paper_M_6,p24_DSC_Paper_N_6,p24_DSC_Paper_O_6,p24_DSC_Paper_Y_6,p24_DSC_Paper_DollarAmount_6,p24_DSC_Paper_Percent_6,p24_DSC_Paper_CoPayCalculation_6,p24_DSC_Paper_MinimumDollar_6,p24_DSC_Paper_MaximumDollar_6,p24_DSC_Paper_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_7,p24_DSC_Paper_DL_DG_Name_7,p24_DSC_Paper_Stepped_7,p24_DSC_Paper_M_7,p24_DSC_Paper_N_7,p24_DSC_Paper_O_7,p24_DSC_Paper_Y_7,p24_DSC_Paper_DollarAmount_7,p24_DSC_Paper_Percent_7,p24_DSC_Paper_CoPayCalculation_7,p24_DSC_Paper_MinimumDollar_7,p24_DSC_Paper_MaximumDollar_7,p24_DSC_Paper_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperTiers",p24_DSC_Plan_Type_Paper_Present,"",p24_DSC_Paper_DrugList_DrugGroup_8,p24_DSC_Paper_DL_DG_Name_8,p24_DSC_Paper_Stepped_8,p24_DSC_Paper_M_8,p24_DSC_Paper_N_8,p24_DSC_Paper_O_8,p24_DSC_Paper_Y_8,p24_DSC_Paper_DollarAmount_8,p24_DSC_Paper_Percent_8,p24_DSC_Paper_CoPayCalculation_8,p24_DSC_Paper_MinimumDollar_8,p24_DSC_Paper_MaximumDollar_8,p24_DSC_Paper_Reverse_8,"False");*/
		GetReportValues.FailedReportValues("DSC_PaperTiers");
		GetReportValues.getAllMapId_DSC("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_1,p24_DSC_PaperOoN_DL_DG_Name_1,p24_DSC_PaperOoN_Stepped_1,p24_DSC_PaperOoN_M_1,p24_DSC_PaperOoN_N_1,p24_DSC_PaperOoN_O_1,p24_DSC_PaperOoN_Y_1,p24_DSC_PaperOoN_DollarAmount_1,p24_DSC_PaperOoN_Percent_1,p24_DSC_PaperOoN_CoPayCalculation_1,p24_DSC_PaperOoN_MinimumDollar_1,p24_DSC_PaperOoN_MaximumDollar_1,p24_DSC_PaperOoN_Reverse_1,"False");
		/*ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_2,p24_DSC_PaperOoN_DL_DG_Name_2,p24_DSC_PaperOoN_Stepped_2,p24_DSC_PaperOoN_M_2,p24_DSC_PaperOoN_N_2,p24_DSC_PaperOoN_O_2,p24_DSC_PaperOoN_Y_2,p24_DSC_PaperOoN_DollarAmount_2,p24_DSC_PaperOoN_Percent_2,p24_DSC_PaperOoN_CoPayCalculation_2,p24_DSC_PaperOoN_MinimumDollar_2,p24_DSC_PaperOoN_MaximumDollar_2,p24_DSC_PaperOoN_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_3,p24_DSC_PaperOoN_DL_DG_Name_3,p24_DSC_PaperOoN_Stepped_3,p24_DSC_PaperOoN_M_3,p24_DSC_PaperOoN_N_3,p24_DSC_PaperOoN_O_3,p24_DSC_PaperOoN_Y_3,p24_DSC_PaperOoN_DollarAmount_3,p24_DSC_PaperOoN_Percent_3,p24_DSC_PaperOoN_CoPayCalculation_3,p24_DSC_PaperOoN_MinimumDollar_3,p24_DSC_PaperOoN_MaximumDollar_3,p24_DSC_PaperOoN_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_4,p24_DSC_PaperOoN_DL_DG_Name_4,p24_DSC_PaperOoN_Stepped_4,p24_DSC_PaperOoN_M_4,p24_DSC_PaperOoN_N_4,p24_DSC_PaperOoN_O_4,p24_DSC_PaperOoN_Y_4,p24_DSC_PaperOoN_DollarAmount_4,p24_DSC_PaperOoN_Percent_4,p24_DSC_PaperOoN_CoPayCalculation_4,p24_DSC_PaperOoN_MinimumDollar_4,p24_DSC_PaperOoN_MaximumDollar_4,p24_DSC_PaperOoN_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_5,p24_DSC_PaperOoN_DL_DG_Name_5,p24_DSC_PaperOoN_Stepped_5,p24_DSC_PaperOoN_M_5,p24_DSC_PaperOoN_N_5,p24_DSC_PaperOoN_O_5,p24_DSC_PaperOoN_Y_5,p24_DSC_PaperOoN_DollarAmount_5,p24_DSC_PaperOoN_Percent_5,p24_DSC_PaperOoN_CoPayCalculation_5,p24_DSC_PaperOoN_MinimumDollar_5,p24_DSC_PaperOoN_MaximumDollar_5,p24_DSC_PaperOoN_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_6,p24_DSC_PaperOoN_DL_DG_Name_6,p24_DSC_PaperOoN_Stepped_6,p24_DSC_PaperOoN_M_6,p24_DSC_PaperOoN_N_6,p24_DSC_PaperOoN_O_6,p24_DSC_PaperOoN_Y_6,p24_DSC_PaperOoN_DollarAmount_6,p24_DSC_PaperOoN_Percent_6,p24_DSC_PaperOoN_CoPayCalculation_6,p24_DSC_PaperOoN_MinimumDollar_6,p24_DSC_PaperOoN_MaximumDollar_6,p24_DSC_PaperOoN_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_7,p24_DSC_PaperOoN_DL_DG_Name_7,p24_DSC_PaperOoN_Stepped_7,p24_DSC_PaperOoN_M_7,p24_DSC_PaperOoN_N_7,p24_DSC_PaperOoN_O_7,p24_DSC_PaperOoN_Y_7,p24_DSC_PaperOoN_DollarAmount_7,p24_DSC_PaperOoN_Percent_7,p24_DSC_PaperOoN_CoPayCalculation_7,p24_DSC_PaperOoN_MinimumDollar_7,p24_DSC_PaperOoN_MaximumDollar_7,p24_DSC_PaperOoN_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_PaperOutOfNetwork",p24_DSC_Plan_Type_Paper_Out_of_Network_Present,"",p24_DSC_PaperOoN_DrugList_DrugGroup_8,p24_DSC_PaperOoN_DL_DG_Name_8,p24_DSC_PaperOoN_Stepped_8,p24_DSC_PaperOoN_M_8,p24_DSC_PaperOoN_N_8,p24_DSC_PaperOoN_O_8,p24_DSC_PaperOoN_Y_8,p24_DSC_PaperOoN_DollarAmount_8,p24_DSC_PaperOoN_Percent_8,p24_DSC_PaperOoN_CoPayCalculation_8,p24_DSC_PaperOoN_MinimumDollar_8,p24_DSC_PaperOoN_MaximumDollar_8,p24_DSC_PaperOoN_Reverse_8,"False");*/
		GetReportValues.FailedReportValues("DSC_PaperOutOfNetwork");
		GetReportValues.getAllMapId_DSC("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_1,p24_DSC_Mail_PaperOoN_DL_DG_Name_1,p24_DSC_Mail_PaperOoN_Stepped_1,p24_DSC_Mail_PaperOoN_M_1,p24_DSC_Mail_PaperOoN_N_1,p24_DSC_Mail_PaperOoN_O_1,p24_DSC_Mail_PaperOoN_Y_1,p24_DSC_Mail_PaperOoN_DollarAmount_1,p24_DSC_Mail_PaperOoN_Percent_1,p24_DSC_Mail_PaperOoN_CoPayCalculation_1,p24_DSC_Mail_PaperOoN_MinimumDollar_1,p24_DSC_Mail_PaperOoN_MaximumDollar_1,p24_DSC_Mail_PaperOoN_Reverse_1,"False");
		/*ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_2,p24_DSC_Mail_PaperOoN_DL_DG_Name_2,p24_DSC_Mail_PaperOoN_Stepped_2,p24_DSC_Mail_PaperOoN_M_2,p24_DSC_Mail_PaperOoN_N_2,p24_DSC_Mail_PaperOoN_O_2,p24_DSC_Mail_PaperOoN_Y_2,p24_DSC_Mail_PaperOoN_DollarAmount_2,p24_DSC_Mail_PaperOoN_Percent_2,p24_DSC_Mail_PaperOoN_CoPayCalculation_2,p24_DSC_Mail_PaperOoN_MinimumDollar_2,p24_DSC_Mail_PaperOoN_MaximumDollar_2,p24_DSC_Mail_PaperOoN_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_3,p24_DSC_Mail_PaperOoN_DL_DG_Name_3,p24_DSC_Mail_PaperOoN_Stepped_3,p24_DSC_Mail_PaperOoN_M_3,p24_DSC_Mail_PaperOoN_N_3,p24_DSC_Mail_PaperOoN_O_3,p24_DSC_Mail_PaperOoN_Y_3,p24_DSC_Mail_PaperOoN_DollarAmount_3,p24_DSC_Mail_PaperOoN_Percent_3,p24_DSC_Mail_PaperOoN_CoPayCalculation_3,p24_DSC_Mail_PaperOoN_MinimumDollar_3,p24_DSC_Mail_PaperOoN_MaximumDollar_3,p24_DSC_Mail_PaperOoN_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_4,p24_DSC_Mail_PaperOoN_DL_DG_Name_4,p24_DSC_Mail_PaperOoN_Stepped_4,p24_DSC_Mail_PaperOoN_M_4,p24_DSC_Mail_PaperOoN_N_4,p24_DSC_Mail_PaperOoN_O_4,p24_DSC_Mail_PaperOoN_Y_4,p24_DSC_Mail_PaperOoN_DollarAmount_4,p24_DSC_Mail_PaperOoN_Percent_4,p24_DSC_Mail_PaperOoN_CoPayCalculation_4,p24_DSC_Mail_PaperOoN_MinimumDollar_4,p24_DSC_Mail_PaperOoN_MaximumDollar_4,p24_DSC_Mail_PaperOoN_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_5,p24_DSC_Mail_PaperOoN_DL_DG_Name_5,p24_DSC_Mail_PaperOoN_Stepped_5,p24_DSC_Mail_PaperOoN_M_5,p24_DSC_Mail_PaperOoN_N_5,p24_DSC_Mail_PaperOoN_O_5,p24_DSC_Mail_PaperOoN_Y_5,p24_DSC_Mail_PaperOoN_DollarAmount_5,p24_DSC_Mail_PaperOoN_Percent_5,p24_DSC_Mail_PaperOoN_CoPayCalculation_5,p24_DSC_Mail_PaperOoN_MinimumDollar_5,p24_DSC_Mail_PaperOoN_MaximumDollar_5,p24_DSC_Mail_PaperOoN_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_6,p24_DSC_Mail_PaperOoN_DL_DG_Name_6,p24_DSC_Mail_PaperOoN_Stepped_6,p24_DSC_Mail_PaperOoN_M_6,p24_DSC_Mail_PaperOoN_N_6,p24_DSC_Mail_PaperOoN_O_6,p24_DSC_Mail_PaperOoN_Y_6,p24_DSC_Mail_PaperOoN_DollarAmount_6,p24_DSC_Mail_PaperOoN_Percent_6,p24_DSC_Mail_PaperOoN_CoPayCalculation_6,p24_DSC_Mail_PaperOoN_MinimumDollar_6,p24_DSC_Mail_PaperOoN_MaximumDollar_6,p24_DSC_Mail_PaperOoN_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_7,p24_DSC_Mail_PaperOoN_DL_DG_Name_7,p24_DSC_Mail_PaperOoN_Stepped_7,p24_DSC_Mail_PaperOoN_M_7,p24_DSC_Mail_PaperOoN_N_7,p24_DSC_Mail_PaperOoN_O_7,p24_DSC_Mail_PaperOoN_Y_7,p24_DSC_Mail_PaperOoN_DollarAmount_7,p24_DSC_Mail_PaperOoN_Percent_7,p24_DSC_Mail_PaperOoN_CoPayCalculation_7,p24_DSC_Mail_PaperOoN_MinimumDollar_7,p24_DSC_Mail_PaperOoN_MaximumDollar_7,p24_DSC_Mail_PaperOoN_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("24",p24_DC_Line_Value,"DSC_Mail_PaperOutOfNetwork",p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,"",p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_8,p24_DSC_Mail_PaperOoN_DL_DG_Name_8,p24_DSC_Mail_PaperOoN_Stepped_8,p24_DSC_Mail_PaperOoN_M_8,p24_DSC_Mail_PaperOoN_N_8,p24_DSC_Mail_PaperOoN_O_8,p24_DSC_Mail_PaperOoN_Y_8,p24_DSC_Mail_PaperOoN_DollarAmount_8,p24_DSC_Mail_PaperOoN_Percent_8,p24_DSC_Mail_PaperOoN_CoPayCalculation_8,p24_DSC_Mail_PaperOoN_MinimumDollar_8,p24_DSC_Mail_PaperOoN_MaximumDollar_8,p24_DSC_Mail_PaperOoN_Reverse_8,"False");*/
		GetReportValues.FailedReportValues("DSC_Mail_PaperOutOfNetwork");
		
		
	}

	public static void getProvision24TemplateVlaues(Object[][] provision24Template)     {


		p24_DC_Line_Value = provision24Template[0][1].toString().trim();
		p24_DC_Line_Text = provision24Template[0][2].toString().trim();
	

		p24_DC_Retail_DrugList_DrugGroup_1 = provision24Template[0][5].toString().trim();

		p24_DSC_Retail_DL_DG_Name_1 = provision4Template[0][7].toString().trim();
		p24_DC_Retail_InclusionDrugClass_1 = provision24Template[0][8].toString().trim();
		p24_DC_Retail_InclusionExclusion_1 = provision24Template[0][9].toString().trim();
		p24_DC_Retail_ApplyLimitations_1 = provision24Template[0][10].toString().trim();
		p24_DC_Retail_StartAge_1 = provision24Template[0][11].toString().trim();
		p24_DC_Retail_EndAge_1 = provision24Template[0][12].toString().trim();
		p24_DC_Retail_Gender_1 = provision24Template[0][13].toString().trim();
		p24_DC_Retail_MinimumDays_1 = provision24Template[0][14].toString().trim();
		p24_DC_Retail_MinimumQuantity_1 = provision24Template[0][15].toString().trim();
		p24_DC_Retail_DailyDose_1 = provision24Template[0][16].toString().trim();
		p24_DC_Retail_StartAgeType_1 = provision24Template[0][17].toString().trim();
		p24_DC_Retail_EndAgeType_1 = provision24Template[0][18].toString().trim();
		p24_DC_Retail_DayQuantityRule_1 = provision24Template[0][19].toString().trim();
		p24_DC_Retail_MaximumDays_1 = provision24Template[0][20].toString().trim();
		p24_DC_Retail_MaximumFills_1 = provision24Template[0][21].toString().trim();
		p24_DC_Retail_MaxDaysPerFill_1 = provision24Template[0][22].toString().trim();
		p24_DC_Retail_DOT_TimePeriod_1 = provision24Template[0][23].toString().trim();
		p24_DC_Retail_DOT_NoOfDays_1 = provision24Template[0][24].toString().trim();
		p24_DC_Retail_DOT_TimeValue_1 = provision24Template[0][25].toString().trim();
		p24_DC_Retail_MaxQuantityPerFill_1 = provision24Template[0][26].toString().trim();
		p24_DC_Retail_QOT_Quantity_1 = provision24Template[0][27].toString().trim();
		p24_DC_Retail_QOT_TimePeriod_1 = provision24Template[0][28].toString().trim();
		p24_DC_Retail_QOT_TimeValue_1 = provision24Template[0][29].toString().trim();
		p24_DC_Retail_BypassMOOP_1 = provision24Template[0][30].toString().trim();

		p24_DSC_Retail_DrugList_DrugGroup_2 = provision4Template[0][32].toString().trim();
		p24_DSC_Retail_DL_DG_Name_2 = provision4Template[0][33].toString().trim();
		p24_DC_Retail_InclusionDrugClass_2 = provision24Template[0][34].toString().trim();
		p24_DC_Retail_InclusionExclusion_2 = provision24Template[0][35].toString().trim();
		p24_DC_Retail_ApplyLimitations_2 = provision24Template[0][36].toString().trim();
		p24_DC_Retail_StartAge_2 = provision24Template[0][37].toString().trim();
		p24_DC_Retail_EndAge_2 = provision24Template[0][38].toString().trim();
		p24_DC_Retail_Gender_2 = provision24Template[0][39].toString().trim();
		p24_DC_Retail_MinimumDays_2 = provision24Template[0][40].toString().trim();
		p24_DC_Retail_MinimumQuantity_2 = provision24Template[0][41].toString().trim();
		p24_DC_Retail_DailyDose_2 = provision24Template[0][42].toString().trim();
		p24_DC_Retail_StartAgeType_2 = provision24Template[0][43].toString().trim();
		p24_DC_Retail_EndAgeType_2 = provision24Template[0][44].toString().trim();
		p24_DC_Retail_DayQuantityRule_2 = provision24Template[0][45].toString().trim();
		p24_DC_Retail_MaximumDays_2 = provision24Template[0][46].toString().trim();
		p24_DC_Retail_MaximumFills_2 = provision24Template[0][47].toString().trim();
		p24_DC_Retail_MaxDaysPerFill_2 = provision24Template[0][48].toString().trim();
		p24_DC_Retail_DOT_TimePeriod_2 = provision24Template[0][49].toString().trim();
		p24_DC_Retail_DOT_NoOfDays_2 = provision24Template[0][50].toString().trim();
		p24_DC_Retail_DOT_TimeValue_2 = provision24Template[0][51].toString().trim();
		p24_DC_Retail_MaxQuantityPerFill_2 = provision24Template[0][52].toString().trim();
		p24_DC_Retail_QOT_Quantity_2 = provision24Template[0][53].toString().trim();
		p24_DC_Retail_QOT_TimePeriod_2 = provision24Template[0][54].toString().trim();
		p24_DC_Retail_QOT_TimeValue_2 = provision24Template[0][55].toString().trim();
		p24_DC_Retail_BypassMOOP_2 = provision24Template[0][56].toString().trim();

		p24_DSC_Retail_DrugList_DrugGroup_3 = provision4Template[0][58].toString().trim();
		p24_DSC_Retail_DL_DG_Name_3 = provision4Template[0][59].toString().trim();
		p24_DC_Retail_InclusionDrugClass_3 = provision24Template[0][60].toString().trim();
		p24_DC_Retail_InclusionExclusion_3 = provision24Template[0][61].toString().trim();
		p24_DC_Retail_ApplyLimitations_3 = provision24Template[0][62].toString().trim();
		p24_DC_Retail_StartAge_3 = provision24Template[0][63].toString().trim();
		p24_DC_Retail_EndAge_3 = provision24Template[0][64].toString().trim();
		p24_DC_Retail_Gender_3 = provision24Template[0][65].toString().trim();
		p24_DC_Retail_MinimumDays_3 = provision24Template[0][66].toString().trim();
		p24_DC_Retail_MinimumQuantity_3 = provision24Template[0][67].toString().trim();
		p24_DC_Retail_DailyDose_3 = provision24Template[0][68].toString().trim();
		p24_DC_Retail_StartAgeType_3 = provision24Template[0][69].toString().trim();
		p24_DC_Retail_EndAgeType_3 = provision24Template[0][70].toString().trim();
		p24_DC_Retail_DayQuantityRule_3 = provision24Template[0][71].toString().trim();
		p24_DC_Retail_MaximumDays_3 = provision24Template[0][72].toString().trim();
		p24_DC_Retail_MaximumFills_3 = provision24Template[0][73].toString().trim();
		p24_DC_Retail_MaxDaysPerFill_3 = provision24Template[0][74].toString().trim();
		p24_DC_Retail_DOT_TimePeriod_3 = provision24Template[0][75].toString().trim();
		p24_DC_Retail_DOT_NoOfDays_3 = provision24Template[0][76].toString().trim();
		p24_DC_Retail_DOT_TimeValue_3 = provision24Template[0][77].toString().trim();
		p24_DC_Retail_MaxQuantityPerFill_3 = provision24Template[0][78].toString().trim();
		p24_DC_Retail_QOT_Quantity_3 = provision24Template[0][79].toString().trim();
		p24_DC_Retail_QOT_TimePeriod_3 = provision24Template[0][80].toString().trim();
		p24_DC_Retail_QOT_TimeValue_3 = provision24Template[0][81].toString().trim();
		p24_DC_Retail_BypassMOOP_3 = provision24Template[0][82].toString().trim();

		p24_DSC_Retail_DrugList_DrugGroup_4 = provision4Template[0][84].toString().trim();
		p24_DSC_Retail_DL_DG_Name_4 = provision4Template[0][85].toString().trim();
		p24_DC_Retail_InclusionDrugClass_4 = provision24Template[0][86].toString().trim();
		p24_DC_Retail_InclusionExclusion_4 = provision24Template[0][87].toString().trim();
		p24_DC_Retail_ApplyLimitations_4 = provision24Template[0][88].toString().trim();
		p24_DC_Retail_StartAge_4 = provision24Template[0][89].toString().trim();
		p24_DC_Retail_EndAge_4 = provision24Template[0][90].toString().trim();
		p24_DC_Retail_Gender_4 = provision24Template[0][91].toString().trim();
		p24_DC_Retail_MinimumDays_4 = provision24Template[0][92].toString().trim();
		p24_DC_Retail_MinimumQuantity_4 = provision24Template[0][93].toString().trim();
		p24_DC_Retail_DailyDose_4 = provision24Template[0][94].toString().trim();
		p24_DC_Retail_StartAgeType_4 = provision24Template[0][95].toString().trim();
		p24_DC_Retail_EndAgeType_4 = provision24Template[0][96].toString().trim();
		p24_DC_Retail_DayQuantityRule_4 = provision24Template[0][97].toString().trim();
		p24_DC_Retail_MaximumDays_4 = provision24Template[0][98].toString().trim();
		p24_DC_Retail_MaximumFills_4 = provision24Template[0][99].toString().trim();
		p24_DC_Retail_MaxDaysPerFill_4 = provision24Template[0][100].toString().trim();
		p24_DC_Retail_DOT_TimePeriod_4 = provision24Template[0][101].toString().trim();
		p24_DC_Retail_DOT_NoOfDays_4 = provision24Template[0][102].toString().trim();
		p24_DC_Retail_DOT_TimeValue_4 = provision24Template[0][103].toString().trim();
		p24_DC_Retail_MaxQuantityPerFill_4 = provision24Template[0][104].toString().trim();
		p24_DC_Retail_QOT_Quantity_4 = provision24Template[0][105].toString().trim();
		p24_DC_Retail_QOT_TimePeriod_4 = provision24Template[0][106].toString().trim();
		p24_DC_Retail_QOT_TimeValue_4 = provision24Template[0][107].toString().trim();
		p24_DC_Retail_BypassMOOP_4 = provision24Template[0][108].toString().trim();

		p24_DC_Mail_DrugList_DrugGroup_1 = provision24Template[0][109].toString().trim();

		p24_DC_Mail_DL_DG_Name_1 = provision24Template[0][110].toString().trim();
		p24_DC_Mail_InclusionDrugClass_1 = provision24Template[0][111].toString().trim();
		p24_DC_Mail_InclusionExclusion_1 = provision24Template[0][112].toString().trim();
		p24_DC_Mail_ApplyLimitations_1 = provision24Template[0][113].toString().trim();
		p24_DC_Mail_StartAge_1 = provision24Template[0][114].toString().trim();
		p24_DC_Mail_EndAge_1 = provision24Template[0][115].toString().trim();
		p24_DC_Mail_Gender_1 = provision24Template[0][116].toString().trim();
		p24_DC_Mail_MinimumDays_1 = provision24Template[0][117].toString().trim();
		p24_DC_Mail_MinimumQuantity_1 = provision24Template[0][118].toString().trim();
		p24_DC_Mail_DailyDose_1 = provision24Template[0][119].toString().trim();
		p24_DC_Mail_StartAgeType_1 = provision24Template[0][120].toString().trim();
		p24_DC_Mail_EndAgeType_1 = provision24Template[0][121].toString().trim();
		p24_DC_Mail_DayQuantityRule_1 = provision24Template[0][122].toString().trim();
		p24_DC_Mail_MaximumDays_1 = provision24Template[0][123].toString().trim();
		p24_DC_Mail_MaximumFills_1 = provision24Template[0][124].toString().trim();
		p24_DC_Mail_MaxDaysPerFill_1 = provision24Template[0][125].toString().trim();
		p24_DC_Mail_DOT_TimePeriod_1 = provision24Template[0][126].toString().trim();
		p24_DC_Mail_DOT_NoOfDays_1 = provision24Template[0][127].toString().trim();
		p24_DC_Mail_DOT_TimeValue_1 = provision24Template[0][128].toString().trim();
		p24_DC_Mail_MaxQuantityPerFill_1 = provision24Template[0][129].toString().trim();
		p24_DC_Mail_QOT_Quantity_1 = provision24Template[0][130].toString().trim();
		p24_DC_Mail_QOT_TimePeriod_1 = provision24Template[0][131].toString().trim();
		p24_DC_Mail_QOT_TimeValue_1 = provision24Template[0][132].toString().trim();
		p24_DC_Mail_BypassMOOP_1 = provision24Template[0][133].toString().trim();

		p24_DC_Mail_DrugList_DrugGroup_2 = provision24Template[0][137].toString().trim();
		p24_DC_Mail_DL_DG_Name_2 = provision24Template[0][138].toString().trim();
		p24_DC_Mail_InclusionDrugClass_2 = provision24Template[0][139].toString().trim();
		p24_DC_Mail_InclusionExclusion_2 = provision24Template[0][140].toString().trim();
		p24_DC_Mail_ApplyLimitations_2 = provision24Template[0][141].toString().trim();
		p24_DC_Mail_StartAge_2 = provision24Template[0][142].toString().trim();
		p24_DC_Mail_EndAge_2 = provision24Template[0][143].toString().trim();
		p24_DC_Mail_Gender_2 = provision24Template[0][144].toString().trim();
		p24_DC_Mail_MinimumDays_2 = provision24Template[0][145].toString().trim();
		p24_DC_Mail_MinimumQuantity_2 = provision24Template[0][146].toString().trim();
		p24_DC_Mail_DailyDose_2 = provision24Template[0][147].toString().trim();
		p24_DC_Mail_StartAgeType_2 = provision24Template[0][148].toString().trim();
		p24_DC_Mail_EndAgeType_2 = provision24Template[0][149].toString().trim();
		p24_DC_Mail_DayQuantityRule_2 = provision24Template[0][150].toString().trim();
		p24_DC_Mail_MaximumDays_2 = provision24Template[0][151].toString().trim();
		p24_DC_Mail_MaximumFills_2 = provision24Template[0][152].toString().trim();
		p24_DC_Mail_MaxDaysPerFill_2 = provision24Template[0][153].toString().trim();
		p24_DC_Mail_DOT_TimePeriod_2 = provision24Template[0][154].toString().trim();
		p24_DC_Mail_DOT_NoOfDays_2 = provision24Template[0][155].toString().trim();
		p24_DC_Mail_DOT_TimeValue_2 = provision24Template[0][156].toString().trim();
		p24_DC_Mail_MaxQuantityPerFill_2 = provision24Template[0][157].toString().trim();
		p24_DC_Mail_QOT_Quantity_2 = provision24Template[0][158].toString().trim();
		p24_DC_Mail_QOT_TimePeriod_2 = provision24Template[0][159].toString().trim();
		p24_DC_Mail_QOT_TimeValue_2 = provision24Template[0][160].toString().trim();
		p24_DC_Mail_BypassMOOP_2 = provision24Template[0][161].toString().trim();

		p24_DC_Mail_DrugList_DrugGroup_3 = provision24Template[0][163].toString().trim();
		p24_DC_Mail_DL_DG_Name_3 = provision24Template[0][164].toString().trim();
		p24_DC_Mail_InclusionDrugClass_3 = provision24Template[0][165].toString().trim();
		p24_DC_Mail_InclusionExclusion_3 = provision24Template[0][166].toString().trim();
		p24_DC_Mail_ApplyLimitations_3 = provision24Template[0][167].toString().trim();
		p24_DC_Mail_StartAge_3 = provision24Template[0][168].toString().trim();
		p24_DC_Mail_EndAge_3 = provision24Template[0][169].toString().trim();
		p24_DC_Mail_Gender_3 = provision24Template[0][170].toString().trim();
		p24_DC_Mail_MinimumDays_3 = provision24Template[0][171].toString().trim();
		p24_DC_Mail_MinimumQuantity_3 = provision24Template[0][172].toString().trim();
		p24_DC_Mail_DailyDose_3 = provision24Template[0][173].toString().trim();
		p24_DC_Mail_StartAgeType_3 = provision24Template[0][174].toString().trim();
		p24_DC_Mail_EndAgeType_3 = provision24Template[0][175].toString().trim();
		p24_DC_Mail_DayQuantityRule_3 = provision24Template[0][176].toString().trim();
		p24_DC_Mail_MaximumDays_3 = provision24Template[0][177].toString().trim();
		p24_DC_Mail_MaximumFills_3 = provision24Template[0][178].toString().trim();
		p24_DC_Mail_MaxDaysPerFill_3 = provision24Template[0][179].toString().trim();
		p24_DC_Mail_DOT_TimePeriod_3 = provision24Template[0][180].toString().trim();
		p24_DC_Mail_DOT_NoOfDays_3 = provision24Template[0][181].toString().trim();
		p24_DC_Mail_DOT_TimeValue_3 = provision24Template[0][182].toString().trim();
		p24_DC_Mail_MaxQuantityPerFill_3 = provision24Template[0][183].toString().trim();
		p24_DC_Mail_QOT_Quantity_3 = provision24Template[0][184].toString().trim();
		p24_DC_Mail_QOT_TimePeriod_3 = provision24Template[0][185].toString().trim();
		p24_DC_Mail_QOT_TimeValue_3 = provision24Template[0][186].toString().trim();
		p24_DC_Mail_BypassMOOP_3 = provision24Template[0][187].toString().trim();

		p24_DC_Mail_DrugList_DrugGroup_4 = provision24Template[0][189].toString().trim();
		p24_DC_Mail_DL_DG_Name_4 = provision24Template[0][190].toString().trim();
		p24_DC_Mail_InclusionDrugClass_4 = provision24Template[0][191].toString().trim();
		p24_DC_Mail_InclusionExclusion_4 = provision24Template[0][192].toString().trim();
		p24_DC_Mail_ApplyLimitations_4 = provision24Template[0][193].toString().trim();
		p24_DC_Mail_StartAge_4 = provision24Template[0][194].toString().trim();
		p24_DC_Mail_EndAge_4 = provision24Template[0][195].toString().trim();
		p24_DC_Mail_Gender_4 = provision24Template[0][196].toString().trim();
		p24_DC_Mail_MinimumDays_4 = provision24Template[0][197].toString().trim();
		p24_DC_Mail_MinimumQuantity_4 = provision24Template[0][198].toString().trim();
		p24_DC_Mail_DailyDose_4 = provision24Template[0][199].toString().trim();
		p24_DC_Mail_StartAgeType_4 = provision24Template[0][200].toString().trim();
		p24_DC_Mail_EndAgeType_4 = provision24Template[0][201].toString().trim();
		p24_DC_Mail_DayQuantityRule_4 = provision24Template[0][202].toString().trim();
		p24_DC_Mail_MaximumDays_4 = provision24Template[0][203].toString().trim();
		p24_DC_Mail_MaximumFills_4 = provision24Template[0][204].toString().trim();
		p24_DC_Mail_MaxDaysPerFill_4 = provision24Template[0][205].toString().trim();
		p24_DC_Mail_DOT_TimePeriod_4 = provision24Template[0][206].toString().trim();
		p24_DC_Mail_DOT_NoOfDays_4 = provision24Template[0][207].toString().trim();
		p24_DC_Mail_DOT_TimeValue_4 = provision24Template[0][208].toString().trim();
		p24_DC_Mail_MaxQuantityPerFill_4 = provision24Template[0][209].toString().trim();
		p24_DC_Mail_QOT_Quantity_4 = provision24Template[0][210].toString().trim();
		p24_DC_Mail_QOT_TimePeriod_4 = provision24Template[0][211].toString().trim();
		p24_DC_Mail_QOT_TimeValue_4 = provision24Template[0][212].toString().trim();
		p24_DC_Mail_BypassMOOP_4 = provision24Template[0][213].toString().trim();


		p24_DSC_Plan_Type_Retail_Present = provision24Template[0][216].toString().trim();
		p24_DSC_Retail_DrugList_DrugGroup_1 = provision24Template[0][217].toString().trim();
		p24_DSC_Retail_DL_DG_Name_1 = provision24Template[0][218].toString().trim();
		p24_DSC_Retail_Stepped_1 = provision24Template[0][219].toString().trim();
		p24_DSC_Retail_M_1 = provision24Template[0][220].toString().trim();
		p24_DSC_Retail_N_1 = provision24Template[0][221].toString().trim();
		p24_DSC_Retail_O_1 = provision24Template[0][222].toString().trim();
		p24_DSC_Retail_Y_1 = provision24Template[0][223].toString().trim();
		p24_DSC_Retail_PreferredGeneric_1 = provision24Template[0][224].toString().trim();
		p24_DSC_Retail_NonPreferredGeneric_1 = provision24Template[0][225].toString().trim();
		p24_DSC_Retail_PreferredBrand_1 = provision24Template[0][226].toString().trim();
		p24_DSC_Retail_NonPreferredBrand_1 = provision24Template[0][227].toString().trim();
		p24_DSC_Retail_DollarAmount_1 = provision24Template[0][228].toString().trim();
		p24_DSC_Retail_Percent_1 = provision24Template[0][229].toString().trim();
		p24_DSC_Retail_CoPayCalculation_1 = provision24Template[0][230].toString().trim();
		p24_DSC_Retail_MinimumDollar_1 = provision24Template[0][231].toString().trim();
		p24_DSC_Retail_MaximumDollar_1 = provision24Template[0][232].toString().trim();
		p24_DSC_Retail_Reverse_1 = provision24Template[0][233].toString().trim();


		p24_DSC_Plan_Type_Mail_Present = provision24Template[0][236].toString().trim();
		p24_DSC_Mail_DrugList_DrugGroup_1 = provision24Template[0][237].toString().trim();
		p24_DSC_Mail_DL_DG_Name_1 = provision24Template[0][238].toString().trim();
		p24_DSC_Mail_Stepped_1 = provision24Template[0][239].toString().trim();
		p24_DSC_Mail_M_1 = provision24Template[0][240].toString().trim();
		p24_DSC_Mail_N_1 = provision24Template[0][241].toString().trim();
		p24_DSC_Mail_O_1 = provision24Template[0][242].toString().trim();
		p24_DSC_Mail_Y_1 = provision24Template[0][243].toString().trim();
		p24_DSC_Mail_PreferredGeneric_1 = provision24Template[0][244].toString().trim();
		p24_DSC_Mail_NonPreferredGeneric_1 = provision24Template[0][245].toString().trim();
		p24_DSC_Mail_PreferredBrand_1 = provision24Template[0][246].toString().trim();
		p24_DSC_Mail_NonPreferredBrand_1 = provision24Template[0][247].toString().trim();
		p24_DSC_Mail_DollarAmount_1 = provision24Template[0][248].toString().trim();
		p24_DSC_Mail_Percent_1 = provision24Template[0][249].toString().trim();
		p24_DSC_Mail_CoPayCalculation_1 = provision24Template[0][250].toString().trim();
		p24_DSC_Mail_MinimumDollar_1 = provision24Template[0][251].toString().trim();
		p24_DSC_Mail_MaximumDollar_1 = provision24Template[0][252].toString().trim();
		p24_DSC_Mail_Reverse_1 = provision24Template[0][253].toString().trim();


		p24_DSC_Plan_Type_Specialty_Present = provision24Template[0][256].toString().trim();
		p24_DSC_Specialty_DrugList_DrugGroup_1 = provision24Template[0][257].toString().trim();
		p24_DSC_Specialty_DL_DG_Name_1 = provision24Template[0][258].toString().trim();
		p24_DSC_Specialty_Stepped_1 = provision24Template[0][259].toString().trim();
		p24_DSC_Specialty_M_1 = provision24Template[0][260].toString().trim();
		p24_DSC_Specialty_N_1 = provision24Template[0][261].toString().trim();
		p24_DSC_Specialty_O_1 = provision24Template[0][262].toString().trim();
		p24_DSC_Specialty_Y_1 = provision24Template[0][263].toString().trim();
		p24_DSC_Specialty_PreferredGeneric_1 = provision24Template[0][264].toString().trim();
		p24_DSC_Specialty_NonPreferredGeneric_1 = provision24Template[0][265].toString().trim();
		p24_DSC_Specialty_PreferredBrand_1 = provision24Template[0][266].toString().trim();
		p24_DSC_Specialty_NonPreferredBrand_1 = provision24Template[0][267].toString().trim();
		p24_DSC_Specialty_DollarAmount_1 = provision24Template[0][268].toString().trim();
		p24_DSC_Specialty_Percent_1 = provision24Template[0][269].toString().trim();
		p24_DSC_Specialty_CoPayCalculation_1 = provision24Template[0][270].toString().trim();
		p24_DSC_Specialty_MinimumDollar_1 = provision24Template[0][271].toString().trim();
		p24_DSC_Specialty_MaximumDollar_1 = provision24Template[0][272].toString().trim();
		p24_DSC_Specialty_Reverse_1 = provision24Template[0][273].toString().trim();


		p24_DSC_Plan_Type_Specialty_Out_of_Network_Present = provision24Template[0][276].toString().trim();
		p24_DSC_SpecialtyOoN_DrugList_DrugGroup_1 = provision24Template[0][277].toString().trim();
		p24_DSC_SpecialtyOoN_DL_DG_Name_1 = provision24Template[0][278].toString().trim();
		p24_DSC_SpecialtyOoN_Stepped_1 = provision24Template[0][279].toString().trim();
		p24_DSC_SpecialtyOoN_M_1 = provision24Template[0][280].toString().trim();
		p24_DSC_SpecialtyOoN_N_1 = provision24Template[0][281].toString().trim();
		p24_DSC_SpecialtyOoN_O_1 = provision24Template[0][282].toString().trim();
		p24_DSC_SpecialtyOoN_Y_1 = provision24Template[0][283].toString().trim();
		p24_DSC_SpecialtyOoN_PreferredGeneric_1 = provision24Template[0][284].toString().trim();
		p24_DSC_SpecialtyOoN_NonPreferredGeneric_1 = provision24Template[0][285].toString().trim();
		p24_DSC_SpecialtyOoN_PreferredBrand_1 = provision24Template[0][286].toString().trim();
		p24_DSC_SpecialtyOoN_NonPreferredBrand_1 = provision24Template[0][287].toString().trim();
		p24_DSC_SpecialtyOoN_DollarAmount_1 = provision24Template[0][288].toString().trim();
		p24_DSC_SpecialtyOoN_Percent_1 = provision24Template[0][289].toString().trim();
		p24_DSC_SpecialtyOoN_CoPayCalculation_1 = provision24Template[0][290].toString().trim();
		p24_DSC_SpecialtyOoN_MinimumDollar_1 = provision24Template[0][291].toString().trim();
		p24_DSC_SpecialtyOoN_MaximumDollar_1 = provision24Template[0][292].toString().trim();
		p24_DSC_SpecialtyOoN_Reverse_1 = provision24Template[0][293].toString().trim();


		p24_DSC_Plan_Type_Paper_Present = provision24Template[0][296].toString().trim();
		p24_DSC_Paper_DrugList_DrugGroup_1 = provision24Template[0][297].toString().trim();
		p24_DSC_Paper_DL_DG_Name_1 = provision24Template[0][298].toString().trim();
		p24_DSC_Paper_Stepped_1 = provision24Template[0][299].toString().trim();
		p24_DSC_Paper_M_1 = provision24Template[0][300].toString().trim();
		p24_DSC_Paper_N_1 = provision24Template[0][301].toString().trim();
		p24_DSC_Paper_O_1 = provision24Template[0][302].toString().trim();
		p24_DSC_Paper_Y_1 = provision24Template[0][303].toString().trim();
		p24_DSC_Paper_PreferredGeneric_1 = provision24Template[0][304].toString().trim();
		p24_DSC_Paper_NonPreferredGeneric_1 = provision24Template[0][305].toString().trim();
		p24_DSC_Paper_PreferredBrand_1 = provision24Template[0][306].toString().trim();
		p24_DSC_Paper_NonPreferredBrand_1 = provision24Template[0][307].toString().trim();
		p24_DSC_Paper_DollarAmount_1 = provision24Template[0][308].toString().trim();
		p24_DSC_Paper_Percent_1 = provision24Template[0][309].toString().trim();
		p24_DSC_Paper_CoPayCalculation_1 = provision24Template[0][310].toString().trim();
		p24_DSC_Paper_MinimumDollar_1 = provision24Template[0][311].toString().trim();
		p24_DSC_Paper_MaximumDollar_1 = provision24Template[0][312].toString().trim();
		p24_DSC_Paper_Reverse_1 = provision24Template[0][313].toString().trim();


		p24_DSC_Plan_Type_Paper_Out_of_Network_Present = provision24Template[0][316].toString().trim();
		p24_DSC_PaperOoN_DrugList_DrugGroup_1 = provision24Template[0][317].toString().trim();
		p24_DSC_PaperOoN_DL_DG_Name_1 = provision24Template[0][318].toString().trim();
		p24_DSC_PaperOoN_Stepped_1 = provision24Template[0][319].toString().trim();
		p24_DSC_PaperOoN_M_1 = provision24Template[0][320].toString().trim();
		p24_DSC_PaperOoN_N_1 = provision24Template[0][321].toString().trim();
		p24_DSC_PaperOoN_O_1 = provision24Template[0][322].toString().trim();
		p24_DSC_PaperOoN_Y_1 = provision24Template[0][323].toString().trim();
		p24_DSC_PaperOoN_PreferredGeneric_1 = provision24Template[0][324].toString().trim();
		p24_DSC_PaperOoN_NonPreferredGeneric_1 = provision24Template[0][325].toString().trim();
		p24_DSC_PaperOoN_PreferredBrand_1 = provision24Template[0][326].toString().trim();
		p24_DSC_PaperOoN_NonPreferredBrand_1 = provision24Template[0][327].toString().trim();
		p24_DSC_PaperOoN_DollarAmount_1 = provision24Template[0][328].toString().trim();
		p24_DSC_PaperOoN_Percent_1 = provision24Template[0][329].toString().trim();
		p24_DSC_PaperOoN_CoPayCalculation_1 = provision24Template[0][330].toString().trim();
		p24_DSC_PaperOoN_MinimumDollar_1 = provision24Template[0][331].toString().trim();
		p24_DSC_PaperOoN_MaximumDollar_1 = provision24Template[0][332].toString().trim();
		p24_DSC_PaperOoN_Reverse_1 = provision24Template[0][333].toString().trim();


		p24_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present = provision24Template[0][336].toString().trim();
		p24_DSC_Mail_PaperOoN_DrugList_DrugGroup_1 = provision24Template[0][337].toString().trim();
		p24_DSC_Mail_PaperOoN_DL_DG_Name_1 = provision24Template[0][338].toString().trim();
		p24_DSC_Mail_PaperOoN_Stepped_1 = provision24Template[0][339].toString().trim();
		p24_DSC_Mail_PaperOoN_M_1 = provision24Template[0][340].toString().trim();
		p24_DSC_Mail_PaperOoN_N_1 = provision24Template[0][341].toString().trim();
		p24_DSC_Mail_PaperOoN_O_1 = provision24Template[0][342].toString().trim();
		p24_DSC_Mail_PaperOoN_Y_1 = provision24Template[0][343].toString().trim();
		p24_DSC_Mail_PaperOoN_PreferredGeneric_1 = provision24Template[0][344].toString().trim();
		p24_DSC_Mail_PaperOoN_NonPreferredGeneric_1 = provision24Template[0][345].toString().trim();
		p24_DSC_Mail_PaperOoN_PreferredBrand_1 = provision24Template[0][346].toString().trim();
		p24_DSC_Mail_PaperOoN_NonPreferredBrand_1 = provision24Template[0][347].toString().trim();
		p24_DSC_Mail_PaperOoN_DollarAmount_1 = provision24Template[0][348].toString().trim();
		p24_DSC_Mail_PaperOoN_Percent_1 = provision24Template[0][349].toString().trim();
		p24_DSC_Mail_PaperOoN_CoPayCalculation_1 = provision24Template[0][350].toString().trim();
		p24_DSC_Mail_PaperOoN_MinimumDollar_1 = provision24Template[0][351].toString().trim();
		p24_DSC_Mail_PaperOoN_MaximumDollar_1 = provision24Template[0][352].toString().trim();
		p24_DSC_Mail_PaperOoN_Reverse_1 = provision24Template[0][353].toString().trim();

		
		p24_Accumulations_MAB = provision24Template[0][356].toString();

		p24_Accumulations_M = provision24Template[0][358].toString();
		p24_Accumulations_N = provision24Template[0][359].toString();
		p24_Accumulations_O = provision24Template[0][360].toString();
		p24_Accumulations_Y = provision24Template[0][361].toString();

		p24_Accumulation_DrugList = provision24Template[0][363].toString();
		p24_Accumulation_DrugGroup = provision24Template[0][364].toString();

		p24_Accumulation_MABAmount = provision24Template[0][366].toString();
		p24_Accumulation_MABPeriod = provision24Template[0][367].toString();
		p24_Accumulation_MABMet = provision24Template[0][368].toString(); 

		
	
		}

	
}

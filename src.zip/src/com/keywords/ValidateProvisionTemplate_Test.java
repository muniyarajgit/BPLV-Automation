package com.keywords;

import java.util.ArrayList;

import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.testResultFunctions;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.FrameworkFunctions.GetReportValues;

public class ValidateProvisionTemplate_Test {



	public static String DC_Retail_DrugList_1 = "";	

	public static String strsubsection2	= null;
	public static int CountVal = 0;
	public static ArrayList FailCheck = new ArrayList();
	//Copay
	public static String planTypeRetailFieldValue_1		= null;
	public static String NumberOfTiers_1				= null;
	public static String CopayToPaper_1					= null;
	public static String TierType_1 					= null;
	public static String CRDCopayLogic_1				= null;
	public static String DollarAmount_1					= null;
	public static String DAmount_1					= null;
	public static String Percent_1 						= null;
	public static String CoPayCalculation_1				= null;
	public static String MinimunDollar_1				= null;
	//public static String MinimumDollar_1				= null;
	public static String MaximumDollar_1			= null;
	public static String NonFormularyDollarAmount_1		= null;
	public static String NonFormularyPercent_1			= null;
	public static String NonFormularyCopayCalculation_1 = null;
	public static String NonFormularyMinimumDollar_1	= null;
	public static String NonFormularyMaximumDollar_1	= null;
	public static String NonFormularyAmount_1 			= null;

	//variable declaration for SubSection Process - paper
	public static String paper_planTypeFieldValue_1  	= null;
	public static String paper_NumberOfTiers_1 			= null;
	public static String paper_CopayToPaper_1  			= null;
	public static String paper_TierType_1  				= null;
	public static String paper_DollarAmount_1  			= null;
	public static String paper_Percent_1  				= null;
	public static String paper_CoPayCalculation_1  		= null;
	public static String paper_MinimunDollar_1  		= null;
	public static String paper_MaximumDollar_1  		= null;
	public static String paper_NonFormularyDollarAmount_1 	 	= null;
	public static String paper_NonFormularyPercent_1  	  	 	= null;
	public static String paper_NonFormularyCopayCalculation_1  	= null;
	public static String paper_NonFormularyMinimumDollar_1 		= null;
	public static String paper_NonFormularyMaximumDollar_1  	= null;
	//variable declaration for SubSection Process - Paper Out of network
	public static String PaperOutOfNetwork_planTypeFieldValue_1 	= null;
	public static String PaperOutOfNetwork_NumberOfTiers_1			= null;
	public static String PaperOutOfNetwork_CopayToPaper_1 			= null;
	public static String PaperOutOfNetwork_TierType_1 				= null;
	public static String PaperOutOfNetwork_DollarAmount_1 			= null;
	public static String PaperOutOfNetwork_Percent_1 				= null;
	public static String PaperOutOfNetwork_CoPayCalculation_1 		= null;
	public static String PaperOutOfNetwork_MinimunDollar_1 			= null;
	public static String PaperOutOfNetwork_MaximumDollar_1 			= null;
	public static String PaperOutOfNetwork_NonFormularyDollarAmount_1= null;
	public static String PaperOutOfNetwork_NonFormularyPercent_1 	= null;
	public static String PaperOutOfNetwork_NonFormularyCopayCalculation_1 = null;
	public static String PaperOutOfNetwork_NonFormularyMinimumDollar_1 	  = null;
	public static String PaperOutOfNetwork_NonFormularyMaximumDollar_1 	  = null;


	//
	private static final String[][] String 				= null;
	public static String provisionNumber 				= null;
	public static String provisionLineValue				= null;
	public static String Provision_LineText 			= null;
	public static String subSection 					= null;
	public static String FieldName						= null;
	public static String strFieldName 					= null;
	//Drug Specific Copay - Speciality Tiers 
	public static String DSC_SpecialtyTiers_1      		= null;	
	public static String DSC_RetailTier;
	public static String DSC_RetailFieldValue 			= null;
	public static String strcopayNonFormularyValue		= null;
	public static String strcopayFormularyValue		= null;
	//Expected Provision Report Details
	public static GetReportValues objExcelFunc = new GetReportValues();
	// common Variable
	public static int row;
	public static int Subsection;
	//ExpectedReport Variable declarations
	public static String Rep_provisionNumber 				= null;
	public static String Rep_provisionLineValue				= null;
	public static String Rep_Provision_LineText 			= null;
	public static String Rep_subSection 					= null;
	public static String Rep_FieldName						= null;
	public static String Rep_planTypeRetailFieldValue_1		= null;
	public static String Rep_NumberOfTiers_1				= null;
	public static String Rep_CopayToPaper_1					= null;
	public static String Rep_TierType_1 					= null;
	public static String Rep_CRDCopayLogic_1				= null;
	public static String Rep_DollarAmount_1					= null;
	public static String Rep_Percent_1 						= null;
	public static String Rep_CoPayCalculation_1				= null;
	public static String Rep_MinimunDollar_1				= null;
	public static String Rep_MaximumDollar_1				= null;
	public static String Rep_NonFormularyDollarAmount_1		= null;
	public static String Rep_NonFormularyPercent_1			= null;
	public static String Rep_NonFormularyCopayCalculation_1 = null;
	public static String Rep_NonFormularyMinimumDollar_1	= null;
	public static String Rep_NonFormularyMaximumDollar_1	= null;
	//
	public static XSSFSheet xssfSheet = null;
	//
	public static String strNumberOfTierValue 			 = null;
	public static String strsubProcessValue 	 		 = null;
	public static String srtTierType			 		 = null;
	public static String strDollarAmountValue 			 = null;
	public static String strNonFormularyAmountValueOrder = null;

	public static String subsectionProcessType_Value	 = null;
	public static String DSC_FieldValue					 = null;
	public static String strCRDCopayLogic 				 = null;
	public static String DSC__DrugList					 = null;
	//public static String DC__DrugList					 = null;
	public static String planTypeCopayPresentValue    	 = null;
	public static String dsc_Subsection					 = null;
	public static String strProvisionLineValue_id		 = null;
	public static int rowCount;
	public static String DSC__DrugListSelection			 = null;
	public static ArrayList arr_ProvisionLineValue =  new ArrayList();
	public static ArrayList arrRowValue = new ArrayList();
	//Jayashree
	public static String DC_Retail_DrugListorDrugGroup_1 		= null; 
	public static String DC__DrugListDrugGroupSelection_1		= null; 

	public static String DC_Retail_DrugClass_1 		= null;
	public static String DC_Retail_IncExcl_1 		= null;
	public static String DC_ApplyLimit_1 			= null;
	public static String DC_Retail_StartAge_1 		= null;
	public static String DC_Retail_EndAge_1 		= null;
	public static String DC_Gender_1 				= null;
	public static String DC_Mindays_1 				= null;
	public static String DC_Minquantity_1 			= null;
	public static String DC_DailyDose_1 			= null;
	public static String DC_Retail_StrtAgeType_1 	= null;
	public static String DC_Retail_EnAgeType_1 		= null;
	public static String DC_Retail_Day_QuantityRule_1= null;
	public static String DC_Retail_MaxDaysperFill_1 = null;
	public static String DC_Retail_MaxDays_1 		= null;
	public static String DC_Retail_MaxFills_1 		= null;
	public static String DC_Retail_DOT1_TP_1 		= null;
	public static String DC_Retail_DOT_Days_1		= null;
	public static String DC_Retail_DOT_TV_1			= null;
	public static String DC_Retail_MaxQtyperFill_1 	= null;
	public static String DC_Retail_QOT_Qty_1 		= null;
	public static String DC_Retail_QOT_TP_1 		= null;
	public static String DC_Retail_QOT_TV_1 		= null;
	public static String DC_Retail_BypassMOOP_1 	= null;

	//Accums specific DSC
	public static String Accum_DrugSpecific_MAB    	  = null;
	public static String Accum_DrugSpecific_M      	  = null;
	public static String Accum_DrugSpecific_N      	  = null;
	public static String Accum_DrugSpecific_O      	  = null;
	public static String Accum_DrugSpecific_Y         = null;
	public static String Accum_DrugSpecific_DL        = null;
	public static String Accum_DrugSpecific_DG  	  = null;
	public static String Accum_DrugSpecific_MABAmount = null;
	public static String Accum_DrugSpecific_MABPeriod = null;
	public static String Accum_DrugSpecific_MABMet    = null;
	//

	public static String tempsubsec = "";
	public static String tempDLid = "";
	public static String tempIncExcl = "";
	public static String tempIncExclDC = "";
	public static String tempApplylimit = "";
	public static String tempStartAge = "";
	public static String tempEndAge = "";
	public static String tempGender = "";
	public static String tempMindays = "";
	public static String tempMinquantity = "";
	public static String tempDailyDose = "";
	public static String tempStartAgeType = "";
	public static String tempEndAgeType = "";
	public static String tempDay_QuantityRule = "";
	public static String tempMaxDaysperFill = "";
	public static String tempMaxDays = "";
	public static String tempMaxFills = "";
	public static String tempDOT_TP = "";
	public static String tempDOT_Days = "";
	public static String tempDOT_TV = "";
	public static String tempMaxQtyperFill = "";
	public static String tempQOT_Qty = "";
	public static String tempQOT_TP = "";
	public static String tempQOT_TV = "";
	public static String tempBypassMOOP = "";

	//DSC
	public static String tempStepped = "";
	public static String tempM = "";
	public static String tempN = "";
	public static String tempO = "";
	public static String tempY = "";
	public static String tempDollarAmount = "";
	public static String tempPercentAmount = "";
	public static String tempMindollar = "";
	public static String tempMaxdollar = "";
	public static String tempCopayCalc = "";
	public static String tempReverse = "";

	// Drug Specific CoPay - Retail Tiers 
	public static String DSC_Retail_FormularyGroup = null;
	public static String DSC_Retail_DrugList 	   = null;
	public static String DSC_Retail_Stepped 	   = null;
	public static String DSC_Retail_M 	   		   = null;
	public static String DSC_Retail_N 	  		   = null;
	public static String DSC_Retail_O 	   		   = null;
	public static String DSC_Retail_Y 	   		   = null;
	public static String DSC_Retail_DollarAmount   = null;
	public static String DSC_Retail_Percent 	   = null;
	public static String DSC_Retail_CopayCalculation= null;
	public static String DSC_Retail_MinimumDollar  = null;
	public static String DSC_Retail_MaximumDollar  = null;
	public static String DSC_Retail_Reverse 	   = null;



	public static void validateDrugCoverageDetails(String pNo,
			String LValue,
			String T_subsectionProcessType_Value,
			String T_DC_Retail_DrugListorDrugGroup_1,
			String T_DC_Retail_DrugList_1,
			String T_DC_Retail_DrugClass_1,
			String T_DC_Retail_IncExcl_1,
			String T_DC_ApplyLimit_1,
			String T_DC_Retail_StartAge_1,
			String T_DC_Retail_EndAge_1,
			String T_DC_Gender_1,
			String T_DC_Mindays_1,
			String T_DC_Minquantity_1,
			String T_DC_DailyDose_1,
			String T_DC_Retail_StrtAgeType_1,
			String T_DC_Retail_EnAgeType_1,
			String T_DC_Retail_Day_QuantityRule_1,
			String T_DC_Retail_MaxDays_1,
			String T_DC_Retail_MaxFills_1,
			String T_DC_Retail_MaxDaysperFill_1,
			String T_DC_Retail_DOT1_TP_1,
			String T_DC_Retail_DOT_Days_1,
			String T_DC_Retail_DOT_TV_1,
			String T_DC_Retail_MaxQtyperFill_1,
			String T_DC_Retail_QOT_Qty_1,
			String T_DC_Retail_QOT_TP_1,
			String T_DC_Retail_QOT_TV_1,
			String T_DC_Retail_BypassMOOP_1) throws Exception	{
		// Read Values from Template
		provisionNumber = pNo;
		provisionLineValue = LValue;
		subsectionProcessType_Value = T_subsectionProcessType_Value;
		DC_Retail_DrugListorDrugGroup_1 = T_DC_Retail_DrugListorDrugGroup_1;
		DC_Retail_DrugList_1 = T_DC_Retail_DrugList_1;
		DC_Retail_DrugClass_1 = T_DC_Retail_DrugClass_1;
		DC_Retail_IncExcl_1 = T_DC_Retail_IncExcl_1;
		DC_ApplyLimit_1 = T_DC_ApplyLimit_1;
		DC_Retail_StartAge_1 = T_DC_Retail_StartAge_1;
		DC_Retail_EndAge_1 = T_DC_Retail_EndAge_1;
		DC_Gender_1 = T_DC_Gender_1;
		DC_Mindays_1 = T_DC_Mindays_1;
		DC_Minquantity_1 = T_DC_Minquantity_1;
		DC_DailyDose_1 = T_DC_DailyDose_1;
		DC_Retail_StrtAgeType_1 = T_DC_Retail_StrtAgeType_1;
		DC_Retail_EnAgeType_1 = T_DC_Retail_EnAgeType_1;
		DC_Retail_Day_QuantityRule_1 = T_DC_Retail_Day_QuantityRule_1;
		DC_Retail_MaxDays_1 = T_DC_Retail_MaxDays_1;
		DC_Retail_MaxFills_1 = T_DC_Retail_MaxFills_1;
		DC_Retail_MaxDaysperFill_1 = T_DC_Retail_MaxDaysperFill_1;
		DC_Retail_DOT1_TP_1 = T_DC_Retail_DOT1_TP_1;
		DC_Retail_DOT_Days_1 = T_DC_Retail_DOT_Days_1;
		DC_Retail_DOT_TV_1 = T_DC_Retail_DOT_TV_1;
		DC_Retail_MaxQtyperFill_1 = T_DC_Retail_MaxQtyperFill_1;
		DC_Retail_QOT_Qty_1 = T_DC_Retail_QOT_Qty_1;
		DC_Retail_QOT_TP_1 = T_DC_Retail_QOT_TP_1;
		DC_Retail_QOT_TV_1 = T_DC_Retail_QOT_TV_1;
		DC_Retail_BypassMOOP_1 = T_DC_Retail_BypassMOOP_1;

		

		//Split and store values in array
		tempsubsec = DC_Retail_DrugListorDrugGroup_1;
		tempDLid = DC_Retail_DrugList_1;
		tempIncExclDC = DC_Retail_DrugClass_1;
		tempIncExcl = DC_Retail_IncExcl_1;
		tempApplylimit= DC_ApplyLimit_1;
		tempStartAge= DC_Retail_StartAge_1;
		tempEndAge = DC_Retail_EndAge_1; 
		tempGender= DC_Gender_1; 
		tempMindays = DC_Mindays_1;
		tempMinquantity= DC_Minquantity_1 ;
		tempDailyDose =  DC_DailyDose_1 ;
		tempStartAgeType = DC_Retail_StrtAgeType_1 ;
		tempEndAgeType = DC_Retail_EnAgeType_1 ;
		tempDay_QuantityRule =  DC_Retail_Day_QuantityRule_1 ;
		tempMaxDaysperFill = DC_Retail_MaxDaysperFill_1 ;
		tempMaxDays = DC_Retail_MaxDays_1;		
		tempMaxFills = DC_Retail_MaxFills_1;
		tempDOT_TP = DC_Retail_DOT1_TP_1;
		tempDOT_Days = DC_Retail_DOT_Days_1;
		tempDOT_TV = DC_Retail_DOT_TV_1;
		tempMaxQtyperFill = DC_Retail_MaxQtyperFill_1;
		tempQOT_Qty = DC_Retail_QOT_Qty_1;
		tempQOT_TP = DC_Retail_QOT_TP_1;
		tempQOT_TV = DC_Retail_QOT_TV_1;
		tempBypassMOOP = DC_Retail_BypassMOOP_1;		 

		System.out.println("Line Value: "+provisionLineValue);
		System.out.println("Section: "+subsectionProcessType_Value);


		if(!DC_Retail_DrugListorDrugGroup_1.equalsIgnoreCase(""))	{
			String[] DrugListSel = DC_Retail_DrugListorDrugGroup_1.split("\n");
			String[] DrugListID = DC_Retail_DrugList_1.split("\n");
			for(int i=0;i<DrugListSel.length;i++) {
				if(DrugListSel[i].equalsIgnoreCase("Drug List")) {
					DSC__DrugList = DrugListID[i];
					GetReportValues.findDrugList_DC();
					GetReportValues.getparentmapping();
					if(GetReportValues.parntMappingValueFinal != ""){
					System.out.println("DSC__DrugList : "+DSC__DrugList);
					System.out.println("drugListValueID : "+GetReportValues.drugListValueID);
					System.out.println("parntMappingValueFinal : "+GetReportValues.parntMappingValueFinal);
					for(int rowIterator=0;rowIterator<GetReportValues.row;rowIterator++)	{
						if(GetReportValues.ninthColumnValue.get(rowIterator).toString().equalsIgnoreCase(GetReportValues.parntMappingValueFinal))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Drug List"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().contains(GetReportValues.drugListValueID)) {
									testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Drug List Value", GetReportValues.drugListValueID, GetReportValues.eighthColumnValue.get(rowIterator).toString(), GetReportValues.parntMappingValueFinal, "Pass");
									System.out.println("<<< Drug List value is matched>>>>");							
								}
								else {
									testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Drug List Value", GetReportValues.drugListValueID, GetReportValues.eighthColumnValue.get(rowIterator).toString(), GetReportValues.parntMappingValueFinal, "Fail");	
								}
							}
						}

					}
					}
				}
				else
					if((DrugListSel[i].equalsIgnoreCase("Drug Group"))){
						DSC__DrugList = DrugListID[i];
						//System.out.println(DSC__DrugList);
						GetReportValues.findDrugGroupName_DC();
						GetReportValues.getparentmapping();
						if(GetReportValues.parntMappingValueFinal != ""){
						System.out.println("DSC__DrugList : "+DSC__DrugList);
						System.out.println("drugListValueID : "+GetReportValues.drugGroupListValueID);
						System.out.println("parntMappingValueFinal : "+GetReportValues.parntMappingValueFinal);
						for(int rowIterator=0;rowIterator<GetReportValues.row;rowIterator++)	{
							if(GetReportValues.ninthColumnValue.get(rowIterator).toString().equalsIgnoreCase(GetReportValues.parntMappingValueFinal))	{
								if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Drug Group"))	{
									if(GetReportValues.eighthColumnValue.get(rowIterator).toString().contains(GetReportValues.drugGroupListValueID)) {
										testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Drug Group Value", GetReportValues.drugGroupListValueID, GetReportValues.eighthColumnValue.get(rowIterator).toString(), GetReportValues.parntMappingValueFinal, "Pass");
										System.out.println("<<< Drug List value is matched>>>>");							
									}
									else {
										testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Drug Group Value", GetReportValues.drugGroupListValueID, GetReportValues.eighthColumnValue.get(rowIterator).toString(), GetReportValues.parntMappingValueFinal, "Fail");	
									}
								}
							}

						}
						}
					}

				if(GetReportValues.parntMappingValueFinal != ""){
					GetReportValues.arr_DC_MAPID.remove(GetReportValues.parntMappingValueFinal);
					if(!DC_Retail_DrugClass_1.equalsIgnoreCase(""))	
					{
						String[] IncExcl_DC = tempIncExclDC.split("\n");
						DC_Retail_DrugClass_1 = IncExcl_DC[i].trim();
						GetReportValues.getInExDCField_Value();

						if(DC_Retail_DrugClass_1.equalsIgnoreCase(GetReportValues.strDC_Retail_IncExcl_DC)) {
							
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Inclusion Exclusion Drug Class", DC_Retail_DrugClass_1, GetReportValues.strDC_Retail_IncExcl_DC, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< Inclusion Exclusion Drug Class value is matched>>>>");							
						}
						else {
							System.out.println(DC_Retail_DrugClass_1);
							System.out.println(GetReportValues.strDC_Retail_IncExcl_DC);
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Inclusion Exclusion Drug Class", DC_Retail_DrugClass_1, GetReportValues.strDC_Retail_IncExcl_DC, GetReportValues.parntMappingValueFinal, "Fail");	
						}
					}
					if(!DC_Retail_IncExcl_1.equalsIgnoreCase(""))	
					{
						String[] IncExcl = tempIncExcl.split("\n");
						DC_Retail_IncExcl_1 = IncExcl[i];
						GetReportValues.getInExField_Value();
						if(DC_Retail_IncExcl_1.equalsIgnoreCase(GetReportValues.strDC_Retail_IncExcl_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Inclusion Exclusion", DC_Retail_IncExcl_1, GetReportValues.strDC_Retail_IncExcl_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< Inclusion Exclusion value is matched>>>>");							
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Inclusion Exclusion", DC_Retail_IncExcl_1, GetReportValues.strDC_Retail_IncExcl_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}



					}
					if(!DC_ApplyLimit_1.equalsIgnoreCase(""))	
					{
						String[] ApplyLimit = tempApplylimit.split("\n");
						DC_ApplyLimit_1 = ApplyLimit[i];
						GetReportValues.getApplylimit_Value();
						if(DC_ApplyLimit_1.equalsIgnoreCase(GetReportValues.strDC_ApplyLimit_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Apply Limitations", DC_ApplyLimit_1, GetReportValues.strDC_ApplyLimit_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  Apply Limitations value is matched>>>>");							
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Apply Limitations", DC_ApplyLimit_1, GetReportValues.strDC_ApplyLimit_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}




					}
					if(!DC_Retail_StartAge_1.equalsIgnoreCase(""))	
					{
						String[] StartAge = tempStartAge.split("\n");
						DC_Retail_StartAge_1 = StartAge[i];
						GetReportValues.getStartAge_Value();
						if(DC_Retail_StartAge_1.equalsIgnoreCase(GetReportValues.strDC_Retail_StartAge_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Start Age", DC_Retail_StartAge_1, GetReportValues.strDC_Retail_StartAge_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  Start Age value is matched>>>>");							
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Start Age", DC_Retail_StartAge_1, GetReportValues.strDC_Retail_StartAge_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}





					}
					if(!DC_Retail_EndAge_1.equalsIgnoreCase(""))	
					{
						String[] EndAge = tempEndAge.split("\n");
						DC_Retail_EndAge_1  = EndAge[i];
						GetReportValues.getEndAge_Value();
						if(DC_Retail_EndAge_1.equalsIgnoreCase(GetReportValues.strDC_Retail_EndAge_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "End Age", DC_Retail_EndAge_1, GetReportValues.strDC_Retail_EndAge_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  End Age value is matched>>>>");						
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "End Age", DC_Retail_EndAge_1, GetReportValues.strDC_Retail_EndAge_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_Gender_1.equalsIgnoreCase(""))	
					{
						String[] Gender = tempGender.split("\n");
						DC_Gender_1   = Gender[i];
						GetReportValues.getGender_Value();
						if(DC_Gender_1.equalsIgnoreCase(GetReportValues.strDC_Gender_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Gender", DC_Gender_1, GetReportValues.strDC_Gender_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  Gender value is matched>>>>");						
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Gender", DC_Gender_1, GetReportValues.strDC_Gender_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_Mindays_1.equalsIgnoreCase(""))	
					{
						String[] Mindays = tempMindays.split("\n");
						DC_Mindays_1   = Mindays[i];
						GetReportValues.getMindays_Value();

						if(DC_Mindays_1.equalsIgnoreCase(GetReportValues.strDC_MinDays_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Minimum Days", DC_Mindays_1, GetReportValues.strDC_MinDays_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  Minimum Days value is matched>>>>");						
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Minimum Days", DC_Mindays_1, GetReportValues.strDC_MinDays_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}
					}
					if(!DC_Minquantity_1.equalsIgnoreCase(""))	
					{
						String[] Minquantity = tempMinquantity.split("\n");
						DC_Minquantity_1    = Minquantity[i];
						GetReportValues.getMinQty_Value();

						if(DC_Minquantity_1.equalsIgnoreCase(GetReportValues.strDC_MinQty_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Minimum quantity", DC_Minquantity_1, GetReportValues.strDC_MinQty_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  Minimum quantity value is matched>>>>");						
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Minimum quantity", DC_Minquantity_1, GetReportValues.strDC_MinQty_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_DailyDose_1.equalsIgnoreCase(""))	
					{
						String[] DailyDose = tempDailyDose.split("\n");
						DC_DailyDose_1     = DailyDose[i];
						GetReportValues.getDailyDose_Value();

						if(DC_DailyDose_1.equalsIgnoreCase(GetReportValues.strDC_DailyDose_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Daily Dose", DC_DailyDose_1, GetReportValues.strDC_DailyDose_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  Daily Dose value is matched>>>>");						
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Daily Dose", DC_DailyDose_1, GetReportValues.strDC_DailyDose_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}

					}
					if(!DC_Retail_StrtAgeType_1.equalsIgnoreCase(""))	
					{
						String[] StartAgeType = tempStartAgeType.split("\n");
						DC_Retail_StrtAgeType_1      = StartAgeType[i];
						GetReportValues.getstartagetype_Value();

						if(DC_Retail_StrtAgeType_1.equalsIgnoreCase(GetReportValues.strDC_StartAgeType_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "StartAgeType", DC_Retail_StrtAgeType_1, GetReportValues.strDC_StartAgeType_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  StartAgeType value is matched>>>>");						
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "StartAgeType", DC_Retail_StrtAgeType_1, GetReportValues.strDC_StartAgeType_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_Retail_EnAgeType_1.equalsIgnoreCase(""))	
					{
						String[] EndAgeType =  tempEndAgeType.split("\n");
						DC_Retail_EnAgeType_1       = EndAgeType[i];
						GetReportValues.getEndagetype_Value();

						if(DC_Retail_EnAgeType_1.equalsIgnoreCase(GetReportValues.strDC_EndAgeType_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "EndAgeType", DC_Retail_EnAgeType_1, GetReportValues.strDC_EndAgeType_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<<  EndAgeType value is matched>>>>");						
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "EndAgeType", DC_Retail_EnAgeType_1, GetReportValues.strDC_EndAgeType_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}
					}
					if(!DC_Retail_MaxDays_1.equalsIgnoreCase(""))	
					{
						String[] MaxDays =   tempMaxDays.split("\n");
						DC_Retail_MaxDays_1       = MaxDays[i];
						GetReportValues.getMaxDays_Value();

						if(DC_Retail_MaxDays_1.equalsIgnoreCase(GetReportValues.strDC_MaxDays_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Days", DC_Retail_MaxDays_1, GetReportValues.strDC_MaxDays_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< Maximum Days value is matched>>>>");				
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Days", DC_Retail_MaxDays_1, GetReportValues.strDC_MaxDays_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_Retail_MaxFills_1.equalsIgnoreCase(""))	
					{
						String[] MaxFills =    tempMaxFills.split("\n");
						DC_Retail_MaxFills_1       = MaxFills[i];
						GetReportValues.getMaxFills_Value();

						if(DC_Retail_MaxFills_1.equalsIgnoreCase(GetReportValues.strDC_MaxFills_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Fills", DC_Retail_MaxFills_1, GetReportValues.strDC_MaxFills_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< Maximum Fills value is matched>>>>");				
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Fills", DC_Retail_MaxFills_1, GetReportValues.strDC_MaxFills_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}



					}
					if(!DC_Retail_MaxDaysperFill_1.equalsIgnoreCase(""))	
					{
						String[] MaxDaysperFill =    tempMaxDaysperFill.split("\n");
						DC_Retail_MaxDaysperFill_1       = MaxDaysperFill[i];
						GetReportValues.getMaxDaysperfill_Value();

						if(DC_Retail_MaxDaysperFill_1.equalsIgnoreCase(GetReportValues.strDC_MaxDaysperfill_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Days per Fill", DC_Retail_MaxDaysperFill_1, GetReportValues.strDC_MaxDaysperfill_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< Maximum Days per Fill value is matched>>>>");			
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Days per Fill", DC_Retail_MaxDaysperFill_1, GetReportValues.strDC_MaxDaysperfill_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_Retail_DOT1_TP_1.equalsIgnoreCase(""))	
					{
						String[] DOT_TP =    tempMaxDaysperFill.split("\n");
						DC_Retail_DOT1_TP_1       = DOT_TP[i];
						GetReportValues.getDOTTP_Value();

						if(DC_Retail_DOT1_TP_1.equalsIgnoreCase(GetReportValues.strDC_DOTTP_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "DOT Time period", DC_Retail_DOT1_TP_1, GetReportValues.strDC_DOTTP_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< DOT Time period value is matched>>>>");			
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "DOT Time period", DC_Retail_DOT1_TP_1, GetReportValues.strDC_DOTTP_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}
					}
					if(!DC_Retail_DOT_Days_1.equalsIgnoreCase(""))	
					{
						String[] DOT_Days =    tempDOT_Days.split("\n");
						DC_Retail_DOT_Days_1       = DOT_Days[i];
						GetReportValues.getDOTDays_Value();

						if(DC_Retail_DOT_Days_1.equalsIgnoreCase(GetReportValues.strDC_DOTDays_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " DOT Days", DC_Retail_DOT_Days_1, GetReportValues.strDC_DOTDays_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< DOT Days value is matched>>>>");		
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " DOT Days", DC_Retail_DOT_Days_1, GetReportValues.strDC_DOTDays_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_Retail_DOT_TV_1.equalsIgnoreCase(""))	
					{
						String[] DOT_TV =    tempDOT_TV.split("\n");
						DC_Retail_DOT_TV_1       = DOT_TV[i];
						GetReportValues.getDOTTV_Value();
						if(DC_Retail_DOT_TV_1.equalsIgnoreCase(GetReportValues.strDC_DOTTV_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " DOT Timevalue", DC_Retail_DOT_TV_1, GetReportValues.strDC_DOTTV_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< DOT Timevalue value is matched>>>>");		
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " DOT Timevalue", DC_Retail_DOT_TV_1, GetReportValues.strDC_DOTTV_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}


					}
					if(!DC_Retail_QOT_Qty_1.equalsIgnoreCase(""))	
					{
						String[] QOT_Qty =    tempQOT_Qty.split("\n");
						DC_Retail_QOT_Qty_1       = QOT_Qty[i];
						GetReportValues.getQOTQty_Value();


						if(DC_Retail_QOT_Qty_1.equalsIgnoreCase(GetReportValues.strDC_QOTQty_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " QOT Quantity", DC_Retail_QOT_Qty_1, GetReportValues.strDC_QOTQty_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< QOT Quantity value is matched>>>>");		
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " QOT Quantity", DC_Retail_QOT_Qty_1, GetReportValues.strDC_QOTQty_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}




					}
					if(!DC_Retail_QOT_TP_1.equalsIgnoreCase(""))	
					{
						String[] QOT_TP =     tempQOT_TP.split("\n");
						DC_Retail_QOT_TP_1       = QOT_TP[i];
						GetReportValues.getQOTTP_Value();

						if(DC_Retail_QOT_TP_1.equalsIgnoreCase(GetReportValues.strDC_QOTTP_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " QOT Time period", DC_Retail_QOT_TP_1, GetReportValues.strDC_QOTTP_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< QOT Time period value is matched>>>>");		
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " QOT Time period", DC_Retail_QOT_TP_1, GetReportValues.strDC_QOTTP_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}

					}
					if(!DC_Retail_QOT_TV_1.equalsIgnoreCase(""))	
					{
						String[] QOT_TV =     tempQOT_TV.split("\n");
						DC_Retail_QOT_TV_1       = QOT_TV[i];
						GetReportValues.getQOTTV_Value();

						if(DC_Retail_QOT_TV_1.equalsIgnoreCase(GetReportValues.strDC_QOTTV_1)) {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " QOT Time value", DC_Retail_QOT_TV_1, GetReportValues.strDC_QOTTV_1, GetReportValues.parntMappingValueFinal, "Pass");
							System.out.println("<<< QOT Time value is matched>>>>");		
						}
						else {
							testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, " QOT Time value", DC_Retail_QOT_TV_1, GetReportValues.strDC_QOTTV_1, GetReportValues.parntMappingValueFinal, "Fail");	
						}

					}
				//}




			}
			}
		}

	}


		

	public static void validateCopaySubSectionProcess(String pNo,
			String LValue,
			String T_subsectionProcessType_Value,
			String T_planTypePresent,
			String T_NumberOfTiers_1 ,
			String T_TierType_1,
			String T_strCRDCopayLogic,
			String T_DAmount_1,
			String T_Percent_1,
			String T_CoPayCalculation_1,
			String T_MinimunDollar_1,
			String T_MaximumDollar_1,
			String T_NonFormularyDollarAmount_1,
			String T_NonFormularyPercent_1,
			String T_NonFormularyCopayCalculation_1,
			String T_NonFormularyMinimumDollar_1,
			String T_NonFormularyMaximumDollar_1) throws Exception	{



		subsectionProcessType_Value = T_subsectionProcessType_Value;

		provisionNumber = pNo;
		provisionLineValue = LValue;

		System.out.println("Line Value: "+provisionLineValue);
		System.out.println("Section: "+subsectionProcessType_Value);


		if(subsectionProcessType_Value.equalsIgnoreCase("Retail") || subsectionProcessType_Value.equalsIgnoreCase("Mail") || subsectionProcessType_Value.equalsIgnoreCase("Paper") || subsectionProcessType_Value.equalsIgnoreCase("Paper Out of Network"))	{
			planTypeCopayPresentValue = T_planTypePresent;
			NumberOfTiers_1  = T_NumberOfTiers_1 ;
			TierType_1 = T_TierType_1;
			strCRDCopayLogic = T_strCRDCopayLogic;
			DAmount_1 = T_DAmount_1;
			Percent_1 = T_Percent_1;
			CoPayCalculation_1 = T_CoPayCalculation_1;
			MinimunDollar_1 = T_MinimunDollar_1;
			MaximumDollar_1 = T_MaximumDollar_1;
			NonFormularyDollarAmount_1 = T_NonFormularyDollarAmount_1;
			NonFormularyPercent_1 = T_NonFormularyPercent_1;
			NonFormularyAmount_1 = T_NonFormularyPercent_1;
			NonFormularyCopayCalculation_1 = T_NonFormularyCopayCalculation_1;
			NonFormularyMinimumDollar_1 = T_NonFormularyMinimumDollar_1;
			NonFormularyMaximumDollar_1 = T_NonFormularyMaximumDollar_1;
			//				System.out.println("NonFormularyMaximumDollar_1 : " + planTypeRetailFieldValue_1);

			strcopayNonFormularyValue = "";
			if(subsectionProcessType_Value.equalsIgnoreCase("Retail")||subsectionProcessType_Value.equalsIgnoreCase("Mail") || subsectionProcessType_Value.equalsIgnoreCase("Paper"))	{
				if(!NonFormularyDollarAmount_1.equalsIgnoreCase(""))	{	
					if(NonFormularyDollarAmount_1.contains(".")){
						if(NonFormularyDollarAmount_1.endsWith("0"))
						{
							
						}else{
							NonFormularyDollarAmount_1 =NonFormularyDollarAmount_1+"0";
							System.out.println("TEST::"+NonFormularyDollarAmount_1);
						}
						
					}else{
						NonFormularyDollarAmount_1 =NonFormularyDollarAmount_1+".00";	
					}
				}
				if(!NonFormularyPercent_1.equalsIgnoreCase(""))	{
					if(NonFormularyPercent_1.contains(".")){
						if(NonFormularyPercent_1.endsWith("0"))
						{
							
						}else{
							NonFormularyPercent_1 =NonFormularyPercent_1+"0";
						}
					}else{
					NonFormularyPercent_1 =NonFormularyPercent_1+".00";
					}
				}
				if(!NonFormularyCopayCalculation_1.equalsIgnoreCase(""))	{
					if(NonFormularyCopayCalculation_1.contains(".")){
						if(NonFormularyCopayCalculation_1.endsWith("0"))
						{
							
						}else{
							NonFormularyCopayCalculation_1 =NonFormularyCopayCalculation_1+"0";
						}
					}else{
						NonFormularyCopayCalculation_1 =NonFormularyCopayCalculation_1+".00";
					}
				}
				if(!NonFormularyMinimumDollar_1.equalsIgnoreCase(""))	{
					if(NonFormularyMinimumDollar_1.contains(".")){
						if(NonFormularyMinimumDollar_1.endsWith("0"))
						{
							
						}else{
							NonFormularyMinimumDollar_1 =NonFormularyMinimumDollar_1+"0";
						}
					}else{
					NonFormularyMinimumDollar_1 =NonFormularyMinimumDollar_1+".00";
					}
				}
				if(!NonFormularyMaximumDollar_1.equalsIgnoreCase(""))	{
					if(NonFormularyMaximumDollar_1.contains(".")){
						if(NonFormularyMaximumDollar_1.endsWith("0"))
						{
							
						}else{
							NonFormularyMaximumDollar_1 =NonFormularyMaximumDollar_1+"0";
						}
					}else{
					NonFormularyMaximumDollar_1 =NonFormularyMaximumDollar_1+".00";
					}
				}
				if(!NonFormularyDollarAmount_1.equalsIgnoreCase("") || !NonFormularyPercent_1.equalsIgnoreCase("") || !NonFormularyCopayCalculation_1.equalsIgnoreCase("") || !NonFormularyMinimumDollar_1.equalsIgnoreCase("") || !NonFormularyMaximumDollar_1.equalsIgnoreCase("")) {
					strcopayNonFormularyValue = NonFormularyDollarAmount_1+","+NonFormularyPercent_1+","+NonFormularyMinimumDollar_1+","+NonFormularyMaximumDollar_1+","+NonFormularyCopayCalculation_1;
					System.out.println("TEST::"+strcopayNonFormularyValue);
				}

			}	
			else if(subsectionProcessType_Value.equalsIgnoreCase("Paper") || subsectionProcessType_Value.equalsIgnoreCase("Paper Out of Network")){
				if(!NonFormularyDollarAmount_1.equalsIgnoreCase(""))	{
					if(NonFormularyDollarAmount_1.contains(".")){
						if(NonFormularyDollarAmount_1.endsWith("0"))
						{
							
						}else{
							NonFormularyDollarAmount_1 =NonFormularyDollarAmount_1+"0";
						}
					}else{
					NonFormularyDollarAmount_1 =NonFormularyDollarAmount_1+".00";
					}
				}
				if(!NonFormularyAmount_1.equalsIgnoreCase(""))	{
					if(NonFormularyAmount_1.contains(".")){
						if(NonFormularyAmount_1.endsWith("0"))
						{
							
						}else{
							NonFormularyAmount_1 =NonFormularyAmount_1+"0";
						}
					}else{
					NonFormularyAmount_1 =NonFormularyAmount_1+".00";
					}
				}
				if(!NonFormularyCopayCalculation_1.equalsIgnoreCase(""))	{
					if(NonFormularyCopayCalculation_1.contains(".")){
						if(NonFormularyCopayCalculation_1.endsWith("0"))
						{
							
						}else{
							NonFormularyCopayCalculation_1 =NonFormularyCopayCalculation_1+"0";
						}
					}else{
					NonFormularyCopayCalculation_1 =NonFormularyCopayCalculation_1+".00";
					}
				}
				if(!NonFormularyMinimumDollar_1.equalsIgnoreCase(""))	{
					if(NonFormularyMinimumDollar_1.contains(".")){
						if(NonFormularyMinimumDollar_1.endsWith("0"))
						{
							
						}else{
							NonFormularyMinimumDollar_1 =NonFormularyMinimumDollar_1+"0";
						}
					}else{
					NonFormularyMinimumDollar_1 =NonFormularyMinimumDollar_1+".00";
					}
				}
				if(!NonFormularyMaximumDollar_1.equalsIgnoreCase(""))	{
					if(NonFormularyMaximumDollar_1.contains(".")){
						if(NonFormularyMaximumDollar_1.endsWith("0"))
						{
							
						}else{
							NonFormularyMaximumDollar_1 =NonFormularyMaximumDollar_1+"0";
						}
					}else{
					NonFormularyMaximumDollar_1 =NonFormularyMaximumDollar_1+".00";
					}
				}
				if(!NonFormularyDollarAmount_1.equalsIgnoreCase("") || !NonFormularyAmount_1.equalsIgnoreCase("") || !NonFormularyCopayCalculation_1.equalsIgnoreCase("") || !NonFormularyMinimumDollar_1.equalsIgnoreCase("") || !NonFormularyMaximumDollar_1.equalsIgnoreCase("")) {
					strcopayNonFormularyValue = NonFormularyDollarAmount_1+","+NonFormularyAmount_1+","+NonFormularyMinimumDollar_1+","+NonFormularyMaximumDollar_1+","+NonFormularyCopayCalculation_1;					
				}
			}
			if(!subsectionProcessType_Value.equalsIgnoreCase(""))	{
				int MapCountTest = GetReportValues.MapCountVal;
				CountVal = 0;
				
				for(int MapCount =0; MapCount<MapCountTest; MapCount++){
					FailCheck.clear();
					CountVal = MapCount;
					//if(CountVal == 0 || ValidateProvisionTemplate_Test.FailCheck.contains("Fail"))
					{
				Validate_Copay();
				
				GetReportValues.getCopayValues();
				GetReportValues.arrMAPID_Copay.remove(GetReportValues.ParentMapVal);
if(!GetReportValues.ParentMapVal.equals("")){ /*
	testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Mail Number of Tiers", "Use Copay Logic", "", GetReportValues.ParentMapVal, "Fail");
	testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Tier Type", "Use Copay Logic", "", GetReportValues.ParentMapVal, "Fail");

}else{
				testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Mail Number of Tiers", "Use Copay Logic", GetReportValues.strNumberOfTierValue, GetReportValues.ParentMapVal, "Pass");
				testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Tier Type", "Use Copay Logic", GetReportValues.srtTierType, GetReportValues.ParentMapVal, "Pass");
				FailCheck.add("Fail");
}	*/	

//
if(!T_NumberOfTiers_1.equalsIgnoreCase("")){
if(GetReportValues.strNumberOfTierValue.equalsIgnoreCase(GetReportValues.strNumberOfTierValue)) {
	testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Mail Number of Tiers", "Use Copay Logic", GetReportValues.strNumberOfTierValue, GetReportValues.ParentMapVal, "Pass");
	System.out.println("Field Name: Mail Number of Tiers\t<<matched>>");
}
else {
	testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Mail Number of Tiers", "Use Copay Logic", GetReportValues.strNumberOfTierValue, GetReportValues.ParentMapVal, "Fail");
	System.out.println("Field Name: Mail Number of Tiers\t<<not matched>>");
	FailCheck.add("Fail");
}
}

if(!T_TierType_1.equalsIgnoreCase("")){
if(GetReportValues.srtTierType.equalsIgnoreCase(GetReportValues.srtTierType)) {
	testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Tier Type", "Use Copay Logic", GetReportValues.srtTierType, GetReportValues.ParentMapVal, "Pass");
	System.out.println("Field Name: Mail Number of Tiers\t<<matched>>");
}
else {
	testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Tier Type", "Use Copay Logic", GetReportValues.srtTierType, GetReportValues.ParentMapVal, "Fail");
	System.out.println("Field Name: Tier Type\t<<not matched>>");
	FailCheck.add("Fail");
}
}
//


				if(!strCRDCopayLogic.equalsIgnoreCase("")) {
					if(GetReportValues.CRDCopayLogic.equalsIgnoreCase(strCRDCopayLogic)) {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Pass");
						System.out.println("Field Name: CRD Copay Logic\t<<matched>>");
					}
					else {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CRD Copay Logic", strCRDCopayLogic, GetReportValues.CRDCopayLogic, GetReportValues.ParentMapVal, "Fail");
						System.out.println("Field Name: CRD Copay Logic\t<<not matched>>");
						FailCheck.add("Fail");
					}					
				}

				if(!DAmount_1.equalsIgnoreCase("")) {
					System.out.println("DAmount_1 : "+DAmount_1);
					System.out.println("strDollarAmountValue : "+GetReportValues.strDollarAmountValue);

				//	if(GetReportValues.strDollarAmountValue.equalsIgnoreCase(DAmount_1)) {
					if(DAmount_1.contains(GetReportValues.strDollarAmountValue)&& (!GetReportValues.strDollarAmountValue.equals(""))) {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Dollar Amount", DAmount_1, GetReportValues.strDollarAmountValue, GetReportValues.ParentMapVal, "Pass");
						System.out.println("Field Name: Dollar Amount\t<<matched>>");
					}
					else {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Dollar Amount", DAmount_1, GetReportValues.strDollarAmountValue, GetReportValues.ParentMapVal, "Fail");
						System.out.println("Field Name: Dollar Amount\t<<not matched>>");
						FailCheck.add("Fail");
					}					
				}

				if(!Percent_1.equalsIgnoreCase("")) {
					if(GetReportValues.strPercentRepo.equalsIgnoreCase(Percent_1)) {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Percent", Percent_1, GetReportValues.strPercentRepo, GetReportValues.ParentMapVal, "Pass");
						System.out.println("Field Name: Percent\t<<matched>>");
					}
					else {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Percent", Percent_1, GetReportValues.strPercentRepo, GetReportValues.ParentMapVal, "Fail");
						System.out.println("Field Name: Percent\t<<not matched>>");
						FailCheck.add("Fail");
					}					
				}

				if(!CoPayCalculation_1.equalsIgnoreCase("")) {
					if(GetReportValues.strCopayCalculationreport.equalsIgnoreCase(CoPayCalculation_1)) {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CoPay Calculation", CoPayCalculation_1, GetReportValues.strCopayCalculationreport, GetReportValues.ParentMapVal, "Pass");
						System.out.println("Field Name: CoPay Calculation\t<<matched>>");
					}
					else {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "CoPay Calculation", CoPayCalculation_1, GetReportValues.strCopayCalculationreport, GetReportValues.ParentMapVal, "Fail");
						System.out.println("Field Name: CoPay Calculation\t<<not matched>>");
						FailCheck.add("Fail");
					}					
				}

				if(!MinimunDollar_1.equalsIgnoreCase("")) {
					if(MinimunDollar_1.contains(GetReportValues.strmindollarreport)&&(!GetReportValues.strmindollarreport.equals(""))) {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Minimum Dollar", MinimunDollar_1, GetReportValues.strmindollarreport, GetReportValues.ParentMapVal, "Pass");
						System.out.println("Field Name: Minimum Dollar\t<<matched>>");
					}
					else {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Minimum Dollar", MinimunDollar_1, GetReportValues.strmindollarreport, GetReportValues.ParentMapVal, "Fail");
						System.out.println("Field Name: Minimum Dollar\t<<not matched>>");
						FailCheck.add("Fail");
					}					
				}

				if(!MaximumDollar_1.equalsIgnoreCase("")) {
					if(MaximumDollar_1.contains(GetReportValues.strmaxdollarreport)&&(!GetReportValues.strmaxdollarreport.equals(""))) {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Dollar", MaximumDollar_1, GetReportValues.strmaxdollarreport, GetReportValues.ParentMapVal, "Pass");
						System.out.println("Field Name: Maximum Dollar\t<<matched>>");
					}
					else {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "Maximum Dollar", MaximumDollar_1, GetReportValues.strmaxdollarreport, GetReportValues.ParentMapVal, "Fail");
						System.out.println("Field Name: Maximum Dollar\t<<not matched>>");
						FailCheck.add("Fail");
					}					
				}

				if(!strcopayNonFormularyValue.equalsIgnoreCase("")) {
					if(GetReportValues.strNonFormularyAmountValueOrder.equalsIgnoreCase(strcopayNonFormularyValue)) {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "NonFormulary order", strcopayNonFormularyValue, GetReportValues.strNonFormularyAmountValueOrder, GetReportValues.ParentMapVal, "Pass");
						System.out.println("Field Name: NonFormulary order\t<<matched>>");
					}
					else {
						testResultFunctions.set_custom_message_in_Report_Test("", pNo, LValue, T_subsectionProcessType_Value, "NonFormulary order", strcopayNonFormularyValue, GetReportValues.strNonFormularyAmountValueOrder, GetReportValues.ParentMapVal, "Fail");
						System.out.println("Field Name: NonFormulary order\t<<not matched>>");
						FailCheck.add("Fail");
					}					
				}
}

				System.out.println("\n\n");

			}
		}	
		}
		}
	}



	public static void validateAccumulationsDrugSpecific(String PNo,String LValue, String T_Accum_DrugSpecific_MAB,
			String T_Accum_DrugSpecific_M,
			String T_Accum_DrugSpecific_N,
			String T_Accum_DrugSpecific_O,
			String T_Accum_DrugSpecific_Y,
			String T_Accum_DrugSpecific_DL,
			String T_Accum_DrugSpecific_DG,
			String T_Accum_DrugSpecific_MABAmount,
			String T_Accum_DrugSpecific_MABPeriod,
			String T_Accum_DrugSpecific_MABMet) throws Exception  {
        
		Accum_DrugSpecific_MAB = T_Accum_DrugSpecific_MAB;
		Accum_DrugSpecific_M = T_Accum_DrugSpecific_M;
		Accum_DrugSpecific_N = T_Accum_DrugSpecific_N;
		Accum_DrugSpecific_O = T_Accum_DrugSpecific_O;
		Accum_DrugSpecific_Y = T_Accum_DrugSpecific_Y;
		Accum_DrugSpecific_DL = T_Accum_DrugSpecific_DL;
		Accum_DrugSpecific_DG = T_Accum_DrugSpecific_DG;
		Accum_DrugSpecific_MABAmount = T_Accum_DrugSpecific_MABAmount;
		Accum_DrugSpecific_MABPeriod = T_Accum_DrugSpecific_MABPeriod;
		Accum_DrugSpecific_MABMet = T_Accum_DrugSpecific_MABMet;		
                                          
        DSC__DrugList = Accum_DrugSpecific_DL;
        
        GetReportValues.findDrugList();
        GetReportValues.getAccumulationsDrugSpecific();
                                       
        
        if(!Accum_DrugSpecific_MAB.equalsIgnoreCase("")){
               System.out.println("Are there any drug specific MAB?  is matched");
        }
        
        Thread.sleep(1000);
        if(!Accum_DrugSpecific_M.equalsIgnoreCase("")){
               System.out.println("Accum Drug Specific- M  is matched");
        }
        
        Thread.sleep(1000);
        if(!Accum_DrugSpecific_N.equalsIgnoreCase("")){
               System.out.println("Accum Drug Specific- N  is matched");
        }
        
        Thread.sleep(1000);
        if(!Accum_DrugSpecific_O.equalsIgnoreCase("")){
               System.out.println("Accum Drug Specific- O  is matched");
        }
        
        Thread.sleep(1000);
        if(!Accum_DrugSpecific_Y.equalsIgnoreCase("")){
               System.out.println("Accum Drug Specific- Y  is matched");
        }
        
    
        if(!Accum_DrugSpecific_MABAmount.equalsIgnoreCase("")){
     	       System.out.println("MAB Amount  is matched");
        }
        
       
        if(!Accum_DrugSpecific_MABPeriod.equalsIgnoreCase("")){
     	   Thread.sleep(3000);
               System.out.println("MAB Period  is matched");
        }
       
        if(!Accum_DrugSpecific_MABMet.equalsIgnoreCase("")){
     	   Thread.sleep(3000);
               System.out.println("What happens when MAB is met? is matched");
        }
        
         if(!Accum_DrugSpecific_DL.equalsIgnoreCase("")){
     	       System.out.println("Accum Drug Specific- Drug List is matched");
        }
        
}          


	//Drug specific copay
	public static void validateDrugSpecificCopayDetails(String PNo,String LValue,String T_subsectionProcessType_Value,String T_DSC_RetailFieldValue,String T_DSC_Retail_FormularyGroup,String T_DSC__DrugListSelection,String T_DSC__DrugList,String T_DSC_Retail_Stepped,String T_DSC_Retail_M,String T_DSC_Retail_N,String T_DSC_Retail_O,String T_DSC_Retail_Y,String T_DSC_Retail_DollarAmount,String T_DSC_Retail_Percent,String T_DSC_Retail_CopayCalculation,String T_DSC_Retail_MinimumDollar,String T_DSC_Retail_MaximumDollar,String T_DSC_Retail_Reverse) throws Exception	
	{

		provisionNumber = PNo;
		provisionLineValue = LValue;		
		subsectionProcessType_Value = T_subsectionProcessType_Value;
		DSC_RetailFieldValue = T_DSC_RetailFieldValue;

		DSC_Retail_FormularyGroup	= T_DSC_Retail_FormularyGroup;		
		DSC__DrugList  		   				 = T_DSC__DrugList;
		DSC__DrugListSelection	   			 = T_DSC__DrugListSelection;
		DSC_Retail_Stepped		 		   	 = T_DSC_Retail_Stepped;
		DSC_Retail_M		 		  	 	 = T_DSC_Retail_M;
		DSC_Retail_N		 		   		 = T_DSC_Retail_N;
		DSC_Retail_O		 		   		 = T_DSC_Retail_O;
		DSC_Retail_Y		 		   		 = T_DSC_Retail_Y;
		DSC_Retail_DollarAmount		 	   	 = T_DSC_Retail_DollarAmount;
		DSC_Retail_Percent		 		   	 = T_DSC_Retail_Percent;
		DSC_Retail_CopayCalculation		   	 = T_DSC_Retail_CopayCalculation;
		DSC_Retail_MinimumDollar		   	 = T_DSC_Retail_MinimumDollar;
		DSC_Retail_MaximumDollar		   	 = T_DSC_Retail_MaximumDollar;
		DSC_Retail_Reverse		 		   	 = T_DSC_Retail_Reverse;



		Validate_DSC();

		//		String value2 = "";


		tempStepped = DSC_Retail_Stepped;
		tempM = DSC_Retail_M;
		tempN = DSC_Retail_N;
		tempO = DSC_Retail_O;
		tempY = DSC_Retail_Y;
		tempDollarAmount = DSC_Retail_DollarAmount;
		tempPercentAmount = DSC_Retail_Percent;
		tempMindollar = DSC_Retail_MinimumDollar;
		tempMaxdollar = DSC_Retail_MaximumDollar;
		tempCopayCalc = DSC_Retail_CopayCalculation;
		tempReverse = DSC_Retail_Reverse;

		String value2 = "";
		String[] data = DSC_Retail_FormularyGroup.split("\n");
		for(int i=0;i<data.length;i++)	{
			value2 = value2.trim().replaceAll("\\s", "")+data[i].trim().replaceAll("\\s", "")+";";
		}
		DSC_Retail_FormularyGroup = value2;
		if(DSC_Retail_FormularyGroup.endsWith(";"))	{
			DSC_Retail_FormularyGroup = DSC_Retail_FormularyGroup.substring(0,DSC_Retail_FormularyGroup.length()-1).trim();
		}


		GetReportValues.getFormularyId();
		if(!DSC__DrugListSelection.equalsIgnoreCase(""))	
		{
			String[] DrugListSel = DSC__DrugListSelection.split("\n");
			String[] DrugListID = DSC__DrugList.split("\n");
			for(int i=0;i<DrugListSel.length;i++) {
				if(DrugListSel[i].equalsIgnoreCase("Drug List") || DrugListSel[i].contains("Drug List")) {
					DSC__DrugList = DrugListID[i];
					GetReportValues.findDrugList();
					GetReportValues.getParentMappingValue();					
					for(int formularyIteraor= 0; formularyIteraor<GetReportValues.row;formularyIteraor++)	{
						if(GetReportValues.ninthColumnValue.get(formularyIteraor).equalsIgnoreCase(GetReportValues.parntMappingValueFinal)) {
							if(GetReportValues.eighthColumnValue.get(formularyIteraor).equalsIgnoreCase(GetReportValues.drugListValueID))
								System.out.println("LV: "+provisionLineValue+"\tSection: "+subsectionProcessType_Value+"\tField Name: Drug List\tMatched");
						}
					}


				}
				else if(DrugListSel[i].equalsIgnoreCase("Drug Group")) {
					DSC__DrugList = DrugListID[i];
					GetReportValues.findDrugGroupName();
					GetReportValues.getParentMappingValue();

				}
				if(!tempStepped.equalsIgnoreCase(""))	
				{
					String[] DSC_Stepped = tempStepped.split("\n");
					DSC_Retail_Stepped = DSC_Stepped[i];
					GetReportValues.getStepped_Value();
					//					System.out.println("DSC_Retail_Stepped : "+DSC_Retail_Stepped);
					//					System.out.println("strsteppedCopay : "+GetReportValues.strsteppedCopay);


				}
				if(!tempM.equalsIgnoreCase(""))	
				{
					String[] DSC_M = tempM.split("\n");
					DSC_Retail_M = DSC_M[i];
					GetReportValues.getM_Value();
					//					System.out.println("DSC_Retail_M : "+DSC_Retail_M);
					//					System.out.println("strM_Value : "+GetReportValues.strM_Value);

				}
				if(!tempN.equalsIgnoreCase(""))	
				{
					String[] DSC_N = tempN.split("\n");
					DSC_Retail_N = DSC_N[i];
					GetReportValues.getN_Value();
					//					System.out.println("DSC_Retail_N : "+DSC_Retail_N);
					//					System.out.println("strN_Value : "+GetReportValues.strN_Value);

				}
				if(!tempO.equalsIgnoreCase(""))	
				{
					String[] DSC_O = tempO.split("\n");
					DSC_Retail_O = DSC_O[i];
					GetReportValues.getO_Value();
					//					System.out.println("DSC_Retail_O : "+DSC_Retail_O);
					//					System.out.println("strO_Value : "+GetReportValues.strO_Value);

				}
				if(!tempY.equalsIgnoreCase(""))	
				{
					String[] DSC_Y = tempY.split("\n");
					DSC_Retail_Y = DSC_Y[i];
					GetReportValues.getY_Value();
					//					System.out.println("DSC_Retail_Y : "+DSC_Retail_Y);
					//					System.out.println("strY_Value : "+GetReportValues.strY_Value);					
				}
				if(!tempDollarAmount.equalsIgnoreCase(""))  
				{
					String[] DSC_Dollar = tempDollarAmount.split("\n");
					DSC_Retail_DollarAmount = DSC_Dollar[i];
					GetReportValues.getDollarAmount_Value();
					//					System.out.println("DSC_Retail_DollarAmount : "+DSC_Retail_DollarAmount);
					//					System.out.println("strDollarAmount_Value : "+GetReportValues.strDollarAmount_Value);					

				}
				if(!tempPercentAmount.equalsIgnoreCase(""))  
				{
					String[] DSC_Percent = tempPercentAmount.split("\n");
					DSC_Retail_Percent = DSC_Percent[i];
					GetReportValues.getPercent_Value();
					//					System.out.println("DSC_Retail_Percent : "+DSC_Retail_Percent);
					//					System.out.println("DSC_Retail_Percent : "+GetReportValues.strPercent_Value);					

				}
				if(!tempMindollar.equalsIgnoreCase(""))  
				{
					String[] DSC_Mindollar = tempMindollar.split("\n");
					DSC_Retail_MinimumDollar = DSC_Mindollar[i];
					GetReportValues.getMindollar_Value();
					//					System.out.println("DSC_Retail_MinimumDollar : "+DSC_Retail_MinimumDollar);
					//					System.out.println("strMinimumDollar_Value : "+GetReportValues.strMinimumDollar_Value);					

				}
				if(!tempMaxdollar.equalsIgnoreCase(""))  
				{
					String[] DSC_Maxdollar = tempMaxdollar.split("\n");
					DSC_Retail_MaximumDollar = DSC_Maxdollar[i];
					GetReportValues.getMaxdollar_Value();
					//					System.out.println("DSC_Retail_MaximumDollar : "+DSC_Retail_MaximumDollar);
					//					System.out.println("strMaximumDollar_Value : "+GetReportValues.strMaximumDollar_Value);					

				}
				if(!tempCopayCalc.equalsIgnoreCase(""))  
				{
					String[] DSC_Copaycalc = tempCopayCalc.split("\n");
					DSC_Retail_CopayCalculation = DSC_Copaycalc[i];
					GetReportValues.getCopaycalc_Value();
					//					System.out.println("DSC_Retail_CopayCalculation : "+DSC_Retail_CopayCalculation);
					//					System.out.println("CRDCopayLogic : "+GetReportValues.CRDCopayLogic);					

				}
				if(!tempReverse.equalsIgnoreCase(""))  
				{
					String[] DSC_Reverse = tempCopayCalc.split("\n");
					DSC_Retail_Reverse = DSC_Reverse[i];
					GetReportValues.getReverse_Value();
					//					System.out.println("DSC_Retail_Reverse : "+DSC_Retail_Reverse);
					//					System.out.println("strReverse : "+GetReportValues.strReverse);					

				}

			}
		}

	}

	public static void Validate_Copay()
	{
		for(int rowIterator=0;rowIterator<GetReportValues.row;rowIterator++)	{
			if(GetReportValues.ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+provisionNumber+"L"+provisionLineValue))	{
				if(GetReportValues.sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRD__c"))	{
					if(GetReportValues.tenthColumnValue.get(rowIterator).toString().contains("Creates CRD"))	{

						if(subsectionProcessType_Value.equalsIgnoreCase("Retail") && GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Plan Type: Retail"))	{
							if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.planTypeCopayPresentValue))	{
								System.out.println("Field Name: Plan Type Retail\t<<matched>>");
								strsubProcessValue = GetReportValues.eighthColumnValue.get(rowIterator).toString();
							}
						}	

						else if(subsectionProcessType_Value.equalsIgnoreCase("Mail") && GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Plan Types: Mail"))	{
							if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.planTypeCopayPresentValue))	{
								System.out.println("Field Name: Plan Type Mail\t<<matched>>");
								strsubProcessValue =  planTypeCopayPresentValue;
							}
						}

						else if(subsectionProcessType_Value.equalsIgnoreCase("Paper") && GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Plan Types: Paper"))	{
							if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.planTypeCopayPresentValue))	{
								System.out.println("Field Name: Plan Type Paper\t<<matched>>");
								strsubProcessValue =  planTypeCopayPresentValue;
							}
						}

						else if(subsectionProcessType_Value.equalsIgnoreCase("PaperOutOfNetwork") && GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Plan Types:Paper Out of Network"))	{
							if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(ValidateProvisionTemplate_Test.planTypeCopayPresentValue))	{
								System.out.println("Field Name: Plan Type Paper OoN\t<<matched>>");
								strsubProcessValue =  planTypeCopayPresentValue;
							}
						}							

					}	
				}

			}	
		}

	}


	public static void Validate_DSC()	
	{


		for(int rowIterator=0;rowIterator<GetReportValues.row;rowIterator++)	{			
			if(GetReportValues.ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+provisionNumber+"L"+provisionLineValue))	{
				if(GetReportValues.sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRD__c"))	{
					if(GetReportValues.tenthColumnValue.get(rowIterator).toString().contains("Creates CRD"))	{
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail")){
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Retail copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										System.out.println("Field Name: Any DSC\tMatched");
										strsubsection2 = DSC_RetailFieldValue;
									}
								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Mail copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Field Name: Any DSC\tMatched");
									}
								}
							}
						}

						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyTiers"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Field Name: Any DSC\tMatched");
									}
								}
							}
						}	
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOutOfNetwork"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty OON copays"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Field Name: Any DSC\tMatched");
									}

								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperTiers"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Field Name: Any DSC\tMatched");
									}

								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOutOfNetwork"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper Out of Network copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Field Name: Any DSC\tMatched");
									}

								}
							}
						}							
					}
				}	
			}
		}
	}

}


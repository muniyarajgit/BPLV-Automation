package com.keywords;

import org.testng.annotations.Test;

public class getTemplateValues  {
	
	
	

	public static void getProvision13TemplateVlaues(Object[][] provision13Template)     {

		System.out.println("\n\n\n");
		
		}

	
}

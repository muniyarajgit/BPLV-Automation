package com.keywords;



import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.FrameworkFunctions.GetReportValues;
import com.framework.BPLV_Functions;
import com.framework.commonExcelFunctions;
import com.FrameworkFunctions.ExcelUtils;
import com.keywords.getTemplateValues_13;
import com.FrameworkFunctions.GetReportValues;
import com.FrameworkFunctions.GetReportValues;
//import com.FrameworkFunctions.GetReportValues_1;

public class ValidateProvisionTemplate_13 {
	
	public static String provisionNumber 				= null;
	public static String provisionLineValue				= null;
	public static String Provision_LineText 			= null;
	public static String subsectionProcessType_Value 	= null;
	public static String DSC_RetailFieldValue 	= null;
	public static String strsubsection2 	= null;
	
	//DSC
		public static String tempStepped = "";
		public static String tempM = "";
		public static String tempN = "";
		public static String tempO = "";
		public static String tempY = "";
		public static String tempDollarAmount = "";
		public static String tempPercentAmount = "";
		public static String tempMindollar = "";
		public static String tempMaxdollar = "";
		public static String tempCopayCalc = "";
		public static String tempReverse = "";
		
		// Drug Specific CoPay - Retail Tiers 
		public static String DSC_Mail_FormularyGroup = null;
		public static String DSC_Mail_DrugList 	   = null;
		public static String DSC_Mail_DrugListSelection 	   = null;
		public static String DSC_Mail_Stepped 	   = null;
		public static String DSC_Mail_M 	   		   = null;
		public static String DSC_Mail_N 	  		   = null;
		public static String DSC_Mail_O 	   		   = null;
		public static String DSC_Mail_Y 	   		   = null;
		public static String DSC_Mail_DollarAmount   = null;
		public static String DSC_Mail_Percent 	   = null;
		public static String DSC_Mail_CopayCalculation= null;
		public static String DSC_Mail_MinimumDollar  = null;
		public static String DSC_Mail_MaximumDollar  = null;
	
	public static void validateDrugSpecificCopayDetails(String PNo,String LValue,String T_subsectionProcessType_Value,String T_DSC_MailFieldValue,String T_DSC_Mail_FormularyGroup,String T_DSC_Mail_DrugListSelection,String T_DSC_Mail_DrugList,String T_DSC_Mail_Stepped,String T_DSC_Mail_M,String T_DSC_Mail_N,String T_DSC_Mail_O,String T_DSC_Mail_Y,String T_DSC_Mail_DollarAmount,String T_DSC_Mail_Percent,String T_DSC_Mail_CopayCalculation,String T_DSC_Mail_MinimumDollar,String T_DSC_Mail_MaximumDollar){
		System.out.println("Provision Number :"+PNo);
		System.out.println("PV LineValue: "+LValue);
		System.out.println("Sub Section Process Type: "+T_subsectionProcessType_Value);
				
		//Splitting 
		
		provisionNumber = PNo;
		provisionLineValue = LValue;		
		subsectionProcessType_Value = T_subsectionProcessType_Value;
		DSC_RetailFieldValue = T_DSC_MailFieldValue;
		
		DSC_Mail_FormularyGroup	= T_DSC_Mail_FormularyGroup;		
		DSC_Mail_DrugList  		   				 = T_DSC_Mail_DrugList;
		DSC_Mail_DrugListSelection	   			 = T_DSC_Mail_DrugListSelection;
		DSC_Mail_Stepped		 		   	 = T_DSC_Mail_Stepped;
		DSC_Mail_M		 		  	 	 = T_DSC_Mail_M;
		DSC_Mail_N		 		   		 = T_DSC_Mail_N;
		DSC_Mail_O		 		   		 = T_DSC_Mail_O;
		DSC_Mail_Y		 		   		 = T_DSC_Mail_Y;
		DSC_Mail_DollarAmount		 	   	 = T_DSC_Mail_DollarAmount;
		DSC_Mail_Percent		 		   	 = T_DSC_Mail_Percent;
		DSC_Mail_CopayCalculation		   	 = T_DSC_Mail_CopayCalculation;
		DSC_Mail_MinimumDollar		   	 = T_DSC_Mail_MinimumDollar;
		DSC_Mail_MaximumDollar		   	 = T_DSC_Mail_MaximumDollar;

		
		
		Validate_DSC();

//		String value2 = "";

		
		tempStepped = DSC_Mail_Stepped;
		tempM = DSC_Mail_M;
		tempN = DSC_Mail_N;
		tempO = DSC_Mail_O;
		tempY = DSC_Mail_Y;
		tempDollarAmount = DSC_Mail_DollarAmount;
		tempPercentAmount = DSC_Mail_Percent;
		tempMindollar = DSC_Mail_MinimumDollar;
		tempMaxdollar = DSC_Mail_MaximumDollar;
		tempCopayCalc = DSC_Mail_CopayCalculation;
		
	}
	public static void Validate_DSC()	
	{

		
		for(int rowIterator=0;rowIterator<GetReportValues.row;rowIterator++)	{			
			if(GetReportValues.ThirdColumnValue.get(rowIterator).toString().equalsIgnoreCase("P"+provisionNumber+"L"+provisionLineValue))	{
				if(GetReportValues.sixthColumnValue.get(rowIterator).toString().equalsIgnoreCase("CRD__c"))	{
					if(GetReportValues.tenthColumnValue.get(rowIterator).toString().contains("Creates CRD"))	{
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Retail")){
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Retail copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Retail Col Matched");
										strsubsection2 = DSC_RetailFieldValue;
									}
								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Mail"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Mail copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Mail Col Matched");
									}
								}
							}
						}

						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Specialty"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Specialty Col Matched");
									}
								}
							}
						}	
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_SpecialtyOoN"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Specialty OON copays"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Line Value: "+provisionLineValue+" Any DSC SpecialtyOoN Col Matched");
									}

								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_Paper"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Line Value: "+provisionLineValue+" Any DSC Paper Col Matched");
									}

								}
							}
						}
						if(subsectionProcessType_Value.equalsIgnoreCase("DSC_PaperOoN"))	{
							if(GetReportValues.seventhColumnValue.get(rowIterator).toString().equalsIgnoreCase("Any drug specific Paper Out of Network copays?"))	{
								if(GetReportValues.eighthColumnValue.get(rowIterator).toString().equalsIgnoreCase(DSC_RetailFieldValue))	{
									{
										strsubsection2 = DSC_RetailFieldValue;
										System.out.println("Line Value: "+provisionLineValue+" Any DSC PaperOoN Col Matched");
									}

								}
							}
						}							
					}
				}	
			}
		}
	}

}

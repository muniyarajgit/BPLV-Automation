package com.keywords;

import java.util.ArrayList;

import org.testng.annotations.Test;

import com.FrameworkFunctions.GetReportValues;

public class CopyOfgetTemplateValues_2  {

	//initialization
	public static String p2_Line_Value = "";
	public static String p2_DC_Line_Text = "";
	public static String p2_DC_PaperOoN_IsTherePaperOoN_1 = "";
	public static String p2_DC_PaperOoN_TierNumber_1 = "";
	public static String p2_DC_PaperOoN_TierType_1 = "";
	public static String p2_DC_PaperOoN_DollarAmount_1 = "";
	public static String p2_DC_PaperOoN_Percent_1 = "";
	public static String p2_DC_PaperOoN_CopayCalculation_1 = "";
	public static String p2_DC_PaperOoN_MinimumDollar_1 = "";
	public static String p2_DC_PaperOoN_MaximumDollar_1 = "";
	public static String p2_DC_PaperOoN_DaysPerFill_1 = "";
	public static String p2_DC_PaperOoN_TierNumber_2 = "";
	public static String p2_DC_PaperOoN_TierType_2 = "";
	public static String p2_DC_PaperOoN_DollarAmount_2 = "";
	public static String p2_DC_PaperOoN_Percent_2 = "";
	public static String p2_DC_PaperOoN_CopayCalculation_2 = "";
	public static String p2_DC_PaperOoN_MinimumDollar_2 = "";
	public static String p2_DC_PaperOoN_MaximumDollar_2 = "";
	public static String p2_DC_PaperOoN_DaysPerFill_2 = "";
	public static String p2_DC_PaperOoN_TierNumber_3 = "";
	public static String p2_DC_PaperOoN_TierType_3 = "";
	public static String p2_DC_PaperOoN_DollarAmount_3 = "";
	public static String p2_DC_PaperOoN_Percent_3 = "";
	public static String p2_DC_PaperOoN_CopayCalculation_3 = "";
	public static String p2_DC_PaperOoN_MinimumDollar_3 = "";
	public static String p2_DC_PaperOoN_MaximumDollar_3 = "";
	public static String p2_DC_PaperOoN_DaysPerFill_3 = "";
	
		//			public static String P2_DSC__PaperOutOfNetwork_1  
	public static String p2_DSC_PaperOoN_Notes_1                                                                  = "";
	public static String p2_DSC_PaperOoN_Present_1                                                                  = "";
	public static String p2_DSC_PaperOoN_DrugListSelection_1                                              = "";
	public static String p2_DSC_PaperOoN_DrugList_1                                                               = "";
	public static String p2_DSC_PaperOoN_Stepped_1                                                                = "";
	public static String p2_DSC_PaperOoN_M_1                                                                      = "";
	public static String p2_DSC_PaperOoN_N_1                                                                      = "";
	public static String p2_DSC_PaperOoN_O_1                                                                      = "";
	public static String p2_DSC_PaperOoN_Y_1                                                                      = "";
	public static String p2_DSC_PaperOoN_PreferredGeneric_1                                                           = "";
	public static String p2_DSC_PaperOoN_NonPreferredGeneric_1                                                                = "";
	public static String p2_DSC_PaperOoN_PreferredBrand_1                                                               = "";
	public static String p2_DSC_PaperOoN_NonPreferredBrand_1 = "";
	public static String p2_DSC_PaperOoN_DollarAmount_1                                                           = "";
	public static String p2_DSC_PaperOoN_Percent_1                                                                = "";
	public static String p2_DSC_PaperOoN_CopayCalculation_1                                                               = "";
	public static String p2_DSC_PaperOoN_MinimumDollar_1  = "";
	public static String p2_DSC_PaperOoN_MaximumDollar_1                                                             = "";
	public static String p2_DSC_PaperOoN_Reverse_1                                                                = "";
	
//	public static String P2_DSC__PaperOutOfNetwork_2
	
	public static String p2_DSC_PaperOoN_Present_2 = "";
	public static String p2_DSC_PaperOoN_DrugListSelection_2                                              = "";
	public static String p2_DSC_PaperOoN_DrugList_2                                                                                            = "";
	public static String p2_DSC_PaperOoN_Stepped_2                                                                = "";
	public static String p2_DSC_PaperOoN_M_2                                                                      = "";
	public static String p2_DSC_PaperOoN_N_2                                                                      = "";
	public static String p2_DSC_PaperOoN_O_2                                                                      = "";
	public static String p2_DSC_PaperOoN_Y_2                                                                      = "";
	public static String p2_DSC_PaperOoN_PreferredGeneric_2                                                           = "";
	public static String p2_DSC_PaperOoN_NonPreferredGeneric_2                                                                = "";
	public static String p2_DSC_PaperOoN_PreferredBrand_2                                                               = "";
	public static String p2_DSC_PaperOoN_NonPreferredBrand_2  = "";
	public static String p2_DSC_PaperOoN_DollarAmount_2                                                           = "";
	public static String p2_DSC_PaperOoN_Percent_2                                                                = "";
	public static String p2_DSC_PaperOoN_CopayCalculation_2                                                               = "";
	public static String p2_DSC_PaperOoN_MinimumDollar_2  = "";
	public static String p2_DSC_PaperOoN_MaximumDollar_2                                                             = "";
	public static String p2_DSC_PaperOoN_Reverse_2                                                                = "";

	

	

/*
	public static void validateDC() throws Exception {

		GetReportValues.MapValDC("4", p4_Line_Value, "DC_Retail");
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Retail", p4_DC_Retail_DrugList_DrugGroup_1, p4_DC_Retail_DrugList_1, p4_DC_Retail_InclusionExclusionDrugClass_1, p4_DC_Retail_InclusionExclusion_1, p4_DC_Retail_ApplyLimitations_1, p4_DC_Retail_StartAge_1, p4_DC_Retail_EndAge_1, p4_DC_Retail_Gender_1, p4_DC_Retail_MinimumDays_1, p4_DC_Retail_MinimumQuality_1, p4_DC_Retail_DailyDose_1, p4_DC_Retail_StartAgeType_1, p4_DC_Retail_EndAgeType_1, p4_DC_Retail_DayQuantityRule_1, p4_DC_Retail_MaximumDays_1, p4_DC_Retail_MaximumFills_1, p4_DC_Retail_MaximumDaysperFill_1, p4_DC_Retail_DaysOverTimeTimePeriod_1, p4_DC_Retail_DaysoverTimeofDays_1, p4_DC_Retail_DaysoverTimeTimeValue_1, p4_DC_Retail_MaxQuantityperFill_1, p4_DC_Retail_QuantityoverTimeQuantity_1, p4_DC_Retail_QuantityOverTimeTimePeriod_1, p4_DC_Retail_QuantityoverTimeTimeValue_1, p4_DC_Retail_BypassMOOP_1);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Retail", p4_DC_Retail_DrugList_DrugGroup_2, p4_DC_Retail_DrugList_2, p4_DC_Retail_InclusionExclusionDrugClass_2, p4_DC_Retail_InclusionExclusion_2, p4_DC_Retail_ApplyLimitations_2, p4_DC_Retail_StartAge_2, p4_DC_Retail_EndAge_2, p4_DC_Retail_Gender_2, p4_DC_Retail_MinimumDays_2, p4_DC_Retail_MinimumQuality_2, p4_DC_Retail_DailyDose_2, p4_DC_Retail_StartAgeType_2, p4_DC_Retail_EndAgeType_2, p4_DC_Retail_DayQuantityRule_2, p4_DC_Retail_MaximumDays_2, p4_DC_Retail_MaximumFills_2, p4_DC_Retail_MaximumDaysperFill_2, p4_DC_Retail_DaysOverTimeTimePeriod_2, p4_DC_Retail_DaysoverTimeofDays_2, p4_DC_Retail_DaysoverTimeTimeValue_2, p4_DC_Retail_MaxQuantityperFill_2, p4_DC_Retail_QuantityoverTimeQuantity_2, p4_DC_Retail_QuantityOverTimeTimePeriod_2, p4_DC_Retail_QuantityoverTimeTimeValue_2, p4_DC_Retail_BypassMOOP_2);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Retail", p4_DC_Retail_DrugList_DrugGroup_3, p4_DC_Retail_DrugList_3, p4_DC_Retail_InclusionExclusionDrugClass_3, p4_DC_Retail_InclusionExclusion_3, p4_DC_Retail_ApplyLimitations_3, p4_DC_Retail_StartAge_3, p4_DC_Retail_EndAge_3, p4_DC_Retail_Gender_3, p4_DC_Retail_MinimumDays_3, p4_DC_Retail_MinimumQuality_3, p4_DC_Retail_DailyDose_3, p4_DC_Retail_StartAgeType_3, p4_DC_Retail_EndAgeType_3, p4_DC_Retail_DayQuantityRule_3, p4_DC_Retail_MaximumDays_3, p4_DC_Retail_MaximumFills_3, p4_DC_Retail_MaximumDaysperFill_3, p4_DC_Retail_DaysOverTimeTimePeriod_3, p4_DC_Retail_DaysoverTimeofDays_3, p4_DC_Retail_DaysoverTimeTimeValue_3, p4_DC_Retail_MaxQuantityperFill_3, p4_DC_Retail_QuantityoverTimeQuantity_3, p4_DC_Retail_QuantityOverTimeTimePeriod_3, p4_DC_Retail_QuantityoverTimeTimeValue_3, p4_DC_Retail_BypassMOOP_3);		
		GetReportValues.FailedReportValues_DC("DC_Retail");
		GetReportValues.MapValDC("4", p4_Line_Value, "DC_Mail");
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_1, p4_DC_Mail_DrugList_1, p4_DC_Mail_InclusionExclusionDrugClass_1, p4_DC_Mail_InclusionExclusion_1, p4_DC_Mail_ApplyLimitations_1, p4_DC_Mail_StartAge_1, p4_DC_Mail_EndAge_1, p4_DC_Mail_Gender_1, p4_DC_Mail_MinimumDays_1, p4_DC_Mail_MinimumQuality_1, p4_DC_Mail_DailyDose_1, p4_DC_Mail_StartAgeType_1, p4_DC_Mail_EndAgeType_1, p4_DC_Mail_DayQuantityRule_1, p4_DC_Mail_MaximumDays_1, p4_DC_Mail_MaximumFills_1, p4_DC_Mail_MaximumDaysperFill_1, p4_DC_Mail_DaysOverTimeTimePeriod_1, p4_DC_Mail_DaysoverTimeofDays_1, p4_DC_Mail_DaysoverTimeTimeValue_1, p4_DC_Mail_MaxQuantityperFill_1, p4_DC_Mail_QuantityoverTimeQuantity_1, p4_DC_Mail_QuantityOverTimeTimePeriod_1, p4_DC_Mail_QuantityoverTimeTimeValue_1, p4_DC_Mail_BypassMOOP_1);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_2, p4_DC_Mail_DrugList_2, p4_DC_Mail_InclusionExclusionDrugClass_2, p4_DC_Mail_InclusionExclusion_2, p4_DC_Mail_ApplyLimitations_2, p4_DC_Mail_StartAge_2, p4_DC_Mail_EndAge_2, p4_DC_Mail_Gender_2, p4_DC_Mail_MinimumDays_2, p4_DC_Mail_MinimumQuality_2, p4_DC_Mail_DailyDose_2, p4_DC_Mail_StartAgeType_2, p4_DC_Mail_EndAgeType_2, p4_DC_Mail_DayQuantityRule_2, p4_DC_Mail_MaximumDays_2, p4_DC_Mail_MaximumFills_2, p4_DC_Mail_MaximumDaysperFill_2, p4_DC_Mail_DaysOverTimeTimePeriod_2, p4_DC_Mail_DaysoverTimeofDays_2, p4_DC_Mail_DaysoverTimeTimeValue_2, p4_DC_Mail_MaxQuantityperFill_2, p4_DC_Mail_QuantityoverTimeQuantity_2, p4_DC_Mail_QuantityOverTimeTimePeriod_2, p4_DC_Mail_QuantityoverTimeTimeValue_2, p4_DC_Mail_BypassMOOP_2);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_3, p4_DC_Mail_DrugList_3, p4_DC_Mail_InclusionExclusionDrugClass_3, p4_DC_Mail_InclusionExclusion_3, p4_DC_Mail_ApplyLimitations_3, p4_DC_Mail_StartAge_3, p4_DC_Mail_EndAge_3, p4_DC_Mail_Gender_3, p4_DC_Mail_MinimumDays_3, p4_DC_Mail_MinimumQuality_3, p4_DC_Mail_DailyDose_3, p4_DC_Mail_StartAgeType_3, p4_DC_Mail_EndAgeType_3, p4_DC_Mail_DayQuantityRule_3, p4_DC_Mail_MaximumDays_3, p4_DC_Mail_MaximumFills_3, p4_DC_Mail_MaximumDaysperFill_3, p4_DC_Mail_DaysOverTimeTimePeriod_3, p4_DC_Mail_DaysoverTimeofDays_3, p4_DC_Mail_DaysoverTimeTimeValue_3, p4_DC_Mail_MaxQuantityperFill_3, p4_DC_Mail_QuantityoverTimeQuantity_3, p4_DC_Mail_QuantityOverTimeTimePeriod_3, p4_DC_Mail_QuantityoverTimeTimeValue_3, p4_DC_Mail_BypassMOOP_3);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_4, p4_DC_Mail_DrugList_4, p4_DC_Mail_InclusionExclusionDrugClass_4, p4_DC_Mail_InclusionExclusion_4, p4_DC_Mail_ApplyLimitations_4, p4_DC_Mail_StartAge_4, p4_DC_Mail_EndAge_4, p4_DC_Mail_Gender_4, p4_DC_Mail_MinimumDays_4, p4_DC_Mail_MinimumQuality_4, p4_DC_Mail_DailyDose_4, p4_DC_Mail_StartAgeType_4, p4_DC_Mail_EndAgeType_4, p4_DC_Mail_DayQuantityRule_4, p4_DC_Mail_MaximumDays_4, p4_DC_Mail_MaximumFills_4, p4_DC_Mail_MaximumDaysperFill_4, p4_DC_Mail_DaysOverTimeTimePeriod_4, p4_DC_Mail_DaysoverTimeofDays_4, p4_DC_Mail_DaysoverTimeTimeValue_4, p4_DC_Mail_MaxQuantityperFill_4, p4_DC_Mail_QuantityoverTimeQuantity_4, p4_DC_Mail_QuantityOverTimeTimePeriod_4, p4_DC_Mail_QuantityoverTimeTimeValue_4, p4_DC_Mail_BypassMOOP_4);		
		GetReportValues.FailedReportValues_DC("DC_Mail");
		GetReportValues.LineValueCheck("4",p4_Line_Value);
		
	}*/
	public static void validateDSC() throws Exception {

	
		GetReportValues.getAllMapId_DSC("2",p2_Line_Value,"DSC_PaperOutOfNetwork");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("2",p2_Line_Value,"DSC_PaperOutOfNetwork",p2_DSC_PaperOoN_Present_1,"",p2_DSC_PaperOoN_DrugListSelection_1,p2_DSC_PaperOoN_DrugList_1,p2_DSC_PaperOoN_Stepped_1,p2_DSC_PaperOoN_M_1,p2_DSC_PaperOoN_N_1,p2_DSC_PaperOoN_O_1,p2_DSC_PaperOoN_Y_1,p2_DSC_PaperOoN_PreferredGeneric_1,p2_DSC_PaperOoN_NonPreferredGeneric_1,p2_DSC_PaperOoN_PreferredBrand_1,p2_DSC_PaperOoN_NonPreferredBrand_1,p2_DSC_PaperOoN_DollarAmount_1,p2_DSC_PaperOoN_Percent_1,p2_DSC_PaperOoN_CopayCalculation_1,p2_DSC_PaperOoN_MinimumDollar_1,p2_DSC_PaperOoN_MaximumDollar_1,p2_DSC_PaperOoN_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("2",p2_Line_Value,"DSC_PaperOutOfNetwork",p2_DSC_PaperOoN_Present_1,"",p2_DSC_PaperOoN_DrugListSelection_2,p2_DSC_PaperOoN_DrugList_2,p2_DSC_PaperOoN_Stepped_2,p2_DSC_PaperOoN_M_2,p2_DSC_PaperOoN_N_2,p2_DSC_PaperOoN_O_2,p2_DSC_PaperOoN_Y_2,p2_DSC_PaperOoN_PreferredGeneric_1,p2_DSC_PaperOoN_NonPreferredGeneric_1,p2_DSC_PaperOoN_PreferredBrand_1,p2_DSC_PaperOoN_NonPreferredBrand_1,p2_DSC_PaperOoN_DollarAmount_2,p2_DSC_PaperOoN_Percent_2,p2_DSC_PaperOoN_CopayCalculation_2,p2_DSC_PaperOoN_MinimumDollar_2,p2_DSC_PaperOoN_MaximumDollar_2,p2_DSC_PaperOoN_Reverse_2,"False");
	
		GetReportValues.FailedReportValues("DSC_PaperOutOfNetwork");
		
	}
	/*public static void validateAccum() throws Exception {	
		ValidateProvisionTemplate_Test.validateAccumulationsDrugSpecific("4", p2_Line_Value, P2_Accum_ArethereanydrugspecificMAB, P4_Accum_M,P4_Accum_O, P4_Accum_N, P4_Accum_Y,P4_Accum_Druglist, P4_Accum_DrugGroup,P4_Accum_MAB_Amount, P4_Accum_MAB_Period, P4_Accum_MAB_Met);		
	}*/



	public static void getProvision2TemplateValues(Object[][] provision2Template) 	{

		p2_Line_Value = provision2Template[0][1].toString();
		p2_DC_Line_Text = provision2Template[0][2].toString();
		p2_DC_PaperOoN_IsTherePaperOoN_1 = provision2Template[0][6].toString();
		p2_DC_PaperOoN_TierNumber_1 = provision2Template[0][14].toString();
		p2_DC_PaperOoN_TierType_1 = provision2Template[0][15].toString();
		p2_DC_PaperOoN_DollarAmount_1 = provision2Template[0][16].toString();
		p2_DC_PaperOoN_Percent_1 = provision2Template[0][17].toString();
		p2_DC_PaperOoN_CopayCalculation_1 = provision2Template[0][18].toString();
		p2_DC_PaperOoN_MinimumDollar_1 = provision2Template[0][19].toString();
		p2_DC_PaperOoN_MaximumDollar_1 = provision2Template[0][20].toString();
		p2_DC_PaperOoN_DaysPerFill_1 = provision2Template[0][21].toString();
		p2_DC_PaperOoN_TierNumber_2 = provision2Template[0][23].toString();
		p2_DC_PaperOoN_TierType_2 = provision2Template[0][24].toString();
		p2_DC_PaperOoN_DollarAmount_2 = provision2Template[0][25].toString();
		p2_DC_PaperOoN_Percent_2 = provision2Template[0][26].toString();
		p2_DC_PaperOoN_CopayCalculation_2 = provision2Template[0][27].toString();
		p2_DC_PaperOoN_MinimumDollar_2 = provision2Template[0][28].toString();
		p2_DC_PaperOoN_MaximumDollar_2 = provision2Template[0][29].toString();
		p2_DC_PaperOoN_DaysPerFill_2 = provision2Template[0][30].toString();
		p2_DC_PaperOoN_TierNumber_3 = provision2Template[0][32].toString();
		p2_DC_PaperOoN_TierType_3 = provision2Template[0][33].toString();
		p2_DC_PaperOoN_DollarAmount_3 = provision2Template[0][34].toString();
		p2_DC_PaperOoN_Percent_3 = provision2Template[0][35].toString();
		p2_DC_PaperOoN_CopayCalculation_3 = provision2Template[0][36].toString();
		p2_DC_PaperOoN_MinimumDollar_3 = provision2Template[0][37].toString();
		p2_DC_PaperOoN_MaximumDollar_3 = provision2Template[0][38].toString();
		p2_DC_PaperOoN_DaysPerFill_3 = provision2Template[0][39].toString();
		
		p2_DSC_PaperOoN_Notes_1 = provision2Template[0][41].toString();
		p2_DSC_PaperOoN_Present_1 = provision2Template[0][42].toString();
		p2_DSC_PaperOoN_DrugListSelection_1 = provision2Template[0][43].toString();
		p2_DSC_PaperOoN_DrugList_1 = provision2Template[0][44].toString();
		p2_DSC_PaperOoN_Stepped_1 = provision2Template[0][45].toString();
		p2_DSC_PaperOoN_M_1 = provision2Template[0][46].toString();
		p2_DSC_PaperOoN_N_1 = provision2Template[0][47].toString();
		p2_DSC_PaperOoN_O_1 = provision2Template[0][48].toString();
		p2_DSC_PaperOoN_Y_1 = provision2Template[0][49].toString();
		p2_DSC_PaperOoN_PreferredGeneric_1 = provision2Template[0][50].toString();
		p2_DSC_PaperOoN_NonPreferredGeneric_1 = provision2Template[0][51].toString();
		p2_DSC_PaperOoN_PreferredBrand_1 = provision2Template[0][52].toString();
		p2_DSC_PaperOoN_NonPreferredBrand_1 = provision2Template[0][53].toString();
		p2_DSC_PaperOoN_DollarAmount_1 = provision2Template[0][54].toString();
		p2_DSC_PaperOoN_Percent_1 = provision2Template[0][55].toString(); 

		p2_DSC_PaperOoN_CopayCalculation_1 = provision2Template[0][56].toString();
		p2_DSC_PaperOoN_MinimumDollar_1 = provision2Template[0][57].toString();
		p2_DSC_PaperOoN_MaximumDollar_1 = provision2Template[0][58].toString();
		p2_DSC_PaperOoN_Reverse_1 = provision2Template[0][59].toString();
		p2_DSC_PaperOoN_Present_2 = provision2Template[0][62].toString();
		p2_DSC_PaperOoN_DrugListSelection_2 = provision2Template[0][63].toString();
		p2_DSC_PaperOoN_DrugList_2 = provision2Template[0][64].toString();
		p2_DSC_PaperOoN_Stepped_2 = provision2Template[0][65].toString();
		p2_DSC_PaperOoN_M_2 = provision2Template[0][66].toString();
		p2_DSC_PaperOoN_N_2 = provision2Template[0][67].toString();
		p2_DSC_PaperOoN_O_2 = provision2Template[0][68].toString();
		p2_DSC_PaperOoN_Y_2 = provision2Template[0][69].toString();
		p2_DSC_PaperOoN_PreferredGeneric_2 = provision2Template[0][70].toString();
		p2_DSC_PaperOoN_NonPreferredGeneric_2 = provision2Template[0][71].toString();
		p2_DSC_PaperOoN_PreferredBrand_2 = provision2Template[0][72].toString();
		p2_DSC_PaperOoN_NonPreferredBrand_2 = provision2Template[0][73].toString();
		p2_DSC_PaperOoN_DollarAmount_2 = provision2Template[0][74].toString();
		p2_DSC_PaperOoN_Percent_2 = provision2Template[0][75].toString();
		p2_DSC_PaperOoN_CopayCalculation_2 = provision2Template[0][76].toString();
		p2_DSC_PaperOoN_MinimumDollar_2 = provision2Template[0][77].toString();
		p2_DSC_PaperOoN_MaximumDollar_2 = provision2Template[0][78].toString();
		p2_DSC_PaperOoN_Reverse_2 = provision2Template[0][79].toString();
		
	}



}

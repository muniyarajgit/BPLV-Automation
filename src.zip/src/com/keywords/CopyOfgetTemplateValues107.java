package com.keywords;
import java.util.ArrayList;

import org.testng.annotations.Test;

import com.FrameworkFunctions.GetReportValues;

public class CopyOfgetTemplateValues_107  {

public static String p107_Line_Value                                                                      = "";
public static String p107_DC_Line_Text                                                                      = "";


public static String p107_DC_Retail_DrugList_DrugGroup_1                                                                      = "";
public static String p107_DC_Retail_Notes_1                                                                      = "";
public static String p107_DC_Retail_DrugList_1                                                                      = "";
public static String p107_DC_Retail_InclusionExclusionDrugClass_1                                                                      = "";
public static String p107_DC_Retail_InclusionExclusion_1                                                                      = "";
public static String p107_DC_Retail_ApplyLimitations_1                                                                      = "";
public static String p107_DC_Retail_StartAge_1                                                                      = "";
public static String p107_DC_Retail_EndAge_1                                                                      = "";
public static String p107_DC_Retail_Gender_1                                                                      = "";
public static String p107_DC_Retail_MinimumDays_1                                                                      = "";
public static String p107_DC_Retail_MinimumQuality_1                                                                      = "";
public static String p107_DC_Retail_DailyDose_1                                                                      = "";
public static String p107_DC_Retail_StartAgeType_1                                                                      = "";
public static String p107_DC_Retail_EndAgeType_1                                                                      = "";
public static String p107_DC_Retail_DayQuantityRule_1                                                                      = "";
public static String p107_DC_Retail_MaximumDays_1                                                                      = "";
public static String p107_DC_Retail_MaximumFills_1                                                                      = "";
public static String p107_DC_Retail_MaximumDaysperFill_1                                                                      = "";
public static String p107_DC_Retail_DaysOverTimeTimePeriod_1                                                                      = "";
public static String p107_DC_Retail_DaysoverTimeofDays_1                                                                       = "";
public static String p107_DC_Retail_DaysoverTimeTimeValue_1                                                                      = "";
public static String p107_DC_Retail_MaxQuantityperFill_1                                                                      = "";
public static String p107_DC_Retail_QuantityoverTimeQuantity_1                                                                      = "";
public static String p107_DC_Retail_QuantityOverTimeTimePeriod_1                                                                      = "";
public static String p107_DC_Retail_QuantityoverTimeTimeValue_1                                                                      = "";
public static String p107_DC_Retail_BypassMOOP_1                                                                      = "";

public static String p107_DC_Mail_DrugList_DrugGroup_1                                                                      = "";
public static String p107_DC_Mail_Notes_1                                                                      = "";
public static String p107_DC_Mail_DrugList_1                                                                      = "";
public static String p107_DC_Mail_InclusionExclusionDrugClass_1                                                                      = "";
public static String p107_DC_Mail_InclusionExclusion_1                                                                      = "";
public static String p107_DC_Mail_ApplyLimitations_1                                                                      = "";
public static String p107_DC_Mail_StartAge_1                                                                      = "";
public static String p107_DC_Mail_EndAge_1                                                                      = "";
public static String p107_DC_Mail_Gender_1                                                                      = "";
public static String p107_DC_Mail_MinimumDays_1                                                                      = "";
public static String p107_DC_Mail_MinimumQuality_1                                                                      = "";
public static String p107_DC_Mail_DailyDose_1                                                                      = "";
public static String p107_DC_Mail_StartAgeType_1                                                                      = "";
public static String p107_DC_Mail_EndAgeType_1                                                                      = "";
public static String p107_DC_Mail_DayQuantityRule_1                                                                      = "";
public static String p107_DC_Mail_MaximumDays_1                                                                      = "";
public static String p107_DC_Mail_MaximumFills_1                                                                      = "";
public static String p107_DC_Mail_MaximumDaysperFill_1                                                                      = "";
public static String p107_DC_Mail_DaysOverTimeTimePeriod_1                                                                      = "";
public static String p107_DC_Mail_DaysoverTimeofDays_1                                                                       = "";
public static String p107_DC_Mail_DaysoverTimeTimeValue_1                                                                      = "";
public static String p107_DC_Mail_MaxQuantityperFill_1                                                                      = "";
public static String p107_DC_Mail_QuantityoverTimeQuantity_1                                                                      = "";
public static String p107_DC_Mail_QuantityOverTimeTimePeriod_1                                                                      = "";
public static String p107_DC_Mail_QuantityoverTimeTimeValue_1                                                                      = "";
public static String p107_DC_Mail_BypassMOOP_1                                                                      = "";


public static String p107_DSC__Retail_Retail_Present_1                                                                                = "";
public static String p107_DSC__Retail_DrugListSelection_1                                                                    = "";
public static String p107_DSC__Retail_DrugList_1                                                                    = "";
public static String p107_DSC__Retail_Stepped_1                                                                    = "";
public static String p107_DSC__Retail_M_1                                                                    = "";
public static String p107_DSC__Retail_N_1                                                                    = "";
public static String p107_DSC__Retail_O_1                                                                    = "";
public static String p107_DSC__Retail_Y_1                                                                    = "";
public static String p107_DSC__Retail_PreferredGeneric_1                                                                    = "";
public static String p107_DSC__Retail_NonPreferredGeneric_1                                                                    = "";
public static String p107_DSC__Retail_PreferredBrand_1                                                                    = "";
public static String p107_DSC__Retail_NonPreferredBrand_1                                                                    = "";
public static String p107_DSC__Retail_DollarAmount_1                                                                    = "";
public static String p107_DSC__Retail_Percent_1                                                                    = "";
public static String p107_DSC__Retail_CopayCal_1                                                                    = "";
public static String p107_DSC__Retail_MinDollar_1                                                                    = "";
public static String p107_DSC__Retail_Max_Dollar_1                                                                    = "";
public static String p107_DSC__Retail_Reverse_1                                                                    = "";


public static String p107_DSC__Mail_Present_1                                                                    = "";
public static String p107_DSC__Mail_DrugListSelection_1                                                                    = "";
public static String p107_DSC__Mail_DrugList_1                                                                    = "";
public static String p107_DSC__Mail_Stepped_1                                                                    = "";
public static String p107_DSC__Mail_M_1                                                                    = "";
public static String p107_DSC__Mail_N_1                                                                    = "";
public static String p107_DSC__Mail_O_1                                                                    = "";
public static String p107_DSC__Mail_Y_1                                                                    = "";
public static String p107_DSC__Mail_PreferredGeneric_1                                                                    = "";
public static String p107_DSC__Mail_NonPreferredGeneric_1                                                                    = "";
public static String p107_DSC__Mail_PreferredBrand_1                                                                    = "";
public static String p107_DSC__Mail_NonPreferredBrand_1                                                                    = "";
public static String p107_DSC__Mail_DollarAmount_1                                                                    = "";
public static String p107_DSC__Mail_Percent_1                                                                    = "";
public static String p107_DSC__Mail_CopayCal_1                                                                    = "";
public static String p107_DSC__Mail_MinDollar_1                                                                    = "";
public static String p107_DSC__Mail_Max_Dollar_1                                                                    = "";
public static String p107_DSC__Mail_Reverse_1                                                                    = "";


public static String p107_DSC__Specialty_Present_1                                                                    = "";
public static String p107_DSC__Specialty_DrugListSelection_1                                                                    = "";
public static String p107_DSC__Specialty_DrugList_1                                                                    = "";
public static String p107_DSC__Specialty_Stepped_1                                                                    = "";
public static String p107_DSC__Specialty_M_1                                                                    = "";
public static String p107_DSC__Specialty_N_1                                                                    = "";
public static String p107_DSC__Specialty_O_1                                                                    = "";
public static String p107_DSC__Specialty_Y_1                                                                    = "";
public static String p107_DSC__Specialty_PreferredGeneric_1                                                                    = "";
public static String p107_DSC__Specialty_NonPreferredGeneric_1                                                                    = "";
public static String p107_DSC__Specialty_PreferredBrand_1                                                                    = "";
public static String p107_DSC__Specialty_NonPreferredBrand_1                                                                    = "";
public static String p107_DSC__Specialty_DollarAmount_1                                                                    = "";
public static String p107_DSC__Specialty_Percent_1                                                                    = "";
public static String p107_DSC__Specialty_CopayCal_1                                                                    = "";
public static String p107_DSC__Specialty_MinDollar_1                                                                    = "";
public static String p107_DSC__Specialty_Max_Dollar_1                                                                    = "";
public static String p107_DSC__Specialty_Reverse_1                                                                    = "";


public static String p107_DSC__SpecialtyOutoFNetwork_Present_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_DrugListSelection_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_DrugList_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_Stepped_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_M_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_N_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_O_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_Y_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_PreferredGeneric_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_NonPreferredGeneric_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_PreferredBrand_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_NonPreferredBrand_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_DollarAmount_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_Percent_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_CopayCal_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_MinDollar_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_Max_Dollar_1                                                                    = "";
public static String p107_DSC__SpecialtyOutoFNetwork_Reverse_1                                                                    = "";


public static String p107_DSC__Paper_Present_1                                                                    = "";
public static String p107_DSC__Paper_DrugListSelection_1                                                                    = "";
public static String p107_DSC__Paper_DrugList_1                                                                    = "";
public static String p107_DSC__Paper_Stepped_1                                                                    = "";
public static String p107_DSC__Paper_M_1                                                                    = "";
public static String p107_DSC__Paper_N_1                                                                    = "";
public static String p107_DSC__Paper_O_1                                                                    = "";
public static String p107_DSC__Paper_Y_1                                                                    = "";
public static String p107_DSC__Paper_PreferredGeneric_1                                                                    = "";
public static String p107_DSC__Paper_NonPreferredGeneric_1                                                                    = "";
public static String p107_DSC__Paper_PreferredBrand_1                                                                    = "";
public static String p107_DSC__Paper_NonPreferredBrand_1                                                                    = "";
public static String p107_DSC__Paper_DollarAmount_1                                                                    = "";
public static String p107_DSC__Paper_Percent_1                                                                    = "";
public static String p107_DSC__Paper_CopayCal_1                                                                    = "";
public static String p107_DSC__Paper_MinDollar_1                                                                    = "";
public static String p107_DSC__Paper_Max_Dollar_1                                                                    = "";
public static String p107_DSC__Paper_Reverse_1                                                                    = "";


public static String p107_DSC__PaperOutoFNetwork_Present_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_DrugListSelection_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_DrugList_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_Stepped_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_M_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_N_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_O_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_Y_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_PreferredGeneric_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_NonPreferredGeneric_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_PreferredBrand_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_NonPreferredBrand_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_DollarAmount_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_Percent_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_CopayCal_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_MinDollar_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_Max_Dollar_1                                                                    = "";
public static String p107_DSC__PaperOutoFNetwork_Reverse_1                                                                    = "";


public static String p107_DSC__Mail_PaperOoN_Present_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_DrugListSelection_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_DrugList_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_Stepped_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_M_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_N_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_O_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_Y_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_PreferredGeneric_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_NonPreferredGeneric_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_PreferredBrand_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_NonPreferredBrand_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_DollarAmount_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_Percent_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_CopayCal_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_MinDollar_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_Max_Dollar_1                                                                    = "";
public static String p107_DSC__Mail_PaperOoN_Reverse_1                                                                    = "";


public static void validateDC() throws Exception {

		GetReportValues.MapValDC("107", p107_Line_Value, "DC_Retail");
		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("107", p107_Line_Value, "DC_Retail", p107_DC_Retail_DrugList_DrugGroup_1, p107_DC_Retail_DrugList_1, p107_DC_Retail_InclusionExclusionDrugClass_1, p107_DC_Retail_InclusionExclusion_1, p107_DC_Retail_ApplyLimitations_1, p107_DC_Retail_StartAge_1, p107_DC_Retail_EndAge_1, p107_DC_Retail_Gender_1, p107_DC_Retail_MinimumDays_1, p107_DC_Retail_MinimumQuality_1, p107_DC_Retail_DailyDose_1, p107_DC_Retail_StartAgeType_1, p107_DC_Retail_EndAgeType_1, p107_DC_Retail_DayQuantityRule_1, p107_DC_Retail_MaximumDays_1, p107_DC_Retail_MaximumFills_1, p107_DC_Retail_MaximumDaysperFill_1, p107_DC_Retail_DaysOverTimeTimePeriod_1, p107_DC_Retail_DaysoverTimeofDays_1, p107_DC_Retail_DaysoverTimeTimeValue_1, p107_DC_Retail_MaxQuantityperFill_1, p107_DC_Retail_QuantityoverTimeQuantity_1, p107_DC_Retail_QuantityOverTimeTimePeriod_1, p107_DC_Retail_QuantityoverTimeTimeValue_1, p107_DC_Retail_BypassMOOP_1);	
		
		GetReportValues.FailedReportValues_DC("DC_Retail");
		
		GetReportValues.MapValDC("107", p107_Line_Value, "DC_Mail");
		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("107", p107_Line_Value, "DC_Mail", p107_DC_Mail_DrugList_DrugGroup_1, p107_DC_Mail_DrugList_1, p107_DC_Mail_InclusionExclusionDrugClass_1, p107_DC_Mail_InclusionExclusion_1, p107_DC_Mail_ApplyLimitations_1, p107_DC_Mail_StartAge_1, p107_DC_Mail_EndAge_1, p107_DC_Mail_Gender_1, p107_DC_Mail_MinimumDays_1, p107_DC_Mail_MinimumQuality_1, p107_DC_Mail_DailyDose_1, p107_DC_Mail_StartAgeType_1, p107_DC_Mail_EndAgeType_1, p107_DC_Mail_DayQuantityRule_1, p107_DC_Mail_MaximumDays_1, p107_DC_Mail_MaximumFills_1, p107_DC_Mail_MaximumDaysperFill_1, p107_DC_Mail_DaysOverTimeTimePeriod_1, p107_DC_Mail_DaysoverTimeofDays_1, p107_DC_Mail_DaysoverTimeTimeValue_1, p107_DC_Mail_MaxQuantityperFill_1, p107_DC_Mail_QuantityoverTimeQuantity_1, p107_DC_Mail_QuantityOverTimeTimePeriod_1, p107_DC_Mail_QuantityoverTimeTimeValue_1, p107_DC_Mail_BypassMOOP_1);	
		
		GetReportValues.FailedReportValues_DC("DC_Mail");
		
		GetReportValues.LineValueCheck("107",p107_Line_Value);
}
public static void validateDSC() throws Exception {


		GetReportValues.getAllMapId_DSC("107",p107_Line_Value,"DSC_Retail");
		
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("107",p107_Line_Value,"DSC_Retail",p107_DSC__Retail_Retail_Present_1,"",p107_DSC__Retail_DrugListSelection_1,p107_DSC__Retail_DrugList_1,p107_DSC__Retail_Stepped_1,p107_DSC__Retail_M_1,p107_DSC__Retail_N_1,p107_DSC__Retail_O_1,p107_DSC__Retail_Y_1,p107_DSC__Retail_PreferredGeneric_1,p107_DSC__Retail_NonPreferredGeneric_1,p107_DSC__Retail_PreferredBrand_1,p107_DSC__Retail_NonPreferredBrand_1,p107_DSC__Retail_DollarAmount_1,p107_DSC__Retail_Percent_1,p107_DSC__Retail_CopayCal_1,p107_DSC__Retail_MinDollar_1,p107_DSC__Retail_Max_Dollar_1,p107_DSC__Retail_Reverse_1,"False");
		
		GetReportValues.FailedReportValues("DSC_Retail");
		
		GetReportValues.getAllMapId_DSC("107",p107_Line_Value,"DSC_Mail");
		
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("107",p107_Line_Value,"DSC_Mail",p107_DSC__Mail_Present_1,"",p107_DSC__Mail_DrugListSelection_1,p107_DSC__Mail_DrugList_1,p107_DSC__Mail_Stepped_1,p107_DSC__Mail_M_1,p107_DSC__Mail_N_1,p107_DSC__Mail_O_1,p107_DSC__Mail_Y_1,p107_DSC__Mail_PreferredGeneric_1,p107_DSC__Mail_NonPreferredGeneric_1,p107_DSC__Mail_PreferredBrand_1,p107_DSC__Mail_NonPreferredBrand_1,p107_DSC__Mail_DollarAmount_1,p107_DSC__Mail_Percent_1,p107_DSC__Mail_CopayCal_1,p107_DSC__Mail_MinDollar_1,p107_DSC__Mail_Max_Dollar_1,p107_DSC__Mail_Reverse_1,"False");

		GetReportValues.FailedReportValues("DSC_Mail");
		
		GetReportValues.getAllMapId_DSC("107",p107_Line_Value,"DSC_SpecialtyTiers");
		
		
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("107",p107_Line_Value,"DSC_SpecialtyTiers",p107_DSC__Specialty_Present_1,"",p107_DSC__Specialty_DrugListSelection_1,p107_DSC__Specialty_DrugList_1,p107_DSC__Specialty_Stepped_1,p107_DSC__Specialty_M_1,p107_DSC__Specialty_N_1,p107_DSC__Specialty_O_1,p107_DSC__Specialty_Y_1,p107_DSC__Specialty_PreferredGeneric_1,p107_DSC__Specialty_NonPreferredGeneric_1,p107_DSC__Specialty_PreferredBrand_1,p107_DSC__Specialty_NonPreferredBrand_1,p107_DSC__Specialty_DollarAmount_1,p107_DSC__Specialty_Percent_1,p107_DSC__Specialty_CopayCal_1,p107_DSC__Specialty_MinDollar_1,p107_DSC__Specialty_Max_Dollar_1,p107_DSC__Specialty_Reverse_1,"False");
		
		GetReportValues.FailedReportValues("DSC_SpecialtyTiers");
		
		GetReportValues.getAllMapId_DSC("107",p107_Line_Value,"DSC_SpecialtyOutOfNetwork");
		
		
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("107",p107_Line_Value,"DSC_SpecialityOutoFNetworkOutOfNetworkTiers",p107_DSC__SpecialtyOutoFNetwork_Present_1,"",p107_DSC__SpecialtyOutoFNetwork_DrugListSelection_1,p107_DSC__SpecialtyOutoFNetwork_DrugList_1,p107_DSC__SpecialtyOutoFNetwork_Stepped_1,p107_DSC__SpecialtyOutoFNetwork_M_1,p107_DSC__SpecialtyOutoFNetwork_N_1,p107_DSC__SpecialtyOutoFNetwork_O_1,p107_DSC__SpecialtyOutoFNetwork_Y_1,p107_DSC__SpecialtyOutoFNetwork_PreferredGeneric_1,p107_DSC__SpecialtyOutoFNetwork_NonPreferredGeneric_1,p107_DSC__SpecialtyOutoFNetwork_PreferredBrand_1,p107_DSC__SpecialtyOutoFNetwork_NonPreferredBrand_1,p107_DSC__SpecialtyOutoFNetwork_DollarAmount_1,p107_DSC__SpecialtyOutoFNetwork_Percent_1,p107_DSC__SpecialtyOutoFNetwork_CopayCal_1,p107_DSC__SpecialtyOutoFNetwork_MinDollar_1,p107_DSC__SpecialtyOutoFNetwork_Max_Dollar_1,p107_DSC__SpecialtyOutoFNetwork_Reverse_1,"False");
		
		GetReportValues.FailedReportValues("DSC_SpecialtyOutOfNetwork");
		
		GetReportValues.getAllMapId_DSC("107",p107_Line_Value,"DSC_PaperTiers");
		
		
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("107",p107_Line_Value,"DSC_PaperTiers",p107_DSC__Paper_Present_1,"",p107_DSC__Paper_DrugListSelection_1,p107_DSC__Paper_DrugList_1,p107_DSC__Paper_Stepped_1,p107_DSC__Paper_M_1,p107_DSC__Paper_N_1,p107_DSC__Paper_O_1,p107_DSC__Paper_Y_1,p107_DSC__Paper_PreferredGeneric_1,p107_DSC__Paper_NonPreferredGeneric_1,p107_DSC__Paper_PreferredBrand_1,p107_DSC__Paper_NonPreferredBrand_1,p107_DSC__Paper_DollarAmount_1,p107_DSC__Paper_Percent_1,p107_DSC__Paper_CopayCal_1,p107_DSC__Paper_MinDollar_1,p107_DSC__Paper_Max_Dollar_1,p107_DSC__Paper_Reverse_1,"False");
		
		GetReportValues.FailedReportValues("DSC_PaperTiers");
		
		GetReportValues.getAllMapId_DSC("107",p107_Line_Value,"DSC_PaperOutOfNetwork");
		
		
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("107",p107_Line_Value,"DSC_PaperOutoFNetwork",p107_DSC__PaperOutoFNetwork_Present_1,"",p107_DSC__PaperOutoFNetwork_DrugListSelection_1,p107_DSC__PaperOutoFNetwork_DrugList_1,p107_DSC__PaperOutoFNetwork_Stepped_1,p107_DSC__PaperOutoFNetwork_M_1,p107_DSC__PaperOutoFNetwork_N_1,p107_DSC__PaperOutoFNetwork_O_1,p107_DSC__PaperOutoFNetwork_Y_1,p107_DSC__PaperOutoFNetwork_PreferredGeneric_1,p107_DSC__PaperOutoFNetwork_NonPreferredGeneric_1,p107_DSC__PaperOutoFNetwork_PreferredBrand_1,p107_DSC__PaperOutoFNetwork_NonPreferredBrand_1,p107_DSC__PaperOutoFNetwork_DollarAmount_1,p107_DSC__PaperOutoFNetwork_Percent_1,p107_DSC__PaperOutoFNetwork_CopayCal_1,p107_DSC__PaperOutoFNetwork_MinDollar_1,p107_DSC__PaperOutoFNetwork_Max_Dollar_1,p107_DSC__PaperOutoFNetwork_Reverse_1,"False");
		
		GetReportValues.FailedReportValues("DSC_PaperOutOfNetwork");
		
		GetReportValues.getAllMapId_DSC("107",p107_Line_Value,"DSC_Mail_PaperOutOfNetwork");
		
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("107",p107_Line_Value,"DSC_Mail_PaperOutoFNetwork",p107_DSC__Mail_PaperOoN_Present_1,"",p107_DSC__Mail_PaperOoN_DrugListSelection_1,p107_DSC__Mail_PaperOoN_DrugList_1,p107_DSC__Mail_PaperOoN_Stepped_1,p107_DSC__Mail_PaperOoN_M_1,p107_DSC__Mail_PaperOoN_N_1,p107_DSC__Mail_PaperOoN_O_1,p107_DSC__Mail_PaperOoN_Y_1,p107_DSC__Mail_PaperOoN_PreferredGeneric_1,p107_DSC__Mail_PaperOoN_NonPreferredGeneric_1,p107_DSC__Mail_PaperOoN_PreferredBrand_1,p107_DSC__Mail_PaperOoN_NonPreferredBrand_1,p107_DSC__Mail_PaperOoN_DollarAmount_1,p107_DSC__Mail_PaperOoN_Percent_1,p107_DSC__Mail_PaperOoN_CopayCal_1,p107_DSC__Mail_PaperOoN_MinDollar_1,p107_DSC__Mail_PaperOoN_Max_Dollar_1,p107_DSC__Mail_PaperOoN_Reverse_1,"False");

		GetReportValues.FailedReportValues("DSC_Mail_PaperOutOfNetwork");

		
		}	
		
		public static void validateAccum() throws Exception {	
		ValidateProvisionTemplate_Test.validateAccumulationsDrugSpecific("107", P107_Line_Value, P107_Accum_ArethereanydrugspecificMAB, P107_Accum_M,P107_Accum_O, P107_Accum_N, P107_Accum_Y,P107_Accum_Druglist, P107_Accum_DrugGroup,P107_Accum_MAB_Amount, P107_Accum_MAB_Period, P107_Accum_MAB_Met);		
	}
	
	public static void getProvision107TemplateValues(Object[][] provision107Template){

p107_Line_Value     =   provision107Template[0][1].toString();
p107_DC_Line_Text     =   provision107Template[0][2].toString();


p107_DC_Retail_DrugList_DrugGroup_1     =   provision107Template[0][5].toString();
p107_DC_Retail_Notes_1     =   provision107Template[0][6].toString();
p107_DC_Retail_DrugList_1     =   provision107Template[0][7].toString();
p107_DC_Retail_InclusionExclusionDrugClass_1     =   provision107Template[0][8].toString();
p107_DC_Retail_InclusionExclusion_1     =   provision107Template[0][9].toString();
p107_DC_Retail_ApplyLimitations_1     =   provision107Template[0][10].toString();
p107_DC_Retail_StartAge_1     =   provision107Template[0][11].toString();
p107_DC_Retail_EndAge_1     =   provision107Template[0][12].toString();
p107_DC_Retail_Gender_1     =   provision107Template[0][13].toString();
p107_DC_Retail_MinimumDays_1     =   provision107Template[0][14].toString();
p107_DC_Retail_MinimumQuality_1     =   provision107Template[0][15].toString();
p107_DC_Retail_DailyDose_1     =   provision107Template[0][16].toString();
p107_DC_Retail_StartAgeType_1     =   provision107Template[0][17].toString();
p107_DC_Retail_EndAgeType_1     =   provision107Template[0][18].toString();
p107_DC_Retail_DayQuantityRule_1     =   provision107Template[0][19].toString();
p107_DC_Retail_MaximumDays_1     =   provision107Template[0][20].toString();
p107_DC_Retail_MaximumFills_1     =   provision107Template[0][21].toString();
p107_DC_Retail_MaximumDaysperFill_1     =   provision107Template[0][22].toString();
p107_DC_Retail_DaysOverTimeTimePeriod_1     =   provision107Template[0][23].toString();
p107_DC_Retail_DaysoverTimeofDays_1      =   provision107Template[0][24].toString();
p107_DC_Retail_DaysoverTimeTimeValue_1     =   provision107Template[0][25].toString();
p107_DC_Retail_MaxQuantityperFill_1     =   provision107Template[0][26].toString();
p107_DC_Retail_QuantityoverTimeQuantity_1     =   provision107Template[0][27].toString();
p107_DC_Retail_QuantityOverTimeTimePeriod_1     =   provision107Template[0][28].toString();
p107_DC_Retail_QuantityoverTimeTimeValue_1     =   provision107Template[0][29].toString();
p107_DC_Retail_BypassMOOP_1     =   provision107Template[0][30].toString();

p107_DC_Mail_DrugList_DrugGroup_1     =   provision107Template[0][32].toString();
p107_DC_Mail_Notes_1     =   provision107Template[0][33].toString();
p107_DC_Mail_DrugList_1     =   provision107Template[0][34].toString();
p107_DC_Mail_InclusionExclusionDrugClass_1     =   provision107Template[0][35].toString();
p107_DC_Mail_InclusionExclusion_1     =   provision107Template[0][36].toString();
p107_DC_Mail_ApplyLimitations_1     =   provision107Template[0][37].toString();
p107_DC_Mail_StartAge_1     =   provision107Template[0][38].toString();
p107_DC_Mail_EndAge_1     =   provision107Template[0][39].toString();
p107_DC_Mail_Gender_1     =   provision107Template[0][40].toString();
p107_DC_Mail_MinimumDays_1     =   provision107Template[0][41].toString();
p107_DC_Mail_MinimumQuality_1     =   provision107Template[0][42].toString();
p107_DC_Mail_DailyDose_1     =   provision107Template[0][43].toString();
p107_DC_Mail_StartAgeType_1     =   provision107Template[0][44].toString();
p107_DC_Mail_EndAgeType_1     =   provision107Template[0][45].toString();
p107_DC_Mail_DayQuantityRule_1     =   provision107Template[0][46].toString();
p107_DC_Mail_MaximumDays_1     =   provision107Template[0][47].toString();
p107_DC_Mail_MaximumFills_1     =   provision107Template[0][48].toString();
p107_DC_Mail_MaximumDaysperFill_1     =   provision107Template[0][49].toString();
p107_DC_Mail_DaysOverTimeTimePeriod_1     =   provision107Template[0][50].toString();
p107_DC_Mail_DaysoverTimeofDays_1      =   provision107Template[0][51].toString();
p107_DC_Mail_DaysoverTimeTimeValue_1     =   provision107Template[0][52].toString();
p107_DC_Mail_MaxQuantityperFill_1     =   provision107Template[0][53].toString();
p107_DC_Mail_QuantityoverTimeQuantity_1     =   provision107Template[0][54].toString();
p107_DC_Mail_QuantityOverTimeTimePeriod_1     =   provision107Template[0][55].toString();
p107_DC_Mail_QuantityoverTimeTimeValue_1     =   provision107Template[0][56].toString();
p107_DC_Mail_BypassMOOP_1     =   provision107Template[0][57].toString();


p107_DSC__Retail_Retail_Present_1               =   provision107Template[0][60].toString();
p107_DSC__Retail_DrugListSelection_1   =   provision107Template[0][61].toString();
p107_DSC__Retail_DrugList_1   =   provision107Template[0][62].toString();
p107_DSC__Retail_Stepped_1   =   provision107Template[0][63].toString();
p107_DSC__Retail_M_1   =   provision107Template[0][64].toString();
p107_DSC__Retail_N_1   =   provision107Template[0][65].toString();
p107_DSC__Retail_O_1   =   provision107Template[0][66].toString();
p107_DSC__Retail_Y_1   =   provision107Template[0][67].toString();
p107_DSC__Retail_PreferredGeneric_1   =   provision107Template[0][68].toString();
p107_DSC__Retail_NonPreferredGeneric_1   =   provision107Template[0][69].toString();
p107_DSC__Retail_PreferredBrand_1   =   provision107Template[0][70].toString();
p107_DSC__Retail_NonPreferredBrand_1   =   provision107Template[0][71].toString();
p107_DSC__Retail_DollarAmount_1   =   provision107Template[0][72].toString();
p107_DSC__Retail_Percent_1   =   provision107Template[0][73].toString();
p107_DSC__Retail_CopayCal_1   =   provision107Template[0][74].toString();
p107_DSC__Retail_MinDollar_1   =   provision107Template[0][75].toString();
p107_DSC__Retail_Max_Dollar_1   =   provision107Template[0][76].toString();
p107_DSC__Retail_Reverse_1   =   provision107Template[0][77].toString();


p107_DSC__Mail_Present_1   =   provision107Template[0][80].toString();
p107_DSC__Mail_DrugListSelection_1   =   provision107Template[0][81].toString();
p107_DSC__Mail_DrugList_1   =   provision107Template[0][82].toString();
p107_DSC__Mail_Stepped_1   =   provision107Template[0][83].toString();
p107_DSC__Mail_M_1   =   provision107Template[0][84].toString();
p107_DSC__Mail_N_1   =   provision107Template[0][85].toString();
p107_DSC__Mail_O_1   =   provision107Template[0][86].toString();
p107_DSC__Mail_Y_1   =   provision107Template[0][87].toString();
p107_DSC__Mail_PreferredGeneric_1   =   provision107Template[0][88].toString();
p107_DSC__Mail_NonPreferredGeneric_1   =   provision107Template[0][89].toString();
p107_DSC__Mail_PreferredBrand_1   =   provision107Template[0][90].toString();
p107_DSC__Mail_NonPreferredBrand_1   =   provision107Template[0][91].toString();
p107_DSC__Mail_DollarAmount_1   =   provision107Template[0][92].toString();
p107_DSC__Mail_Percent_1   =   provision107Template[0][93].toString();
p107_DSC__Mail_CopayCal_1   =   provision107Template[0][94].toString();
p107_DSC__Mail_MinDollar_1   =   provision107Template[0][95].toString();
p107_DSC__Mail_Max_Dollar_1   =   provision107Template[0][96].toString();
p107_DSC__Mail_Reverse_1   =   provision107Template[0][97].toString();


p107_DSC__Specialty_Present_1   =   provision107Template[0][100].toString();
p107_DSC__Specialty_DrugListSelection_1   =   provision107Template[0][101].toString();
p107_DSC__Specialty_DrugList_1   =   provision107Template[0][102].toString();
p107_DSC__Specialty_Stepped_1   =   provision107Template[0][103].toString();
p107_DSC__Specialty_M_1   =   provision107Template[0][104].toString();
p107_DSC__Specialty_N_1   =   provision107Template[0][105].toString();
p107_DSC__Specialty_O_1   =   provision107Template[0][106].toString();
p107_DSC__Specialty_Y_1   =   provision107Template[0][107].toString();
p107_DSC__Specialty_PreferredGeneric_1   =   provision107Template[0][108].toString();
p107_DSC__Specialty_NonPreferredGeneric_1   =   provision107Template[0][109].toString();
p107_DSC__Specialty_PreferredBrand_1   =   provision107Template[0][110].toString();
p107_DSC__Specialty_NonPreferredBrand_1   =   provision107Template[0][111].toString();
p107_DSC__Specialty_DollarAmount_1   =   provision107Template[0][112].toString();
p107_DSC__Specialty_Percent_1   =   provision107Template[0][113].toString();
p107_DSC__Specialty_CopayCal_1   =   provision107Template[0][114].toString();
p107_DSC__Specialty_MinDollar_1   =   provision107Template[0][115].toString();
p107_DSC__Specialty_Max_Dollar_1   =   provision107Template[0][116].toString();
p107_DSC__Specialty_Reverse_1   =   provision107Template[0][117].toString();


p107_DSC__SpecialtyOutoFNetwork_Present_1   =   provision107Template[0][120].toString();
p107_DSC__SpecialtyOutoFNetwork_DrugListSelection_1   =   provision107Template[0][121].toString();
p107_DSC__SpecialtyOutoFNetwork_DrugList_1   =   provision107Template[0][122].toString();
p107_DSC__SpecialtyOutoFNetwork_Stepped_1   =   provision107Template[0][123].toString();
p107_DSC__SpecialtyOutoFNetwork_M_1   =   provision107Template[0][124].toString();
p107_DSC__SpecialtyOutoFNetwork_N_1   =   provision107Template[0][125].toString();
p107_DSC__SpecialtyOutoFNetwork_O_1   =   provision107Template[0][126].toString();
p107_DSC__SpecialtyOutoFNetwork_Y_1   =   provision107Template[0][127].toString();
p107_DSC__SpecialtyOutoFNetwork_PreferredGeneric_1   =   provision107Template[0][128].toString();
p107_DSC__SpecialtyOutoFNetwork_NonPreferredGeneric_1   =   provision107Template[0][129].toString();
p107_DSC__SpecialtyOutoFNetwork_PreferredBrand_1   =   provision107Template[0][130].toString();
p107_DSC__SpecialtyOutoFNetwork_NonPreferredBrand_1   =   provision107Template[0][131].toString();
p107_DSC__SpecialtyOutoFNetwork_DollarAmount_1   =   provision107Template[0][132].toString();
p107_DSC__SpecialtyOutoFNetwork_Percent_1   =   provision107Template[0][133].toString();
p107_DSC__SpecialtyOutoFNetwork_CopayCal_1   =   provision107Template[0][134].toString();
p107_DSC__SpecialtyOutoFNetwork_MinDollar_1   =   provision107Template[0][135].toString();
p107_DSC__SpecialtyOutoFNetwork_Max_Dollar_1   =   provision107Template[0][136].toString();
p107_DSC__SpecialtyOutoFNetwork_Reverse_1   =   provision107Template[0][137].toString();


p107_DSC__Paper_Present_1   =   provision107Template[0][140].toString();
p107_DSC__Paper_DrugListSelection_1   =   provision107Template[0][141].toString();
p107_DSC__Paper_DrugList_1   =   provision107Template[0][142].toString();
p107_DSC__Paper_Stepped_1   =   provision107Template[0][143].toString();
p107_DSC__Paper_M_1   =   provision107Template[0][144].toString();
p107_DSC__Paper_N_1   =   provision107Template[0][145].toString();
p107_DSC__Paper_O_1   =   provision107Template[0][146].toString();
p107_DSC__Paper_Y_1   =   provision107Template[0][147].toString();
p107_DSC__Paper_PreferredGeneric_1   =   provision107Template[0][148].toString();
p107_DSC__Paper_NonPreferredGeneric_1   =   provision107Template[0][149].toString();
p107_DSC__Paper_PreferredBrand_1   =   provision107Template[0][150].toString();
p107_DSC__Paper_NonPreferredBrand_1   =   provision107Template[0][151].toString();
p107_DSC__Paper_DollarAmount_1   =   provision107Template[0][152].toString();
p107_DSC__Paper_Percent_1   =   provision107Template[0][153].toString();
p107_DSC__Paper_CopayCal_1   =   provision107Template[0][154].toString();
p107_DSC__Paper_MinDollar_1   =   provision107Template[0][155].toString();
p107_DSC__Paper_Max_Dollar_1   =   provision107Template[0][156].toString();
p107_DSC__Paper_Reverse_1   =   provision107Template[0][157].toString();


p107_DSC__PaperOutoFNetwork_Present_1   =   provision107Template[0][160].toString();
p107_DSC__PaperOutoFNetwork_DrugListSelection_1   =   provision107Template[0][161].toString();
p107_DSC__PaperOutoFNetwork_DrugList_1   =   provision107Template[0][162].toString();
p107_DSC__PaperOutoFNetwork_Stepped_1   =   provision107Template[0][163].toString();
p107_DSC__PaperOutoFNetwork_M_1   =   provision107Template[0][164].toString();
p107_DSC__PaperOutoFNetwork_N_1   =   provision107Template[0][165].toString();
p107_DSC__PaperOutoFNetwork_O_1   =   provision107Template[0][166].toString();
p107_DSC__PaperOutoFNetwork_Y_1   =   provision107Template[0][167].toString();
p107_DSC__PaperOutoFNetwork_PreferredGeneric_1   =   provision107Template[0][168].toString();
p107_DSC__PaperOutoFNetwork_NonPreferredGeneric_1   =   provision107Template[0][169].toString();
p107_DSC__PaperOutoFNetwork_PreferredBrand_1   =   provision107Template[0][170].toString();
p107_DSC__PaperOutoFNetwork_NonPreferredBrand_1   =   provision107Template[0][171].toString();
p107_DSC__PaperOutoFNetwork_DollarAmount_1   =   provision107Template[0][172].toString();
p107_DSC__PaperOutoFNetwork_Percent_1   =   provision107Template[0][173].toString();
p107_DSC__PaperOutoFNetwork_CopayCal_1   =   provision107Template[0][174].toString();
p107_DSC__PaperOutoFNetwork_MinDollar_1   =   provision107Template[0][175].toString();
p107_DSC__PaperOutoFNetwork_Max_Dollar_1   =   provision107Template[0][176].toString();
p107_DSC__PaperOutoFNetwork_Reverse_1   =   provision107Template[0][177].toString();


p107_DSC__Mail_PaperOoN_Present_1   =   provision107Template[0][180].toString();
p107_DSC__Mail_PaperOoN_DrugListSelection_1   =   provision107Template[0][181].toString();
p107_DSC__Mail_PaperOoN_DrugList_1   =   provision107Template[0][182].toString();
p107_DSC__Mail_PaperOoN_Stepped_1   =   provision107Template[0][183].toString();
p107_DSC__Mail_PaperOoN_M_1   =   provision107Template[0][184].toString();
p107_DSC__Mail_PaperOoN_N_1   =   provision107Template[0][185].toString();
p107_DSC__Mail_PaperOoN_O_1   =   provision107Template[0][186].toString();
p107_DSC__Mail_PaperOoN_Y_1   =   provision107Template[0][187].toString();
p107_DSC__Mail_PaperOoN_PreferredGeneric_1   =   provision107Template[0][188].toString();
p107_DSC__Mail_PaperOoN_NonPreferredGeneric_1   =   provision107Template[0][189].toString();
p107_DSC__Mail_PaperOoN_PreferredBrand_1   =   provision107Template[0][190].toString();
p107_DSC__Mail_PaperOoN_NonPreferredBrand_1   =   provision107Template[0][191].toString();
p107_DSC__Mail_PaperOoN_DollarAmount_1   =   provision107Template[0][192].toString();
p107_DSC__Mail_PaperOoN_Percent_1   =   provision107Template[0][193].toString();
p107_DSC__Mail_PaperOoN_CopayCal_1   =   provision107Template[0][194].toString();
p107_DSC__Mail_PaperOoN_MinDollar_1   =   provision107Template[0][195].toString();
p107_DSC__Mail_PaperOoN_Max_Dollar_1   =   provision107Template[0][196].toString();
p107_DSC__Mail_PaperOoN_Reverse_1   =   provision107Template[0][197].toString();
	}
	}
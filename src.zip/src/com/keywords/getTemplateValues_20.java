package com.keywords;

import java.util.ArrayList;

import org.testng.annotations.Test;

import com.FrameworkFunctions.GetReportValues;

public class getTemplateValues_20  {

	//initialization
	//Drug coverage
	
	public static String p20_Line_Value = "";
	public static String p20_Line_Text = "";
	public static String p20_DC_Retail_DrugList_DrugGroup_1 = "";
	public static String p20_DC_Retail_DrugList_1 = "";
	public static String p20_DC_Retail_InclusionExclusionDrugClass_1 = "";
	public static String p20_DC_Retail_InclusionExclusion_1 = "";
	public static String p20_DC_Retail_ApplyLimitations_1 = "";
	public static String p20_DC_Retail_StartAge_1 = "";
	public static String p20_DC_Retail_EndAge_1 = "";
	public static String p20_DC_Retail_Gender_1 = "";
	public static String p20_DC_Retail_MinimumDays_1 = "";
	public static String p20_DC_Retail_MinimumQuality_1 = "";
	public static String p20_DC_Retail_DailyDose_1 = "";
	public static String p20_DC_Retail_StartAgeType_1 = "";
	public static String p20_DC_Retail_EndAgeType_1 = "";
	public static String p20_DC_Retail_DayQuantityRule_1 = "";
	public static String p20_DC_Retail_MaximumDays_1 = "";
	public static String p20_DC_Retail_MaximumFills_1 = "";
	public static String p20_DC_Retail_MaximumDaysperFill_1 = "";
	public static String p20_DC_Retail_DaysOverTimeTimePeriod_1 = "";
	public static String p20_DC_Retail_DaysoverTimeofDays_1  = "";
	public static String p20_DC_Retail_DaysoverTimeTimeValue_1 = "";
	public static String p20_DC_Retail_MaxQuantityperFill_1 = "";
	public static String p20_DC_Retail_QuantityoverTimeQuantity_1 = "";
	public static String p20_DC_Retail_QuantityOverTimeTimePeriod_1 = "";
	public static String p20_DC_Retail_QuantityoverTimeTimeValue_1 = "";
	public static String p20_DC_Retail_BypassMOOP_1 = "";
	public static String p20_DC_Retail_DrugList_DrugGroup_2 = "";
	public static String p20_DC_Retail_DrugList_2 = "";
	public static String p20_DC_Retail_InclusionExclusionDrugClass_2 = "";
	public static String p20_DC_Retail_InclusionExclusion_2 = "";
	public static String p20_DC_Retail_ApplyLimitations_2 = "";
	public static String p20_DC_Retail_StartAge_2 = "";
	public static String p20_DC_Retail_EndAge_2 = "";
	public static String p20_DC_Retail_Gender_2 = "";
	public static String p20_DC_Retail_MinimumDays_2 = "";
	public static String p20_DC_Retail_MinimumQuality_2 = "";
	public static String p20_DC_Retail_DailyDose_2 = "";
	public static String p20_DC_Retail_StartAgeType_2 = "";
	public static String p20_DC_Retail_EndAgeType_2 = "";
	public static String p20_DC_Retail_DayQuantityRule_2 = "";
	public static String p20_DC_Retail_MaximumDays_2 = "";
	public static String p20_DC_Retail_MaximumFills_2 = "";
	public static String p20_DC_Retail_MaximumDaysperFill_2 = "";
	public static String p20_DC_Retail_DaysOverTimeTimePeriod_2 = "";
	public static String p20_DC_Retail_DaysoverTimeofDays_2  = "";
	public static String p20_DC_Retail_DaysoverTimeTimeValue_2 = "";
	public static String p20_DC_Retail_MaxQuantityperFill_2 = "";
	public static String p20_DC_Retail_QuantityoverTimeQuantity_2 = "";
	public static String p20_DC_Retail_QuantityOverTimeTimePeriod_2 = "";
	public static String p20_DC_Retail_QuantityoverTimeTimeValue_2 = "";
	public static String p20_DC_Retail_BypassMOOP_2 = "";
	public static String p20_DC_Mail_DrugList_DrugGroup_1 = "";
	public static String p20_DC_Mail_DrugList_1 = "";
	public static String p20_DC_Mail_InclusionExclusionDrugClass_1 = "";
	public static String p20_DC_Mail_InclusionExclusion_1 = "";
	public static String p20_DC_Mail_ApplyLimitations_1 = "";
	public static String p20_DC_Mail_StartAge_1 = "";
	public static String p20_DC_Mail_EndAge_1 = "";
	public static String p20_DC_Mail_Gender_1 = "";
	public static String p20_DC_Mail_MinimumDays_1 = "";
	public static String p20_DC_Mail_MinimumQuality_1 = "";
	public static String p20_DC_Mail_DailyDose_1 = "";
	public static String p20_DC_Mail_StartAgeType_1 = "";
	public static String p20_DC_Mail_EndAgeType_1 = "";
	public static String p20_DC_Mail_DayQuantityRule_1 = "";
	public static String p20_DC_Mail_MaximumDays_1 = "";
	public static String p20_DC_Mail_MaximumFills_1 = "";
	public static String p20_DC_Mail_MaximumDaysperFill_1 = "";
	public static String p20_DC_Mail_DaysOverTimeTimePeriod_1 = "";
	public static String p20_DC_Mail_DaysoverTimeofDays_1  = "";
	public static String p20_DC_Mail_DaysoverTimeTimeValue_1 = "";
	public static String p20_DC_Mail_MaxQuantityperFill_1 = "";
	public static String p20_DC_Mail_QuantityoverTimeQuantity_1 = "";
	public static String p20_DC_Mail_QuantityOverTimeTimePeriod_1 = "";
	public static String p20_DC_Mail_QuantityoverTimeTimeValue_1 = "";
	public static String p20_DC_Mail_BypassMOOP_1 = "";
	public static String p20_DC_Mail_DrugList_DrugGroup_2 = "";
	public static String p20_DC_Mail_DrugList_2 = "";
	public static String p20_DC_Mail_InclusionExclusionDrugClass_2 = "";
	public static String p20_DC_Mail_InclusionExclusion_2 = "";
	public static String p20_DC_Mail_ApplyLimitations_2 = "";
	public static String p20_DC_Mail_StartAge_2 = "";
	public static String p20_DC_Mail_EndAge_2 = "";
	public static String p20_DC_Mail_Gender_2 = "";
	public static String p20_DC_Mail_MinimumDays_2 = "";
	public static String p20_DC_Mail_MinimumQuality_2 = "";
	public static String p20_DC_Mail_DailyDose_2 = "";
	public static String p20_DC_Mail_StartAgeType_2 = "";
	public static String p20_DC_Mail_EndAgeType_2 = "";
	public static String p20_DC_Mail_DayQuantityRule_2 = "";
	public static String p20_DC_Mail_MaximumDays_2 = "";
	public static String p20_DC_Mail_MaximumFills_2 = "";
	public static String p20_DC_Mail_MaximumDaysperFill_2 = "";
	public static String p20_DC_Mail_DaysOverTimeTimePeriod_2 = "";
	public static String p20_DC_Mail_DaysoverTimeofDays_2  = "";
	public static String p20_DC_Mail_DaysoverTimeTimeValue_2 = "";
	public static String p20_DC_Mail_MaxQuantityperFill_2 = "";
	public static String p20_DC_Mail_QuantityoverTimeQuantity_2 = "";
	public static String p20_DC_Mail_QuantityOverTimeTimePeriod_2 = "";
	public static String p20_DC_Mail_QuantityoverTimeTimeValue_2 = "";
	public static String p20_DC_Mail_BypassMOOP_2 = "";
	
	    // Drug specific Copay
		//			public static String P20_DSC__Retail_1  
	
	public static String p20_DSC_Retail_Notes_1                                                                  = "";
	public static String p20_DSC_Retail_Present_1                                                                  = "";
	public static String p20_DSC_Retail_DrugList_DrugGroup_1                                              = "";
	public static String p20_DSC_Retail_DrugList_1                                                               = "";
	public static String p20_DSC_Retail_Stepped_1                                                                = "";
	public static String p20_DSC_Retail_M_1                                                                      = "";
	public static String p20_DSC_Retail_N_1                                                                      = "";
	public static String p20_DSC_Retail_O_1                                                                      = "";
	public static String p20_DSC_Retail_Y_1                                                                      = "";
	public static String p20_DSC_Retail_PreferredGeneric_1                                                           = "";
	public static String p20_DSC_Retail_NonPreferredGeneric_1                                                                = "";
	public static String p20_DSC_Retail_PreferredBrand_1                                                               = "";
	public static String p20_DSC_Retail_NonPreferredBrand_1 = "";
	public static String p20_DSC_Retail_DollarAmount_1                                                           = "";
	public static String p20_DSC_Retail_Percent_1                                                                = "";
	public static String P20_DSC_Retail_CopayCalculation_1                                                               = "";
	public static String P20_DSC_Retail_MinimumDollar_1  = "";
	public static String P20_DSC_Retail_MaximumDollar_1                                                             = "";
	public static String P20_DSC_Retail_Reverse_1                                                                = "";
	
//	public static String P20_DSC__Mail_1
	
	public static String p20_DSC_Mail_Notes_1                                                                  = "";
	public static String p20_DSC_Mail_Present_1                                                                  = "";
	public static String p20_DSC_Mail_DrugList_DrugGroup_1                                              = "";
	public static String p20_DSC_Mail_DrugList_1                                                               = "";
	public static String p20_DSC_Mail_Stepped_1                                                                = "";
	public static String p20_DSC_Mail_M_1                                                                      = "";
	public static String p20_DSC_Mail_N_1                                                                      = "";
	public static String p20_DSC_Mail_O_1                                                                      = "";
	public static String p20_DSC_Mail_Y_1                                                                      = "";
	public static String p20_DSC_Mail_PreferredGeneric_1                                                           = "";
	public static String p20_DSC_Mail_NonPreferredGeneric_1                                                                = "";
	public static String p20_DSC_Mail_PreferredBrand_1                                                               = "";
	public static String p20_DSC_Mail_NonPreferredBrand_1 = "";
	public static String p20_DSC_Mail_DollarAmount_1                                                           = "";
	public static String p20_DSC_Mail_Percent_1                                                                = "";
	public static String P20_DSC_Mail_CopayCalculation_1                                                               = "";
	public static String P20_DSC_Mail_MinimumDollar_1  = "";
	public static String P20_DSC_Mail_MaximumDollar_1                                                             = "";
	public static String P20_DSC_Mail_Reverse_1                                                                = "";

//	public static String P20_DSC__Specialty_1
	
	public static String p20_DSC_Specialty_Notes_1                                                                  = "";
	public static String p20_DSC_Specialty_Present_1                                                                  = "";
	public static String p20_DSC_Specialty_DrugList_DrugGroup_1                                              = "";
	public static String p20_DSC_Specialty_DrugList_1                                                               = "";
	public static String p20_DSC_Specialty_Stepped_1                                                                = "";
	public static String p20_DSC_Specialty_M_1                                                                      = "";
	public static String p20_DSC_Specialty_N_1                                                                      = "";
	public static String p20_DSC_Specialty_O_1                                                                      = "";
	public static String p20_DSC_Specialty_Y_1                                                                      = "";
	public static String p20_DSC_Specialty_PreferredGeneric_1                                                           = "";
	public static String p20_DSC_Specialty_NonPreferredGeneric_1                                                                = "";
	public static String p20_DSC_Specialty_PreferredBrand_1                                                               = "";
	public static String p20_DSC_Specialty_NonPreferredBrand_1 = "";
	public static String p20_DSC_Specialty_DollarAmount_1                                                           = "";
	public static String p20_DSC_Specialty_Percent_1                                                                = "";
	public static String P20_DSC_Specialty_CopayCalculation_1                                                               = "";
	public static String P20_DSC_Specialty_MinimumDollar_1  = "";
	public static String P20_DSC_Specialty_MaximumDollar_1                                                             = "";
	public static String P20_DSC_Specialty_Reverse_1                                                                = "";

//	public static String P20_DSC__SpecialtyOoN_1
	
	public static String p20_DSC_SpecialtyOoN_Notes_1                                                                  = "";
	public static String p20_DSC_SpecialtyOoN_Present_1                                                                  = "";
	public static String p20_DSC_SpecialtyOoN_DrugList_DrugGroup_1                                              = "";
	public static String p20_DSC_SpecialtyOoN_DrugList_1                                                               = "";
	public static String p20_DSC_SpecialtyOoN_Stepped_1                                                                = "";
	public static String p20_DSC_SpecialtyOoN_M_1                                                                      = "";
	public static String p20_DSC_SpecialtyOoN_N_1                                                                      = "";
	public static String p20_DSC_SpecialtyOoN_O_1                                                                      = "";
	public static String p20_DSC_SpecialtyOoN_Y_1                                                                      = "";
	public static String p20_DSC_SpecialtyOoN_PreferredGeneric_1                                                           = "";
	public static String p20_DSC_SpecialtyOoN_NonPreferredGeneric_1                                                                = "";
	public static String p20_DSC_SpecialtyOoN_PreferredBrand_1                                                               = "";
	public static String p20_DSC_SpecialtyOoN_NonPreferredBrand_1 = "";
	public static String p20_DSC_SpecialtyOoN_DollarAmount_1                                                           = "";
	public static String p20_DSC_SpecialtyOoN_Percent_1                                                                = "";
	public static String P20_DSC_SpecialtyOoN_CopayCalculation_1                                                               = "";
	public static String P20_DSC_SpecialtyOoN_MinimumDollar_1  = "";
	public static String P20_DSC_SpecialtyOoN_MaximumDollar_1                                                             = "";
	public static String P20_DSC_SpecialtyOoN_Reverse_1                                                                = "";

//	public static String P20_DSC__Paper_1
	
	public static String p20_DSC_Paper_Notes_1                                                                  = "";
	public static String p20_DSC_Paper_Present_1                                                                  = "";
	public static String p20_DSC_Paper_DrugList_DrugGroup_1                                              = "";
	public static String p20_DSC_Paper_DrugList_1                                                               = "";
	public static String p20_DSC_Paper_Stepped_1                                                                = "";
	public static String p20_DSC_Paper_M_1                                                                      = "";
	public static String p20_DSC_Paper_N_1                                                                      = "";
	public static String p20_DSC_Paper_O_1                                                                      = "";
	public static String p20_DSC_Paper_Y_1                                                                      = "";
	public static String p20_DSC_Paper_PreferredGeneric_1                                                           = "";
	public static String p20_DSC_Paper_NonPreferredGeneric_1                                                                = "";
	public static String p20_DSC_Paper_PreferredBrand_1                                                               = "";
	public static String p20_DSC_Paper_NonPreferredBrand_1 = "";
	public static String p20_DSC_Paper_DollarAmount_1                                                           = "";
	public static String p20_DSC_Paper_Percent_1                                                                = "";
	public static String P20_DSC_Paper_CopayCalculation_1                                                               = "";
	public static String P20_DSC_Paper_MinimumDollar_1  = "";
	public static String P20_DSC_Paper_MaximumDollar_1                                                             = "";
	public static String P20_DSC_Paper_Reverse_1                                                                = "";

//	public static String P20_DSC__PaperOutOfNetwork_1
	
	public static String p20_DSC_PaperOoN_Notes_1                                                                  = "";
	public static String p20_DSC_PaperOoN_Present_1 = "";
	public static String p20_DSC_PaperOoN_DrugList_DrugGroup_1                                             = "";
	public static String p20_DSC_PaperOoN_DrugList_1                                                                                            = "";
	public static String p20_DSC_PaperOoN_Stepped_1                                                               = "";
	public static String p20_DSC_PaperOoN_M_1                                                                     = "";
	public static String p20_DSC_PaperOoN_N_1                                                                      = "";
	public static String p20_DSC_PaperOoN_O_1                                                                     = "";
	public static String p20_DSC_PaperOoN_Y_1                                                                      = "";
	public static String p20_DSC_PaperOoN_PreferredGeneric_1                                                           = "";
	public static String p20_DSC_PaperOoN_NonPreferredGeneric_1                                                               = "";
	public static String p20_DSC_PaperOoN_PreferredBrand_1                                                               = "";
	public static String p20_DSC_PaperOoN_NonPreferredBrand_1  = "";
	public static String p20_DSC_PaperOoN_DollarAmount_1                                                          = "";
	public static String p20_DSC_PaperOoN_Percent_1                                                                = "";
	public static String P20_DSC_PaperOoN_CopayCalculation_1                                                               = "";
	public static String P20_DSC_PaperOoN_MinimumDollar_1  = "";
	public static String P20_DSC_PaperOoN_MaximumDollar_1                                                             = "";
	public static String P20_DSC_PaperOoN_Reverse_1                                                                = "";

//	public static String P20_DSC_Mail_PaperOutOfNetwork_1
	
	public static String p20_DSC_Mail_PaperOoN_Notes_1                                                                  = "";
	public static String p20_DSC_Mail_PaperOoN_Present_1 = "";
	public static String p20_DSC_Mail_PaperOoN_DrugList_DrugGroup_1                                              = "";
	public static String p20_DSC_Mail_PaperOoN_DrugList_1                                                                                            = "";
	public static String p20_DSC_Mail_PaperOoN_Stepped_1                                                               = "";
	public static String p20_DSC_Mail_PaperOoN_M_1                                                                     = "";
	public static String p20_DSC_Mail_PaperOoN_N_1                                                                      = "";
	public static String p20_DSC_Mail_PaperOoN_O_1                                                                     = "";
	public static String p20_DSC_Mail_PaperOoN_Y_1                                                                      = "";
	public static String p20_DSC_Mail_PaperOoN_PreferredGeneric_1                                                           = "";
	public static String p20_DSC_Mail_PaperOoN_NonPreferredGeneric_1                                                               = "";
	public static String p20_DSC_Mail_PaperOoN_PreferredBrand_1                                                               = "";
	public static String p20_DSC_Mail_PaperOoN_NonPreferredBrand_1  = "";
	public static String p20_DSC_Mail_PaperOoN_DollarAmount_1                                                          = "";
	public static String p20_DSC_Mail_PaperOoN_Percent_1                                                                = "";
	public static String P20_DSC_Mail_PaperOoN_CopayCalculation_1                                                               = "";
	public static String P20_DSC_Mail_PaperOoN_MinimumDollar_1  = "";
	public static String P20_DSC_Mail_PaperOoN_MaximumDollar_1                                                             = "";
	public static String P20_DSC_Mail_PaperOoN_Reverse_1                                                                = "";


	
	//Accumulation

	public static String P20_Accum_Notes = "";
	public static String P20_Accum_ArethereanydrugspecificMAB = "";
	public static String P20_Accum_M = "";
	public static String P20_Accum_O = "";
	public static String P20_Accum_N = "";
	public static String P20_Accum_Y = "";
	public static String P20_Accum_Druglist = "";
	public static String P20_Accum_DrugGroup = "";
	public static String P20_Accum_MAB_Amount = "";
	public static String P20_Accum_MAB_Period = "";
	public static String P20_Accum_MAB_Met = "";


/*
	public static void validateDC() throws Exception {

		GetReportValues.MapValDC("4", p4_Line_Value, "DC_Retail");
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Retail", p4_DC_Retail_DrugList_DrugGroup_1, p4_DC_Retail_DrugList_1, p4_DC_Retail_InclusionExclusionDrugClass_1, p4_DC_Retail_InclusionExclusion_1, p4_DC_Retail_ApplyLimitations_1, p4_DC_Retail_StartAge_1, p4_DC_Retail_EndAge_1, p4_DC_Retail_Gender_1, p4_DC_Retail_MinimumDays_1, p4_DC_Retail_MinimumQuality_1, p4_DC_Retail_DailyDose_1, p4_DC_Retail_StartAgeType_1, p4_DC_Retail_EndAgeType_1, p4_DC_Retail_DayQuantityRule_1, p4_DC_Retail_MaximumDays_1, p4_DC_Retail_MaximumFills_1, p4_DC_Retail_MaximumDaysperFill_1, p4_DC_Retail_DaysOverTimeTimePeriod_1, p4_DC_Retail_DaysoverTimeofDays_1, p4_DC_Retail_DaysoverTimeTimeValue_1, p4_DC_Retail_MaxQuantityperFill_1, p4_DC_Retail_QuantityoverTimeQuantity_1, p4_DC_Retail_QuantityOverTimeTimePeriod_1, p4_DC_Retail_QuantityoverTimeTimeValue_1, p4_DC_Retail_BypassMOOP_1);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Retail", p4_DC_Retail_DrugList_DrugGroup_2, p4_DC_Retail_DrugList_2, p4_DC_Retail_InclusionExclusionDrugClass_2, p4_DC_Retail_InclusionExclusion_2, p4_DC_Retail_ApplyLimitations_2, p4_DC_Retail_StartAge_2, p4_DC_Retail_EndAge_2, p4_DC_Retail_Gender_2, p4_DC_Retail_MinimumDays_2, p4_DC_Retail_MinimumQuality_2, p4_DC_Retail_DailyDose_2, p4_DC_Retail_StartAgeType_2, p4_DC_Retail_EndAgeType_2, p4_DC_Retail_DayQuantityRule_2, p4_DC_Retail_MaximumDays_2, p4_DC_Retail_MaximumFills_2, p4_DC_Retail_MaximumDaysperFill_2, p4_DC_Retail_DaysOverTimeTimePeriod_2, p4_DC_Retail_DaysoverTimeofDays_2, p4_DC_Retail_DaysoverTimeTimeValue_2, p4_DC_Retail_MaxQuantityperFill_2, p4_DC_Retail_QuantityoverTimeQuantity_2, p4_DC_Retail_QuantityOverTimeTimePeriod_2, p4_DC_Retail_QuantityoverTimeTimeValue_2, p4_DC_Retail_BypassMOOP_2);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Retail", p4_DC_Retail_DrugList_DrugGroup_3, p4_DC_Retail_DrugList_3, p4_DC_Retail_InclusionExclusionDrugClass_3, p4_DC_Retail_InclusionExclusion_3, p4_DC_Retail_ApplyLimitations_3, p4_DC_Retail_StartAge_3, p4_DC_Retail_EndAge_3, p4_DC_Retail_Gender_3, p4_DC_Retail_MinimumDays_3, p4_DC_Retail_MinimumQuality_3, p4_DC_Retail_DailyDose_3, p4_DC_Retail_StartAgeType_3, p4_DC_Retail_EndAgeType_3, p4_DC_Retail_DayQuantityRule_3, p4_DC_Retail_MaximumDays_3, p4_DC_Retail_MaximumFills_3, p4_DC_Retail_MaximumDaysperFill_3, p4_DC_Retail_DaysOverTimeTimePeriod_3, p4_DC_Retail_DaysoverTimeofDays_3, p4_DC_Retail_DaysoverTimeTimeValue_3, p4_DC_Retail_MaxQuantityperFill_3, p4_DC_Retail_QuantityoverTimeQuantity_3, p4_DC_Retail_QuantityOverTimeTimePeriod_3, p4_DC_Retail_QuantityoverTimeTimeValue_3, p4_DC_Retail_BypassMOOP_3);		
		GetReportValues.FailedReportValues_DC("DC_Retail");
		GetReportValues.MapValDC("4", p4_Line_Value, "DC_Mail");
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_1, p4_DC_Mail_DrugList_1, p4_DC_Mail_InclusionExclusionDrugClass_1, p4_DC_Mail_InclusionExclusion_1, p4_DC_Mail_ApplyLimitations_1, p4_DC_Mail_StartAge_1, p4_DC_Mail_EndAge_1, p4_DC_Mail_Gender_1, p4_DC_Mail_MinimumDays_1, p4_DC_Mail_MinimumQuality_1, p4_DC_Mail_DailyDose_1, p4_DC_Mail_StartAgeType_1, p4_DC_Mail_EndAgeType_1, p4_DC_Mail_DayQuantityRule_1, p4_DC_Mail_MaximumDays_1, p4_DC_Mail_MaximumFills_1, p4_DC_Mail_MaximumDaysperFill_1, p4_DC_Mail_DaysOverTimeTimePeriod_1, p4_DC_Mail_DaysoverTimeofDays_1, p4_DC_Mail_DaysoverTimeTimeValue_1, p4_DC_Mail_MaxQuantityperFill_1, p4_DC_Mail_QuantityoverTimeQuantity_1, p4_DC_Mail_QuantityOverTimeTimePeriod_1, p4_DC_Mail_QuantityoverTimeTimeValue_1, p4_DC_Mail_BypassMOOP_1);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_2, p4_DC_Mail_DrugList_2, p4_DC_Mail_InclusionExclusionDrugClass_2, p4_DC_Mail_InclusionExclusion_2, p4_DC_Mail_ApplyLimitations_2, p4_DC_Mail_StartAge_2, p4_DC_Mail_EndAge_2, p4_DC_Mail_Gender_2, p4_DC_Mail_MinimumDays_2, p4_DC_Mail_MinimumQuality_2, p4_DC_Mail_DailyDose_2, p4_DC_Mail_StartAgeType_2, p4_DC_Mail_EndAgeType_2, p4_DC_Mail_DayQuantityRule_2, p4_DC_Mail_MaximumDays_2, p4_DC_Mail_MaximumFills_2, p4_DC_Mail_MaximumDaysperFill_2, p4_DC_Mail_DaysOverTimeTimePeriod_2, p4_DC_Mail_DaysoverTimeofDays_2, p4_DC_Mail_DaysoverTimeTimeValue_2, p4_DC_Mail_MaxQuantityperFill_2, p4_DC_Mail_QuantityoverTimeQuantity_2, p4_DC_Mail_QuantityOverTimeTimePeriod_2, p4_DC_Mail_QuantityoverTimeTimeValue_2, p4_DC_Mail_BypassMOOP_2);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_3, p4_DC_Mail_DrugList_3, p4_DC_Mail_InclusionExclusionDrugClass_3, p4_DC_Mail_InclusionExclusion_3, p4_DC_Mail_ApplyLimitations_3, p4_DC_Mail_StartAge_3, p4_DC_Mail_EndAge_3, p4_DC_Mail_Gender_3, p4_DC_Mail_MinimumDays_3, p4_DC_Mail_MinimumQuality_3, p4_DC_Mail_DailyDose_3, p4_DC_Mail_StartAgeType_3, p4_DC_Mail_EndAgeType_3, p4_DC_Mail_DayQuantityRule_3, p4_DC_Mail_MaximumDays_3, p4_DC_Mail_MaximumFills_3, p4_DC_Mail_MaximumDaysperFill_3, p4_DC_Mail_DaysOverTimeTimePeriod_3, p4_DC_Mail_DaysoverTimeofDays_3, p4_DC_Mail_DaysoverTimeTimeValue_3, p4_DC_Mail_MaxQuantityperFill_3, p4_DC_Mail_QuantityoverTimeQuantity_3, p4_DC_Mail_QuantityOverTimeTimePeriod_3, p4_DC_Mail_QuantityoverTimeTimeValue_3, p4_DC_Mail_BypassMOOP_3);		
		ValidateProvisionTemplate_Test.validateDrugCoverageDetails("4", p4_Line_Value, "DC_Mail", p4_DC_Mail_DrugList_DrugGroup_4, p4_DC_Mail_DrugList_4, p4_DC_Mail_InclusionExclusionDrugClass_4, p4_DC_Mail_InclusionExclusion_4, p4_DC_Mail_ApplyLimitations_4, p4_DC_Mail_StartAge_4, p4_DC_Mail_EndAge_4, p4_DC_Mail_Gender_4, p4_DC_Mail_MinimumDays_4, p4_DC_Mail_MinimumQuality_4, p4_DC_Mail_DailyDose_4, p4_DC_Mail_StartAgeType_4, p4_DC_Mail_EndAgeType_4, p4_DC_Mail_DayQuantityRule_4, p4_DC_Mail_MaximumDays_4, p4_DC_Mail_MaximumFills_4, p4_DC_Mail_MaximumDaysperFill_4, p4_DC_Mail_DaysOverTimeTimePeriod_4, p4_DC_Mail_DaysoverTimeofDays_4, p4_DC_Mail_DaysoverTimeTimeValue_4, p4_DC_Mail_MaxQuantityperFill_4, p4_DC_Mail_QuantityoverTimeQuantity_4, p4_DC_Mail_QuantityOverTimeTimePeriod_4, p4_DC_Mail_QuantityoverTimeTimeValue_4, p4_DC_Mail_BypassMOOP_4);		
		GetReportValues.FailedReportValues_DC("DC_Mail");
		GetReportValues.LineValueCheck("4",p4_Line_Value);
	}
	public static void validateDSC() throws Exception {


		GetReportValues.getAllMapId_DSC("4",p4_Line_Value,"DSC_Retail");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_1,P4_DSC__Retail_DrugListSelection_1,P4_DSC__Retail_DrugList_1,P4_DSC__Retail_Stepped_1,P4_DSC__Retail_M_1,P4_DSC__Retail_N_1,P4_DSC__Retail_O_1,P4_DSC__Retail_Y_1,P4_DSC__Retail_DollarAmount_1,P4_DSC__Retail_Percent_1,P4_DSC__Retail_CopayCal_1,P4_DSC__Retail_MinDollar_1,P4_DSC__Retail_Max_Dollar_1,P4_DSC__Retail_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_2,P4_DSC__Retail_DrugListSelection_2,P4_DSC__Retail_DrugList_2,P4_DSC__Retail_Stepped_2,P4_DSC__Retail_M_2,P4_DSC__Retail_N_2,P4_DSC__Retail_O_2,P4_DSC__Retail_Y_2,P4_DSC__Retail_DollarAmount_2,P4_DSC__Retail_Percent_2,P4_DSC__Retail_CopayCal_2,P4_DSC__Retail_MinDollar_2,P4_DSC__Retail_Max_Dollar_2,P4_DSC__Retail_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_3,P4_DSC__Retail_DrugListSelection_3,P4_DSC__Retail_DrugList_3,P4_DSC__Retail_Stepped_3,P4_DSC__Retail_M_3,P4_DSC__Retail_N_3,P4_DSC__Retail_O_3,P4_DSC__Retail_Y_3,P4_DSC__Retail_DollarAmount_3,P4_DSC__Retail_Percent_3,P4_DSC__Retail_CopayCal_3,P4_DSC__Retail_MinDollar_3,P4_DSC__Retail_Max_Dollar_3,P4_DSC__Retail_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_4,P4_DSC__Retail_DrugListSelection_4,P4_DSC__Retail_DrugList_4,P4_DSC__Retail_Stepped_4,P4_DSC__Retail_M_4,P4_DSC__Retail_N_4,P4_DSC__Retail_O_4,P4_DSC__Retail_Y_4,P4_DSC__Retail_DollarAmount_4,P4_DSC__Retail_Percent_4,P4_DSC__Retail_CopayCal_4,P4_DSC__Retail_MinDollar_4,P4_DSC__Retail_Max_Dollar_4,P4_DSC__Retail_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_5,P4_DSC__Retail_DrugListSelection_5,P4_DSC__Retail_DrugList_5,P4_DSC__Retail_Stepped_5,P4_DSC__Retail_M_5,P4_DSC__Retail_N_5,P4_DSC__Retail_O_5,P4_DSC__Retail_Y_5,P4_DSC__Retail_DollarAmount_5,P4_DSC__Retail_Percent_5,P4_DSC__Retail_CopayCal_5,P4_DSC__Retail_MinDollar_5,P4_DSC__Retail_Max_Dollar_5,P4_DSC__Retail_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_6,P4_DSC__Retail_DrugListSelection_6,P4_DSC__Retail_DrugList_6,P4_DSC__Retail_Stepped_6,P4_DSC__Retail_M_6,P4_DSC__Retail_N_6,P4_DSC__Retail_O_6,P4_DSC__Retail_Y_6,P4_DSC__Retail_DollarAmount_6,P4_DSC__Retail_Percent_6,P4_DSC__Retail_CopayCal_6,P4_DSC__Retail_MinDollar_6,P4_DSC__Retail_Max_Dollar_6,P4_DSC__Retail_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_7,P4_DSC__Retail_DrugListSelection_7,P4_DSC__Retail_DrugList_7,P4_DSC__Retail_Stepped_7,P4_DSC__Retail_M_7,P4_DSC__Retail_N_7,P4_DSC__Retail_O_7,P4_DSC__Retail_Y_7,P4_DSC__Retail_DollarAmount_7,P4_DSC__Retail_Percent_7,P4_DSC__Retail_CopayCal_7,P4_DSC__Retail_MinDollar_7,P4_DSC__Retail_Max_Dollar_7,P4_DSC__Retail_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Retail",P4_DSC__Retail_Retail_Present_1,P4_DSC__Retail_FormularyGroup_8,P4_DSC__Retail_DrugListSelection_8,P4_DSC__Retail_DrugList_8,P4_DSC__Retail_Stepped_8,P4_DSC__Retail_M_8,P4_DSC__Retail_N_8,P4_DSC__Retail_O_8,P4_DSC__Retail_Y_8,P4_DSC__Retail_DollarAmount_8,P4_DSC__Retail_Percent_8,P4_DSC__Retail_CopayCal_8,P4_DSC__Retail_MinDollar_8,P4_DSC__Retail_Max_Dollar_8,P4_DSC__Retail_Reverse_8,"False");
		GetReportValues.FailedReportValues("DSC_Retail");
		GetReportValues.getAllMapId_DSC("4",p4_Line_Value,"DSC_Mail");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_1,P4_DSC__Mail_DrugListSelection_1,P4_DSC__Mail_DrugList_1,P4_DSC__Mail_Stepped_1,P4_DSC__Mail_M_1,P4_DSC__Mail_N_1,P4_DSC__Mail_O_1,P4_DSC__Mail_Y_1,P4_DSC__Mail_DollarAmount_1,P4_DSC__Mail_Percent_1,P4_DSC__Mail_CopayCal_1,P4_DSC__Mail_MinDollar_1,P4_DSC__Mail_Max_Dollar_1,P4_DSC__Mail_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_2,P4_DSC__Mail_DrugListSelection_2,P4_DSC__Mail_DrugList_2,P4_DSC__Mail_Stepped_2,P4_DSC__Mail_M_2,P4_DSC__Mail_N_2,P4_DSC__Mail_O_2,P4_DSC__Mail_Y_2,P4_DSC__Mail_DollarAmount_2,P4_DSC__Mail_Percent_2,P4_DSC__Mail_CopayCal_2,P4_DSC__Mail_MinDollar_2,P4_DSC__Mail_Max_Dollar_2,P4_DSC__Mail_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_3,P4_DSC__Mail_DrugListSelection_3,P4_DSC__Mail_DrugList_3,P4_DSC__Mail_Stepped_3,P4_DSC__Mail_M_3,P4_DSC__Mail_N_3,P4_DSC__Mail_O_3,P4_DSC__Mail_Y_3,P4_DSC__Mail_DollarAmount_3,P4_DSC__Mail_Percent_3,P4_DSC__Mail_CopayCal_3,P4_DSC__Mail_MinDollar_3,P4_DSC__Mail_Max_Dollar_3,P4_DSC__Mail_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_4,P4_DSC__Mail_DrugListSelection_4,P4_DSC__Mail_DrugList_4,P4_DSC__Mail_Stepped_4,P4_DSC__Mail_M_4,P4_DSC__Mail_N_4,P4_DSC__Mail_O_4,P4_DSC__Mail_Y_4,P4_DSC__Mail_DollarAmount_4,P4_DSC__Mail_Percent_4,P4_DSC__Mail_CopayCal_4,P4_DSC__Mail_MinDollar_4,P4_DSC__Mail_Max_Dollar_4,P4_DSC__Mail_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_5,P4_DSC__Mail_DrugListSelection_5,P4_DSC__Mail_DrugList_5,P4_DSC__Mail_Stepped_5,P4_DSC__Mail_M_5,P4_DSC__Mail_N_5,P4_DSC__Mail_O_5,P4_DSC__Mail_Y_5,P4_DSC__Mail_DollarAmount_5,P4_DSC__Mail_Percent_5,P4_DSC__Mail_CopayCal_5,P4_DSC__Mail_MinDollar_5,P4_DSC__Mail_Max_Dollar_5,P4_DSC__Mail_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_6,P4_DSC__Mail_DrugListSelection_6,P4_DSC__Mail_DrugList_6,P4_DSC__Mail_Stepped_6,P4_DSC__Mail_M_6,P4_DSC__Mail_N_6,P4_DSC__Mail_O_6,P4_DSC__Mail_Y_6,P4_DSC__Mail_DollarAmount_6,P4_DSC__Mail_Percent_6,P4_DSC__Mail_CopayCal_6,P4_DSC__Mail_MinDollar_6,P4_DSC__Mail_Max_Dollar_6,P4_DSC__Mail_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_7,P4_DSC__Mail_DrugListSelection_7,P4_DSC__Mail_DrugList_7,P4_DSC__Mail_Stepped_7,P4_DSC__Mail_M_7,P4_DSC__Mail_N_7,P4_DSC__Mail_O_7,P4_DSC__Mail_Y_7,P4_DSC__Mail_DollarAmount_7,P4_DSC__Mail_Percent_7,P4_DSC__Mail_CopayCal_7,P4_DSC__Mail_MinDollar_7,P4_DSC__Mail_Max_Dollar_7,P4_DSC__Mail_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail",P4_DSC__Mail_Present_1,P4_DSC__Mail_FormularyGroup_8,P4_DSC__Mail_DrugListSelection_8,P4_DSC__Mail_DrugList_8,P4_DSC__Mail_Stepped_8,P4_DSC__Mail_M_8,P4_DSC__Mail_N_8,P4_DSC__Mail_O_8,P4_DSC__Mail_Y_8,P4_DSC__Mail_DollarAmount_8,P4_DSC__Mail_Percent_8,P4_DSC__Mail_CopayCal_8,P4_DSC__Mail_MinDollar_8,P4_DSC__Mail_Max_Dollar_8,P4_DSC__Mail_Reverse_8,"False");
		GetReportValues.FailedReportValues("DSC_Mail");
		GetReportValues.getAllMapId_DSC("4",p4_Line_Value,"DSC_SpecialtyTiers");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_1,P4_DSC__Speciality_DrugListSelection_1,P4_DSC__Speciality_DrugList_1,P4_DSC__Speciality_Stepped_1,P4_DSC__Speciality_M_1,P4_DSC__Speciality_N_1,P4_DSC__Speciality_O_1,P4_DSC__Speciality_Y_1,P4_DSC__Speciality_DollarAmount_1,P4_DSC__Speciality_Percent_1,P4_DSC__Speciality_CopayCal_1,P4_DSC__Speciality_MinDollar_1,P4_DSC__Speciality_Max_Dollar_1,P4_DSC__Speciality_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_2,P4_DSC__Speciality_DrugListSelection_2,P4_DSC__Speciality_DrugList_2,P4_DSC__Speciality_Stepped_2,P4_DSC__Speciality_M_2,P4_DSC__Speciality_N_2,P4_DSC__Speciality_O_2,P4_DSC__Speciality_Y_2,P4_DSC__Speciality_DollarAmount_2,P4_DSC__Speciality_Percent_2,P4_DSC__Speciality_CopayCal_2,P4_DSC__Speciality_MinDollar_2,P4_DSC__Speciality_Max_Dollar_2,P4_DSC__Speciality_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_3,P4_DSC__Speciality_DrugListSelection_3,P4_DSC__Speciality_DrugList_3,P4_DSC__Speciality_Stepped_3,P4_DSC__Speciality_M_3,P4_DSC__Speciality_N_3,P4_DSC__Speciality_O_3,P4_DSC__Speciality_Y_3,P4_DSC__Speciality_DollarAmount_3,P4_DSC__Speciality_Percent_3,P4_DSC__Speciality_CopayCal_3,P4_DSC__Speciality_MinDollar_3,P4_DSC__Speciality_Max_Dollar_3,P4_DSC__Speciality_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_4,P4_DSC__Speciality_DrugListSelection_4,P4_DSC__Speciality_DrugList_4,P4_DSC__Speciality_Stepped_4,P4_DSC__Speciality_M_4,P4_DSC__Speciality_N_4,P4_DSC__Speciality_O_4,P4_DSC__Speciality_Y_4,P4_DSC__Speciality_DollarAmount_4,P4_DSC__Speciality_Percent_4,P4_DSC__Speciality_CopayCal_4,P4_DSC__Speciality_MinDollar_4,P4_DSC__Speciality_Max_Dollar_4,P4_DSC__Speciality_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_5,P4_DSC__Speciality_DrugListSelection_5,P4_DSC__Speciality_DrugList_5,P4_DSC__Speciality_Stepped_5,P4_DSC__Speciality_M_5,P4_DSC__Speciality_N_5,P4_DSC__Speciality_O_5,P4_DSC__Speciality_Y_5,P4_DSC__Speciality_DollarAmount_5,P4_DSC__Speciality_Percent_5,P4_DSC__Speciality_CopayCal_5,P4_DSC__Speciality_MinDollar_5,P4_DSC__Speciality_Max_Dollar_5,P4_DSC__Speciality_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_6,P4_DSC__Speciality_DrugListSelection_6,P4_DSC__Speciality_DrugList_6,P4_DSC__Speciality_Stepped_6,P4_DSC__Speciality_M_6,P4_DSC__Speciality_N_6,P4_DSC__Speciality_O_6,P4_DSC__Speciality_Y_6,P4_DSC__Speciality_DollarAmount_6,P4_DSC__Speciality_Percent_6,P4_DSC__Speciality_CopayCal_6,P4_DSC__Speciality_MinDollar_6,P4_DSC__Speciality_Max_Dollar_6,P4_DSC__Speciality_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_7,P4_DSC__Speciality_DrugListSelection_7,P4_DSC__Speciality_DrugList_7,P4_DSC__Speciality_Stepped_7,P4_DSC__Speciality_M_7,P4_DSC__Speciality_N_7,P4_DSC__Speciality_O_7,P4_DSC__Speciality_Y_7,P4_DSC__Speciality_DollarAmount_7,P4_DSC__Speciality_Percent_7,P4_DSC__Speciality_CopayCal_7,P4_DSC__Speciality_MinDollar_7,P4_DSC__Speciality_Max_Dollar_7,P4_DSC__Speciality_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyTiers",P4_DSC__Speciality_Present_1,P4_DSC__Speciality_FormularyGroup_8,P4_DSC__Speciality_DrugListSelection_8,P4_DSC__Speciality_DrugList_8,P4_DSC__Speciality_Stepped_8,P4_DSC__Speciality_M_8,P4_DSC__Speciality_N_8,P4_DSC__Speciality_O_8,P4_DSC__Speciality_Y_8,P4_DSC__Speciality_DollarAmount_8,P4_DSC__Speciality_Percent_8,P4_DSC__Speciality_CopayCal_8,P4_DSC__Speciality_MinDollar_8,P4_DSC__Speciality_Max_Dollar_8,P4_DSC__Speciality_Reverse_8,"False");
		GetReportValues.FailedReportValues("DSC_SpecialtyTiers");
		GetReportValues.getAllMapId_DSC("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_1,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_1,P4_DSC__SpecialityOutoFNetwork_Stepped_1,P4_DSC__SpecialityOutoFNetwork_M_1,P4_DSC__SpecialityOutoFNetwork_N_1,P4_DSC__SpecialityOutoFNetwork_O_1,P4_DSC__SpecialityOutoFNetwork_Y_1,P4_DSC__SpecialityOutoFNetwork_DollarAmount_1,P4_DSC__SpecialityOutoFNetwork_Percent_1,P4_DSC__SpecialityOutoFNetwork_CopayCal_1,P4_DSC__SpecialityOutoFNetwork_MinDollar_1,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_1,P4_DSC__SpecialityOutoFNetwork_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_2,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_2,P4_DSC__SpecialityOutoFNetwork_Stepped_2,P4_DSC__SpecialityOutoFNetwork_M_2,P4_DSC__SpecialityOutoFNetwork_N_2,P4_DSC__SpecialityOutoFNetwork_O_2,P4_DSC__SpecialityOutoFNetwork_Y_2,P4_DSC__SpecialityOutoFNetwork_DollarAmount_2,P4_DSC__SpecialityOutoFNetwork_Percent_2,P4_DSC__SpecialityOutoFNetwork_CopayCal_2,P4_DSC__SpecialityOutoFNetwork_MinDollar_2,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_2,P4_DSC__SpecialityOutoFNetwork_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_3,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_3,P4_DSC__SpecialityOutoFNetwork_Stepped_3,P4_DSC__SpecialityOutoFNetwork_M_3,P4_DSC__SpecialityOutoFNetwork_N_3,P4_DSC__SpecialityOutoFNetwork_O_3,P4_DSC__SpecialityOutoFNetwork_Y_3,P4_DSC__SpecialityOutoFNetwork_DollarAmount_3,P4_DSC__SpecialityOutoFNetwork_Percent_3,P4_DSC__SpecialityOutoFNetwork_CopayCal_3,P4_DSC__SpecialityOutoFNetwork_MinDollar_3,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_3,P4_DSC__SpecialityOutoFNetwork_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_4,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_4,P4_DSC__SpecialityOutoFNetwork_Stepped_4,P4_DSC__SpecialityOutoFNetwork_M_4,P4_DSC__SpecialityOutoFNetwork_N_4,P4_DSC__SpecialityOutoFNetwork_O_4,P4_DSC__SpecialityOutoFNetwork_Y_4,P4_DSC__SpecialityOutoFNetwork_DollarAmount_4,P4_DSC__SpecialityOutoFNetwork_Percent_4,P4_DSC__SpecialityOutoFNetwork_CopayCal_4,P4_DSC__SpecialityOutoFNetwork_MinDollar_4,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_4,P4_DSC__SpecialityOutoFNetwork_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_5,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_5,P4_DSC__SpecialityOutoFNetwork_Stepped_5,P4_DSC__SpecialityOutoFNetwork_M_5,P4_DSC__SpecialityOutoFNetwork_N_5,P4_DSC__SpecialityOutoFNetwork_O_5,P4_DSC__SpecialityOutoFNetwork_Y_5,P4_DSC__SpecialityOutoFNetwork_DollarAmount_5,P4_DSC__SpecialityOutoFNetwork_Percent_5,P4_DSC__SpecialityOutoFNetwork_CopayCal_5,P4_DSC__SpecialityOutoFNetwork_MinDollar_5,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_5,P4_DSC__SpecialityOutoFNetwork_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_6,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_6,P4_DSC__SpecialityOutoFNetwork_Stepped_6,P4_DSC__SpecialityOutoFNetwork_M_6,P4_DSC__SpecialityOutoFNetwork_N_6,P4_DSC__SpecialityOutoFNetwork_O_6,P4_DSC__SpecialityOutoFNetwork_Y_6,P4_DSC__SpecialityOutoFNetwork_DollarAmount_6,P4_DSC__SpecialityOutoFNetwork_Percent_6,P4_DSC__SpecialityOutoFNetwork_CopayCal_6,P4_DSC__SpecialityOutoFNetwork_MinDollar_6,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_6,P4_DSC__SpecialityOutoFNetwork_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_7,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_7,P4_DSC__SpecialityOutoFNetwork_Stepped_7,P4_DSC__SpecialityOutoFNetwork_M_7,P4_DSC__SpecialityOutoFNetwork_N_7,P4_DSC__SpecialityOutoFNetwork_O_7,P4_DSC__SpecialityOutoFNetwork_Y_7,P4_DSC__SpecialityOutoFNetwork_DollarAmount_7,P4_DSC__SpecialityOutoFNetwork_Percent_7,P4_DSC__SpecialityOutoFNetwork_CopayCal_7,P4_DSC__SpecialityOutoFNetwork_MinDollar_7,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_7,P4_DSC__SpecialityOutoFNetwork_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_SpecialtyOutOfNetwork",P4_DSC__SpecialityOutoFNetwork_Present_1,P4_DSC__SpecialityOutoFNetwork_FormularyGroup_8,P4_DSC__SpecialityOutoFNetwork_DrugListSelection_1,P4_DSC__SpecialityOutoFNetwork_DrugList_8,P4_DSC__SpecialityOutoFNetwork_Stepped_8,P4_DSC__SpecialityOutoFNetwork_M_8,P4_DSC__SpecialityOutoFNetwork_N_8,P4_DSC__SpecialityOutoFNetwork_O_8,P4_DSC__SpecialityOutoFNetwork_Y_8,P4_DSC__SpecialityOutoFNetwork_DollarAmount_8,P4_DSC__SpecialityOutoFNetwork_Percent_8,P4_DSC__SpecialityOutoFNetwork_CopayCal_8,P4_DSC__SpecialityOutoFNetwork_MinDollar_8,P4_DSC__SpecialityOutoFNetwork_Max_Dollar_8,P4_DSC__SpecialityOutoFNetwork_Reverse_8,"False");
		GetReportValues.FailedReportValues("DSC_SpecialtyOutOfNetwork");
		GetReportValues.getAllMapId_DSC("4",p4_Line_Value,"DSC_PaperTiers");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_1,P4_DSC__Paper_DrugListSelection_1,P4_DSC__Paper_DrugList_1,P4_DSC__Paper_Stepped_1,P4_DSC__Paper_M_1,P4_DSC__Paper_N_1,P4_DSC__Paper_O_1,P4_DSC__Paper_Y_1,P4_DSC__Paper_DollarAmount_1,P4_DSC__Paper_Percent_1,P4_DSC__Paper_CopayCal_1,P4_DSC__Paper_MinDollar_1,P4_DSC__Paper_Max_Dollar_1,P4_DSC__Paper_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_2,P4_DSC__Paper_DrugListSelection_2,P4_DSC__Paper_DrugList_2,P4_DSC__Paper_Stepped_2,P4_DSC__Paper_M_2,P4_DSC__Paper_N_2,P4_DSC__Paper_O_2,P4_DSC__Paper_Y_2,P4_DSC__Paper_DollarAmount_2,P4_DSC__Paper_Percent_2,P4_DSC__Paper_CopayCal_2,P4_DSC__Paper_MinDollar_2,P4_DSC__Paper_Max_Dollar_2,P4_DSC__Paper_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_3,P4_DSC__Paper_DrugListSelection_3,P4_DSC__Paper_DrugList_3,P4_DSC__Paper_Stepped_3,P4_DSC__Paper_M_3,P4_DSC__Paper_N_3,P4_DSC__Paper_O_3,P4_DSC__Paper_Y_3,P4_DSC__Paper_DollarAmount_3,P4_DSC__Paper_Percent_3,P4_DSC__Paper_CopayCal_3,P4_DSC__Paper_MinDollar_3,P4_DSC__Paper_Max_Dollar_3,P4_DSC__Paper_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_4,P4_DSC__Paper_DrugListSelection_4,P4_DSC__Paper_DrugList_4,P4_DSC__Paper_Stepped_4,P4_DSC__Paper_M_4,P4_DSC__Paper_N_4,P4_DSC__Paper_O_4,P4_DSC__Paper_Y_4,P4_DSC__Paper_DollarAmount_4,P4_DSC__Paper_Percent_4,P4_DSC__Paper_CopayCal_4,P4_DSC__Paper_MinDollar_4,P4_DSC__Paper_Max_Dollar_4,P4_DSC__Paper_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_5,P4_DSC__Paper_DrugListSelection_5,P4_DSC__Paper_DrugList_5,P4_DSC__Paper_Stepped_5,P4_DSC__Paper_M_5,P4_DSC__Paper_N_5,P4_DSC__Paper_O_5,P4_DSC__Paper_Y_5,P4_DSC__Paper_DollarAmount_5,P4_DSC__Paper_Percent_5,P4_DSC__Paper_CopayCal_5,P4_DSC__Paper_MinDollar_5,P4_DSC__Paper_Max_Dollar_5,P4_DSC__Paper_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_6,P4_DSC__Paper_DrugListSelection_6,P4_DSC__Paper_DrugList_6,P4_DSC__Paper_Stepped_6,P4_DSC__Paper_M_6,P4_DSC__Paper_N_6,P4_DSC__Paper_O_6,P4_DSC__Paper_Y_6,P4_DSC__Paper_DollarAmount_6,P4_DSC__Paper_Percent_6,P4_DSC__Paper_CopayCal_6,P4_DSC__Paper_MinDollar_6,P4_DSC__Paper_Max_Dollar_6,P4_DSC__Paper_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_7,P4_DSC__Paper_DrugListSelection_7,P4_DSC__Paper_DrugList_7,P4_DSC__Paper_Stepped_7,P4_DSC__Paper_M_7,P4_DSC__Paper_N_7,P4_DSC__Paper_O_7,P4_DSC__Paper_Y_7,P4_DSC__Paper_DollarAmount_7,P4_DSC__Paper_Percent_7,P4_DSC__Paper_CopayCal_7,P4_DSC__Paper_MinDollar_7,P4_DSC__Paper_Max_Dollar_7,P4_DSC__Paper_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperTiers",P4_DSC__Paper_Present_1,P4_DSC__Paper_FormularyGroup_8,P4_DSC__Paper_DrugListSelection_8,P4_DSC__Paper_DrugList_8,P4_DSC__Paper_Stepped_8,P4_DSC__Paper_M_8,P4_DSC__Paper_N_8,P4_DSC__Paper_O_8,P4_DSC__Paper_Y_8,P4_DSC__Paper_DollarAmount_8,P4_DSC__Paper_Percent_8,P4_DSC__Paper_CopayCal_8,P4_DSC__Paper_MinDollar_8,P4_DSC__Paper_Max_Dollar_8,P4_DSC__Paper_Reverse_8,"False");
		GetReportValues.FailedReportValues("DSC_PaperTiers");
		GetReportValues.getAllMapId_DSC("4",p4_Line_Value,"DSC_PaperOutOfNetwork");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_1,P4_DSC__PaperOutOfNetwork_DrugListSelection_1,P4_DSC__PaperOutOfNetwork_DrugList_1,P4_DSC__PaperOutOfNetwork_Stepped_1,P4_DSC__PaperOutOfNetwork_M_1,P4_DSC__PaperOutOfNetwork_N_1,P4_DSC__PaperOutOfNetwork_O_1,P4_DSC__PaperOutOfNetwork_Y_1,P4_DSC__PaperOutOfNetwork_DollarAmount_1,P4_DSC__PaperOutOfNetwork_Percent_1,P4_DSC__PaperOutOfNetwork_CopayCal_1,P4_DSC__PaperOutOfNetwork_MinDollar_1,P4_DSC__PaperOutOfNetwork_Max_Dollar_1,P4_DSC__PaperOutOfNetwork_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_2,P4_DSC__PaperOutOfNetwork_DrugListSelection_2,P4_DSC__PaperOutOfNetwork_DrugList_2,P4_DSC__PaperOutOfNetwork_Stepped_2,P4_DSC__PaperOutOfNetwork_M_2,P4_DSC__PaperOutOfNetwork_N_2,P4_DSC__PaperOutOfNetwork_O_2,P4_DSC__PaperOutOfNetwork_Y_2,P4_DSC__PaperOutOfNetwork_DollarAmount_2,P4_DSC__PaperOutOfNetwork_Percent_2,P4_DSC__PaperOutOfNetwork_CopayCal_2,P4_DSC__PaperOutOfNetwork_MinDollar_2,P4_DSC__PaperOutOfNetwork_Max_Dollar_2,P4_DSC__PaperOutOfNetwork_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_3,P4_DSC__PaperOutOfNetwork_DrugListSelection_3,P4_DSC__PaperOutOfNetwork_DrugList_3,P4_DSC__PaperOutOfNetwork_Stepped_3,P4_DSC__PaperOutOfNetwork_M_3,P4_DSC__PaperOutOfNetwork_N_3,P4_DSC__PaperOutOfNetwork_O_3,P4_DSC__PaperOutOfNetwork_Y_3,P4_DSC__PaperOutOfNetwork_DollarAmount_3,P4_DSC__PaperOutOfNetwork_Percent_3,P4_DSC__PaperOutOfNetwork_CopayCal_3,P4_DSC__PaperOutOfNetwork_MinDollar_3,P4_DSC__PaperOutOfNetwork_Max_Dollar_3,P4_DSC__PaperOutOfNetwork_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_4,P4_DSC__PaperOutOfNetwork_DrugListSelection_4,P4_DSC__PaperOutOfNetwork_DrugList_4,P4_DSC__PaperOutOfNetwork_Stepped_4,P4_DSC__PaperOutOfNetwork_M_4,P4_DSC__PaperOutOfNetwork_N_4,P4_DSC__PaperOutOfNetwork_O_4,P4_DSC__PaperOutOfNetwork_Y_4,P4_DSC__PaperOutOfNetwork_DollarAmount_4,P4_DSC__PaperOutOfNetwork_Percent_4,P4_DSC__PaperOutOfNetwork_CopayCal_4,P4_DSC__PaperOutOfNetwork_MinDollar_4,P4_DSC__PaperOutOfNetwork_Max_Dollar_4,P4_DSC__PaperOutOfNetwork_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_5,P4_DSC__PaperOutOfNetwork_DrugListSelection_5,P4_DSC__PaperOutOfNetwork_DrugList_5,P4_DSC__PaperOutOfNetwork_Stepped_5,P4_DSC__PaperOutOfNetwork_M_5,P4_DSC__PaperOutOfNetwork_N_5,P4_DSC__PaperOutOfNetwork_O_5,P4_DSC__PaperOutOfNetwork_Y_5,P4_DSC__PaperOutOfNetwork_DollarAmount_5,P4_DSC__PaperOutOfNetwork_Percent_5,P4_DSC__PaperOutOfNetwork_CopayCal_5,P4_DSC__PaperOutOfNetwork_MinDollar_5,P4_DSC__PaperOutOfNetwork_Max_Dollar_5,P4_DSC__PaperOutOfNetwork_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_6,P4_DSC__PaperOutOfNetwork_DrugListSelection_6,P4_DSC__PaperOutOfNetwork_DrugList_6,P4_DSC__PaperOutOfNetwork_Stepped_6,P4_DSC__PaperOutOfNetwork_M_6,P4_DSC__PaperOutOfNetwork_N_6,P4_DSC__PaperOutOfNetwork_O_6,P4_DSC__PaperOutOfNetwork_Y_6,P4_DSC__PaperOutOfNetwork_DollarAmount_6,P4_DSC__PaperOutOfNetwork_Percent_6,P4_DSC__PaperOutOfNetwork_CopayCal_6,P4_DSC__PaperOutOfNetwork_MinDollar_6,P4_DSC__PaperOutOfNetwork_Max_Dollar_6,P4_DSC__PaperOutOfNetwork_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_7,P4_DSC__PaperOutOfNetwork_DrugListSelection_7,P4_DSC__PaperOutOfNetwork_DrugList_7,P4_DSC__PaperOutOfNetwork_Stepped_7,P4_DSC__PaperOutOfNetwork_M_7,P4_DSC__PaperOutOfNetwork_N_7,P4_DSC__PaperOutOfNetwork_O_7,P4_DSC__PaperOutOfNetwork_Y_7,P4_DSC__PaperOutOfNetwork_DollarAmount_7,P4_DSC__PaperOutOfNetwork_Percent_7,P4_DSC__PaperOutOfNetwork_CopayCal_7,P4_DSC__PaperOutOfNetwork_MinDollar_7,P4_DSC__PaperOutOfNetwork_Max_Dollar_7,P4_DSC__PaperOutOfNetwork_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_PaperOutOfNetwork",P4_DSC__PaperOutOfNetwork_Present_1,P4_DSC__PaperOutOfNetwork_FormularyGroup_8,P4_DSC__PaperOutOfNetwork_DrugListSelection_8,P4_DSC__PaperOutOfNetwork_DrugList_8,P4_DSC__PaperOutOfNetwork_Stepped_8,P4_DSC__PaperOutOfNetwork_M_8,P4_DSC__PaperOutOfNetwork_N_8,P4_DSC__PaperOutOfNetwork_O_8,P4_DSC__PaperOutOfNetwork_Y_8,P4_DSC__PaperOutOfNetwork_DollarAmount_8,P4_DSC__PaperOutOfNetwork_Percent_8,P4_DSC__PaperOutOfNetwork_CopayCal_8,P4_DSC__PaperOutOfNetwork_MinDollar_8,P4_DSC__PaperOutOfNetwork_Max_Dollar_8,P4_DSC__PaperOutOfNetwork_Reverse_8,"False");
		GetReportValues.FailedReportValues("DSC_PaperOutOfNetwork");
		GetReportValues.getAllMapId_DSC("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_1,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_1,p4_DSC_Mail_PaperOoN_DL_DG_Name_1,p4_DSC_Mail_PaperOoN_Stepped_1,p4_DSC_Mail_PaperOoN_M_1,p4_DSC_Mail_PaperOoN_N_1,p4_DSC_Mail_PaperOoN_O_1,p4_DSC_Mail_PaperOoN_Y_1,p4_DSC_Mail_PaperOoN_DollarAmount_1,p4_DSC_Mail_PaperOoN_Percent_1,p4_DSC_Mail_PaperOoN_CoPayCalculation_1,p4_DSC_Mail_PaperOoN_MinimumDollar_1,p4_DSC_Mail_PaperOoN_MaximumDollar_1,p4_DSC_Mail_PaperOoN_Reverse_1,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_2,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_2,p4_DSC_Mail_PaperOoN_DL_DG_Name_2,p4_DSC_Mail_PaperOoN_Stepped_2,p4_DSC_Mail_PaperOoN_M_2,p4_DSC_Mail_PaperOoN_N_2,p4_DSC_Mail_PaperOoN_O_2,p4_DSC_Mail_PaperOoN_Y_2,p4_DSC_Mail_PaperOoN_DollarAmount_2,p4_DSC_Mail_PaperOoN_Percent_2,p4_DSC_Mail_PaperOoN_CoPayCalculation_2,p4_DSC_Mail_PaperOoN_MinimumDollar_2,p4_DSC_Mail_PaperOoN_MaximumDollar_2,p4_DSC_Mail_PaperOoN_Reverse_2,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_3,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_3,p4_DSC_Mail_PaperOoN_DL_DG_Name_3,p4_DSC_Mail_PaperOoN_Stepped_3,p4_DSC_Mail_PaperOoN_M_3,p4_DSC_Mail_PaperOoN_N_3,p4_DSC_Mail_PaperOoN_O_3,p4_DSC_Mail_PaperOoN_Y_3,p4_DSC_Mail_PaperOoN_DollarAmount_3,p4_DSC_Mail_PaperOoN_Percent_3,p4_DSC_Mail_PaperOoN_CoPayCalculation_3,p4_DSC_Mail_PaperOoN_MinimumDollar_3,p4_DSC_Mail_PaperOoN_MaximumDollar_3,p4_DSC_Mail_PaperOoN_Reverse_3,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_4,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_4,p4_DSC_Mail_PaperOoN_DL_DG_Name_4,p4_DSC_Mail_PaperOoN_Stepped_4,p4_DSC_Mail_PaperOoN_M_4,p4_DSC_Mail_PaperOoN_N_4,p4_DSC_Mail_PaperOoN_O_4,p4_DSC_Mail_PaperOoN_Y_4,p4_DSC_Mail_PaperOoN_DollarAmount_4,p4_DSC_Mail_PaperOoN_Percent_4,p4_DSC_Mail_PaperOoN_CoPayCalculation_4,p4_DSC_Mail_PaperOoN_MinimumDollar_4,p4_DSC_Mail_PaperOoN_MaximumDollar_4,p4_DSC_Mail_PaperOoN_Reverse_4,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_5,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_5,p4_DSC_Mail_PaperOoN_DL_DG_Name_5,p4_DSC_Mail_PaperOoN_Stepped_5,p4_DSC_Mail_PaperOoN_M_5,p4_DSC_Mail_PaperOoN_N_5,p4_DSC_Mail_PaperOoN_O_5,p4_DSC_Mail_PaperOoN_Y_5,p4_DSC_Mail_PaperOoN_DollarAmount_5,p4_DSC_Mail_PaperOoN_Percent_5,p4_DSC_Mail_PaperOoN_CoPayCalculation_5,p4_DSC_Mail_PaperOoN_MinimumDollar_5,p4_DSC_Mail_PaperOoN_MaximumDollar_5,p4_DSC_Mail_PaperOoN_Reverse_5,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_6,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_6,p4_DSC_Mail_PaperOoN_DL_DG_Name_6,p4_DSC_Mail_PaperOoN_Stepped_6,p4_DSC_Mail_PaperOoN_M_6,p4_DSC_Mail_PaperOoN_N_6,p4_DSC_Mail_PaperOoN_O_6,p4_DSC_Mail_PaperOoN_Y_6,p4_DSC_Mail_PaperOoN_DollarAmount_6,p4_DSC_Mail_PaperOoN_Percent_6,p4_DSC_Mail_PaperOoN_CoPayCalculation_6,p4_DSC_Mail_PaperOoN_MinimumDollar_6,p4_DSC_Mail_PaperOoN_MaximumDollar_6,p4_DSC_Mail_PaperOoN_Reverse_6,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_7,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_7,p4_DSC_Mail_PaperOoN_DL_DG_Name_7,p4_DSC_Mail_PaperOoN_Stepped_7,p4_DSC_Mail_PaperOoN_M_7,p4_DSC_Mail_PaperOoN_N_7,p4_DSC_Mail_PaperOoN_O_7,p4_DSC_Mail_PaperOoN_Y_7,p4_DSC_Mail_PaperOoN_DollarAmount_7,p4_DSC_Mail_PaperOoN_Percent_7,p4_DSC_Mail_PaperOoN_CoPayCalculation_7,p4_DSC_Mail_PaperOoN_MinimumDollar_7,p4_DSC_Mail_PaperOoN_MaximumDollar_7,p4_DSC_Mail_PaperOoN_Reverse_7,"False");
		ValidateProvisionTemplate.validateDrugSpecificCopayDetails("4",p4_Line_Value,"DSC_Mail_PaperOutOfNetwork",p4_DSC_Plan_Type_Mail_Paper_Out_of_Network_Present,p4_DSC_Mail_PaperOoN_FormularyGroup_8,p4_DSC_Mail_PaperOoN_DrugList_DrugGroup_8,p4_DSC_Mail_PaperOoN_DL_DG_Name_8,p4_DSC_Mail_PaperOoN_Stepped_8,p4_DSC_Mail_PaperOoN_M_8,p4_DSC_Mail_PaperOoN_N_8,p4_DSC_Mail_PaperOoN_O_8,p4_DSC_Mail_PaperOoN_Y_8,p4_DSC_Mail_PaperOoN_DollarAmount_8,p4_DSC_Mail_PaperOoN_Percent_8,p4_DSC_Mail_PaperOoN_CoPayCalculation_8,p4_DSC_Mail_PaperOoN_MinimumDollar_8,p4_DSC_Mail_PaperOoN_MaximumDollar_8,p4_DSC_Mail_PaperOoN_Reverse_8,"False");
		GetReportValues.FailedReportValues("DSC_Mail_PaperOutOfNetwork");
	}
	public static void validateAccum() throws Exception {	
		ValidateProvisionTemplate_Test.validateAccumulationsDrugSpecific("4", p4_Line_Value, P4_Accum_ArethereanydrugspecificMAB, P4_Accum_M,P4_Accum_O, P4_Accum_N, P4_Accum_Y,P4_Accum_Druglist, P4_Accum_DrugGroup,P4_Accum_MAB_Amount, P4_Accum_MAB_Period, P4_Accum_MAB_Met);		
	}


*/

	public static void getProvision20TemplateValues(Object[][] provision20Template) 	{

		p20_Line_Value = provision20Template[0][1].toString();
		p20_Line_Text = provision20Template[0][2].toString();
		p20_DC_Retail_DrugList_DrugGroup_1 = provision20Template[0][5].toString();
		p20_DC_Retail_DrugList_1 = provision20Template[0][7].toString();
		p20_DC_Retail_InclusionExclusionDrugClass_1 = provision20Template[0][8].toString();
	    p20_DC_Retail_InclusionExclusion_1 = provision20Template[0][9].toString();
		p20_DC_Retail_ApplyLimitations_1 = provision20Template[0][10].toString();
		p20_DC_Retail_StartAge_1 = provision20Template[0][11].toString();
		p20_DC_Retail_EndAge_1 = provision20Template[0][12].toString();
		p20_DC_Retail_Gender_1 = provision20Template[0][13].toString();
		p20_DC_Retail_MinimumDays_1 = provision20Template[0][14].toString();
		p20_DC_Retail_MinimumQuality_1 = provision20Template[0][15].toString();
		p20_DC_Retail_DailyDose_1 = provision20Template[0][16].toString();
		p20_DC_Retail_StartAgeType_1 = provision20Template[0][17].toString();
		p20_DC_Retail_EndAgeType_1 = provision20Template[0][18].toString();
		p20_DC_Retail_DayQuantityRule_1 = provision20Template[0][19].toString();
		p20_DC_Retail_MaximumDays_1 = provision20Template[0][20].toString();
		p20_DC_Retail_MaximumFills_1 = provision20Template[0][21].toString();
		p20_DC_Retail_MaximumDaysperFill_1 = provision20Template[0][22].toString();
		p20_DC_Retail_DaysOverTimeTimePeriod_1 = provision20Template[0][23].toString();
		p20_DC_Retail_DaysoverTimeofDays_1  = provision20Template[0][24].toString();
	    p20_DC_Retail_DaysoverTimeTimeValue_1 = provision20Template[0][25].toString();
		p20_DC_Retail_MaxQuantityperFill_1 = provision20Template[0][26].toString();
		p20_DC_Retail_QuantityoverTimeQuantity_1 = provision20Template[0][27].toString();
		p20_DC_Retail_QuantityOverTimeTimePeriod_1 = provision20Template[0][28].toString();
		p20_DC_Retail_QuantityoverTimeTimeValue_1 = provision20Template[0][29].toString();
		p20_DC_Retail_BypassMOOP_1 = provision20Template[0][30].toString();
		p20_DC_Retail_DrugList_DrugGroup_2 = provision20Template[0][32].toString();
		p20_DC_Retail_DrugList_2 = provision20Template[0][34].toString();
		p20_DC_Retail_InclusionExclusionDrugClass_2 = provision20Template[0][35].toString();
		p20_DC_Retail_InclusionExclusion_2 = provision20Template[0][36].toString();
		p20_DC_Retail_ApplyLimitations_2 = provision20Template[0][37].toString();
		p20_DC_Retail_StartAge_2 = provision20Template[0][38].toString();
		p20_DC_Retail_EndAge_2 = provision20Template[0][39].toString();
		p20_DC_Retail_Gender_2 = provision20Template[0][40].toString();
		p20_DC_Retail_MinimumDays_2 = provision20Template[0][41].toString();
		p20_DC_Retail_MinimumQuality_2 = provision20Template[0][42].toString();
		p20_DC_Retail_DailyDose_2 = provision20Template[0][43].toString();
		p20_DC_Retail_StartAgeType_2 = provision20Template[0][44].toString();
		p20_DC_Retail_EndAgeType_2 = provision20Template[0][45].toString();
		p20_DC_Retail_DayQuantityRule_2 = provision20Template[0][46].toString();
		p20_DC_Retail_MaximumDays_2 = provision20Template[0][47].toString();
		p20_DC_Retail_MaximumFills_2 = provision20Template[0][48].toString();
		p20_DC_Retail_MaximumDaysperFill_2 = provision20Template[0][49].toString();
		p20_DC_Retail_DaysOverTimeTimePeriod_2 = provision20Template[50][1].toString();
		p20_DC_Retail_DaysoverTimeofDays_2  = provision20Template[0][51].toString();
		p20_DC_Retail_DaysoverTimeTimeValue_2 = provision20Template[0][52].toString();
		p20_DC_Retail_MaxQuantityperFill_2 = provision20Template[0][53].toString();
		p20_DC_Retail_QuantityoverTimeQuantity_2 = provision20Template[0][54].toString();
		p20_DC_Retail_QuantityOverTimeTimePeriod_2 = provision20Template[0][55].toString();
		p20_DC_Retail_QuantityoverTimeTimeValue_2 = provision20Template[0][56].toString();
		p20_DC_Retail_BypassMOOP_2 = provision20Template[0][57].toString();
		p20_DC_Mail_DrugList_DrugGroup_1 = provision20Template[0][59].toString();
		p20_DC_Mail_DrugList_1 = provision20Template[0][61].toString();
		p20_DC_Mail_InclusionExclusionDrugClass_1 = provision20Template[0][62].toString();
		p20_DC_Mail_InclusionExclusion_1 = provision20Template[0][63].toString();
		p20_DC_Mail_ApplyLimitations_1 = provision20Template[0][64].toString();
		p20_DC_Mail_StartAge_1 = provision20Template[0][65].toString();
		p20_DC_Mail_EndAge_1 = provision20Template[0][66].toString();
		p20_DC_Mail_Gender_1 = provision20Template[0][67].toString();
		p20_DC_Mail_MinimumDays_1 = provision20Template[0][68].toString();
		p20_DC_Mail_MinimumQuality_1 = provision20Template[0][69].toString();
		p20_DC_Mail_DailyDose_1 = provision20Template[0][70].toString();
		p20_DC_Mail_StartAgeType_1 = provision20Template[0][71].toString();
		p20_DC_Mail_EndAgeType_1 = provision20Template[0][72].toString();
		p20_DC_Mail_DayQuantityRule_1 = provision20Template[0][73].toString();
		p20_DC_Mail_MaximumDays_1 = provision20Template[0][74].toString();
		p20_DC_Mail_MaximumFills_1 = provision20Template[0][75].toString();
		p20_DC_Mail_MaximumDaysperFill_1 = provision20Template[0][76].toString();
		p20_DC_Mail_DaysOverTimeTimePeriod_1 = provision20Template[0][77].toString();
		p20_DC_Mail_DaysoverTimeofDays_1  = provision20Template[0][78].toString();
		p20_DC_Mail_DaysoverTimeTimeValue_1 = provision20Template[0][79].toString();
		p20_DC_Mail_MaxQuantityperFill_1 = provision20Template[0][80].toString();
		p20_DC_Mail_QuantityoverTimeQuantity_1 = provision20Template[0][81].toString();
		p20_DC_Mail_QuantityOverTimeTimePeriod_1 = provision20Template[0][82].toString();
		p20_DC_Mail_QuantityoverTimeTimeValue_1 = provision20Template[0][83].toString();
		p20_DC_Mail_BypassMOOP_1 = provision20Template[0][84].toString();
		p20_DC_Mail_DrugList_DrugGroup_2 = provision20Template[0][86].toString();
		p20_DC_Mail_DrugList_2 = provision20Template[0][88].toString();
		p20_DC_Mail_InclusionExclusionDrugClass_2 = provision20Template[0][89].toString();
		p20_DC_Mail_InclusionExclusion_2 = provision20Template[0][90].toString();
		p20_DC_Mail_ApplyLimitations_2 = provision20Template[0][91].toString();
		p20_DC_Mail_StartAge_2 = provision20Template[0][92].toString();
		p20_DC_Mail_EndAge_2 = provision20Template[0][93].toString();
		p20_DC_Mail_Gender_2 = provision20Template[0][94].toString();
		p20_DC_Mail_MinimumDays_2 = provision20Template[0][95].toString();
		p20_DC_Mail_MinimumQuality_2 = provision20Template[0][96].toString();
	    p20_DC_Mail_DailyDose_2 = provision20Template[0][97].toString();
		p20_DC_Mail_StartAgeType_2 = provision20Template[0][98].toString();
		p20_DC_Mail_EndAgeType_2 = provision20Template[0][99].toString();
		p20_DC_Mail_DayQuantityRule_2 = provision20Template[0][100].toString();
		p20_DC_Mail_MaximumDays_2 = provision20Template[0][101].toString();
		p20_DC_Mail_MaximumFills_2 = provision20Template[0][102].toString();
		p20_DC_Mail_MaximumDaysperFill_2 = provision20Template[0][103].toString();
		p20_DC_Mail_DaysOverTimeTimePeriod_2 = provision20Template[0][104].toString();
		p20_DC_Mail_DaysoverTimeofDays_2  = provision20Template[0][105].toString();
		p20_DC_Mail_DaysoverTimeTimeValue_2 = provision20Template[0][106].toString();
		p20_DC_Mail_MaxQuantityperFill_2 = provision20Template[0][107].toString();
		p20_DC_Mail_QuantityoverTimeQuantity_2 = provision20Template[0][108].toString();
		p20_DC_Mail_QuantityOverTimeTimePeriod_2 = provision20Template[0][109].toString();
		p20_DC_Mail_QuantityoverTimeTimeValue_2 = provision20Template[0][110].toString();
	    p20_DC_Mail_BypassMOOP_2 = provision20Template[0][111].toString();
		
	    p20_DSC_Retail_Notes_1 = provision20Template[0][113].toString();
	    p20_DSC_Retail_Present_1 = provision20Template[0][114].toString();
	    p20_DSC_Retail_DrugList_DrugGroup_1 = provision20Template[0][115].toString();
	    p20_DSC_Retail_DrugList_1 = provision20Template[0][116].toString();
	    p20_DSC_Retail_Stepped_1 = provision20Template[0][117].toString();
	    p20_DSC_Retail_M_1 = provision20Template[0][118].toString();
	    p20_DSC_Retail_N_1 = provision20Template[0][119].toString();
	    p20_DSC_Retail_O_1 = provision20Template[0][120].toString();
	    p20_DSC_Retail_Y_1 = provision20Template[0][121].toString();
	    p20_DSC_Retail_PreferredGeneric_1 = provision20Template[0][122].toString();
	    p20_DSC_Retail_NonPreferredGeneric_1 = provision20Template[0][123].toString();
	    p20_DSC_Retail_PreferredBrand_1 = provision20Template[0][124].toString();
	    p20_DSC_Retail_NonPreferredBrand_1 = provision20Template[0][125].toString();
	    p20_DSC_Retail_DollarAmount_1 = provision20Template[0][126].toString();
	    p20_DSC_Retail_Percent_1 = provision20Template[0][127].toString();
	    P20_DSC_Retail_CopayCalculation_1 = provision20Template[0][128].toString();
	    P20_DSC_Retail_MinimumDollar_1 = provision20Template[0][129].toString();
	    P20_DSC_Retail_MaximumDollar_1 = provision20Template[0][130].toString();
	    P20_DSC_Retail_Reverse_1 = provision20Template[0][131].toString();

	    p20_DSC_Mail_Notes_1 = provision20Template[0][133].toString();
	    p20_DSC_Mail_Present_1 = provision20Template[0][134].toString();
	    p20_DSC_Mail_DrugList_DrugGroup_1 = provision20Template[0][135].toString();
	    p20_DSC_Mail_DrugList_1 = provision20Template[0][136].toString();
	    p20_DSC_Mail_Stepped_1 = provision20Template[0][137].toString();
	    p20_DSC_Mail_M_1 = provision20Template[0][138].toString();
	    p20_DSC_Mail_N_1 = provision20Template[0][139].toString();
	    p20_DSC_Mail_O_1 = provision20Template[0][140].toString();
	    p20_DSC_Mail_Y_1 = provision20Template[0][141].toString();
	    p20_DSC_Mail_PreferredGeneric_1 = provision20Template[0][142].toString();
	    p20_DSC_Mail_NonPreferredGeneric_1 = provision20Template[0][143].toString();
	    p20_DSC_Mail_PreferredBrand_1 = provision20Template[0][144].toString();
	    p20_DSC_Mail_NonPreferredBrand_1 = provision20Template[0][145].toString();
	    p20_DSC_Mail_DollarAmount_1 = provision20Template[0][146].toString();
	    p20_DSC_Mail_Percent_1 = provision20Template[0][147].toString();
	    P20_DSC_Mail_CopayCalculation_1 = provision20Template[0][148].toString();
	    P20_DSC_Mail_MinimumDollar_1 = provision20Template[0][149].toString();
	    P20_DSC_Mail_MaximumDollar_1 = provision20Template[0][150].toString();
	    P20_DSC_Mail_Reverse_1 = provision20Template[0][151].toString();
	    
	    p20_DSC_Specialty_Notes_1 = provision20Template[0][153].toString();
	    p20_DSC_Specialty_Present_1 = provision20Template[0][154].toString();
	    p20_DSC_Specialty_DrugList_DrugGroup_1 = provision20Template[0][155].toString();
	    p20_DSC_Specialty_DrugList_1 = provision20Template[0][156].toString();
	    p20_DSC_Specialty_Stepped_1 = provision20Template[0][157].toString();
	    p20_DSC_Specialty_M_1 = provision20Template[0][158].toString();
	    p20_DSC_Specialty_N_1 = provision20Template[0][159].toString();
	    p20_DSC_Specialty_O_1 = provision20Template[0][160].toString();
	    p20_DSC_Specialty_Y_1 = provision20Template[0][161].toString();
	    p20_DSC_Specialty_PreferredGeneric_1 = provision20Template[0][162].toString();
	    p20_DSC_Specialty_NonPreferredGeneric_1 = provision20Template[0][163].toString();
	    p20_DSC_Specialty_PreferredBrand_1 = provision20Template[0][164].toString();
	    p20_DSC_Specialty_NonPreferredBrand_1 = provision20Template[0][165].toString();
	    p20_DSC_Specialty_DollarAmount_1 = provision20Template[0][166].toString();
	    p20_DSC_Specialty_Percent_1 = provision20Template[0][167].toString();
	    P20_DSC_Specialty_CopayCalculation_1 = provision20Template[0][168].toString();
	    P20_DSC_Specialty_MinimumDollar_1 = provision20Template[0][169].toString();
	    P20_DSC_Specialty_MaximumDollar_1 = provision20Template[0][170].toString();
	    P20_DSC_Specialty_Reverse_1 = provision20Template[0][171].toString();

	    p20_DSC_SpecialtyOoN_Notes_1 = provision20Template[0][173].toString();
	    p20_DSC_SpecialtyOoN_Present_1 = provision20Template[0][174].toString();
	    p20_DSC_SpecialtyOoN_DrugList_DrugGroup_1 = provision20Template[0][175].toString();
	    p20_DSC_SpecialtyOoN_DrugList_1 = provision20Template[0][176].toString();
	    p20_DSC_SpecialtyOoN_Stepped_1 = provision20Template[0][177].toString();
	    p20_DSC_SpecialtyOoN_M_1 = provision20Template[0][178].toString();
	    p20_DSC_SpecialtyOoN_N_1 = provision20Template[0][179].toString();
	    p20_DSC_SpecialtyOoN_O_1 = provision20Template[0][180].toString();
	    p20_DSC_SpecialtyOoN_Y_1 = provision20Template[0][181].toString();
	    p20_DSC_SpecialtyOoN_PreferredGeneric_1 = provision20Template[0][182].toString();
	    p20_DSC_SpecialtyOoN_NonPreferredGeneric_1 = provision20Template[0][183].toString();
	    p20_DSC_SpecialtyOoN_PreferredBrand_1 = provision20Template[0][184].toString();
	    p20_DSC_SpecialtyOoN_NonPreferredBrand_1 = provision20Template[0][185].toString();
	    p20_DSC_SpecialtyOoN_DollarAmount_1 = provision20Template[0][186].toString();
	    p20_DSC_SpecialtyOoN_Percent_1 = provision20Template[0][187].toString();
	    P20_DSC_SpecialtyOoN_CopayCalculation_1 = provision20Template[0][188].toString();
	    P20_DSC_SpecialtyOoN_MinimumDollar_1 = provision20Template[0][189].toString();
	    P20_DSC_SpecialtyOoN_MaximumDollar_1 = provision20Template[0][190].toString();
	    P20_DSC_SpecialtyOoN_Reverse_1 = provision20Template[0][191].toString();

	    p20_DSC_Paper_Notes_1 = provision20Template[0][193].toString();
	    p20_DSC_Paper_Present_1 = provision20Template[0][194].toString();
	    p20_DSC_Paper_DrugList_DrugGroup_1 = provision20Template[0][195].toString();
	    p20_DSC_Paper_DrugList_1 = provision20Template[0][196].toString();
	    p20_DSC_Paper_Stepped_1 = provision20Template[0][197].toString();
	    p20_DSC_Paper_M_1 = provision20Template[0][198].toString();
	    p20_DSC_Paper_N_1 = provision20Template[0][199].toString();
	    p20_DSC_Paper_O_1 = provision20Template[0][200].toString();
	    p20_DSC_Paper_Y_1 = provision20Template[0][201].toString();
	    p20_DSC_Paper_PreferredGeneric_1 = provision20Template[0][202].toString();
	    p20_DSC_Paper_NonPreferredGeneric_1 = provision20Template[0][203].toString();
	    p20_DSC_Paper_PreferredBrand_1 = provision20Template[0][204].toString();
	    p20_DSC_Paper_NonPreferredBrand_1 = provision20Template[0][205].toString();
	    p20_DSC_Paper_DollarAmount_1 = provision20Template[0][206].toString();
	    p20_DSC_Paper_Percent_1 = provision20Template[0][207].toString();
	    P20_DSC_Paper_CopayCalculation_1 = provision20Template[0][208].toString();
	    P20_DSC_Paper_MinimumDollar_1 = provision20Template[0][209].toString();
	    P20_DSC_Paper_MaximumDollar_1 = provision20Template[0][210].toString();
	    P20_DSC_Paper_Reverse_1 = provision20Template[0][211].toString();

	    p20_DSC_PaperOoN_Notes_1 = provision20Template[0][213].toString();
	    p20_DSC_PaperOoN_Present_1 = provision20Template[0][214].toString();
	    p20_DSC_PaperOoN_DrugList_DrugGroup_1 = provision20Template[0][215].toString();
	    p20_DSC_PaperOoN_DrugList_1 = provision20Template[0][216].toString();
	    p20_DSC_PaperOoN_Stepped_1 = provision20Template[0][217].toString();
	    p20_DSC_PaperOoN_M_1 = provision20Template[0][218].toString();
	    p20_DSC_PaperOoN_N_1 = provision20Template[0][219].toString();
	    p20_DSC_PaperOoN_O_1 = provision20Template[0][220].toString();
	    p20_DSC_PaperOoN_Y_1 = provision20Template[0][221].toString();
	    p20_DSC_PaperOoN_PreferredGeneric_1 = provision20Template[0][222].toString();
	    p20_DSC_PaperOoN_NonPreferredGeneric_1 = provision20Template[0][223].toString();
	    p20_DSC_PaperOoN_PreferredBrand_1 = provision20Template[0][224].toString();
	    p20_DSC_PaperOoN_NonPreferredBrand_1 = provision20Template[0][225].toString();
	    p20_DSC_PaperOoN_DollarAmount_1 = provision20Template[0][226].toString();
	    p20_DSC_PaperOoN_Percent_1 = provision20Template[0][227].toString();
	    P20_DSC_PaperOoN_CopayCalculation_1 = provision20Template[0][228].toString();
	    P20_DSC_PaperOoN_MinimumDollar_1 = provision20Template[0][229].toString();
	    P20_DSC_PaperOoN_MaximumDollar_1 = provision20Template[0][230].toString();
	    P20_DSC_PaperOoN_Reverse_1 = provision20Template[0][231].toString();

	    p20_DSC_Mail_PaperOoN_Notes_1 = provision20Template[0][233].toString();
	    p20_DSC_Mail_PaperOoN_Present_1 = provision20Template[0][234].toString();
	    p20_DSC_Mail_PaperOoN_DrugList_DrugGroup_1 = provision20Template[0][235].toString();
	    p20_DSC_Mail_PaperOoN_DrugList_1 = provision20Template[0][236].toString();
	    p20_DSC_Mail_PaperOoN_Stepped_1 = provision20Template[0][237].toString();
	    p20_DSC_Mail_PaperOoN_M_1 = provision20Template[0][238].toString();
	    p20_DSC_Mail_PaperOoN_N_1 = provision20Template[0][239].toString();
	    p20_DSC_Mail_PaperOoN_O_1 = provision20Template[0][240].toString();
	    p20_DSC_Mail_PaperOoN_Y_1 = provision20Template[0][241].toString();
	    p20_DSC_Mail_PaperOoN_PreferredGeneric_1 = provision20Template[0][242].toString();
	    p20_DSC_Mail_PaperOoN_NonPreferredGeneric_1 = provision20Template[0][243].toString();
	    p20_DSC_Mail_PaperOoN_PreferredBrand_1 = provision20Template[0][244].toString();
	    p20_DSC_Mail_PaperOoN_NonPreferredBrand_1 = provision20Template[0][245].toString();
	    p20_DSC_Mail_PaperOoN_DollarAmount_1 = provision20Template[0][246].toString();
	    p20_DSC_Mail_PaperOoN_Percent_1 = provision20Template[0][247].toString();
	    P20_DSC_Mail_PaperOoN_CopayCalculation_1 = provision20Template[0][248].toString();
	    P20_DSC_Mail_PaperOoN_MinimumDollar_1 = provision20Template[0][249].toString();
	    P20_DSC_Mail_PaperOoN_MaximumDollar_1 = provision20Template[0][250].toString();
	    P20_DSC_Mail_PaperOoN_Reverse_1 = provision20Template[0][251].toString();

	    P20_Accum_Notes = provision20Template[0][253].toString();
	    P20_Accum_ArethereanydrugspecificMAB = provision20Template[0][254].toString();
	    P20_Accum_M = provision20Template[0][256].toString();
	    P20_Accum_O = provision20Template[0][257].toString();
	    P20_Accum_N = provision20Template[0][258].toString();
	    P20_Accum_Y = provision20Template[0][259].toString();
	    P20_Accum_Druglist = provision20Template[0][261].toString();
	    P20_Accum_DrugGroup = provision20Template[0][262].toString();
	    P20_Accum_MAB_Amount = provision20Template[0][264].toString();
	    P20_Accum_MAB_Period = provision20Template[0][265].toString();
	    P20_Accum_MAB_Met = provision20Template[0][266].toString();


	}



}

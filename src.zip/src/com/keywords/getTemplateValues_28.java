package com.keywords;
import org.testng.annotations.Test;

import com.FrameworkFunctions.GetReportValues;
import com.keywords.ValidateProvisionTemplate;

public class getTemplateValues_28 {
	public static String p28_WOD_Line_Value = "";
	public static String p28_WOD_Drug_Class = "";

	public static void validate_WOD() throws Exception {
	ValidateProvisionTemplate.validate_WOD_DrugClass("28",p28_WOD_Line_Value,p28_WOD_Drug_Class);
			
	}

	public static void getProvision28TemplateVlaues(Object[][] provision28Template)     {

	p28_WOD_Line_Value = provision28Template[0][1].toString();
	p28_WOD_Drug_Class = provision28Template[0][6].toString();


	}
}
